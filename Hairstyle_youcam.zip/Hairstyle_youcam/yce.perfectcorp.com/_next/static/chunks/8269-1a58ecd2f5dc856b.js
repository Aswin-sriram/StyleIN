(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8269],
  {
    35699: function (e, t, r) {
      "use strict";
      r.d(t, {
        Z: function () {
          return g;
        },
      });
      var n = r(27812),
        a = r(80481),
        o = r.n(a),
        i = r(67294),
        c = r(96026),
        u = r.n(c),
        s = r(1469),
        l = r.n(s),
        f = r(711),
        p = r.n(f),
        h = r(85893);
      function g(e) {
        var t = e.src,
          r = e.skeletonClass,
          a = e.imageClass,
          c = void 0 === a ? "" : a,
          s = e.alwaysShowLoading,
          f = e.transitionDisabled,
          g = e.onlyOneImage,
          d = void 0 !== g && g,
          m = e.onLoad,
          b = e.alt,
          v = void 0 === b ? "" : b,
          y = e.crossOrigin,
          x = void 0 === y ? "anonymous" : y,
          w = (0, i.useState)([null, null]),
          I = w[0],
          M = w[1],
          Z = (0, i.useState)([!1, !1]),
          S = Z[0],
          R = Z[1],
          F = (0, i.useState)(-1),
          k = F[0],
          E = F[1];
        (0, i.useEffect)(
          function () {
            if (t) {
              if (d) {
                O(0, !1), M([t]), E(0);
                return;
              }
              var e = (k + 1) % 2,
                r = (0, n.Z)(I);
              I[e] !== t ? O(e, !1) : O(e, !0), (r[e] = t), M(r), E(e);
            }
          },
          [t]
        );
        var O = function (e) {
          var t =
            !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
          R(function (r) {
            var a = (0, n.Z)(r);
            return (a[e] = t), a;
          });
        };
        return (0, h.jsxs)(h.Fragment, {
          children: [
            u()(d ? 1 : 2).map(function (e) {
              return (
                I[e] &&
                (0, h.jsx)(
                  "img",
                  {
                    loading: "lazy",
                    className: ""
                      .concat(l()(c) ? c[e] : c, " ")
                      .concat(o().image, " ")
                      .concat(
                        k !== e || s
                          ? f && p()(S)
                            ? o().fadeOutWithoutTransition
                            : o().fadeOut
                          : f && p()(S)
                          ? o().fadeInWithoutTransition
                          : o().fadeIn
                      ),
                    crossOrigin: x,
                    src: I[e],
                    onLoad: function () {
                      O(e), m && m();
                    },
                    draggable: !1,
                    alt: v,
                  },
                  e
                )
              );
            }),
            (0, h.jsx)("div", {
              className: ""
                .concat(o().skeleton, " ")
                .concat(void 0 === r ? "" : r, " ")
                .concat(
                  S[k] && !s ? o().skeletonHidden : "",
                  " shimmer-skeleton"
                ),
            }),
          ],
        });
      }
    },
    36175: function (e, t, r) {
      "use strict";
      r.d(t, {
        Z: function () {
          return R;
        },
      });
      var n = r(16835),
        a = r(59499),
        o = r(50029),
        i = r(87794),
        c = r.n(i),
        u = r(67294),
        s = r(84806),
        l = r(19161),
        f = r(54555),
        p = r(57291),
        h = r(13775),
        g = r(28953),
        d = r(32295),
        m = r(84338),
        b = r(27361),
        v = r.n(b),
        y = r(22762),
        x = r.n(y),
        w = r(66913),
        I = r.n(w);
      function M(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function Z(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? M(Object(r), !0).forEach(function (t) {
                (0, a.Z)(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : M(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      var S = {
        debug: !1,
        backend: "wasm",
        modelBasePath: "https://cdn.jsdelivr.net/npm/@vladmandic/human@".concat(
          "3.3.3",
          "/models/"
        ),
        filter: { enabled: !1 },
        face: {
          enabled: !0,
          detector: {
            rotation: !1,
            maxDetected: 20,
            minConfidence: 0.2,
            return: !1,
          },
          iris: { enabled: !1 },
          description: { enabled: !0 },
          emotion: { enabled: !1 },
          antispoof: { enabled: !1 },
          liveness: { enabled: !1 },
        },
        body: { enabled: !1 },
        hand: { enabled: !1 },
        object: { enabled: !1 },
        gesture: { enabled: !1 },
        segmentation: { enabled: !1 },
        async: !0,
        cacheModels: !1,
        softwareKernels: !0,
        warmup: "face",
        cacheSensitivity: 0,
      };
      function R() {
        var e,
          t,
          a,
          i,
          b,
          y,
          w,
          M,
          R,
          F =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          k = F.useWorker,
          E = void 0 !== k && k,
          O = (0, u.useState)(!1),
          P = O[0],
          B = O[1],
          T = (0, u.useState)(null),
          L = T[0],
          j = T[1],
          C = (0, u.useState)(null),
          D = C[0],
          A = C[1],
          U = (0, m.PC)().t,
          z = (0, s.Z)().isDev,
          _ = (0, u.useMemo)(
            function () {
              return (
                l.Z.isWorkerSupported() && l.Z.isOffscreenCanvasSupported() && E
              );
            },
            [E]
          );
        (0, u.useEffect)(function () {
          H();
        }, []),
          (0, u.useEffect)(
            function () {
              D && Y();
            },
            [D]
          );
        var H =
            ((e = (0, o.Z)(
              c().mark(function e() {
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (_) {
                          e.next = 6;
                          break;
                        }
                        return (
                          z && console.log("[Human] normal mode."),
                          (e.next = 4),
                          r
                            .e(1950)
                            .then(r.bind(r, 59279))
                            .then(
                              (function () {
                                var e = (0, o.Z)(
                                  c().mark(function e(t) {
                                    var r;
                                    return c().wrap(function (e) {
                                      for (;;)
                                        switch ((e.prev = e.next)) {
                                          case 0:
                                            return (
                                              (r = new t.default(S)),
                                              (e.next = 3),
                                              r.load().then(function () {
                                                r.warmup().then(function () {
                                                  j(r), B(!0);
                                                });
                                              })
                                            );
                                          case 3:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e);
                                  })
                                );
                                return function (t) {
                                  return e.apply(this, arguments);
                                };
                              })()
                            )
                        );
                      case 4:
                        e.next = 9;
                        break;
                      case 6:
                        z && console.log("[Human] worker mode."),
                          A(new Worker("/workers/human-worker.js"));
                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
          Y =
            ((t = (0, o.Z)(
              c().mark(function e() {
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        (D.onmessage = W), X("init", { humanConfig: S });
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          W = function (e) {
            "init" === e.data.type && "success" === e.data.status
              ? B(!0)
              : "detect" === e.data.type &&
                "success" === e.data.status &&
                d.ZP.trigger(d.Y7.human.detected, {
                  detections: e.data.detections,
                });
          },
          X = function (e, t) {
            D.postMessage(Z({ type: e }, t));
          },
          V = function (e) {
            if (D)
              return new Promise(function (t) {
                var r = f.Z.getImageData(e);
                d.ZP.once(d.Y7.human.detected, function (e) {
                  t(e.detail.detections);
                }),
                  X("detect", {
                    buffer: r.data.buffer,
                    width: r.width,
                    height: r.height,
                  });
              });
          },
          N =
            ((a = (0, o.Z)(
              c().mark(function e(t) {
                var r;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (((r = null), !(!_ || !D))) {
                          e.next = 7;
                          break;
                        }
                        return (e.next = 4), L.detect(t, {});
                      case 4:
                        (r = e.sent), (e.next = 13);
                        break;
                      case 7:
                        return (e.next = 9), V(t);
                      case 9:
                        if (((e.t0 = e.sent), e.t0)) {
                          e.next = 12;
                          break;
                        }
                        e.t0 = {};
                      case 12:
                        r = e.t0;
                      case 13:
                        return (
                          h.Z.addFaceSize(r),
                          h.Z.filterEmptyFaces(r),
                          h.Z.adjustDetectionSize(r, t.width, t.height),
                          e.abrupt("return", r)
                        );
                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return a.apply(this, arguments);
            }),
          q =
            ((i = (0, o.Z)(
              c().mark(function e(t) {
                var r, n, a, o, i, u, s, l, f;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (P) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (e.next = 4), N(t);
                      case 4:
                        if (0 !== (n = (r = e.sent).face).length) {
                          e.next = 8;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult(
                            U,
                            "avatar.face.detect.error.face",
                            h.w.noFace
                          )
                        );
                      case 8:
                        if (0 !== (a = n.filter(h.Z.isFaceScoreValid)).length) {
                          e.next = 13;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult(
                            U,
                            "avatar.face.detect.error.face",
                            h.w.noFace
                          )
                        );
                      case 13:
                        if (!(a.length > 1)) {
                          e.next = 15;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult(
                            U,
                            "avatar.face.detect.error.face.multiple",
                            h.w.multipleFaces
                          )
                        );
                      case 15:
                        return (
                          (o = a[0]),
                          (i = h.Z.calculateBoxPoints(o)),
                          (u = h.Z.calculateEyePoints(o)),
                          (s = h.Z.calculateFaceArea(o, r)),
                          (l = []),
                          (f = []),
                          h.Z.isFaceTooSmall(o, s) &&
                            (l.push(U("avatar.face.detect.error.face.area")),
                            f.push(h.w.faceTooSmall)),
                          e.abrupt("return", {
                            message: l,
                            boxPoints: i,
                            eyePoints: u,
                            type: f,
                          })
                        );
                      case 23:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return i.apply(this, arguments);
            }),
          Q =
            ((b = (0, o.Z)(
              c().mark(function e(t) {
                var r,
                  n,
                  a,
                  o,
                  i,
                  u,
                  s,
                  l,
                  f,
                  d,
                  m,
                  b,
                  y,
                  w,
                  I,
                  M,
                  S,
                  R,
                  F,
                  k,
                  E,
                  O,
                  B,
                  T = arguments;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((r = T.length > 1 && void 0 !== T[1] ? T[1] : {}), P)
                        ) {
                          e.next = 3;
                          break;
                        }
                        return e.abrupt("return");
                      case 3:
                        return (e.next = 5), N(t);
                      case 5:
                        if (
                          ((n = e.sent),
                          z && console.log("Face detections:", n),
                          (a = { width: t.width, height: t.height }),
                          (o = n.face),
                          (i = !1),
                          (u = g.ZP.getParsedItem(
                            g.XC.debug.hairStyle.forceEnter,
                            !1
                          )),
                          (l = (s = ee(t, n, { drawLabels: !0 }))
                            ? window.URL.createObjectURL(s)
                            : null),
                          (d = (f = o.reduce(
                            function (e, t) {
                              return (
                                h.Z.isFaceScoreValid(t)
                                  ? e.validFaceScore.push(t)
                                  : e.invalidFaceScore.push(t),
                                e
                              );
                            },
                            { validFaceScore: [], invalidFaceScore: [] }
                          )).validFaceScore),
                          (m = f.invalidFaceScore),
                          0 !== d.length)
                        ) {
                          e.next = 16;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4HairStyleMultiple(
                            U,
                            "hair.style.face.detect.error.face",
                            m,
                            u,
                            s,
                            l
                          )
                        );
                      case 16:
                        if (
                          ((y = (b = d.reduce(
                            function (e, t) {
                              return (
                                h.Z.isFaceWidthAndHeightValid(t, a)
                                  ? e.passFace.push(t)
                                  : e.rejectedFace.push(t),
                                e
                              );
                            },
                            { passFace: [], rejectedFace: [] }
                          )).passFace),
                          (w = b.rejectedFace),
                          0 !== y.length)
                        ) {
                          e.next = 19;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4HairStyleMultiple(
                            U,
                            "hair.style.face.detect.error.face.area",
                            w,
                            u,
                            s,
                            l
                          )
                        );
                      case 19:
                        if (!(null != r && r.singleFace && y.length > 1)) {
                          e.next = 21;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4HairStyleMultiple(
                            U,
                            "avatar.face.detect.error.face.multiple",
                            [],
                            u,
                            s,
                            l
                          )
                        );
                      case 21:
                        if (
                          ((I = []),
                          (M = y
                            .map(function (e) {
                              if (h.Z.isYawTooLarge(e))
                                return (
                                  I.push(
                                    U("hair.style.face.detect.error.face.yaw")
                                  ),
                                  w.push(e),
                                  null
                                );
                              var r = h.Z.calculateBoundingBox(e);
                              return p.Z.getScale(t, r);
                            })
                            .filter(function (e) {
                              return null !== e;
                            })),
                          (S = v()(x()(M, "scale"), "scale", 1)),
                          (R = 1 === o.length),
                          (F = w.map(function (e) {
                            var r = h.Z.calculateBoundingBox(e);
                            return Z(
                              Z(
                                {},
                                p.Z.getFaceInfosAndBlobForHairStyle(t, r, S, R)
                              ),
                              {},
                              {
                                gender: e.gender,
                                faceScore: e.faceScore,
                                boxScore: e.boxScore,
                              }
                            );
                          })),
                          (k = y
                            .map(function (e) {
                              if (h.Z.isYawTooLarge(e)) return null;
                              var r = h.Z.calculateBoundingBox(e);
                              return Z(
                                Z(
                                  {},
                                  p.Z.getFaceInfosAndBlobForHairStyle(
                                    t,
                                    r,
                                    S,
                                    R
                                  )
                                ),
                                {},
                                {
                                  gender: e.gender,
                                  faceScore: e.faceScore,
                                  boxScore: e.boxScore,
                                }
                              );
                            })
                            .filter(function (e) {
                              return null !== e;
                            })),
                          !g.ZP.getParsedItem(
                            g.XC.debug.hairStyle.cropImageOverlapCheck,
                            !1
                          ) ||
                            0 !==
                              (k = h.Z.removeCropImageOverlappingFaces(k))
                                .length)
                        ) {
                          e.next = 32;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4HairStyleMultiple(
                            U,
                            "hair.style.face.detect.error.face",
                            F,
                            u,
                            s,
                            l
                          )
                        );
                      case 32:
                        return (
                          (i = k.length > 0) &&
                            !u &&
                            ((O = (E = h.Z.removeFaceRectOverlappingFaces(
                              k,
                              F,
                              35
                            )).nonOverlappingFaces),
                            (B = E.nonOverlappingRejectedFaces),
                            0 === O.length
                              ? ((I = []).push(
                                  U("hair.style.face.detect.error.face.overlap")
                                ),
                                (i = !1))
                              : ((k = O), (F = B))),
                          k.sort(function (e, t) {
                            return 25 >
                              Math.abs(e.faceRect.top - t.faceRect.top)
                              ? e.faceRect.left - t.faceRect.left
                              : e.faceRect.top - t.faceRect.top;
                          }),
                          e.abrupt("return", {
                            faceInfos: k,
                            rejectedFaceInfos: F,
                            message: I,
                            goodFaceQuality: i,
                            forceEnter: u,
                            faceMeshBlob: s,
                            faceMeshBlobUrl: l,
                          })
                        );
                      case 36:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return b.apply(this, arguments);
            }),
          G =
            ((y = (0, o.Z)(
              c().mark(function e(t) {
                var r, n, a, o, i, u, s, l, f, g, d, m, b, v, y, x, w, I;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (P) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (r = []), (n = []), (e.next = 6), N(t);
                      case 6:
                        if (0 !== (a = e.sent.face).length) {
                          e.next = 10;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupSourceImage(
                            U,
                            "face.detect.error.no.face"
                          )
                        );
                      case 10:
                        if (0 !== (o = a.filter(h.Z.isFaceScoreValid)).length) {
                          e.next = 13;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupSourceImage(
                            U,
                            "face.detect.error.no.face"
                          )
                        );
                      case 13:
                        if (
                          0 !==
                          (i = o.filter(h.Z.isFaceAreaValid4Makeup)).length
                        ) {
                          e.next = 16;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupSourceImage(
                            U,
                            "face.detect.error.too.small"
                          )
                        );
                      case 16:
                        if (!(i.length > 1)) {
                          e.next = 18;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupSourceImage(
                            U,
                            "face.detect.error.multiple.face"
                          )
                        );
                      case 18:
                        if (
                          ((u = i[0]),
                          (s = h.Z.getEyePoints(u)),
                          (l = h.Z.getNosePoint(u)),
                          (f = h.Z.getMouthPoints(u)),
                          (g = u.rotation.angle),
                          (d = Math.abs(h.Z.radianToDegree(g.yaw))),
                          (m = Math.abs(h.Z.radianToDegree(g.pitch))),
                          !(d > 45 || m > 45))
                        ) {
                          e.next = 27;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupSourceImage(
                            U,
                            "face.detect.error.too.slanted"
                          )
                        );
                      case 27:
                        return (
                          (v = (b = h.Z.boundingBox(
                            u.mesh.map(function (e) {
                              return [e[0], e[1]];
                            })
                          )).minX),
                          (y = b.minY),
                          (x = b.maxX),
                          (w = b.maxY),
                          (I = p.Z.cropFaceForMakeup(t, s, [v, y, x, w])),
                          e.abrupt(
                            "return",
                            h.Z.generateSuccessResult(
                              Z(
                                Z({ titleMessage: r, message: n }, I),
                                {},
                                {
                                  faceInfo: {
                                    leftEye: I.avgEyePoints.left,
                                    rightEye: I.avgEyePoints.right,
                                    nose: l,
                                    leftLip: f.left,
                                    rightLip: f.right,
                                  },
                                  originalAngle: {
                                    yaw: h.Z.radianToDegree(g.yaw),
                                    pitch: h.Z.radianToDegree(g.pitch),
                                    roll: h.Z.radianToDegree(g.roll),
                                  },
                                }
                              )
                            )
                          )
                        );
                      case 30:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return y.apply(this, arguments);
            }),
          K =
            ((w = (0, o.Z)(
              c().mark(function e(t) {
                var r, a, o, i, u, s;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (P) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (e.next = 4), N(t);
                      case 4:
                        if (0 !== (r = e.sent.face).length) {
                          e.next = 8;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupReferenceImage(
                            U,
                            "face.detect.error.no.face"
                          )
                        );
                      case 8:
                        if (0 !== (a = r.filter(h.Z.isFaceScoreValid)).length) {
                          e.next = 11;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupReferenceImage(
                            U,
                            "face.detect.error.no.face"
                          )
                        );
                      case 11:
                        if (
                          0 !==
                          (o = a.filter(h.Z.isFaceAreaValid4Makeup)).length
                        ) {
                          e.next = 14;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4MakeupReferenceImage(
                            U,
                            "face.detect.error.too.small"
                          )
                        );
                      case 14:
                        return (
                          (i = []),
                          (u = []),
                          (s = o
                            .map(function (e) {
                              var r = h.Z.getEyePoints(e),
                                a = h.Z.getNosePoint(e),
                                o = h.Z.getMouthPoints(e),
                                c = e.rotation.angle,
                                s = Math.abs(h.Z.radianToDegree(c.yaw)),
                                l = Math.abs(h.Z.radianToDegree(c.pitch));
                              if (s > 45 || l > 45)
                                return (
                                  i.push(
                                    U("face.detect.error.too.slanted.title")
                                  ),
                                  u.push(
                                    U("face.detect.error.too.slanted.subtitle")
                                  ),
                                  null
                                );
                              var f = h.Z.boundingBox(
                                  e.mesh.map(function (e) {
                                    var t = (0, n.Z)(e, 2);
                                    return [t[0], t[1]];
                                  })
                                ),
                                g = f.minX,
                                d = f.minY,
                                m = f.maxX,
                                b = f.maxY,
                                v = p.Z.cropFaceForMakeup(t, r, [g, d, m, b]);
                              return Z(
                                Z({}, v),
                                {},
                                {
                                  faceInfo: {
                                    leftEye: v.avgEyePoints.left,
                                    rightEye: v.avgEyePoints.right,
                                    nose: a,
                                    leftLip: o.left,
                                    rightLip: o.right,
                                  },
                                  originalAngle: {
                                    yaw: h.Z.radianToDegree(c.yaw),
                                    pitch: h.Z.radianToDegree(c.pitch),
                                    roll: h.Z.radianToDegree(c.roll),
                                  },
                                }
                              );
                            })
                            .filter(function (e) {
                              return null !== e;
                            })),
                          e.abrupt("return", {
                            faceInfos: s,
                            titleMessage: i,
                            message: u,
                          })
                        );
                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return w.apply(this, arguments);
            }),
          $ =
            ((M = (0, o.Z)(
              c().mark(function e(t) {
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (P) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (e.next = 4), N(t);
                      case 4:
                        if (0 !== e.sent.face.length) {
                          e.next = 8;
                          break;
                        }
                        return e.abrupt("return", {
                          message: [U("hair.style.face.detect.error.face")],
                        });
                      case 8:
                        return e.abrupt("return", { message: [] });
                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return M.apply(this, arguments);
            }),
          J =
            ((R = (0, o.Z)(
              c().mark(function e(t) {
                var r, n, a, o, i, u, s, l, f, g, d, m, b, v;
                return c().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (P) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (e.next = 4), N(t);
                      case 4:
                        if (0 !== (n = (r = e.sent).face).length) {
                          e.next = 8;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4AiStudio(
                            U,
                            "avatar.face.detect.error.face"
                          )
                        );
                      case 8:
                        if (0 !== (a = n.filter(h.Z.isFaceScoreValid)).length) {
                          e.next = 13;
                          break;
                        }
                        return e.abrupt(
                          "return",
                          h.Z.generateErrorResult4AiStudio(
                            U,
                            "avatar.face.detect.error.face"
                          )
                        );
                      case 13:
                        if (!(a.length > 1)) {
                          e.next = 18;
                          break;
                        }
                        return (
                          (o = [U("avatar.face.detect.error.face.multiple")]),
                          (u = (i = ee(t, r))
                            ? window.URL.createObjectURL(i)
                            : null),
                          e.abrupt("return", {
                            message: o,
                            faceMeshBlob: i,
                            faceMeshBlobUrl: u,
                          })
                        );
                      case 18:
                        return (
                          (s = a[0]),
                          (l = p.Z.cropFaceForAiStudio(t, s)),
                          (g = (f = ee(t, r))
                            ? window.URL.createObjectURL(f)
                            : null),
                          (d = []),
                          (m = l.cropRect),
                          (b = l.faceRect),
                          h.Z.isFaceTooSmallForAiStudio(b) &&
                            d.push(U("ai.studio.face.detect.error.too.small")),
                          h.Z.isFaceTooCloseupForAiStudio(m, b) &&
                            d.push(
                              U("ai.studio.face.detect.error.too.closeup")
                            ),
                          (v = Z(
                            Z({ message: d }, l),
                            {},
                            { faceMeshBlob: f, faceMeshBlobUrl: g }
                          )),
                          z && console.log("Face detect result:", v),
                          e.abrupt("return", v)
                        );
                      case 29:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return R.apply(this, arguments);
            }),
          ee = function (e, t) {
            var r =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : {};
            if (!z) return null;
            var n = parseInt(
                Math.max(1, (4 * Math.max(e.width, e.height)) / 4096)
              ),
              a = I()(r, {
                lineWidth: 50,
                pointSize: n,
                drawPoints: !0,
                drawLabels: !1,
                drawBoxes: !1,
                drawGaze: !1,
              }),
              o = L.draw,
              i = t.face,
              c = document.createElement("canvas");
            (c.width = e.width),
              (c.height = e.height),
              c.getContext("2d").drawImage(e, 0, 0),
              o.face(c, i, a);
            var u = c.toDataURL();
            return f.Z.base64ToBlob(u);
          };
        return {
          modelsLoaded: P,
          detectFace: q,
          detectFace4HairStyleMultiple: Q,
          detectFace4MakeupSourceImage: G,
          detectFace4MakeupReferenceImage: K,
          detectFace4Text2Image2FaceSwap: $,
          detectFaceForAiStudio: J,
        };
      }
    },
    13775: function (e, t, r) {
      "use strict";
      r.d(t, {
        w: function () {
          return y;
        },
      });
      var n = r(59499),
        a = r(16835),
        o = r(57291),
        i = r(84486),
        c = r.n(i),
        u = r(27361),
        s = r.n(u),
        l = r(35161),
        f = r.n(l),
        p = r(63105),
        h = r.n(p);
      function g(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function d(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var m = ["leftEyeUpper0", "leftEyeLower0"],
        b = ["rightEyeUpper0", "rightEyeLower0"],
        v = [
          "lipsUpperOuter",
          "lipsUpperInner",
          "lipsUpperSemiInner",
          "lipsUpperSemiOuter",
          "lipsLowerOuter",
          "lipsLowerInner",
          "lipsLowerSemiInner",
          "lipsLowerSemiOuter",
        ],
        y = {
          noFace: "noFace",
          multipleFaces: "multipleFaces",
          faceTooSmall: "faceTooSmall",
        },
        x = {
          boundingBox: function (e) {
            var t,
              r = 1 / 0,
              n = 1 / 0,
              o = -1 / 0,
              i = -1 / 0,
              c = (function (e, t) {
                var r =
                  ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                  e["@@iterator"];
                if (!r) {
                  if (
                    Array.isArray(e) ||
                    (r = (function (e, t) {
                      if (e) {
                        if ("string" == typeof e) return d(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        if (
                          ("Object" === r &&
                            e.constructor &&
                            (r = e.constructor.name),
                          "Map" === r || "Set" === r)
                        )
                          return Array.from(e);
                        if (
                          "Arguments" === r ||
                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                        )
                          return d(e, t);
                      }
                    })(e))
                  ) {
                    r && (e = r);
                    var n = 0,
                      a = function () {};
                    return {
                      s: a,
                      n: function () {
                        return n >= e.length
                          ? { done: !0 }
                          : { done: !1, value: e[n++] };
                      },
                      e: function (e) {
                        throw e;
                      },
                      f: a,
                    };
                  }
                  throw TypeError(
                    "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                  );
                }
                var o,
                  i = !0,
                  c = !1;
                return {
                  s: function () {
                    r = r.call(e);
                  },
                  n: function () {
                    var e = r.next();
                    return (i = e.done), e;
                  },
                  e: function (e) {
                    (c = !0), (o = e);
                  },
                  f: function () {
                    try {
                      i || null == r.return || r.return();
                    } finally {
                      if (c) throw o;
                    }
                  },
                };
              })(e);
            try {
              for (c.s(); !(t = c.n()).done; ) {
                var u = (0, a.Z)(t.value, 2),
                  s = u[0],
                  l = u[1];
                s < r && (r = s),
                  l < n && (n = l),
                  s > o && (o = s),
                  l > i && (i = l);
              }
            } catch (f) {
              c.e(f);
            } finally {
              c.f();
            }
            return { minX: r, minY: n, maxX: o, maxY: i };
          },
          calculateBoxPoints: function (e) {
            var t = e.mesh.map(function (e) {
                var t = (0, a.Z)(e, 2);
                return [t[0], t[1]];
              }),
              r = x.boundingBox(t),
              n = r.minX,
              o = r.minY,
              i = r.maxX,
              c = r.maxY;
            return {
              topLeft: { x: n, y: o },
              topRight: { x: i, y: o },
              bottomLeft: { x: n, y: c },
              bottomRight: { x: i, y: c },
            };
          },
          calculateBoundingBox: function (e) {
            var t = e.mesh.map(function (e) {
                var t = (0, a.Z)(e, 2);
                return [t[0], t[1]];
              }),
              r = x.boundingBox(t),
              n = r.minX,
              o = r.minY,
              i = r.maxX;
            return { top: o, bottom: r.maxY, left: n, right: i };
          },
          radianToDegree: function (e) {
            return (180 * e) / Math.PI;
          },
          isYawTooLarge: function (e) {
            var t = e.rotation.angle,
              r = t.yaw,
              n = t.pitch,
              a = t.roll,
              o = Math.abs(x.radianToDegree(r)),
              i = Math.abs(x.radianToDegree(n)),
              c = Math.abs(x.radianToDegree(a));
            return o > 60 || i > 35 || c > 40;
          },
          calculateEyePoints: function (e) {
            return {
              left: m.flatMap(function (t) {
                return o.Z.getAnnotationPoints(e, t);
              }),
              right: b.flatMap(function (t) {
                return o.Z.getAnnotationPoints(e, t);
              }),
            };
          },
          calculateFaceArea: function (e, t) {
            return ((e.size[0] * e.size[1]) / (t.height * t.width)) * 100;
          },
          isFaceTooSmall: function (e, t) {
            return (e.size[0] <= 256 || e.size[1] <= 256) && t < 6.25;
          },
          isFaceTooSmallForAiStudio: function (e) {
            var t = e || {},
              r = t.left,
              n = t.top,
              a = t.right,
              o = t.bottom;
            return a - r <= 180 || o - n <= 180;
          },
          isFaceTooCloseupForAiStudio: function (e, t) {
            var r = e.left,
              n = e.top,
              a = e.right,
              o = e.bottom,
              i = t.left,
              c = t.top,
              u = t.right,
              s = t.bottom;
            return u - i > 0.8 * (a - r) || s - c > 0.8 * (o - n);
          },
          generateErrorResult: function (e, t, r) {
            return {
              message: [e(t)],
              type: [r],
              boxPoints: null,
              eyePoints: null,
            };
          },
          generateErrorResult4HairStyleMultiple: function (e, t, r, n, a, o) {
            return {
              faceInfos: [],
              rejectedFaceInfos: r || [],
              message: [e(t)],
              goodFaceQuality: !1,
              forceEnter: n || !1,
              faceMeshBlob: a,
              faceMeshBlobUrl: o,
            };
          },
          generateErrorResult4MakeupSourceImage: function (e, t) {
            return {
              titleMessage: [e("".concat(t, ".title"))],
              message: [e("".concat(t, ".subtitle"))],
              scale: null,
              cropRect: null,
              cropBlob: null,
              originalImage: null,
            };
          },
          generateErrorResult4MakeupReferenceImage: function (e, t) {
            return {
              faceInfos: [],
              titleMessage: [e("".concat(t, ".title"))],
              message: [e("".concat(t, ".subtitle"))],
            };
          },
          generateErrorResult4AiStudio: function (e, t) {
            return { message: [e(t)] };
          },
          isFaceAreaValid: function (e) {
            return e.size[0] * e.size[1] >= 16384;
          },
          isFaceWidthAndHeightValid: function (e, t) {
            var r = 0.125 * (t.width > 1024 ? 1024 : t.width),
              n = 0.125 * (t.height > 1024 ? 1024 : t.height),
              a = e.size[1] >= r,
              o = e.size[0] >= n;
            return a && o;
          },
          isFaceScoreValid: function (e) {
            return 1 === e.faceScore && e.boxScore > 0.3;
          },
          isFaceAreaValid4Makeup: function (e) {
            var t = e.mesh.map(function (e) {
                var t = (0, a.Z)(e, 2);
                return [t[0], t[1]];
              }),
              r = x.boundingBox(t),
              n = r.minX;
            return r.maxX - n >= 200;
          },
          getEyePoints: function (e) {
            return {
              left: m.flatMap(function (t) {
                return o.Z.getAnnotationPoints(e, t);
              }),
              right: b.flatMap(function (t) {
                return o.Z.getAnnotationPoints(e, t);
              }),
            };
          },
          getNosePoint: function (e) {
            return {
              x: e.annotations.noseTip[0][0],
              y: e.annotations.noseTip[0][1],
            };
          },
          getMouthPoints: function (e) {
            var t = v.flatMap(function (t) {
                return o.Z.getAnnotationPoints(e, t);
              }),
              r = o.Z.findLeftRightPoints(t);
            return { left: r.leftPoint, right: r.rightPoint };
          },
          generateSuccessResult: function (e) {
            return (function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? arguments[t] : {};
                t % 2
                  ? g(Object(r), !0).forEach(function (t) {
                      (0, n.Z)(e, t, r[t]);
                    })
                  : Object.getOwnPropertyDescriptors
                  ? Object.defineProperties(
                      e,
                      Object.getOwnPropertyDescriptors(r)
                    )
                  : g(Object(r)).forEach(function (t) {
                      Object.defineProperty(
                        e,
                        t,
                        Object.getOwnPropertyDescriptor(r, t)
                      );
                    });
              }
              return e;
            })({}, e);
          },
          removeCropImageOverlappingFaces: function (e) {
            for (var t = [], r = new Set(), n = 0; n < e.length; n++)
              for (var a = n + 1; a < e.length; a++)
                x.isCropImageOverlap(e[n].cropRect, e[a].cropRect) &&
                  (r.add(n), r.add(a));
            for (var o = 0; o < e.length; o++) r.has(o) || t.push(e[o]);
            return t;
          },
          isCropImageOverlap: function (e, t) {
            return (
              e.cropLeft < t.cropRight &&
              e.cropRight > t.cropLeft &&
              e.cropTop < t.cropBottom &&
              e.cropBottom > t.cropTop
            );
          },
          isFaceRectOverlap: function (e, t) {
            var r =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : 0;
            return (
              e.left < t.right + r &&
              e.right > t.left - r &&
              e.top < t.bottom + r &&
              e.bottom > t.top - r
            );
          },
          removeFaceRectOverlappingFaces: function (e, t, r) {
            for (var n = [], a = new Set(), o = 0; o < e.length; o++)
              for (var i = o + 1; i < e.length; i++)
                x.isFaceRectOverlap(e[o].faceRect, e[i].faceRect, r) &&
                  (a.add(o), a.add(i));
            e.forEach(function (e, n) {
              t.forEach(function (t) {
                x.isFaceRectOverlap(e.faceRect, t.faceRect, r) && a.add(n);
              });
            });
            for (var c = 0; c < e.length; c++)
              a.has(c) ? t.push(e[c]) : n.push(e[c]);
            return { nonOverlappingFaces: n, nonOverlappingRejectedFaces: t };
          },
          rescaleFaceRect: function (e, t) {
            var r = e.scale;
            c()(t, function (e, n) {
              t[n] = e * r;
            });
          },
          rescaleFaceRectForHairStyleMultiple: function (e) {
            c()(e, function (e) {
              var t = e.faceRect;
              x.rescaleFaceRect(e, t);
            });
          },
          minimizeScaleForHairStyleMultiple: function (e, t) {
            c()(e, function (e) {
              var r = e.scale,
                n = e.cropRect,
                a = e.faceRect,
                o = e.relativeRect;
              c()(n, function (e, a) {
                n[a] = (t * e) / r;
              }),
                c()(a, function (e, n) {
                  a[n] = (t * e) / r;
                }),
                c()(o, function (e, n) {
                  o[n] = (t * e) / r;
                }),
                (e.scale = t);
            });
          },
          minimizeScaleForHairStyleMultipleRejectedFace: function (e, t) {
            c()(e, function (e) {
              var r = e.scale,
                n = e.cropRect,
                a = e.faceRect;
              c()(n, function (e, a) {
                n[a] = (t * e) / r;
              }),
                c()(a, function (e, n) {
                  a[n] = (t * e) / r;
                }),
                (e.scale = t);
            });
          },
          addFaceSize: function (e) {
            var t, r;
            c()(s()(e, "face"), function (e) {
              e.size || (e.size = [s()(e, "box.2", 0), s()(e, "box.3", 0)]);
            }),
              (e.width =
                (null == e
                  ? void 0
                  : null === (t = e.canvas) || void 0 === t
                  ? void 0
                  : t.width) || 0),
              (e.height =
                (null == e
                  ? void 0
                  : null === (r = e.canvas) || void 0 === r
                  ? void 0
                  : r.height) || 0);
          },
          filterEmptyFaces: function (e) {
            e.face = h()(e.face, function (e) {
              var t = (0, a.Z)(e.size, 2),
                r = t[0],
                n = t[1];
              return 0 !== r && 0 !== n;
            });
          },
          adjustDetectionSize: function (e, t, r) {
            var n,
              a,
              o =
                (null == e
                  ? void 0
                  : null === (n = e.canvas) || void 0 === n
                  ? void 0
                  : n.width) || 0,
              i =
                (null == e
                  ? void 0
                  : null === (a = e.canvas) || void 0 === a
                  ? void 0
                  : a.height) || 0;
            if (0 !== o && 0 !== i && (!(t <= o) || !(r <= i))) {
              var u = t / o;
              (e.width *= u),
                (e.height *= u),
                c()(e.face, function (e) {
                  c()(["box", "size"], function (t) {
                    e[t] = f()(e[t], function (e) {
                      return e * u;
                    });
                  }),
                    c()(["mesh"], function (t) {
                      e[t] = f()(e[t], function (e) {
                        return f()(e, function (e) {
                          return e * u;
                        });
                      });
                    }),
                    c()(["annotations"], function (t) {
                      c()(e[t], function (r, n) {
                        e[t][n] = f()(e[t][n], function (e) {
                          return f()(e, function (e) {
                            return e * u;
                          });
                        });
                      });
                    });
                });
            }
          },
        };
      t.Z = x;
    },
    57291: function (e, t, r) {
      "use strict";
      var n = r(54555),
        a = r(13775),
        o = r(27361),
        i = r.n(o),
        c = r(73303),
        u = r.n(c),
        s = r(84238),
        l = r.n(s);
      r(35161);
      var f = r(20328),
        p = r.n(f),
        h = r(84486),
        g = r.n(h),
        d = {
          cropFaceForAvatar: function (e, t) {
            var r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 5.5,
              n =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 1,
              a = d.getSmartCropBbox(e, t, r, n);
            return d.drawSquareCropImage(e, a);
          },
          getSmartCropBbox: function (e, t) {
            var r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 5.5,
              n =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 1,
              a = e.width,
              o = e.height,
              i = parseInt(a * n),
              c = parseInt(o * n),
              u = d.getEyePointsInfo(t, n),
              s = u.eyeCenter,
              l = Math.min(parseInt(u.eyeDistance * r), i, c),
              f = Math.max(s.x - l / 2, 0),
              p = s.x + l / 2;
            (f = p > i ? parseInt(f - (p - i)) : f), (p = Math.min(p, i));
            var h = Math.max(s.y - 0.4 * l, 0),
              g = Math.min(s.y + 0.6 * l, c);
            return {
              cropLeft: f,
              cropRight: p,
              cropTop: (h = g > c ? parseInt(h - (g - c)) : h),
              cropBottom: (g = Math.min(g, c)),
            };
          },
          drawSquareCropImage: function (e, t) {
            var r = t.cropLeft,
              a = t.cropRight,
              o = t.cropTop,
              i = t.cropBottom,
              c = document.createElement("canvas");
            (c.width = 512), (c.height = 512);
            var u = c.getContext("2d"),
              s = Math.min(a - r, i - o),
              l = parseInt((a + r - s) / 2),
              f = parseInt((i + o - s) / 2);
            u.drawImage(e, l, f, s, s, 0, 0, 512, 512);
            var p = c.toDataURL();
            return n.Z.base64ToBlob(p);
          },
          getEyePointsInfo: function (e, t) {
            var r = e || {},
              n = r.left,
              a = r.right,
              o = {
                left: {
                  x:
                    (t *
                      u()(n, function (e) {
                        return e.x;
                      })) /
                    l()(n),
                  y:
                    (t *
                      u()(n, function (e) {
                        return e.y;
                      })) /
                    l()(n),
                },
                right: {
                  x:
                    (t *
                      u()(a, function (e) {
                        return e.x;
                      })) /
                    l()(a),
                  y:
                    (t *
                      u()(a, function (e) {
                        return e.y;
                      })) /
                    l()(a),
                },
              },
              c = {
                x: parseInt((i()(o, "left.x", 0) + i()(o, "right.x", 0)) / 2),
                y: parseInt((i()(o, "left.y", 0) + i()(o, "right.y", 0)) / 2),
              },
              s = Math.pow(
                Math.pow(i()(o, "left.x", 0) - i()(o, "right.x", 0), 2) +
                  Math.pow(i()(o, "left.y", 0) - i()(o, "right.y", 0), 2),
                0.5
              );
            return { avgEyePoints: o, eyeCenter: c, eyeDistance: s };
          },
          cropRect: function (e) {
            var t = e.width,
              r = e.height,
              n = Math.min(t, r),
              a = Math.max(parseInt((t - n) / 2), 0),
              o = Math.min(parseInt((t + n) / 2), t),
              i = Math.max(parseInt((r - n) / 2), 0),
              c = Math.min(parseInt((r + n) / 2), r);
            return d.drawSquareCropImage(e, {
              cropLeft: a,
              cropRight: o,
              cropTop: i,
              cropBottom: c,
            });
          },
          cropFaceForHairStyle: function (e, t) {
            var r = e.width,
              n = e.height,
              a = t.top,
              o = t.bottom,
              i = t.left,
              c = t.right,
              u = (c + i) / 2,
              s = (o + a) / 2,
              l = Math.max(c - i, o - a),
              f = Math.max(parseInt(u - 1.75 * l), 0),
              p = Math.min(parseInt(u + 1.75 * l), r),
              h = Math.max(parseInt(s - 1.5 * l), 0),
              g = Math.min(parseInt(s + 2.75 * l), n),
              m = p - f,
              b = g - h,
              v = Math.max(m, b),
              y = v > 1024 ? 1024 / v : 1,
              x = d.drawScaleCropImage(
                e,
                { cropLeft: f, cropRight: p, cropTop: h, cropBottom: g },
                y
              );
            return {
              scale: y,
              cropRect: {
                cropLeft: f * y,
                cropRight: p * y,
                cropTop: h * y,
                cropBottom: g * y,
              },
              cropBlob: x,
              originalImage: { width: r, height: n },
              relativeRect: {
                top: Math.max((a - h) * y, 0),
                bottom: Math.min((o - h) * y, b * y),
                left: Math.max((i - f) * y, 0),
                right: Math.min((c - f) * y, m * y),
              },
              faceRect: t,
            };
          },
          getScale: function (e, t) {
            var r = e.width,
              n = e.height,
              a = t.top,
              o = t.bottom,
              i = t.left,
              c = t.right,
              u = (c + i) / 2,
              s = (o + a) / 2,
              l = Math.max(c - i, o - a),
              f = Math.max(parseInt(u - 1.75 * l), 0),
              p = Math.min(parseInt(u + 1.75 * l), r),
              h = Math.max(parseInt(s - 1.5 * l), 0),
              g = Math.max(p - f, Math.min(parseInt(s + 2.75 * l), n) - h);
            return { scale: g > 1024 ? 1024 / g : 1 };
          },
          getFaceInfosAndBlobForHairStyle: function (e, t, r) {
            var n =
                arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              a = e.width,
              o = e.height,
              i = t.top,
              c = t.bottom,
              u = t.left,
              s = t.right,
              l = function (t, r, n, l, f) {
                var p = d.drawScaleCropImage(
                  e,
                  { cropLeft: t, cropRight: r, cropTop: n, cropBottom: l },
                  f
                );
                return {
                  scale: f,
                  cropRect: {
                    cropLeft: t * f,
                    cropRight: r * f,
                    cropTop: n * f,
                    cropBottom: l * f,
                  },
                  cropBlob: p,
                  cropBlobUrl: window.URL.createObjectURL(p),
                  originalImage: { width: a, height: o },
                  relativeRect: {
                    top: Math.max((i - n) * f, 0),
                    bottom: Math.min((c - n) * f, (l - n) * f),
                    left: Math.max((u - t) * f, 0),
                    right: Math.min((s - t) * f, (r - t) * f),
                  },
                  faceRect: {
                    top: i * f,
                    bottom: c * f,
                    left: u * f,
                    right: s * f,
                  },
                };
              };
            if (n) {
              var f = (s + u) / 2,
                p = (c + i) / 2,
                h = Math.max(s - u, c - i);
              return l(
                Math.max(parseInt(f - 1.75 * h), 0),
                Math.min(parseInt(f + 1.75 * h), a),
                Math.max(parseInt(p - 1.5 * h), 0),
                Math.min(parseInt(p + 2.75 * h), o),
                r
              );
            }
            var g = Math.max(a, o);
            return l(0, a, 0, o, g > 1024 ? 1024 / g : r);
          },
          drawScaleCropImage: function (e, t) {
            var r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 1,
              a = t.cropLeft,
              o = t.cropRight,
              i = t.cropTop,
              c = t.cropBottom,
              u = document.createElement("canvas"),
              s = Math.floor(o - a),
              l = Math.floor(c - i);
            (u.width = Math.floor(s * r)),
              (u.height = Math.floor(l * r)),
              u
                .getContext("2d")
                .drawImage(e, a, i, s, l, 0, 0, u.width, u.height);
            var f = u.toDataURL("image/jpeg");
            return n.Z.base64ToBlob(f);
          },
          getAnnotationPoints: function (e, t) {
            if (e && t && e.annotations && e.annotations[t])
              return e.annotations[t].map(function (e) {
                return { x: e[0], y: e[1] };
              });
          },
          findLeftRightPoints: function (e) {
            var t = { x: e[0].x, y: e[0].y },
              r = { x: e[0].x, y: e[0].y };
            return (
              e.forEach(function (e) {
                e.x < t.x && ((t.x = e.x), (t.y = e.y)),
                  e.x > r.x && ((r.x = e.x), (r.y = e.y));
              }),
              { leftPoint: t, rightPoint: r }
            );
          },
          cropFaceForMakeup: function (e, t, r) {
            var n =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 1,
              a =
                arguments.length > 4 && void 0 !== arguments[4]
                  ? arguments[4]
                  : 3.5,
              o =
                arguments.length > 5 && void 0 !== arguments[5]
                  ? arguments[5]
                  : 3.5,
              i = !1,
              c = e.width,
              u = e.height,
              s = parseInt(u * n),
              l = parseInt(c * n),
              f = r.map(function (e) {
                return e * n;
              }),
              p = d.getEyePointsInfo(t, n),
              h = p.avgEyePoints,
              g = p.eyeCenter,
              m = p.eyeDistance,
              b = parseInt(m * a),
              v = parseInt(m * o);
            (b = b < l ? b : l), (v = v < s ? v : s);
            var y = g.x - b / 2,
              x = g.x + b / 2;
            y < 0 && x > l && (i = !0),
              (y = y < 0 ? 0 : y),
              (y = x > l ? parseInt(y - (x - l)) : parseInt(y));
            var w = g.y - 0.4 * v,
              I = g.y + (v - 0.4 * v);
            w < 0 && I > s && (i = !0),
              (w = w < 0 ? 0 : w),
              (w = I > s ? parseInt(w - (I - s)) : parseInt(w));
            var M = {
                cropLeft: f[0] - y,
                cropTop: f[1] - w,
                cropRight: f[2] - y,
                cropBottom: f[3] - w,
              },
              Z = Math.max(M.cropRight - M.cropLeft, M.cropBottom - M.cropTop),
              S = Z > 1024 ? 1024 / Z : 1,
              R = d.drawScaleCropImage(
                e,
                {
                  cropLeft: y,
                  cropRight: y + b,
                  cropTop: w,
                  cropBottom: w + v,
                },
                S
              );
            return {
              scale: S,
              cropRect: {
                cropLeft: y * S,
                cropRight: (y + b) * S,
                cropTop: w * S,
                cropBottom: (w + v) * S,
              },
              smartCropBbox: M,
              smartCropBboxError: i,
              cropBlob: R,
              originalImage: { width: c, height: u },
              avgEyePoints: h,
            };
          },
          cropFaceForAiStudio: function (e, t) {
            var r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 1,
              n =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : 4,
              o =
                arguments.length > 4 && void 0 !== arguments[4]
                  ? arguments[4]
                  : 4.5,
              c = a.Z.calculateBoundingBox(t),
              u = d.shallowScaleObject(c, r),
              s = a.Z.getEyePoints(t),
              l = d.getEyePointsInfo(s, r),
              f = (l.avgEyePoints, l.eyeCenter),
              p = l.eyeDistance,
              h = e.width,
              g = e.height,
              m = h * r,
              b = g * r,
              v = parseInt(Math.min(p * n, m)),
              y = parseInt(Math.min(p * o, b)),
              x = parseInt(Math.max(f.x - v / 2, 0)),
              w = parseInt(Math.min(x + v, m));
            w - x < v && (x = parseInt(Math.max(w - v, 0)));
            var I = parseInt(Math.max(f.y - 0.4 * y, 0)),
              M = parseInt(Math.min(I + y, b));
            M - I < y && (I = parseInt(Math.max(M - y, 0)));
            var Z = Math.min(786 / Math.min(w - x, M - I), 1),
              S = {
                left: parseInt(x * Z),
                top: parseInt(I * Z),
                right: parseInt(w * Z),
                bottom: parseInt(M * Z),
              },
              R = {
                left: parseInt(u.left * Z),
                top: parseInt(u.top * Z),
                right: parseInt(u.right * Z),
                bottom: parseInt(u.bottom * Z),
              },
              F = {
                left: parseInt(R.left - S.left),
                top: parseInt(R.top - S.top),
                right: parseInt(R.right - S.left),
                bottom: parseInt(R.bottom - S.top),
              },
              k = d.drawScaledImageForAiStudio(e, r, Z, S),
              E = k.scaledBlob,
              O = k.cropBlob,
              P = i()(t, "rotation.angle", {}),
              B = {
                yaw: a.Z.radianToDegree(P.yaw),
                pitch: a.Z.radianToDegree(P.pitch),
                roll: a.Z.radianToDegree(P.roll),
              };
            return {
              cropRect: S,
              faceRect: R,
              relativeRect: F,
              cropBlob: O,
              cropBlobUrl: window.URL.createObjectURL(O),
              blob: E,
              blobUrl: window.URL.createObjectURL(E),
              scale: r * Z,
              imageWidth: m * Z,
              imageHeight: b * Z,
              headPose: B,
            };
          },
          drawScaledImageForAiStudio: function (e, t, r, a) {
            var o = e.width,
              i = e.height,
              c = t * r,
              u = document.createElement("canvas");
            (u.width = o * c),
              (u.height = i * c),
              u.getContext("2d").drawImage(e, 0, 0, u.width, u.height);
            var s = u.toDataURL(),
              l = a.left,
              f = a.top,
              p = a.right,
              h = a.bottom,
              g = p - l,
              d = h - f,
              m = document.createElement("canvas");
            (m.width = g),
              (m.height = d),
              m
                .getContext("2d")
                .drawImage(u, l, f, g, d, 0, 0, m.width, m.height);
            var b = m.toDataURL();
            return {
              scaledBlob: n.Z.base64ToBlob(s),
              cropBlob: n.Z.base64ToBlob(b),
            };
          },
          shallowScaleObject: function (e, t) {
            var r = {};
            return (
              g()(e, function (e, n) {
                p()(e) ? (r[n] = e * t) : (r[n] = e);
              }),
              r
            );
          },
        };
      t.Z = d;
    },
    80481: function (e) {
      e.exports = {
        image: "image-lazy-load_image__uCL3_",
        fadeIn: "image-lazy-load_fadeIn__H_IZW",
        fadeInWithoutTransition:
          "image-lazy-load_fadeInWithoutTransition__sQ1IA",
        fadeOut: "image-lazy-load_fadeOut__UC5d6",
        fadeOutWithoutTransition:
          "image-lazy-load_fadeOutWithoutTransition__ojk9M",
        skeleton: "image-lazy-load_skeleton__yW7tq",
        skeletonHidden: "image-lazy-load_skeletonHidden__vdyYt",
      };
    },
  },
]);
