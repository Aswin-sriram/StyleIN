(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6331],
  {
    9982: function (e, t, n) {
      var a = {
        "./ar.js": [56288, 6288],
        "./bg.js": [76219, 6219],
        "./ca.js": [20877, 877],
        "./cs.js": [92378, 2378],
        "./da.js": [44619, 4619],
        "./de.js": [3434, 3434],
        "./el.js": [47680, 7680],
        "./en.js": [90232, 232],
        "./es.js": [31664, 1664],
        "./fi.js": [61811, 1811],
        "./fr.js": [3653, 3653],
        "./hr.js": [42081, 2081],
        "./hu.js": [92007, 2007],
        "./id.js": [15717, 5717],
        "./it.js": [13082, 3082],
        "./ja.js": [3306, 3306],
        "./ko.js": [8010, 8010],
        "./nl.js": [37190, 7190],
        "./pl.js": [65569, 5569],
        "./pt-BR.js": [96600, 6600],
        "./pt.js": [90821, 821],
        "./ro.js": [83275, 3275],
        "./ru.js": [51402, 1402],
        "./si.js": [72480, 2480],
        "./sk.js": [80170, 170],
        "./sv.js": [20291, 291],
        "./th.js": [88714, 8714],
        "./tr.js": [14202, 6269],
        "./uk.js": [7257, 7257],
        "./zh.js": [84881, 4881],
      };
      function i(e) {
        if (!n.o(a, e))
          return Promise.resolve().then(function () {
            var t = Error("Cannot find module '" + e + "'");
            throw ((t.code = "MODULE_NOT_FOUND"), t);
          });
        var t = a[e],
          i = t[0];
        return n.e(t[1]).then(function () {
          return n(i);
        });
      }
      (i.keys = function () {
        return Object.keys(a);
      }),
        (i.id = 9982),
        (e.exports = i);
    },
    89122: function (e, t) {
      "use strict";
      t.Z = {
        styleSelection: "style-selection",
        uploadGuideline: "upload-guideline",
        photoSelection: "photo-selection",
      };
    },
    79325: function (e, t, n) {
      "use strict";
      var a = n(1955);
      t.Z = (0, a.Z)(function () {
        return Promise.all([n.e(3213), n.e(7374)]).then(n.bind(n, 33213));
      });
    },
    1955: function (e, t, n) {
      "use strict";
      n(67294);
      var a = n(68356),
        i = n.n(a),
        r = n(85893),
        c = function () {
          return (0, r.jsx)("div", {});
        };
      t.Z = function (e) {
        return i()({ loader: e, loading: c });
      };
    },
    68524: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return nO;
        },
      });
      var a,
        i,
        r,
        c = n(50029),
        o = n(59499),
        s = n(87794),
        l = n.n(s),
        u = n(4098),
        d = n.n(u),
        p = n(97221),
        m = n(79325),
        h = n(84338),
        _ = n(67294),
        f = n(9473),
        x = n(43263),
        v = n(11163),
        g = n(4730),
        y = n(70894),
        k = n.n(y),
        b = n(64721),
        j = n.n(b),
        w = n(31170),
        C = n(15613),
        N = n(63482),
        D = n(96453),
        S = ["upgrade", "subscribe", "pay", "groupId"],
        T = n(99404),
        A = n(84238),
        I = n.n(A),
        R = n(23493),
        E = n.n(R),
        P = n(92792),
        Z = n(27812),
        O = n(96173),
        M = n.n(O),
        B = n(35045),
        H = n.n(B),
        F = n(41609),
        L = n.n(F),
        K = n(27361),
        V = n.n(K),
        z = n(14293),
        G = n.n(z),
        U = n(30381),
        q = n.n(U),
        W = n(17268),
        Q = n(42320),
        X = n(93539),
        J = n(65234),
        Y = n(18401),
        $ = n(45395),
        ee = n(95857),
        et = n(29040),
        en = n(77030),
        ea = n.n(en),
        ei = n(18224),
        er = n(85893),
        ec = function (e) {
          var t = e.user,
            n = e.accType,
            a = e.isAppleAccountWithoutDisplayName,
            i = e.showAccName,
            r = e.emailForm,
            c = e.iconSize,
            o = e.marginRight,
            s = e.alignCenter,
            l = (0, h.PC)().t,
            u = (0, ei.Z)().isDesktop,
            d = r ? ea().userNameInAccount : ea().userNameInSettings;
          return (0, er.jsxs)("div", {
            className: void 0 !== s && s ? ea().flexLAlignCenter : ea().flexL,
            children: [
              (0, er.jsx)("img", {
                className:
                  "large" === (void 0 === o ? "small" : o)
                    ? ea().accIconMarginRightLarge
                    : "large" === (void 0 === c ? "small" : c) && u
                    ? ea().accIconLarge
                    : ea().accIcon,
                src: n.includes("Google")
                  ? "/assets/images/account/settings/sml-google-logo.png"
                  : n.includes("Facebook")
                  ? "/assets/images/account/settings/sml_round_facebook_logo.png"
                  : n.includes("Apple")
                  ? "/assets/images/account/settings/sml-apple-logo.png"
                  : "/assets/images/account/settings/email_logo.png",
              }),
              (0, er.jsxs)("div", {
                children: [
                  (void 0 === i || i) &&
                    (0, er.jsx)("div", {
                      className: ea().accName,
                      children: l(
                        n.includes("Google")
                          ? "my.account.me.google.account"
                          : n.includes("Facebook")
                          ? "my.account.me.facebook.account"
                          : n.includes("Apple")
                          ? "my.account.me.apple.account"
                          : "my.account.me.email.account"
                      ),
                    }),
                  !!t.name &&
                    (0, er.jsx)("div", { className: d, children: t.name }),
                  a() &&
                    (0, er.jsx)("div", {
                      className: ea().email,
                      style: { marginLeft: 0, lineHeight: "21px" },
                      children: t.email,
                    }),
                  r,
                ],
              }),
            ],
          });
        };
      function eo(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t &&
            (a = a.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function es(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? eo(Object(n), !0).forEach(function (t) {
                (0, o.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : eo(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var el = {
        date: "date",
        description: "description",
        credits: "credits",
        "sub.credit.balance": "sub.credit.balance",
        "pay.as.you.go.balance": "pay.as.you.go.balance",
      };
      function eu(e) {
        var t,
          n = e.reGetSubData,
          a = (0, h.PC)(),
          i = a.t,
          r = a.locale,
          o = (0, P.Z)(),
          s = (0, _.useRef)(null),
          u = (0, _.useRef)(null),
          d = (0, _.useRef)(null),
          p = (0, _.useRef)(null),
          m = (0, _.useRef)(null),
          x = (0, _.useRef)(null),
          v = (0, _.useRef)(null),
          g = (0, _.useRef)([]),
          y = (0, _.useRef)(null),
          k = (0, f.v9)(function (e) {
            return e.api;
          }),
          b = (0, f.v9)(function (e) {
            return e.user.checked;
          }),
          j = (0, f.v9)(function (e) {
            return e.user.subscriptionExpiry;
          }),
          w = (0, f.v9)(function (e) {
            return e.user.token;
          }),
          C = w.remain,
          D = w.history,
          S = w.seq,
          T = w.systemTimeStamp,
          A = (0, _.useMemo)(
            function () {
              return new Date(T);
            },
            [T]
          ),
          I = (0, f.v9)(function (e) {
            return e.user.userInfo;
          }),
          R =
            (0, f.v9)(function (e) {
              return e.info;
            }).accType || "",
          E = (0, _.useMemo)(
            function () {
              var e = new Date(T);
              return e.setDate(e.getDate() + 185), e;
            },
            [T]
          ),
          O = (0, _.useMemo)(
            function () {
              var e = new Date(T);
              return e.setDate(e.getDate() + 30), e;
            },
            [T]
          ),
          B = (0, f.I0)(),
          F = function (e) {
            var t = new Date(e);
            return t.setDate(t.getDate() + 7), t;
          },
          K = F(j),
          z = (0, X.Z)(!1).getSubData,
          U = (0, _.useMemo)(
            function () {
              if (b) return z();
            },
            [b, n, z]
          ),
          en = (0, _.useMemo)(
            function () {
              return null == U ? void 0 : U.isValid;
            },
            [U]
          ),
          ea = (0, _.useMemo)(
            function () {
              return null == U ? void 0 : U.subData;
            },
            [U]
          ),
          ei = (0, _.useMemo)(
            function () {
              return V()(ea, "productDetail.info.customInfo.tokenInfo.amount");
            },
            [ea]
          ),
          eo = (0, _.useMemo)(
            function () {
              return V()(
                ea,
                "productDetail.info.customInfo.tokenInfo.cycleAmt"
              );
            },
            [ea]
          ),
          eu = (0, _.useMemo)(
            function () {
              return V()(ea, "status");
            },
            [ea]
          ),
          ed =
            en &&
            i("my.account.subscription.due.date", {
              planName: ""
                .concat(ei, " ")
                .concat(i("pricing.credit.plan.credits.mo")),
              dueDate: q()(K).format(
                i("my.account.subscription.due.date.format")
              ),
            }),
          ep = (0, _.useState)({}),
          em = ep[0],
          eh = ep[1],
          e_ = (0, _.useState)({}),
          ef = e_[0],
          ex = e_[1],
          ev = (0, _.useState)(0),
          eg = ev[0],
          ey = ev[1],
          ek = (0, _.useState)(0),
          eb = ek[0],
          ej = ek[1],
          ew = (0, _.useState)(0),
          eC = ew[0],
          eN = ew[1],
          eD = (0, _.useState)([]),
          eS = eD[0],
          eT = eD[1],
          eA = (0, _.useState)({
            expiredData4Subs: !1,
            expiredData4PayAsYouGo: !1,
            isSuperlative: !0,
          }),
          eI = eA[0],
          eR = eA[1];
        (0, J.Z)(eo, eT, !0);
        var eE = (0, _.useMemo)(
            function () {
              return L()(em);
            },
            [em]
          ),
          eP = (0, _.useMemo)(
            function () {
              return (
                !eE &&
                en &&
                (null == em ? void 0 : em.amount) !== 0 &&
                (null == em ? void 0 : em.expiry) &&
                new Date(em.expiry).getTime() - A.getTime() <= 2592e6
              );
            },
            [null == em ? void 0 : em.amount, em.expiry, en, eE, A]
          ),
          eZ = (0, _.useMemo)(
            function () {
              return L()(ef);
            },
            [ef]
          ),
          eO = (0, _.useMemo)(
            function () {
              return (
                !eZ &&
                (null == ef ? void 0 : ef.amount) !== 0 &&
                (null == ef ? void 0 : ef.expiry) &&
                new Date(ef.expiry).getTime() - A.getTime() <= 2592e6
              );
            },
            [null == ef ? void 0 : ef.amount, ef.expiry, eZ, A]
          );
        (0, _.useEffect)(
          function () {
            if (null != k && k.initOK && null != k && k.authOK)
              return (
                eM(),
                function () {
                  B((0, N.my)(""));
                }
              );
          },
          [null == k ? void 0 : k.initOK, null == k ? void 0 : k.authOK]
        );
        var eM =
          ((t = (0, c.Z)(
            l().mark(function e() {
              return l().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (e.next = 2), B((0, N.Io)());
                    case 2:
                      B((0, N.LP)());
                    case 3:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          )),
          function () {
            return t.apply(this, arguments);
          });
        (0, _.useEffect)(
          function () {
            null != k && k.initOK && null != k && k.authOK && B((0, N.OZ)());
          },
          [null == k ? void 0 : k.initOK, null == k ? void 0 : k.authOK, S]
        ),
          (0, _.useEffect)(
            function () {
              var e = Y.Z.calculateCredits(C, A);
              eN(e.payAsYouGoCredits),
                ey(e.allSubscriptionCredits),
                ej(e.lastSubscriptionCredits);
            },
            [C, A]
          ),
          (0, _.useEffect)(
            function () {
              if (b) {
                if (
                  (eu === Q.L.CANCEL_SUB && E > j) ||
                  eu === Q.L.PAST_DUE_SUB
                ) {
                  eh({ expiry: F(j), amount: eb }),
                    eR(function (e) {
                      return es(es({}, e), {}, { expiredData4Subs: !0 });
                    });
                  return;
                }
                eh(Y.Z.calculateExpiredData(C, et.kW.ENH_SUB_TKN, A, O)),
                  eR(function (e) {
                    return es(es({}, e), {}, { expiredData4Subs: !0 });
                  });
              }
            },
            [eu, C, b]
          ),
          (0, _.useEffect)(
            function () {
              b &&
                (ex(Y.Z.calculateExpiredData(C, et.kW.ENH_PAYS_TKN, A, O)),
                eR(function (e) {
                  return es(es({}, e), {}, { expiredData4PayAsYouGo: !0 });
                }));
            },
            [C, b]
          );
        var eB = (0, _.useState)(0),
          eH = eB[0],
          eF = eB[1],
          eL = Object.keys(D).length,
          eK = Math.ceil(eL / 50),
          eV = function () {
            (0, W.z)("click_account_CTA", { account_CTA: "upgrade" });
          },
          ez = (0, _.useMemo)(
            function () {
              return L()(eS) ? null : Y.Z.isSuperlativeSubscription(eo, ei, eS);
            },
            [eo, ei, eS]
          );
        (0, _.useEffect)(
          function () {
            G()(ez) ||
              eR(function (e) {
                return es(es({}, e), {}, { isSuperlative: !0 });
              });
          },
          [eo, ei, eS]
        );
        var eG = (0, _.useCallback)(
            function () {
              return (0, er.jsxs)(er.Fragment, {
                children: [
                  (0, er.jsx)("div", {
                    children: en
                      ? (0, er.jsxs)(er.Fragment, {
                          children: [
                            (0, er.jsxs)("div", {
                              className: ""
                                .concat(M().boxTitle, " ")
                                .concat(M().monthly, " ")
                                .concat(ed && M().hasDueDateTitle),
                              children: [
                                ei,
                                " ",
                                i("pricing.credit.plan.credits.mo"),
                              ],
                            }),
                            ed &&
                              (0, er.jsx)("div", {
                                className: M().planDueDate,
                                children: ed,
                              }),
                          ],
                        })
                      : (0, er.jsx)("div", {
                          className: "".concat(M().subscriptionFeature),
                          ref: v,
                          children: [1, 2, 3].map(function (e, t) {
                            return (0, er.jsxs)(
                              "div",
                              {
                                className: "".concat(
                                  M().subscriptionFeatureItem
                                ),
                                ref: function (e) {
                                  return (g.current[t] = e);
                                },
                                children: [
                                  (0, er.jsx)("img", {
                                    src: "/assets/images/icon_tick_g.svg",
                                    alt: "btn_yce_v",
                                    className: M().icon,
                                  }),
                                  (0, er.jsx)("div", {
                                    className: M().text,
                                    children: i(
                                      "my.account.account.subscription.feature.".concat(
                                        e
                                      )
                                    ),
                                  }),
                                ],
                              },
                              t
                            );
                          }),
                        }),
                  }),
                  eu !== Q.L.CANCEL_SUB &&
                    eu !== Q.L.PAST_DUE_SUB &&
                    !ez &&
                    (0, er.jsx)(ee.Z, {
                      href: "/pricing?subscribe=true",
                      children: (0, er.jsx)($.Z, {
                        className: ""
                          .concat(M().button, " ")
                          .concat(!ea && M().noSubButton),
                        onClick: eV,
                        ref: y,
                        hoverClass: "hover-with-border-46e4fa",
                        touchClass: "touch-with-border-46e4fa",
                        children: ea
                          ? i("my.account.subscription.upgrade")
                          : i("my.account.subscription.subscribe"),
                      }),
                    }),
                ],
              });
            },
            [en, ed, ei, i, ea]
          ),
          eU = (0, _.useCallback)(
            function () {
              if (o <= 414) return { minWidth: "unset" };
            },
            [o]
          ),
          eq = (0, _.useCallback)(
            function () {
              if (o <= 414 && ("ja" === r || "zh-tw" === r))
                return { width: "10%" };
            },
            [o, r]
          ),
          eW = (0, _.useMemo)(
            function () {
              var e = function (e) {
                  if (RegExp(/^api_/).test(e)) {
                    var t = e.replaceAll(/^api_/g, "");
                    return (
                      "".concat(
                        i(
                          "my.account.account.token.action.desc.".concat(
                            t.replaceAll(/_( )?/g, ".")
                          )
                        ),
                        " (API)"
                      ) || 0
                    );
                  }
                  return (
                    i(
                      "my.account.account.token.action.desc.".concat(
                        e.replaceAll(/_( )?/g, ".")
                      )
                    ) || e
                  );
                },
                t = Object.values(D);
              return (
                t.sort(function (e, t) {
                  return t.date - e.date;
                }),
                (0, er.jsx)(er.Fragment, {
                  children: t
                    .slice(50 * eH, (eH + 1) * 50)
                    .map(function (t, n) {
                      var a;
                      return (0,
                      er.jsxs)("tr", { className: "".concat(M().tableRow), children: [(0, er.jsx)("td", { className: "".concat(M().date, " ").concat(M().alignLeft), style: eU(), children: ((a = t.date), (0, er.jsx)(er.Fragment, { children: (o <= 414 && "en-us" !== r && "zh-tw" !== r) || 375 === o ? (0, er.jsxs)(er.Fragment, { children: [(0, er.jsxs)("span", { children: [q()(new Date(a)).format("YYYY"), "/"] }), (0, er.jsx)("br", {}), q()(new Date(a)).format("MM/DD")] }) : (0, er.jsx)(er.Fragment, { children: q()(new Date(a)).format("YYYY/MM/DD") }) })) }), (0, er.jsx)("td", { className: "".concat(M().border, " ").concat(M().relative, " ").concat(M().alignLeft), children: e(t.action) }), (0, er.jsx)("td", { children: t.credits < 0 ? (0, er.jsx)("span", { className: M().negative, children: t.credits }) : (0, er.jsxs)("span", { className: M().positive, children: ["+", t.credits] }) }), (0, er.jsx)("td", { children: t.subscription }), (0, er.jsx)("td", { style: eq(), children: t.pay })] }, "".concat(t.id, "-").concat(n));
                    }),
                })
              );
            },
            [D, eH, o, r, i, eU, eq]
          ),
          eQ = Math.round(100 * window.devicePixelRatio),
          eX = function () {
            if (
              !s.current ||
              (eQ <= 110 && o <= parseInt(H()["width-xl"])) ||
              (eQ > 110 && o < parseInt(H()["width-lg"]))
            )
              return "100%";
            var e = (s.current.offsetWidth / 3 - 18).toFixed(0);
            return "".concat(e, "px");
          };
        function eJ(e, t) {
          e.classList.remove(t);
        }
        function eY(e, t) {
          e.classList.add(t);
        }
        function e$(e) {
          return Math.max.apply(
            Math,
            (0, Z.Z)(
              e.map(function (e) {
                var t;
                return (
                  (null === (t = e.current) || void 0 === t
                    ? void 0
                    : t.offsetHeight) || 0
                );
              })
            )
          );
        }
        function e0(e, t) {
          e.forEach(function (e) {
            null != e && e.current && Object.assign(e.current.style, t);
          });
        }
        (0, _.useEffect)(
          function () {
            var e = u.current,
              t = v.current;
            e &&
              (en
                ? eJ(e, M().noSubscription4Dynamic)
                : t &&
                  g.current &&
                  y.current &&
                  (e.offsetWidth -
                    Math.max.apply(
                      Math,
                      (0, Z.Z)(
                        g.current.map(function (e) {
                          return e.offsetWidth;
                        })
                      )
                    ) -
                    y.current.offsetWidth -
                    50 -
                    6 -
                    10 >=
                  0
                    ? (eY(e, M().noSubscription4Dynamic),
                      eY(t, M().subscriptionFeature4Dynamic))
                    : (eJ(e, M().noSubscription4Dynamic),
                      eJ(t, M().subscriptionFeature4Dynamic))),
              (function () {
                var e = [u, d, p],
                  t = [m, x];
                if (
                  (e0(e, { height: "auto" }),
                  e0(t, { height: "auto" }),
                  !(eQ <= 110 && o <= parseInt(H()["width-xl"])))
                ) {
                  var n = e$(e),
                    a = e$(t);
                  e0(e, { height: "".concat(n, "px") }),
                    e0(t, { height: "".concat(a, "px") });
                }
              })());
          },
          [o, C, eQ, en, i]
        );
        var e1 = function () {
            return (0, er.jsxs)("div", {
              className: M().skeletonContainer,
              children: [
                (0, er.jsx)("div", { className: M().skeleton }),
                (0, er.jsx)("div", { className: M().skeletonCircle }),
              ],
            });
          },
          e2 = function () {
            return "fApple" === R && !!V()(I, "email") && !V()(I, "name");
          };
        return (0, er.jsxs)("div", {
          className: M().container,
          ref: s,
          children: [
            (0, er.jsx)("div", {
              className: M().userContainer,
              style: {
                height: (function () {
                  if (R.includes("Facebook") || R.includes("email"))
                    return "auto";
                })(),
              },
              children: (0, er.jsx)("div", {
                className: M().flexL,
                children: (0, er.jsx)(ec, {
                  user: I,
                  accType: R,
                  isAppleAccountWithoutDisplayName: function () {
                    return e2();
                  },
                  showAccName: !1,
                  emailForm:
                    "valid" !== I.emailStatus
                      ? (0, er.jsx)(er.Fragment, {
                          children: (0, er.jsx)("div", {
                            className: M().flexL,
                            children: (0, er.jsxs)("div", {
                              className: M().email,
                              style: { marginRight: I.email ? "20px" : "10px" },
                              children: [
                                (0, er.jsx)("div", {
                                  className: M().emailLabel,
                                  children: I.email || i("general.email"),
                                }),
                                I.email &&
                                  (0, er.jsx)("div", {
                                    className: "".concat(M().emailUnverified),
                                    children: i(
                                      "my.account.me.email.unverified"
                                    ),
                                  }),
                              ],
                            }),
                          }),
                        })
                      : (0, er.jsx)(er.Fragment, {
                          children: (0, er.jsx)("div", {
                            className: M().emailContainer,
                            children:
                              !e2() &&
                              (0, er.jsx)("div", {
                                className: M().email,
                                children: (0, er.jsx)("span", {
                                  children: I.email,
                                }),
                              }),
                          }),
                        }),
                  iconSize: "large",
                  alignCenter: !0,
                }),
              }),
            }),
            (0, er.jsxs)("div", {
              className: M().top,
              children: [
                (0, er.jsxs)("div", {
                  className: M().subscriptionContainer,
                  children: [
                    (0, er.jsx)("div", {
                      className: M().topTitle,
                      ref: m,
                      style: { width: eX() },
                      children: i("my.account.account.your.subscription.plan"),
                    }),
                    (0, er.jsxs)("div", {
                      className: M().subscription,
                      children: [
                        (0, er.jsx)("div", {
                          className: ""
                            .concat(M().subscriptionPlanBox, " ")
                            .concat(ed && M().hasDueDate, " ")
                            .concat(en ? "" : M().noSubscription),
                          ref: u,
                          style: { width: eX() },
                          children: b && eI.isSuperlative ? eG() : e1(),
                        }),
                        (o > parseInt(H()["width-xl"]) ||
                          (eQ > 110 && o >= parseInt(H()["width-lg"]))) &&
                          (0, er.jsx)("div", { className: M().line }),
                      ],
                    }),
                  ],
                }),
                (0, er.jsxs)("div", {
                  className: M().creditContainer,
                  children: [
                    (0, er.jsx)("div", {
                      className: M().topTitle,
                      ref: x,
                      children: i("my.account.account.your.credit"),
                    }),
                    (0, er.jsxs)("div", {
                      className: M().credit,
                      children: [
                        (0, er.jsx)("div", {
                          className: ""
                            .concat(M().creditBox, " ")
                            .concat(!eE && en && M().subscriptionBox),
                          ref: d,
                          style: { width: eX() },
                          children:
                            b && eI.expiredData4Subs && eI.isSuperlative
                              ? (0, er.jsxs)(er.Fragment, {
                                  children: [
                                    (0, er.jsxs)("div", {
                                      children: [
                                        (0, er.jsx)("div", {
                                          className: M().boxSmallTitle,
                                          children: i(
                                            "my.account.account.your.credit.subscription"
                                          ),
                                        }),
                                        (0, er.jsx)("div", {
                                          className: ""
                                            .concat(M().boxTitle, " ")
                                            .concat(M().boxTitle4dpi150),
                                          children: en
                                            ? (0, er.jsxs)(er.Fragment, {
                                                children: [
                                                  (0, er.jsx)("span", {
                                                    className: M().blue,
                                                    children: eb,
                                                  }),
                                                  " ",
                                                  "/",
                                                  eg,
                                                  " ",
                                                  i(
                                                    "my.account.account.credits"
                                                  ),
                                                ],
                                              })
                                            : (0, er.jsxs)(er.Fragment, {
                                                children: [
                                                  (0, er.jsx)("span", {
                                                    className: M().blue,
                                                    children: "0",
                                                  }),
                                                  " /---",
                                                  " ",
                                                  i(
                                                    "my.account.account.credits"
                                                  ),
                                                ],
                                              }),
                                        }),
                                        eP &&
                                          (0, er.jsx)("div", {
                                            className: M().expire,
                                            children: i(
                                              "my.account.account.your.credit.expire",
                                              {
                                                count:
                                                  null == em
                                                    ? void 0
                                                    : em.amount,
                                                date: q()(
                                                  new Date(
                                                    null == em
                                                      ? void 0
                                                      : em.expiry
                                                  )
                                                ).format("MM/DD"),
                                              }
                                            ),
                                          }),
                                      ],
                                    }),
                                    eu !== Q.L.CANCEL_SUB &&
                                      eu !== Q.L.PAST_DUE_SUB &&
                                      !ez &&
                                      (0, er.jsx)(ee.Z, {
                                        href: "/pricing?subscribe=true",
                                        children: (0, er.jsx)($.Z, {
                                          className: M().button,
                                          onClick: function () {
                                            (0, W.z)("click_account_CTA", {
                                              account_CTA: "subscribe",
                                            });
                                          },
                                          hoverClass:
                                            "hover-with-border-46e4fa",
                                          touchClass:
                                            "touch-with-border-46e4fa",
                                          children: ea
                                            ? i(
                                                "my.account.subscription.upgrade"
                                              )
                                            : i(
                                                "my.account.subscription.subscribe"
                                              ),
                                        }),
                                      }),
                                  ],
                                })
                              : e1(),
                        }),
                        (0, er.jsx)("div", {
                          className: ""
                            .concat(M().creditBox, " ")
                            .concat(!eE && en && M().subscriptionBox),
                          ref: p,
                          style: { width: eX() },
                          children:
                            b && eI.expiredData4PayAsYouGo
                              ? (0, er.jsxs)(er.Fragment, {
                                  children: [
                                    (0, er.jsxs)("div", {
                                      children: [
                                        (0, er.jsx)("div", {
                                          className: M().boxSmallTitle,
                                          children: i(
                                            "my.account.account.pay.as.you.go"
                                          ),
                                        }),
                                        (0, er.jsxs)("div", {
                                          className: ""
                                            .concat(M().boxTitle, " ")
                                            .concat(M().blue, " ")
                                            .concat(M().boxTitle4dpi150),
                                          children: [
                                            eC,
                                            " ",
                                            i("my.account.account.credits"),
                                          ],
                                        }),
                                        eO &&
                                          (0, er.jsx)("div", {
                                            className: M().expire,
                                            children: i(
                                              "my.account.account.your.credit.expire",
                                              {
                                                count:
                                                  null == ef
                                                    ? void 0
                                                    : ef.amount,
                                                date: q()(
                                                  new Date(
                                                    null == ef
                                                      ? void 0
                                                      : ef.expiry
                                                  )
                                                ).format("MM/DD"),
                                              }
                                            ),
                                          }),
                                      ],
                                    }),
                                    (0, er.jsx)(ee.Z, {
                                      href: "/pricing?pay=true",
                                      children: (0, er.jsx)($.Z, {
                                        className: M().button,
                                        onClick: function () {
                                          (0, W.z)("click_account_CTA", {
                                            account_CTA: "purchase",
                                          });
                                        },
                                        hoverClass: "hover-with-border-46e4fa",
                                        touchClass: "touch-with-border-46e4fa",
                                        children: i(
                                          "my.account.subscription.purchase"
                                        ),
                                      }),
                                    }),
                                  ],
                                })
                              : e1(),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, er.jsxs)("div", {
              className: M().bottom,
              children: [
                (0, er.jsxs)("div", {
                  className: M().bottomTitleContainer,
                  children: [
                    (0, er.jsx)("div", {
                      className: M().bottomTitle,
                      children: i(
                        "my.account.account.credit.usage.record.title"
                      ),
                    }),
                    !L()(D) &&
                      (0, er.jsxs)("div", {
                        className: M().flex,
                        children: [
                          (0, er.jsxs)("div", {
                            className: M().page,
                            children: [
                              50 * eH + 1,
                              "-",
                              Math.min((eH + 1) * 50, eL),
                              " ",
                              i("my.account.account.credit.usage.of"),
                              " ",
                              eL,
                            ],
                          }),
                          (0, er.jsx)("img", {
                            className: ""
                              .concat(M().prev, " ")
                              .concat(0 === eH && M().disable),
                            src: "/assets/images/icon_prev.svg",
                            onClick: function () {
                              eH > 0 &&
                                eF(function (e) {
                                  return e - 1;
                                });
                            },
                            disabled: 0 === eH,
                          }),
                          (0, er.jsx)("img", {
                            className: ""
                              .concat(M().next, " ")
                              .concat(
                                (eH === eK - 1 || 0 === eK) && M().disable
                              ),
                            src: "/assets/images/icon_next.svg",
                            onClick: function () {
                              eK > 0 &&
                                eF(function (e) {
                                  return Math.min(e + 1, eK - 1);
                                });
                            },
                            disabled: eH === eK - 1 || 0 === eK,
                          }),
                        ],
                      }),
                  ],
                }),
                (0, er.jsx)("table", {
                  className: M().table,
                  children: (0, er.jsxs)("tbody", {
                    children: [
                      (0, er.jsx)("tr", {
                        children: Object.keys(el).map(function (e, t) {
                          var n = ["date", "description"].includes(e),
                            a = "date" === e,
                            r = "description" === e,
                            c =
                              ("pay.as.you.go.balance" === e ||
                                "sub.credit.balance" === e) &&
                              o < parseInt(H()["width-xl"])
                                ? "pay.as.you.go.balance" === e
                                  ? i("my.account.account.pay.as.you.go")
                                  : i(
                                      "my.account.account.your.credit.subscription"
                                    )
                                : i(
                                    "my.account.account.credit.usage.".concat(e)
                                  );
                          return (0, er.jsx)(
                            "th",
                            {
                              className: ""
                                .concat(M().tableHeader, " ")
                                .concat(a ? M().date : "", " ")
                                .concat(n ? M().alignLeft : "", " ")
                                .concat(r ? M().border : "", " ")
                                .concat(r ? M().description : ""),
                              style:
                                "pay.as.you.go.balance" === e
                                  ? eq()
                                  : a
                                  ? eU()
                                  : {},
                              children: c,
                            },
                            t
                          );
                        }),
                      }),
                      L()(D)
                        ? (0, er.jsxs)("tr", {
                            className: ""
                              .concat(M().tableRow, " ")
                              .concat(M().noDataText),
                            children: [
                              (0, er.jsx)("td", {
                                className: M().textLeft,
                                children: "-",
                              }),
                              (0, er.jsx)("td", {
                                className: " "
                                  .concat(M().relative, " ")
                                  .concat(M().border, " ")
                                  .concat(M().textLeft),
                                children: i(
                                  "my.account.account.credit.usage.no.information"
                                ),
                              }),
                              (0, er.jsx)("td", { children: "-" }),
                              (0, er.jsx)("td", { children: "-" }),
                              (0, er.jsx)("td", { children: "-" }),
                            ],
                          })
                        : eW,
                    ],
                  }),
                }),
              ],
            }),
          ],
        });
      }
      var ed = n(38498),
        ep = n.n(ed),
        em = n(75088),
        eh = n(94319),
        e_ = n(41379),
        ef = n(7146),
        ex = n(49114),
        ev = n(89984),
        eg = n(9585),
        ey = n(63105),
        ek = n.n(ey),
        eb = n(18446),
        ej = n.n(eb),
        ew = n(96026),
        eC = n.n(ew),
        eN = n(91966),
        eD = n.n(eN),
        eS = n(34394),
        eT = n.n(eS),
        eA = n(34900),
        eI = n(35699),
        eR = n(17911),
        eE = n.n(eR),
        eP = n(54555),
        eZ = n(43070);
      function eO(e) {
        var t = e.currentTab,
          n = e.moduleTypeForPromote,
          a = (0, v.useRouter)(),
          i = (0, h.PC)().t,
          r = (0, _.useRef)(null),
          c = (0, e_.Z)({ moduleType: n }),
          o = c.handleInputClick,
          s = c.handleInputFileChange,
          l = (0, _.useMemo)(
            function () {
              return t === T._x.photoEditor
                ? "/assets/images/account/gallery/emptyContent/photo-editing.png"
                : t === T._x.aiArtGenerator || t === T._x.faceAi
                ? "/assets/images/account/gallery/emptyContent/generative-ai.png"
                : t === T._x.videoEditor
                ? "/assets/images/account/gallery/emptyContent/video-editing.png"
                : "";
            },
            [t]
          ),
          u = (0, _.useMemo)(
            function () {
              return t === T._x.photoEditor
                ? i("my.account.gallery.no.photo.editing")
                : t === T._x.aiArtGenerator || t === T._x.faceAi
                ? i("my.account.gallery.no.generative.ai")
                : t === T._x.videoEditor
                ? i("my.account.gallery.no.video.editing")
                : "";
            },
            [t]
          ),
          d = (0, _.useMemo)(
            function () {
              return t === T._x.photoEditor
                ? "/photo-enhance/result-photo"
                : t === T._x.aiArtGenerator
                ? "/ai-art-generator/result-photo"
                : t === T._x.faceAi
                ? "/face-swap/result-photo"
                : t === T._x.videoEditor
                ? "/ai-headshot-generator/create"
                : "";
            },
            [t]
          ),
          p = (0, _.useMemo)(
            function () {
              return (
                t === T._x.photoEditor ||
                t === T._x.faceAi ||
                t === T._x.videoEditor
              );
            },
            [t]
          ),
          m = (0, _.useMemo)(
            function () {
              return t === T._x.photoEditor
                ? i("my.account.gallery.enhance.photo.now")
                : t === T._x.aiArtGenerator || t === T._x.faceAi
                ? i("my.account.gallery.generative.now")
                : t === T._x.videoEditor
                ? i("my.account.gallery.enhance.video.now")
                : "";
            },
            [t]
          );
        return (0, er.jsxs)("div", {
          className: eE().container,
          children: [
            (0, er.jsxs)("div", {
              className: eE().flex,
              children: [
                (0, er.jsx)("img", { src: l, className: eE().emptyImg }),
                (0, er.jsx)("div", { className: eE().emptyText, children: u }),
                (0, er.jsx)("button", {
                  className: eE().createButton,
                  onClick: function () {
                    p ? o(r) : C.Z.push(a, d);
                  },
                  children: m,
                }),
              ],
            }),
            p &&
              (0, er.jsx)(eZ.Z, {
                inputRef: r,
                handleInputFileChange: s,
                customAccept:
                  t === T._x.videoEditor ? ef.e.join(",") : eP.e.join(","),
              }),
          ],
        });
      }
      function eM(e) {
        var t,
          n,
          a,
          i,
          r,
          o,
          s,
          u = e.data,
          d = e.showVideoEnhanceRedDot,
          p = e.setShowVideoEnhanceRedDot,
          m = e.showAiVideoFiltersRedDot,
          x = e.setShowAiVideoFiltersRedDot,
          v = e.showVideoFaceSwapRedDot,
          g = e.setShowVideoFaceSwapRedDot,
          y = e.setSelectedHistoryIds,
          k = e.selectedHistoryIds,
          b = e.setFilteredData4VideoSr,
          w = e.isEditing,
          C = e.currentTab,
          N = (0, h.PC)().t,
          D = (0, em.Z)().createShareAndRedirect,
          S = (0, f.I0)(),
          T = (0, _.useState)([]),
          A = T[0],
          I = T[1],
          R = (0, _.useState)([]),
          E = R[0],
          O = R[1],
          M = (0, _.useState)([]),
          B = M[0],
          H = M[1],
          F = (0, _.useRef)(null),
          K = (0, f.v9)(function (e) {
            return e.user;
          }),
          z = V()(K, "userInfo.userId", null),
          G = (0, f.v9)(function (e) {
            return e.videoEnhance;
          }),
          U = (0, f.v9)(function (e) {
            return e.aiVideoFilters;
          }),
          q = (0, f.v9)(function (e) {
            return e.videoFaceSwap;
          }),
          W = G.pollingList,
          Q = G.pollingData,
          X = U.pollingList,
          J = U.pollingData,
          Y = q.pollingList,
          $ = q.pollingData,
          ee = (0, _.useState)(null),
          et = ee[0],
          en = ee[1],
          ea = (0, P.Z)(),
          ei = (0, _.useState)({ controller: null, initialized: !1 }),
          ec = ei[0],
          eo = ei[1],
          es = (0, _.useState)({ controller: null, initialized: !1 }),
          el = es[0],
          eu = es[1],
          ed = (0, _.useState)({ controller: null, initialized: !1 }),
          ep = ed[0],
          eh = ed[1];
        (0, _.useEffect)(function () {
          return (
            e_(),
            window.addEventListener("beforeunload", eb),
            function () {
              window.removeEventListener("beforeunload", eb),
                ey(),
                p([]),
                x([]),
                g([]),
                ef(),
                ex();
            }
          );
        }, []);
        var e_ =
            ((t = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (0, eA.CE)(eA.H$.yceVideoEnhanceTaskPollingList, eo)
                        );
                      case 2:
                        return (
                          (e.next = 4),
                          (0, eA.CE)(eA.H$.yceAiVideoFiltersTaskPollingList, eu)
                        );
                      case 4:
                        return (
                          (e.next = 6),
                          (0, eA.CE)(eA.H$.yceVideoFaceSwapTaskPollingList, eh)
                        );
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          ef =
            ((n = (0, c.Z)(
              l().mark(function e() {
                var t, n, a;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (t = new eA.ZP(eA.H$.yceVideoEnhanceCompletedTask)),
                          (e.next = 3),
                          t.delete()
                        );
                      case 3:
                        return (e.next = 5), t.close();
                      case 5:
                        return (
                          (n = new eA.ZP(eA.H$.yceAiVideoFiltersCompletedTask)),
                          (e.next = 8),
                          n.delete()
                        );
                      case 8:
                        return (e.next = 10), n.close();
                      case 10:
                        return (
                          (a = new eA.ZP(eA.H$.yceVideoFaceSwapCompletedTask)),
                          (e.next = 13),
                          a.delete()
                        );
                      case 13:
                        return (e.next = 15), a.close();
                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          ex =
            ((a = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (0, eA.tp)(eA.H$.yceVideoEnhanceTask2HistoryList, z)
                        );
                      case 2:
                        return (
                          (e.next = 4),
                          (0, eA.tp)(eA.H$.yceAiVideoFiltersTask2HistoryList, z)
                        );
                      case 4:
                        return (
                          (e.next = 6),
                          (0, eA.tp)(eA.H$.yceVideoFaceSwapTask2HistoryList, z)
                        );
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
          ey =
            ((i = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (0, eA.tp)(eA.H$.yceVideoEnhanceRedDot, z)
                        );
                      case 2:
                        return (
                          (e.next = 4),
                          (0, eA.tp)(eA.H$.yceAiVideoFiltersRedDot, z)
                        );
                      case 4:
                        return (
                          (e.next = 6),
                          (0, eA.tp)(eA.H$.yceVideoFaceSwapRedDot, z)
                        );
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
          eb =
            ((r = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), ey();
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return r.apply(this, arguments);
            });
        (0, _.useEffect)(
          function () {
            var e,
              t =
                ((e = (0, c.Z)(
                  l().mark(function e() {
                    var t;
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (
                              (t = []), (e.next = 3), ec.controller.getData(z)
                            );
                          case 3:
                            e.sent.forEach(function (e) {
                              W.includes(e.taskId) && t.push(e);
                            }),
                              I(t);
                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function () {
                  return e.apply(this, arguments);
                });
            !L()(W) && z && ec.initialized
              ? t()
              : L()(W) && z && ec.initialized && I([]);
          },
          [W, ec, z]
        ),
          (0, _.useEffect)(
            function () {
              var e,
                t =
                  ((e = (0, c.Z)(
                    l().mark(function e() {
                      var t;
                      return l().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (t = []), (e.next = 3), el.controller.getData(z)
                              );
                            case 3:
                              e.sent.forEach(function (e) {
                                X.includes(e.taskId) && t.push(e);
                              }),
                                O(t);
                            case 6:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              !L()(X) && z && el.initialized
                ? t()
                : L()(X) && z && el.initialized && O([]);
            },
            [X, el, z]
          ),
          (0, _.useEffect)(
            function () {
              var e,
                t =
                  ((e = (0, c.Z)(
                    l().mark(function e() {
                      var t;
                      return l().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (t = []), (e.next = 3), ep.controller.getData(z)
                              );
                            case 3:
                              e.sent.forEach(function (e) {
                                Y.includes(e.taskId) && t.push(e);
                              }),
                                H(t);
                            case 6:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              !L()(Y) && z && ep.initialized
                ? t()
                : L()(Y) && z && ep.initialized && H([]);
            },
            [Y, ep, z]
          );
        var ej =
            ((o = (0, c.Z)(
              l().mark(function e(t) {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), S((0, eg.x8)([t]));
                      case 2:
                        b(
                          u.filter(function (e) {
                            return e.id !== t;
                          })
                        );
                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return o.apply(this, arguments);
            }),
          ew =
            ((s = (0, c.Z)(
              l().mark(function e(t, n, a) {
                var i, r, c, o;
                return l().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            t.stopPropagation(),
                            (e.prev = 1),
                            (e.next = 4),
                            fetch(n)
                          );
                        case 4:
                          return (i = e.sent), (e.next = 7), i.blob();
                        case 7:
                          (r = e.sent),
                            (c = document.createElement("a")),
                            (o = URL.createObjectURL(r)),
                            (c.href = o),
                            (c.download = a),
                            document.body.appendChild(c),
                            c.click(),
                            document.body.removeChild(c),
                            URL.revokeObjectURL(o),
                            (e.next = 21);
                          break;
                        case 18:
                          (e.prev = 18),
                            (e.t0 = e.catch(1)),
                            console.error("Error downloading the file", e.t0);
                        case 21:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[1, 18]]
                );
              })
            )),
            function (e, t, n) {
              return s.apply(this, arguments);
            }),
          eC = function (e) {
            w &&
              y(
                j()(k, e)
                  ? ek()(k, function (t) {
                      return t !== e;
                    })
                  : [].concat((0, Z.Z)(k), [e])
              );
          };
        (0, _.useEffect)(
          function () {
            if (F.current && !L()(A)) {
              var e = F.current.getBoundingClientRect().height;
              0 !== e && en(e);
            } else en(null);
          },
          [ea, A, Q]
        );
        var eN = function (e) {
            var t =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : ev.ft.videoSr;
            w || D(t, e);
          },
          eD = (0, _.useMemo)(
            function () {
              return (
                (null == A ? void 0 : A.length) === 0 &&
                (null == E ? void 0 : E.length) === 0 &&
                (null == B ? void 0 : B.length) === 0 &&
                (null == u ? void 0 : u.length) === 0
              );
            },
            [A, E, B, u]
          );
        return (0, er.jsxs)("div", {
          className: eT().container,
          children: [
            eD &&
              (0, er.jsx)(eO, {
                currentTab: C,
                moduleTypeForPromote: ev.ft.videoSr,
              }),
            (0, er.jsx)("div", {
              className: eT().packsContainer,
              children: (0, er.jsxs)("div", {
                className: eT().packs,
                children: [
                  A.map(function (e, t) {
                    var n = V()(e, "name", null),
                      a = V()(e, "thumbnail", null),
                      i = V()(e, "taskId", null),
                      r = V()(Q, i, null),
                      c = V()(r, "result.estDueTs", null);
                    return (0,
                    er.jsxs)("div", { className: eT().pack, children: [(0, er.jsx)("div", { className: eT().packHeader, children: (0, er.jsx)("div", { className: eT().packTitle, children: n }) }), (0, er.jsxs)("div", { className: "".concat(eT().row), ref: F, children: [(0, er.jsx)("div", { className: eT().leftBlock, children: (0, er.jsx)("div", { className: eT().imageContainer, children: (0, er.jsx)(eI.Z, { src: a, imageClass: eT().image, skeletonClass: eT().image }, "image-".concat(t)) }) }), (0, er.jsxs)("div", { className: "".concat(eT().rightBlock, " ").concat(eT().rightBlock4Running), children: [(0, er.jsx)("img", { src: "/assets/images/account/aiTools/yce_aiTools_loading.png", className: eT().loading }), (0, er.jsxs)("div", { className: eT().textContainer, children: [(0, er.jsx)("div", { className: eT().title, children: N("aiheadshot.tool.creating.aiheadshot") }), (0, er.jsx)("div", { className: eT().description, children: N("avatar.tool.creating.avatars.1") }), (0, er.jsx)("div", { className: eT().description, children: N("video.editing.creating.video") }), c && (0, er.jsx)("div", { className: eT().timeLeft, children: N(c < 60 ? "avatar.tool.within.a.minute.left" : 60 === c ? "avatar.tool.minute.left" : "avatar.tool.minutes.left", { minutes: Math.ceil(c / 60) }) })] })] })] })] }, "r" + t);
                  }),
                  E.map(function (e, t) {
                    var n = V()(e, "name", null),
                      a = V()(e, "thumbnail", null),
                      i = V()(e, "taskId", null),
                      r = V()(J, i, null),
                      c = V()(r, "result.estDueTs", null);
                    return (0,
                    er.jsxs)("div", { className: eT().pack, children: [(0, er.jsx)("div", { className: eT().packHeader, children: (0, er.jsx)("div", { className: eT().packTitle, children: n }) }), (0, er.jsxs)("div", { className: "".concat(eT().row), ref: F, children: [(0, er.jsx)("div", { className: eT().leftBlock, children: (0, er.jsx)("div", { className: eT().imageContainer, children: (0, er.jsx)(eI.Z, { src: a, imageClass: eT().image, skeletonClass: eT().image }, "image-".concat(t)) }) }), (0, er.jsxs)("div", { className: "".concat(eT().rightBlock, " ").concat(eT().rightBlock4Running), children: [(0, er.jsx)("img", { src: "/assets/images/account/aiTools/yce_aiTools_loading.png", className: eT().loading }), (0, er.jsxs)("div", { className: eT().textContainer, children: [(0, er.jsx)("div", { className: eT().title, children: N("aiheadshot.tool.creating.aiheadshot") }), (0, er.jsx)("div", { className: eT().description, children: N("avatar.tool.creating.avatars.1") }), (0, er.jsx)("div", { className: eT().description, children: N("video.editing.creating.video") }), c && (0, er.jsx)("div", { className: eT().timeLeft, children: N(c < 60 ? "avatar.tool.within.a.minute.left" : 60 === c ? "avatar.tool.minute.left" : "avatar.tool.minutes.left", { minutes: Math.ceil(c / 60) }) })] })] })] })] }, "r" + t);
                  }),
                  B.map(function (e, t) {
                    var n = V()(e, "name", null),
                      a = V()(e, "thumbnail", null),
                      i = V()(e, "taskId", null),
                      r = V()($, i, null),
                      c = V()(r, "result.estDueTs", null);
                    return (0,
                    er.jsxs)("div", { className: eT().pack, children: [(0, er.jsx)("div", { className: eT().packHeader, children: (0, er.jsx)("div", { className: eT().packTitle, children: n }) }), (0, er.jsxs)("div", { className: "".concat(eT().row), ref: F, children: [(0, er.jsx)("div", { className: eT().leftBlock, children: (0, er.jsx)("div", { className: eT().imageContainer, children: (0, er.jsx)(eI.Z, { src: a, imageClass: eT().image, skeletonClass: eT().image }, "image-".concat(t)) }) }), (0, er.jsxs)("div", { className: "".concat(eT().rightBlock, " ").concat(eT().rightBlock4Running), children: [(0, er.jsx)("img", { src: "/assets/images/account/aiTools/yce_aiTools_loading.png", className: eT().loading }), (0, er.jsxs)("div", { className: eT().textContainer, children: [(0, er.jsx)("div", { className: eT().title, children: N("aiheadshot.tool.creating.aiheadshot") }), (0, er.jsx)("div", { className: eT().description, children: N("avatar.tool.creating.avatars.1") }), (0, er.jsx)("div", { className: eT().description, children: N("video.editing.creating.video") }), c && (0, er.jsx)("div", { className: eT().timeLeft, children: N(c < 60 ? "avatar.tool.within.a.minute.left" : 60 === c ? "avatar.tool.minute.left" : "avatar.tool.minutes.left", { minutes: Math.ceil(c / 60) }) })] })] })] })] }, "r" + t);
                  }),
                  u.map(function (e, t) {
                    var n = d.length + m.length + v.length,
                      a = V()(e, "result.misc.custom.clientCfg.name", null),
                      i = V()(e, "result.results.0.data.0.duration", null),
                      r = Math.floor(i),
                      c = Math.floor(r / 60)
                        .toString()
                        .padStart(2, "0"),
                      o = (r % 60).toString().padStart(2, "0"),
                      s = "".concat(c, ":").concat(o),
                      l = V()(e, "result.results.0.data.0.width", null),
                      u = V()(e, "result.results.0.data.0.height", null),
                      p = V()(e, "result.results.0.data.0.fps", null),
                      h = Math.ceil(parseFloat(p).toFixed(2)),
                      _ = V()(e, "result.results.0.data.0.url", null),
                      f = V()(e, "result.results.0.data.0.thumbUrl", null);
                    return (0, er.jsxs)(
                      "div",
                      {
                        className: ""
                          .concat(eT().pack, " ")
                          .concat(w && eT().editing),
                        onClick: function () {
                          return eC(e.id);
                        },
                        children: [
                          (0, er.jsx)("div", {
                            className: eT().packHeader,
                            children: (0, er.jsxs)("div", {
                              className: eT().packTitle,
                              children: [
                                a,
                                t < n &&
                                  (0, er.jsx)("span", {
                                    className: eT().redDot,
                                  }),
                              ],
                            }),
                          }),
                          (0, er.jsxs)("div", {
                            className: ""
                              .concat(eT().row, " ")
                              .concat(w ? "" : eT().rowWithCursorPointer),
                            style: { minHeight: et && "".concat(et, "px") },
                            onClick: function () {
                              return eN(e.id, e.effect);
                            },
                            children: [
                              (0, er.jsx)("div", {
                                className: eT().leftBlock,
                                children: (0, er.jsx)("div", {
                                  className: eT().imageContainer,
                                  children: (0, er.jsx)(
                                    eI.Z,
                                    {
                                      src: f,
                                      imageClass: eT().image,
                                      skeletonClass: eT().image,
                                    },
                                    "image-".concat(t)
                                  ),
                                }),
                              }),
                              (0, er.jsxs)("div", {
                                className: "".concat(eT().rightBlock),
                                children: [
                                  i &&
                                    (0, er.jsxs)("div", {
                                      className: eT().iconContainer,
                                      children: [
                                        (0, er.jsx)("img", {
                                          src: "/assets/images/account/gallery/videoEditing/dt_yce_time_icon.png",
                                          className: eT().icon,
                                        }),
                                        (0, er.jsx)("div", {
                                          className: eT().videoInfoText,
                                          children: s,
                                        }),
                                      ],
                                    }),
                                  l &&
                                    u &&
                                    (0, er.jsxs)("div", {
                                      className: eT().iconContainer,
                                      children: [
                                        (0, er.jsx)("img", {
                                          src: "/assets/images/account/gallery/videoEditing/dt_yce_scale_icon.png",
                                          className: eT().icon,
                                        }),
                                        (0, er.jsxs)("div", {
                                          className: eT().videoInfoText,
                                          children: [l, " x ", u],
                                        }),
                                      ],
                                    }),
                                  p &&
                                    (0, er.jsxs)("div", {
                                      className: eT().iconContainer,
                                      children: [
                                        (0, er.jsx)("img", {
                                          src: "/assets/images/account/gallery/videoEditing/dt_yce_fps_icon.png",
                                          className: eT().icon,
                                        }),
                                        (0, er.jsxs)("div", {
                                          className: eT().videoInfoText,
                                          children: [
                                            h,
                                            " ",
                                            N("video.editing.fps"),
                                          ],
                                        }),
                                      ],
                                    }),
                                  w &&
                                    (0, er.jsx)("div", {
                                      className: ""
                                        .concat(eT().checkmark, " ")
                                        .concat(
                                          j()(k, e.id) &&
                                            eT().checkmarkBackground
                                        ),
                                      children:
                                        j()(k, e.id) &&
                                        (0, er.jsx)("img", {
                                          src: "/assets/images/account/aiTools/aiHeadshot/icon_Tick.svg",
                                          className: eT().checkmarkChecked,
                                          alt: "checked",
                                        }),
                                    }),
                                  (0, er.jsxs)("div", {
                                    className: eT().bottomIconContainer,
                                    children: [
                                      (0, er.jsx)("img", {
                                        src: "/assets/images/account/gallery/videoEditing/btn_trash.png",
                                        className: ""
                                          .concat(eT().bottomIcon, " ")
                                          .concat(w && eT().disabled),
                                        onClick: function (t) {
                                          t.stopPropagation(), w || ej(e.id);
                                        },
                                      }),
                                      (0, er.jsx)("img", {
                                        src: "/assets/images/account/gallery/videoEditing/icon_download.png",
                                        className: ""
                                          .concat(eT().bottomIcon, " ")
                                          .concat(w && eT().disabled),
                                        onClick: function (e) {
                                          e.stopPropagation(), w || ew(e, _, a);
                                        },
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      },
                      "r" + t
                    );
                  }),
                ],
              }),
            }),
          ],
        });
      }
      var eB = n(74398),
        eH = n.n(eB),
        eF = n(95475),
        eL = n.n(eF),
        eK = (0, _.memo)(function (e) {
          var t = e.props,
            n = t.effect,
            a = t.result,
            i = t.customStyle,
            r = function (e) {
              switch (e) {
                case ev.ft.colorize:
                  return "colorize";
                case ev.ft.colorCorrection:
                  return "colorCorrection";
                default:
                  return e;
              }
            };
          return (0, er.jsx)("div", {
            className: i
              ? eL().customModuleTypeWrapper
              : eL().moduleTypeWrapper,
            children: (0, er.jsx)("img", {
              className: ""
                .concat(eL().moduleTypeIcon, "\n        ")
                .concat(n === ev.ft.hairStyle ? eL().invert : ""),
              src: (function (e) {
                if (e !== ev.ft.sod && e !== ev.ft.colorize)
                  return "/assets/images/account/gallery/ico_yce_".concat(
                    e === ev.ft.objRemoval ? "removal" : e,
                    "_s.png"
                  );
                if (e === ev.ft.colorize) {
                  var t = V()(a, "result.misc.clientCfg"),
                    n = V()(t, "colorizeType", ev.ft.colorize);
                  return "/assets/images/account/gallery/ico_yce_".concat(
                    r(n),
                    "_s.png"
                  );
                }
                var i = V()(a, "result.misc.clientCfg"),
                  c = V()(i, "sodType", ev.f6.remove);
                return c === ev.f6.remove
                  ? "/assets/images/account/gallery/ico_yce_".concat(
                      c,
                      "_s.png"
                    )
                  : "/assets/images/account/gallery/ico_yce_".concat(
                      c,
                      "_s.svg"
                    );
              })(n),
            }),
          });
        });
      function eV(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t &&
            (a = a.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function ez(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? eV(Object(n), !0).forEach(function (t) {
                (0, o.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : eV(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function eG(e) {
        var t = e.results,
          n = e.detailsResults,
          a = e.processId,
          i = e.isEditing,
          r = e.selectedHistoryIds,
          c = e.handleCellClick,
          o = e.isFaceAi,
          s = void 0 !== o && o,
          l = e.currentTab,
          u = (0, _.useMemo)(
            function () {
              return l === T._x.photoEditor
                ? ev.ft.enhance
                : l === T._x.faceAi
                ? ev.ft.faceSwap
                : l === T._x.videoEditor
                ? ev.ft.videoSr
                : "";
            },
            [l]
          );
        return (0, er.jsxs)(er.Fragment, {
          children: [
            (null == t ? void 0 : t.length) === 0 &&
              (0, er.jsx)(eO, { currentTab: l, moduleTypeForPromote: u }),
            (null == t ? void 0 : t.length) > 0 &&
              t.map(function (e, t) {
                var o,
                  l = ej()(a, e.id),
                  u = n[t],
                  d = s && V()(u, "result.afterImg.0.files.0.url", null);
                return (0, er.jsx)(
                  "div",
                  {
                    className: eH().cell,
                    children: (0, er.jsxs)("div", {
                      style: { cursor: l ? "unset" : "pointer" },
                      className: eH().imageContainer,
                      onClick: function () {
                        return c(e.id, e.effect);
                      },
                      children: [
                        i &&
                          (0, er.jsx)("div", {
                            className: ""
                              .concat(eH().checkmark, " ")
                              .concat(
                                j()(r, e.id) ? eH().checkmarkChecked : ""
                              ),
                          }),
                        ((o = ez(
                          ez({}, e),
                          {},
                          {
                            thumbnail: L()(V()(e, "thumbnail", null))
                              ? d
                              : V()(e, "thumbnail", null),
                          }
                        )),
                        (0, er.jsx)("div", {
                          className: eH().thumbnailContainer,
                          children:
                            o.thumbnails.length >= 4
                              ? o.thumbnails.slice(0, 4).map(function (e, t) {
                                  return (0,
                                  er.jsx)(eI.Z, { imageClass: eH().thumbnail4Group, src: e }, "".concat(o.id, " - image").concat(t));
                                })
                              : (0, er.jsx)(eI.Z, {
                                  imageClass: eH().thumbnail,
                                  src: o.thumbnails[0] || o.thumbnail,
                                }),
                        })),
                        (0, er.jsx)(eK, {
                          props: {
                            effect: e.effect,
                            detailResult: u,
                            customStyle: !0,
                          },
                        }),
                        l &&
                          (0, er.jsx)("div", {
                            className: eH().loading,
                            style: {
                              backgroundImage:
                                "url(/assets/images/loading.png)",
                            },
                          }),
                      ],
                    }),
                  },
                  "".concat(e.id, "-").concat(t)
                );
              }),
          ],
        });
      }
      function eU(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t &&
            (a = a.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      var eq = function (e) {
          var t,
            n = e.tabMap,
            a = e.setTab,
            i = void 0 === a ? null : a,
            r = e.isManualChange,
            s = void 0 === r ? null : r,
            u = e.querySwitch,
            d = void 0 === u || u,
            p = (0, v.useRouter)(),
            m =
              ((t = (0, c.Z)(
                l().mark(function e(t) {
                  var a, r, c, u, d, m, h, _, f, x;
                  return l().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            (s && (s.current = !0),
                            (r =
                              (a = p.query.locale) && "en-us" !== a
                                ? "/".concat(a)
                                : ""),
                            (u = (c = n[t]).basePath),
                            (d = c.pathSuffix),
                            (m = c.queryKey),
                            (h = c.queryValue),
                            (_ = "".concat(u).concat(d)),
                            (f = (function (e) {
                              for (var t = 1; t < arguments.length; t++) {
                                var n =
                                  null != arguments[t] ? arguments[t] : {};
                                t % 2
                                  ? eU(Object(n), !0).forEach(function (t) {
                                      (0, o.Z)(e, t, n[t]);
                                    })
                                  : Object.getOwnPropertyDescriptors
                                  ? Object.defineProperties(
                                      e,
                                      Object.getOwnPropertyDescriptors(n)
                                    )
                                  : eU(Object(n)).forEach(function (t) {
                                      Object.defineProperty(
                                        e,
                                        t,
                                        Object.getOwnPropertyDescriptor(n, t)
                                      );
                                    });
                              }
                              return e;
                            })({ locale: a || "en-us" }, (0, o.Z)({}, m, h))),
                            (x = r + _),
                            !ej()(p.asPath, x))
                          ) {
                            e.next = 10;
                            break;
                          }
                          return e.abrupt("return");
                        case 10:
                          return (
                            (e.next = 12), window.history.pushState({}, "", x)
                          );
                        case 12:
                          return (e.next = 14), C.Z.shallowReplace(p, f, x);
                        case 14:
                          i && i(t);
                        case 15:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )),
              function (e) {
                return t.apply(this, arguments);
              });
          return (
            (0, _.useEffect)(
              function () {
                if (d) {
                  if (s && s.current) {
                    s.current = !1;
                    return;
                  }
                  var e = !1;
                  Object.keys(n).forEach(function (t) {
                    var a = n[t],
                      r = a.queryKey,
                      c = a.queryValue;
                    ej()(p.query[r], c) && i && (i(t), (e = !0));
                  }),
                    !e && i && i(Object.keys(n)[0]);
                }
              },
              [p.query]
            ),
            { handleSetTab: m }
          );
        },
        eW = [
          {
            key: T._x.photoEditor,
            label: "post.featured.topic.CT_PHOTO_EDITING",
          },
          {
            key: T._x.aiArtGenerator,
            label: "my.account.history.tab.ai.art.generator",
          },
          { key: T._x.faceAi, label: "header.items.product.group.face.ai" },
          {
            key: T._x.videoEditor,
            label: "post.featured.topic.CT_VIDEO_EDITING",
          },
        ],
        eQ =
          ((a = {}),
          (0, o.Z)(a, T._x.photoEditor, {
            basePath: "/account/gallery",
            pathSuffix: "?type=photoEditor",
            queryKey: "type",
            queryValue: "photoEditor",
          }),
          (0, o.Z)(a, T._x.aiArtGenerator, {
            basePath: "/account/gallery",
            pathSuffix: "?aiArt=true",
            queryKey: "aiArt",
            queryValue: "true",
          }),
          (0, o.Z)(a, T._x.faceAi, {
            basePath: "/account/gallery",
            pathSuffix: "?type=faceAi",
            queryKey: "type",
            queryValue: "faceAi",
          }),
          (0, o.Z)(a, T._x.videoEditor, {
            basePath: "/account/gallery",
            pathSuffix: "?type=videoSr",
            queryKey: "type",
            queryValue: "videoSr",
          }),
          a);
      function eX(e) {
        var t,
          n,
          a = e.runNext,
          i = e.showVideoEnhanceRedDot,
          r = e.setShowVideoEnhanceRedDot,
          s = e.showAiVideoFiltersRedDot,
          u = e.setShowAiVideoFiltersRedDot,
          d = e.showVideoFaceSwapRedDot,
          p = e.setShowVideoFaceSwapRedDot,
          m = (0, _.useState)(T._x.photoEditor),
          v = m[0],
          g = m[1],
          y = (0, _.useState)(!0),
          k = y[0],
          b = y[1],
          w = (0, _.useState)(!0),
          C = w[0],
          N = w[1],
          D = (0, _.useState)(!0),
          S = D[0],
          A = D[1],
          R = (0, _.useState)(!0),
          E = R[0],
          P = R[1],
          O = (0, _.useState)(!1),
          M = O[0],
          B = O[1],
          H = (0, _.useState)([]),
          F = H[0],
          K = H[1],
          z = (0, _.useState)(null),
          U = z[0],
          q = z[1],
          W = (0, _.useState)(!0),
          Q = W[0],
          X = W[1],
          J = (0, _.useRef)(!1),
          Y = (0, h.PC)(),
          $ = Y.t,
          ee = Y.locale,
          et = (0, em.Z)().createShareAndRedirect,
          en = (0, f.I0)(),
          ea = (0, f.v9)(function (e) {
            return e.task;
          }),
          ei = (0, f.v9)(function (e) {
            return e.api;
          }),
          ec = ea.history,
          eo = ec.seq,
          es = ec.data,
          el = ea.history4AiArtGenerator,
          eu = el.seq,
          ed = el.data,
          ey = ea.history4FaceAi,
          eb = ey.seq,
          ew = ey.data,
          eC = ea.history4VideoSr,
          eN = eC.seq,
          eS = eC.data,
          eT = (0, eh.Z)(es).results,
          eA = (0, eh.Z)(ed).results,
          eI = (0, eh.Z)(ew).results,
          eR = (0, eh.Z)(eS).results,
          eE = (0, _.useState)([]),
          eP = eE[0],
          eO = eE[1],
          eB = (0, f.v9)(function (e) {
            return e.videoEnhance;
          }).successResults,
          eH = (0, f.v9)(function (e) {
            return e.aiVideoFilters;
          }).successResults,
          eF = (0, f.v9)(function (e) {
            return e.videoFaceSwap;
          }).successResults,
          eL = (0, _.useState)([]),
          eK = eL[0],
          eV = eL[1],
          ez = (0, _.useState)([]),
          eU = ez[0],
          eX = ez[1],
          eY = (0, _.useState)([]),
          e$ = eY[0],
          e0 = eY[1],
          e1 = (0, e_.Z)({ moduleType: ev.ft.videoSr }),
          e2 = e1.handleInputFileChange,
          e4 = e1.handleInputClick,
          e6 = (0, _.useRef)(null),
          e3 = (0, _.useMemo)(
            function () {
              return F.length;
            },
            [F]
          ),
          e8 = (0, _.useCallback)(
            function (e) {
              return ej()(v, e);
            },
            [v]
          );
        (0, _.useEffect)(
          function () {
            var e,
              t =
                ((e = (0, c.Z)(
                  l().mark(function e() {
                    var t;
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (
                              (t = eD()(eB, eK).length),
                              (e.next = 3),
                              en((0, eg.Hb)(t))
                            );
                          case 3:
                            eV(eB);
                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function () {
                  return e.apply(this, arguments);
                });
            L()(eB) || t();
          },
          [eB]
        ),
          (0, _.useEffect)(
            function () {
              var e,
                t =
                  ((e = (0, c.Z)(
                    l().mark(function e() {
                      var t;
                      return l().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (t = eD()(eH, eU).length),
                                (e.next = 3),
                                en((0, eg.Hb)(t))
                              );
                            case 3:
                              eX(eH);
                            case 4:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              L()(eH) || t();
            },
            [eH]
          ),
          (0, _.useEffect)(
            function () {
              var e,
                t =
                  ((e = (0, c.Z)(
                    l().mark(function e() {
                      var t;
                      return l().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (t = eD()(eF, e$).length),
                                (e.next = 3),
                                en((0, eg.Hb)(t))
                              );
                            case 3:
                              e0(eF);
                            case 4:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              L()(eF) || t();
            },
            [eF]
          );
        var e5 =
          (null == ei ? void 0 : ei.initOK) &&
          (null == ei ? void 0 : ei.authOK);
        (0, _.useEffect)(
          function () {
            e5 &&
              (e8(T._x.photoEditor) && k && (e7(), b(!1)),
              e8(T._x.aiArtGenerator) && C && (e7(), N(!1)),
              e8(T._x.videoEditor) && S && (e7(), A(!1)),
              e8(T._x.faceAi) && E && (e7(), P(!1)));
          },
          [e5, v]
        );
        var e9 = eq({ tabMap: eQ, setTab: g, isManualChange: J }).handleSetTab;
        (0, _.useEffect)(
          function () {
            K([]), B(!1);
          },
          [v]
        );
        var e7 =
          ((t = (0, c.Z)(
            l().mark(function e() {
              var t, n;
              return l().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (
                        (X(!0),
                        (t = {}),
                        (0, o.Z)(t, T._x.photoEditor, eg.HW),
                        (0, o.Z)(t, T._x.aiArtGenerator, eg.YR),
                        (0, o.Z)(t, T._x.videoEditor, eg.c1),
                        (0, o.Z)(t, T._x.faceAi, eg.md),
                        !(n = t[v]))
                      ) {
                        e.next = 6;
                        break;
                      }
                      return (e.next = 6), en(n(18));
                    case 6:
                      X(!1);
                    case 7:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          )),
          function () {
            return t.apply(this, arguments);
          });
        (0, _.useEffect)(
          function () {
            e5 && a && e7();
          },
          [a]
        ),
          (0, _.useEffect)(
            function () {
              if (ea.deleteHistoryConfirmed) {
                en((0, eg.t8)(!1));
                var e,
                  t = ((e = {}),
                  (0, o.Z)(e, T._x.photoEditor, eg.Bk),
                  (0, o.Z)(e, T._x.aiArtGenerator, eg.Nc),
                  (0, o.Z)(e, T._x.videoEditor, eg.x8),
                  (0, o.Z)(e, T._x.faceAi, eg.$G),
                  e)[v];
                t &&
                  en(t(F)).then(function (e) {
                    L()(e) || e.error || ta();
                  });
              }
            },
            [ea.deleteHistoryConfirmed]
          ),
          (0, _.useEffect)(
            function () {
              eO(
                eR.filter(function (e) {
                  return V()(
                    e,
                    "result.misc.custom.clientCfg.download",
                    V()(e, "result.misc.clientCfg.download", !1)
                  );
                })
              );
            },
            [eR]
          );
        var te = (0, _.useCallback)(
            function () {
              return e8(T._x.photoEditor)
                ? ej()(
                    es.filter(function (e) {
                      return T.zS.includes(e.effect);
                    }).length,
                    e3
                  )
                : e8(T._x.aiArtGenerator)
                ? ej()(
                    ed.filter(function (e) {
                      return T.WI.includes(e.effect);
                    }).length,
                    e3
                  )
                : e8(T._x.faceAi)
                ? ej()(
                    ew.filter(function (e) {
                      return T.oi.includes(e.effect);
                    }).length,
                    e3
                  )
                : !!e8(T._x.videoEditor) && ej()(eP.length, e3);
            },
            [e8, es, ed, ew, eP, e3]
          ),
          tt = function () {
            e8(T._x.videoEditor)
              ? en((0, x.Xt)({ show: !0, type: "history.notice.video" }))
              : (en((0, eg.Q2)(!0)),
                setTimeout(function () {
                  return en((0, eg.Q2)(!1));
                }, 100));
          },
          tn = function () {
            e8(T._x.videoEditor)
              ? 1 === e3
                ? en(
                    (0, x.Xt)({
                      show: !0,
                      type: "delete.history.video.singular",
                    })
                  )
                : en((0, x.Xt)({ show: !0, type: "delete.history.video" }))
              : (en((0, eg.z6)(!0)),
                setTimeout(function () {
                  return en((0, eg.z6)(!1));
                }, 100));
          },
          ta = function () {
            G()(U) && (K([]), B(!M));
          },
          ti = function () {
            te()
              ? K([])
              : e8(T._x.photoEditor)
              ? K(
                  es.map(function (e) {
                    return e.id;
                  })
                )
              : e8(T._x.aiArtGenerator)
              ? K(
                  ed.map(function (e) {
                    return e.id;
                  })
                )
              : e8(T._x.faceAi)
              ? K(
                  ew.map(function (e) {
                    return e.id;
                  })
                )
              : e8(T._x.videoEditor) &&
                K(
                  eP.map(function (e) {
                    return e.id;
                  })
                );
          },
          tr = (0, _.useCallback)(
            ((n = (0, c.Z)(
              l().mark(function e(t) {
                var n,
                  a = arguments;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((n =
                            a.length > 1 && void 0 !== a[1]
                              ? a[1]
                              : ev.ft.enhance),
                          G()(U))
                        ) {
                          e.next = 3;
                          break;
                        }
                        return e.abrupt("return");
                      case 3:
                        if (M) {
                          e.next = 9;
                          break;
                        }
                        return q(t), (e.next = 7), et(n, t);
                      case 7:
                        return q(null), e.abrupt("return");
                      case 9:
                        K(
                          j()(F, t)
                            ? ek()(F, function (e) {
                                return e !== t;
                              })
                            : [].concat((0, Z.Z)(F), [t])
                        );
                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return n.apply(this, arguments);
            }),
            [U, M, F, et]
          ),
          tc = (0, _.useMemo)(
            function () {
              return (
                !(
                  (e8(T._x.photoEditor) && "" === eo) ||
                  (e8(T._x.aiArtGenerator) && "" === eu) ||
                  (e8(T._x.faceAi) && "" === eb) ||
                  (e8(T._x.videoEditor) && "" === eN)
                ) && Q
              );
            },
            [v, Q, eo, eu, eb, eN]
          ),
          to = (0, _.useMemo)(
            function () {
              return (e8(T._x.photoEditor) && "" !== eo) ||
                (e8(T._x.aiArtGenerator) && "" !== eu) ||
                (e8(T._x.faceAi) && "" !== eb) ||
                (e8(T._x.videoEditor) && "" !== eN)
                ? 5
                : 18;
            },
            [v, eo, eu, eb, eN]
          ),
          ts = (0, _.useMemo)(
            function () {
              return "de" === ee ? ep().specialTab : "";
            },
            [ee]
          );
        return (0, er.jsxs)("div", {
          className: ep().container,
          children: [
            (0, er.jsxs)("div", {
              className: ""
                .concat(ep().header, " ")
                .concat(M ? ep().headerBottom : ""),
              children: [
                M
                  ? (0, er.jsx)("div", {
                      className: ep().flex,
                      children: (0, er.jsx)("button", {
                        className: ep().deleteButton,
                        disabled: F.length <= 0,
                        onClick: function () {
                          return tn();
                        },
                        children: (0, er.jsx)("img", {
                          src: "/assets/images/account/btn_trash.svg",
                        }),
                      }),
                    })
                  : (0, er.jsxs)("div", {
                      className: ep().flex,
                      children: [
                        (0, er.jsx)("div", {
                          className: ep().icon,
                          onClick: function () {
                            return tt();
                          },
                        }),
                        (0, er.jsx)("div", {
                          className: ep().tip,
                          dangerouslySetInnerHTML: {
                            __html: e8(T._x.videoEditor)
                              ? ex.Z.sanitize(
                                  $("my.account.history.enhance.video.tip", {
                                    dtl: '<span style="color: #03ADE2;">7</span>',
                                  }),
                                  "span"
                                )
                              : ex.Z.sanitize(
                                  $("my.account.history.tip", {
                                    dtl: '<span style="color: #03ADE2;">7</span>',
                                  }),
                                  "span"
                                ),
                          },
                        }),
                      ],
                    }),
                (0, er.jsx)("button", {
                  className: ep().editButton,
                  disabled:
                    !G()(U) ||
                    (e8(T._x.photoEditor) && es.length <= 0) ||
                    (e8(T._x.aiArtGenerator) && ed.length <= 0) ||
                    (e8(T._x.faceAi) && ew.length <= 0) ||
                    (e8(T._x.videoEditor) && eP.length <= 0),
                  onClick: function () {
                    return ta();
                  },
                  children: $(
                    M
                      ? "my.account.history.cancel"
                      : "my.account.history.select"
                  ),
                }),
              ],
            }),
            M &&
              (0, er.jsx)("div", {
                className: ep().helper,
                children: (0, er.jsxs)("div", {
                  className: ep().flex,
                  children: [
                    (0, er.jsx)("span", {
                      className: "".concat(ep().checkbox),
                      onClick: function () {
                        return ti();
                      },
                      children:
                        te() &&
                        (0, er.jsx)("img", {
                          src: "/assets/images/icon_tick_w.svg",
                          className: ep().checkboxChecked,
                        }),
                    }),
                    (0, er.jsxs)("label", {
                      className: ep().label,
                      children: [
                        $("my.account.history.select.all"),
                        (0, er.jsx)("input", {
                          type: "checkbox",
                          onClick: function () {
                            return ti();
                          },
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            (0, er.jsx)("div", {
              className: ep().tabHeader,
              children: (0, er.jsx)("div", {
                className: ep().tabs,
                children: eW.map(function (e, t) {
                  return (0, er.jsxs)(
                    "div",
                    {
                      className: ""
                        .concat(ep().tab, " ")
                        .concat(ts, " ")
                        .concat(ej()(v, e.key) && ep().tabActive),
                      onClick: function () {
                        return e9(e.key);
                      },
                      children: [
                        $(e.label),
                        (I()(i) > 0 || I()(s) > 0 || I()(d) > 0) &&
                          ej()(e.key, T._x.videoEditor) &&
                          (0, er.jsx)("span", { className: ep().redDot }),
                      ],
                    },
                    e.key
                  );
                }),
              }),
            }),
            e8(T._x.videoEditor) &&
              (null == eP ? void 0 : eP.length) > 0 &&
              (0, er.jsxs)("div", {
                className: ep().videoEditingLinkContainer,
                children: [
                  (0, er.jsx)("div", {
                    className: ep().videoEditingLink,
                    onClick: function () {
                      return e4(e6);
                    },
                    children: $("video.editing.more.video"),
                  }),
                  (0, er.jsx)("img", {
                    className: ep().arrowIcon,
                    src: "/assets/images/account/gallery/video_enhancer_next.svg",
                  }),
                  (0, er.jsx)(eZ.Z, {
                    inputRef: e6,
                    handleInputFileChange: e2,
                    customAccept: ef.e.join(","),
                  }),
                ],
              }),
            (0, er.jsx)("div", {
              className: ep().cellsContainer,
              children: (0, er.jsxs)("div", {
                className: ep().cells,
                children: [
                  e8(T._x.photoEditor) &&
                    (0, er.jsx)(eG, {
                      results: es,
                      detailsResults: eT,
                      processId: U,
                      isEditing: M,
                      selectedHistoryIds: F,
                      handleCellClick: tr,
                      currentTab: T._x.photoEditor,
                    }),
                  e8(T._x.aiArtGenerator) &&
                    (0, er.jsx)(eG, {
                      results: ed,
                      detailsResults: eA,
                      processId: U,
                      isEditing: M,
                      selectedHistoryIds: F,
                      handleCellClick: tr,
                      currentTab: T._x.aiArtGenerator,
                    }),
                  e8(T._x.faceAi) &&
                    (0, er.jsx)(eG, {
                      results: ew,
                      detailsResults: eI,
                      processId: U,
                      isEditing: M,
                      selectedHistoryIds: F,
                      handleCellClick: tr,
                      isFaceAi: !0,
                      currentTab: T._x.faceAi,
                    }),
                  e8(T._x.videoEditor) &&
                    (0, er.jsx)(eM, {
                      data: eP,
                      showVideoEnhanceRedDot: i,
                      setShowVideoEnhanceRedDot: r,
                      showAiVideoFiltersRedDot: s,
                      setShowAiVideoFiltersRedDot: u,
                      showVideoFaceSwapRedDot: d,
                      setShowVideoFaceSwapRedDot: p,
                      selectedHistoryIds: F,
                      setSelectedHistoryIds: K,
                      setFilteredData4VideoSr: eO,
                      isEditing: M,
                      currentTab: T._x.videoEditor,
                    }),
                  tc && (0, er.jsx)(eJ, { num: to }),
                ],
              }),
            }),
          ],
        });
      }
      function eJ(e) {
        var t = e.num;
        return (0, er.jsx)(er.Fragment, {
          children: eC()(t).map(function (e) {
            return (0,
            er.jsx)("div", { className: "".concat(ep().cell, " ").concat(ep().skeleton, " shimmer-skeleton"), children: (0, er.jsx)("div", { className: ep().imageContainer }) }, e);
          }),
        });
      }
      var eY = n(18567),
        e$ = n.n(eY),
        e0 = n(66430),
        e1 = n.n(e0),
        e2 = n(84753),
        e4 = n.n(e2),
        e6 = n(34645),
        e3 = n(95717),
        e8 = n(6180),
        e5 = _.forwardRef(function (e, t) {
          var n = e.label,
            a = e.type,
            i = e.value,
            r = e.onChange;
          return (0, er.jsxs)("div", {
            className: e$().textField,
            children: [
              (0, er.jsx)("div", {
                className: e$().textFieldLabel,
                children: n,
              }),
              (0, er.jsx)("input", {
                className: e$().textFieldInput,
                ref: t,
                type: a,
                value: void 0 === i ? "" : i,
                onChange: function (e) {
                  return r && r(e.target.value);
                },
              }),
            ],
          });
        });
      function e9(e) {
        var t,
          n,
          a,
          i = e.showFillEmailDialog,
          r = (0, _.useState)(!1),
          o = r[0],
          s = r[1],
          u = (0, _.useState)(!1),
          d = u[0],
          p = u[1],
          m = (0, _.useState)(!1),
          g = m[0],
          y = m[1],
          k = (0, _.useState)(""),
          b = k[0],
          j = k[1],
          w = (0, v.useRouter)(),
          D = (0, f.I0)(),
          S = (0, f.v9)(function (e) {
            return e.user;
          }),
          T = (0, f.v9)(function (e) {
            return e.user.userInfo;
          }),
          A = (0, f.v9)(function (e) {
            return e.user.subscription;
          }),
          I = (0, f.v9)(function (e) {
            return e.ui;
          }).focusOnEditEmail,
          R =
            (0, f.v9)(function (e) {
              return e.info;
            }).accType || "",
          E = (0, _.useMemo)(
            function () {
              var e = e4()(A, "expiry"),
                t = null == e ? void 0 : e.status;
              return !!e && "ACTIVE" === t;
            },
            [A]
          ),
          Z = (0, _.useRef)(null),
          O = (0, _.useRef)(null),
          M = (0, h.PC)().t,
          B = (0, _.useState)(!1),
          F = B[0],
          L = B[1],
          K = (0, e3.Z)(),
          z = K.isShowSubscribeNoticeCheckboxFunc,
          G = K.isEmailValidFunc,
          U = (0, P.Z)(),
          q = (0, e8.Z)().getSubscribeData,
          W =
            null == O
              ? void 0
              : null === (a = O.current) || void 0 === a
              ? void 0
              : a.querySelector('[data-nodes="unsubscriber"]');
        (0, _.useEffect)(function () {
          return (
            p(T.optIn),
            function () {
              z() && null === T.optIn && (D((0, N.Lt)(!1)), p(!1));
            }
          );
        }, []),
          (0, _.useEffect)(
            function () {
              W && (W.onclick = $);
            },
            [W]
          ),
          (0, _.useEffect)(
            function () {
              I && "valid" !== T.emailStatus && Q();
            },
            [I]
          ),
          (0, _.useEffect)(
            function () {
              var e = T.optIn;
              L(null === e), p(e);
            },
            [T.optIn]
          );
        var Q = function () {
            j(T.email || b),
              s(!0),
              setTimeout(function () {
                return Z.current && Z.current.focus();
              }, 300);
          },
          X = function () {
            D(
              (0, N.$M)(
                { mailType: "setContactEmail", contactEmail: T.email },
                !0
              )
            );
          },
          J =
            ((n = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), D((0, N.UX)());
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          Y = function () {
            if (!T.email || "valid" !== T.emailStatus) {
              i();
              return;
            }
            D((0, N.XQ)("deleteUser"));
          },
          $ = function () {
            D((0, N.sK)(!0)),
              setTimeout(function () {
                return D((0, N.sK)(!1));
              }, 100);
          },
          ee = function () {
            return "fApple" === R && !!V()(T, "email") && !V()(T, "name");
          },
          et = function () {
            var e = T.optIn,
              t = S.showUnsubscribeDialog,
              n = !e;
            if (!g) {
              if (d)
                t && D((0, N.du)(!1)),
                  setTimeout(function () {
                    D((0, N.du)(!0));
                  }, 100);
              else if (G()) {
                var a = T.email,
                  i = q(a);
                D((0, x.Iq)(!0)),
                  y(!0),
                  D(
                    (0, N.fv)(
                      "".concat("W8Qzyc"),
                      a,
                      i,
                      function () {
                        D((0, N.Lt)(!0)), y(!1);
                      },
                      function () {
                        y(!1);
                      }
                    )
                  ),
                  setTimeout(function () {
                    p(n), D((0, x.Iq)(!1));
                  }, 200);
              }
            }
          };
        return (0, er.jsxs)("div", {
          className: e$().container,
          children: [
            (0, er.jsxs)("div", {
              className: e$().userContainer,
              style: {
                height: (function () {
                  if (R.includes("Facebook") || R.includes("email"))
                    return "auto";
                })(),
              },
              children: [
                (0, er.jsx)(ec, {
                  user: T,
                  accType: R,
                  isAppleAccountWithoutDisplayName: function () {
                    return ee();
                  },
                  marginRight: "large",
                }),
                o
                  ? (0, er.jsxs)("div", {
                      className: e$().textFieldContainer,
                      children: [
                        (0, er.jsx)(e5, {
                          ref: Z,
                          label: M("general.email"),
                          type: "email",
                          value: b,
                          onChange: function (e) {
                            return j(e);
                          },
                        }),
                        (0, er.jsx)("button", {
                          className: e$().submit,
                          disabled:
                            ((t = RegExp(
                              /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/
                            )),
                            !(b && b.match(t))),
                          onClick: function () {
                            D(
                              (0, N.$M)(
                                {
                                  mailType: "setContactEmail",
                                  contactEmail: b,
                                },
                                !0
                              )
                            ),
                              s(!1);
                          },
                          children: M("my.account.me.submit"),
                        }),
                      ],
                    })
                  : "valid" !== T.emailStatus
                  ? (0, er.jsxs)(er.Fragment, {
                      children: [
                        (0, er.jsxs)("div", {
                          className: e$().emailContainer,
                          children: [
                            (0, er.jsx)("div", {
                              className: e$().flexL,
                              children: (0, er.jsxs)("div", {
                                className: e$().email,
                                style: {
                                  marginRight: T.email ? "20px" : "10px",
                                },
                                children: [
                                  (0, er.jsxs)("div", {
                                    className: e$().emailLabel,
                                    children: [
                                      T.email || M("general.email"),
                                      (0, er.jsx)("button", {
                                        className: "".concat(e$().edit),
                                        onClick: Q,
                                        children: (0, er.jsx)("span", {
                                          children: M("my.account.me.edit"),
                                        }),
                                      }),
                                    ],
                                  }),
                                  T.email &&
                                    (0, er.jsx)("div", {
                                      className: "".concat(
                                        e$().emailUnverified
                                      ),
                                      children: M(
                                        "my.account.me.email.unverified"
                                      ),
                                    }),
                                ],
                              }),
                            }),
                            T.email &&
                              U > parseInt(H()["width-sm"]) &&
                              (0, er.jsx)("button", {
                                className: e$().resentEmail,
                                onClick: X,
                                children: M("my.account.me.resent.email"),
                              }),
                          ],
                        }),
                        T.email &&
                          U <= parseInt(H()["width-sm"]) &&
                          (0, er.jsx)("button", {
                            className: e$().resentEmail,
                            onClick: X,
                            children: M("my.account.me.resent.email"),
                          }),
                      ],
                    })
                  : (0, er.jsxs)(er.Fragment, {
                      children: [
                        (0, er.jsx)("div", {
                          className: e$().emailContainer,
                          children:
                            !ee() &&
                            (0, er.jsx)("div", {
                              className: e$().email,
                              children: (0, er.jsx)("span", {
                                children: T.email,
                              }),
                            }),
                        }),
                        R.includes("email") &&
                          (0, er.jsx)("button", {
                            className: e$().resetPassword,
                            onClick: function () {
                              C.Z.push(w, "/change-password");
                            },
                            children: M("my.account.me.reset.password"),
                          }),
                      ],
                    }),
              ],
            }),
            z() &&
              (0, er.jsxs)("div", {
                className: "".concat(e$().agreement),
                onClick: function () {
                  return et();
                },
                children: [
                  F && (0, er.jsx)("div", { className: e$().redDot }),
                  (0, er.jsx)("div", {
                    className: e1().checkbox,
                    style: (function () {
                      return (arguments.length > 0 &&
                        void 0 !== arguments[0] &&
                        arguments[0],
                      d)
                        ? {
                            backgroundImage:
                              "url(/assets/images/icon_tick_w.svg)",
                            backgroundColor: "#212529",
                            borderColor: "#212529",
                          }
                        : null;
                    })("receive"),
                  }),
                  (0, er.jsx)("div", {
                    dangerouslySetInnerHTML: {
                      __html: ex.Z.sanitize(M("sign.up.notice.receive.info")),
                    },
                  }),
                ],
              }),
            (0, er.jsxs)("div", {
              className: e$().footer,
              children: [
                (0, er.jsx)("div", {
                  ref: O,
                  className: "".concat(e$().contactUs),
                  dangerouslySetInnerHTML: {
                    __html: ""
                      .concat(
                        E
                          ? ex.Z.sanitize(
                              M("my.account.subscription.unsubscribe"),
                              "a"
                            )
                          : ""
                      )
                      .concat(E ? " " : "")
                      .concat(
                        ex.Z.sanitize(
                          M(
                            "my.account.contact.us",
                            e6.Z.getMailToInterpolationObject()
                          ),
                          "a"
                        )
                      ),
                  },
                }),
                (0, er.jsxs)("div", {
                  className: e$().accPanel,
                  children: [
                    (0, er.jsx)("div", {
                      className: e$().logout,
                      onClick: function () {
                        return J();
                      },
                      children: M("my.account.me.logout"),
                    }),
                    (0, er.jsx)("div", { className: e$().divider }),
                    (0, er.jsx)("div", {
                      className: e$().deleteUser,
                      onClick: function () {
                        return Y();
                      },
                      children: M("my.account.me.delete.account"),
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      }
      var e7 = n(29273),
        te = n.n(e7),
        tt = n(86340),
        tn = n.n(tt);
      function ta(e) {
        var t = e.setOpen,
          n = e.amount,
          a = (0, h.PC)().t;
        return (0, er.jsxs)("div", {
          className: tn().container,
          children: [
            (0, er.jsx)("div", {
              className: tn().title,
              dangerouslySetInnerHTML: {
                __html: ex.Z.sanitize(a("apikey.modal.first.title"), "span"),
              },
            }),
            (0, er.jsx)("div", {
              className: tn().content,
              children: a("apikey.modal.first.desc", { credits: n || 0 }),
            }),
            (0, er.jsx)($.Z, {
              className: tn().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: function () {
                t(!1);
              },
              children: a("message.dialog.button.free.ai.art.generator"),
            }),
          ],
        });
      }
      var ti = n(18344),
        tr = n.n(ti),
        tc = n(11808);
      function to(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t &&
            (a = a.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function ts(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? to(Object(n), !0).forEach(function (t) {
                (0, o.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : to(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      n(19074);
      var tl = {
        "en-us": "en",
        ja: "ja",
        de: "de",
        fr: "fr",
        es: "es",
        pt: "pt",
        it: "it",
        "zh-tw": "zh",
      };
      function tu(e) {
        var t = e.expireDate,
          a = e.setExpireDate,
          i = e.inputRef,
          r = e.isPermanent,
          o = e.setIsPermanent,
          s = (0, _.useState)(null),
          u = s[0],
          d = s[1],
          p = (0, h.PC)(),
          m = (p.t, p.locale),
          f = (0, P.Z)(),
          x = (0, ei.Z)().isMobile,
          v = function () {
            var e = document.querySelector(".air-datepicker-nav--title");
            e &&
              Object.assign(e.style, {
                color: "#15171F",
                textAlign: "center",
                fontFamily: "Roboto",
                fontSize: "15.953px",
                fontStyle: "normal",
                fontWeight: "500",
                lineHeight: "normal",
              }),
              document
                .querySelectorAll(".air-datepicker-nav--action")
                .forEach(function (e) {
                  var t = e.querySelectorAll("path");
                  t &&
                    t.forEach(function (e) {
                      Object.assign(e.style, { stroke: "#15171F" });
                    });
                });
            var t = document.querySelectorAll(".air-datepicker-body--day-name");
            t &&
              t.forEach(function (e) {
                Object.assign(e.style, {
                  color: "#03ADE2",
                  textAlign: "center",
                  fontFamily: "Roboto",
                  fontSize: "13.959px",
                  fontStyle: "normal",
                  fontWeight: "500",
                  lineHeight: "normal",
                });
              });
          };
        return (
          (0, _.useEffect)(function () {
            var e;
            ((e = (0, c.Z)(
              l().mark(function e() {
                var c, o, s, u, p, h;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (i.current) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (e.next = 4), n(9982)("./".concat(tl[m], ".js"));
                      case 4:
                        (o = e.sent),
                          (s = new Date()),
                          (u = new Date(s)).setDate(s.getDate() + 60),
                          (p = t ? [new Date(t)] : r ? [] : [u]),
                          (h = new tc.Z(i.current, {
                            isMobile: x,
                            autoClose: !0,
                            dateFormat: "yyyy/MM/dd",
                            locale: ts(
                              ts({}, o.default),
                              {},
                              {
                                daysMin:
                                  "en-us" === m
                                    ? ["S", "M", "T", "W", "T", "F", "S"]
                                    : o.default.daysMin,
                              }
                            ),
                            selectedDates: p,
                          })),
                          a(
                            (null === (c = p[0]) || void 0 === c
                              ? void 0
                              : c.getTime()) || null
                          ),
                          d(h);
                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return e.apply(this, arguments);
            })();
          }, []),
          (0, _.useEffect)(
            function () {
              if (u) {
                var e;
                ((e = (0, c.Z)(
                  l().mark(function e() {
                    var t;
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (
                              (e.next = 2), n(9982)("./".concat(tl[m], ".js"))
                            );
                          case 2:
                            (t = e.sent),
                              u.update({
                                isMobile: x,
                                locale: ts(
                                  ts({}, t.default),
                                  {},
                                  {
                                    daysMin:
                                      "en-us" === m
                                        ? ["S", "M", "T", "W", "T", "F", "S"]
                                        : t.default.daysMin,
                                  }
                                ),
                                onShow: function () {
                                  v();
                                },
                                onSelect: function (e) {
                                  e.date
                                    ? (a(e.date.getTime()), o(!1))
                                    : a(null);
                                },
                              });
                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function () {
                  return e.apply(this, arguments);
                })();
              }
            },
            [u, x, m]
          ),
          (0, _.useEffect)(
            function () {
              u && v();
            },
            [f]
          ),
          {
            airDatePicker: u,
            handleOpenDatePicker: function () {
              u && (u.visible || u.show());
            },
          }
        );
      }
      var td = function (e) {
          e.setOpen;
          var t,
            n = e.setModalStatus,
            a = e.setKeys,
            i = (0, _.useState)(!1),
            r = i[0],
            o = i[1],
            s = (0, _.useState)(null),
            u = s[0],
            d = s[1],
            p = (0, _.useState)(""),
            m = p[0],
            x = p[1],
            v = (0, f.I0)(),
            g = (0, h.PC)().t,
            y = (0, _.useRef)(),
            k = tu({
              expireDate: u,
              setExpireDate: d,
              inputRef: y,
              isPermanent: r,
              setIsPermanent: o,
            }),
            b = k.airDatePicker,
            j = k.handleOpenDatePicker,
            w = (0, _.useCallback)(
              function () {
                return !!(!r && (!u || u < Date.now()));
              },
              [u, r]
            ),
            C =
              ((t = (0, c.Z)(
                l().mark(function e() {
                  var t, i;
                  return l().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!w()) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt("return");
                        case 2:
                          return (
                            (t = { name: null, expiry: r ? null : u, desc: m }),
                            (e.next = 5),
                            v((0, N.Qd)(t))
                          );
                        case 5:
                          (i = e.sent),
                            ej()(i, !1) || (a(i), n(T.x5.secret_api_key));
                        case 7:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )),
              function () {
                return t.apply(this, arguments);
              }),
            D = E()(C, 3e3, { leading: !0, trailing: !1 });
          return (0, er.jsxs)("div", {
            className: tr().container,
            children: [
              (0, er.jsx)("h1", {
                className: tr().title,
                children: g("apikey.modal.generate.title"),
              }),
              (0, er.jsxs)("div", {
                className: tr().inputContainer,
                children: [
                  (0, er.jsxs)("div", {
                    className: tr().expireDateContainer,
                    children: [
                      (0, er.jsx)("div", {
                        className: tr().expireDaeTitle,
                        children: g("apikey.modal.generate.expiration"),
                      }),
                      (0, er.jsx)("input", {
                        ref: y,
                        className: tr().input,
                        id: "datepicker",
                      }),
                      (0, er.jsx)("img", {
                        src: "/assets/images/account/apikey/icon_date.svg",
                        alt: "",
                        className: tr().dateIcon,
                        onClick: j,
                      }),
                    ],
                  }),
                  (0, er.jsxs)("div", {
                    className: tr().checkmarkContainer,
                    onClick: function () {
                      if ((o(!r), r && !u)) {
                        var e = new Date(),
                          t = new Date(e);
                        t.setDate(e.getDate() + 60), b.selectDate(t);
                      }
                      r || b.clear();
                    },
                    children: [
                      (0, er.jsx)("div", {
                        className: ""
                          .concat(tr().checkboxContainer, " ")
                          .concat(r ? tr().checkboxContainerBackground : ""),
                        children:
                          r &&
                          (0, er.jsx)("img", {
                            src: "/assets/images/icon_tick_w.svg",
                            className: tr().checkboxChecked,
                            alt: "",
                          }),
                      }),
                      (0, er.jsx)("div", {
                        children: g("apikey.modal.generate.permanent"),
                      }),
                    ],
                  }),
                ],
              }),
              (0, er.jsx)("textarea", {
                maxLength: 50,
                placeholder: g("apikey.modal.generate.desc"),
                className: tr().textarea,
                value: m,
                onChange: function (e) {
                  x(e.target.value);
                },
              }),
              (0, er.jsx)("button", {
                className: ""
                  .concat(tr().commonButton, " ")
                  .concat(w() ? tr().disabled : ""),
                onClick: D,
                disabled: w(),
                children: g("text.to.image.settings.button"),
              }),
            ],
          });
        },
        tp = n(86240),
        tm = n.n(tp),
        th = function (e) {
          var t = e.keys,
            n = e.handleCancel,
            a = (0, h.PC)().t,
            i = (0, _.useRef)(null),
            r = (0, _.useRef)(null),
            c = (0, _.useState)(!1),
            o = c[0],
            s = c[1],
            l = (0, _.useState)(!1),
            u = l[0],
            d = l[1],
            p = (0, _.useState)(!1),
            m = p[0],
            f = p[1],
            x = (0, _.useState)(!1),
            v = x[0],
            g = x[1],
            y = null,
            k = function (e, t, n) {
              if (e && e.current) {
                var a = e.current.textContent || e.current.value;
                clearTimeout(y),
                  navigator.clipboard
                    .writeText(a)
                    .then(function () {
                      t(!0),
                        "apiKeyFade" === n ? f(!0) : g(!0),
                        (y = setTimeout(function () {
                          t(!1), "apiKeyFade" === n ? f(!1) : g(!1);
                        }, 2e3));
                    })
                    .catch(function (e) {
                      t(!1);
                    });
              }
            };
          return (0, er.jsxs)("div", {
            className: tm().container,
            children: [
              (0, er.jsx)("h1", {
                className: tm().title,
                children: a("apikey.modal.secret.title"),
              }),
              (0, er.jsx)("h2", {
                className: tm().subtitle,
                children: a("my.account.tabs.apikey"),
              }),
              (0, er.jsxs)("div", {
                className: ""
                  .concat(tm().keyContainer, " ")
                  .concat(o ? tm().copied : ""),
                ref: i,
                onClick: function () {
                  k(i, s, "apiKeyFade");
                },
                children: [
                  (0, er.jsx)("img", {
                    src: "/assets/images/account/apikey/icon_copy.svg",
                    alt: "copy",
                    className: tm().copyIcon,
                  }),
                  (0, er.jsx)("div", {
                    className: tm().key,
                    children: t.apiKey,
                  }),
                ],
              }),
              (0, er.jsx)("div", {
                className: tm().copyContainer,
                children: (0, er.jsxs)("div", {
                  className: ""
                    .concat(tm().copiedTip, " ")
                    .concat(m ? tm().fadeIn : tm().fadeOut),
                  children: [
                    (0, er.jsx)("img", {
                      src: "/assets/images/icon_tick.svg",
                      alt: "check",
                    }),
                    (0, er.jsx)("div", {
                      className: tm().tipText,
                      children: a("apikey.modal.secret.copied"),
                    }),
                  ],
                }),
              }),
              (0, er.jsx)("h2", {
                className: tm().subtitle,
                children: a("apikey.modal.secret.subtitle"),
              }),
              (0, er.jsx)("div", {
                className: tm().desc,
                children: a("apikey.modal.secret.desc"),
              }),
              (0, er.jsxs)("div", {
                className: ""
                  .concat(tm().keyContainer, " ")
                  .concat(u ? tm().copied : ""),
                ref: r,
                onClick: function () {
                  k(r, d, "secretKeyFade");
                },
                children: [
                  (0, er.jsx)("img", {
                    src: "/assets/images/account/apikey/icon_copy.svg",
                    alt: "copy",
                    className: tm().copyIcon,
                  }),
                  (0, er.jsx)("div", {
                    className: tm().key,
                    children: t.secretKey,
                  }),
                ],
              }),
              (0, er.jsx)("div", {
                className: tm().copyContainer,
                children: (0, er.jsxs)("div", {
                  className: ""
                    .concat(tm().copiedTip, " ")
                    .concat(v ? tm().fadeIn : tm().fadeOut),
                  children: [
                    (0, er.jsx)("img", {
                      src: "/assets/images/icon_tick.svg",
                      alt: "check",
                    }),
                    (0, er.jsx)("div", {
                      className: tm().tipText,
                      children: a("apikey.modal.secret.copied"),
                    }),
                  ],
                }),
              }),
              (0, er.jsx)("div", {
                className: "".concat(tm().buttonContainer),
                children: (0, er.jsx)($.Z, {
                  className: tm().button,
                  hoverClass: "hover-46e4fa",
                  touchClass: "touch-46e4fa",
                  onClick: n,
                  children: a("my.account.me.submit"),
                }),
              }),
            ],
          });
        },
        t_ = n(82603),
        tf = n.n(t_),
        tx = function (e) {
          var t,
            n = e.setOpen,
            a = e.apiData,
            i = a.id,
            r = a.name,
            o = a.desc,
            s = a.status,
            u = a.expiry,
            d = (0, _.useState)(!u),
            p = d[0],
            m = d[1],
            x = (0, _.useState)(u),
            v = x[0],
            g = x[1],
            y = (0, _.useState)(o),
            k = y[0],
            b = y[1],
            j = (0, _.useState)(s),
            w = j[0],
            C = j[1],
            D = (0, _.useRef)(),
            S = (0, f.I0)(),
            A = (0, h.PC)().t,
            I = tu({
              expireDate: u,
              setExpireDate: g,
              inputRef: D,
              isPermanent: p,
              setIsPermanent: m,
            }),
            R = I.airDatePicker,
            E = I.handleOpenDatePicker,
            P = (0, _.useMemo)(
              function () {
                return w === T.mP.active;
              },
              [w]
            ),
            Z = (0, _.useMemo)(
              function () {
                return ej()(o, k) && ej()(s, w) && ej()(!u, p) && ej()(u, v);
              },
              [o, k, s, w, u, p, v]
            ),
            O = (0, _.useCallback)(
              function () {
                return !!(!p && (!v || v < Date.now()));
              },
              [v, p]
            ),
            M =
              ((t = (0, c.Z)(
                l().mark(function e() {
                  var t;
                  return l().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!Z) {
                            e.next = 3;
                            break;
                          }
                          return n(!1), e.abrupt("return");
                        case 3:
                          if (!O()) {
                            e.next = 5;
                            break;
                          }
                          return e.abrupt("return");
                        case 5:
                          return (
                            (t = {
                              id: i,
                              name: r,
                              expiry: p ? null : v,
                              desc: k,
                              status: w,
                            }),
                            (e.next = 8),
                            S((0, N.dh)(t))
                          );
                        case 8:
                          n(!1);
                        case 9:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )),
              function () {
                return t.apply(this, arguments);
              });
          return (0, er.jsxs)("div", {
            className: tf().container,
            children: [
              (0, er.jsx)("h1", {
                className: tf().title,
                children: A("apikey.modal.edit.title"),
              }),
              (0, er.jsx)("div", { className: tf().secretKey, children: r }),
              (0, er.jsxs)("div", {
                className: tf().statusContainer,
                children: [
                  (0, er.jsxs)("div", {
                    className: tf().statusTitle,
                    children: [A("apikey.modal.edit.status"), ":"],
                  }),
                  (0, er.jsxs)("div", {
                    className: tf().radioContainer,
                    onClick: function () {
                      C(T.mP.active);
                    },
                    children: [
                      (0, er.jsx)("div", {
                        className: ""
                          .concat(tf().radioOuter, " ")
                          .concat(P ? tf().radioOuterChecked : ""),
                        children: (0, er.jsx)("div", {
                          className: ""
                            .concat(tf().radioInner, " ")
                            .concat(P ? tf().radioInnerChecked : ""),
                        }),
                      }),
                      (0, er.jsx)("div", {
                        children: A("apikey.modal.edit.status.available"),
                      }),
                    ],
                  }),
                  (0, er.jsxs)("div", {
                    className: tf().radioContainer,
                    onClick: function () {
                      C(T.mP.inactive);
                    },
                    children: [
                      (0, er.jsx)("div", {
                        className: ""
                          .concat(tf().radioOuter, " ")
                          .concat(P ? "" : tf().radioOuterChecked),
                        children: (0, er.jsx)("div", {
                          className: ""
                            .concat(tf().radioInner, " ")
                            .concat(P ? "" : tf().radioInnerChecked),
                        }),
                      }),
                      (0, er.jsx)("div", {
                        children: A("apikey.modal.edit.status.disabled"),
                      }),
                    ],
                  }),
                ],
              }),
              (0, er.jsxs)("div", {
                className: tf().inputContainer,
                children: [
                  (0, er.jsxs)("div", {
                    className: tf().expireDateContainer,
                    children: [
                      (0, er.jsx)("div", {
                        className: tf().expireDaeTitle,
                        children: A("apikey.modal.generate.expiration"),
                      }),
                      (0, er.jsx)("input", {
                        ref: D,
                        className: tf().input,
                        id: "datepicker",
                      }),
                      (0, er.jsx)("img", {
                        src: "/assets/images/account/apikey/icon_date.svg",
                        alt: "",
                        className: tf().dateIcon,
                        onClick: E,
                      }),
                    ],
                  }),
                  (0, er.jsxs)("div", {
                    className: tf().checkmarkContainer,
                    onClick: function () {
                      if ((m(!p), p && !v)) {
                        var e = new Date(),
                          t = new Date(e);
                        t.setDate(e.getDate() + 60), R.selectDate(t);
                      }
                      p || R.clear();
                    },
                    children: [
                      (0, er.jsx)("div", {
                        className: ""
                          .concat(tf().checkboxContainer, " ")
                          .concat(p ? tf().checkboxContainerBackground : ""),
                        children:
                          p &&
                          (0, er.jsx)("img", {
                            src: "/assets/images/icon_tick_w.svg",
                            className: tf().checkboxChecked,
                            alt: "",
                          }),
                      }),
                      (0, er.jsx)("div", {
                        children: A("apikey.modal.generate.permanent"),
                      }),
                    ],
                  }),
                ],
              }),
              (0, er.jsx)("textarea", {
                maxLength: 50,
                placeholder: A("apikey.modal.generate.desc"),
                className: tf().textarea,
                value: k || "",
                onChange: function (e) {
                  return b(e.target.value);
                },
              }),
              (0, er.jsx)("button", {
                className: ""
                  .concat(tf().commonButton, " ")
                  .concat(O() ? tf().disabled : ""),
                onClick: M,
                disabled: O(),
                children: A("my.account.me.submit"),
              }),
            ],
          });
        },
        tv = n(54473),
        tg = n(44517),
        ty = n.n(tg),
        tk = n(28953);
      function tb(e) {
        e.setOpen;
        var t = e.setModalStatus,
          n = (0, h.PC)(),
          a = n.t;
        n.locale;
        var i = (0, _.useState)(!1),
          r = i[0],
          c = i[1],
          o = (0, _.useRef)(null),
          s = (0, f.v9)(function (e) {
            return e.user;
          }),
          l = (0, v.useRouter)(),
          u = function (e) {
            if (e && !r) {
              o.current.classList.add("text-shake"),
                setTimeout(function () {
                  o.current.classList.remove("text-shake");
                }, 200);
              return;
            }
            var n = V()(s, "userInfo.userId"),
              a = tk.ZP.getParsedItem(tk.XC.initApiKey, {});
            (a[n] = !0),
              tk.ZP.updateObjectInfo(tk.XC.initApiKey, a),
              t(T.x5.generate_api_key);
          };
        return (0, er.jsxs)("div", {
          className: ty().container,
          children: [
            (0, er.jsx)("div", {
              className: ty().title,
              children: a("apikey.modal.init.title"),
            }),
            (0, er.jsx)("div", {
              className: ty().content,
              children: a("apikey.modal.init.desc"),
            }),
            (0, er.jsxs)("div", {
              className: ty().agreement,
              onClick: function (e) {
                e.target.hasAttribute("href") || c(!r);
              },
              children: [
                (0, er.jsx)("div", {
                  className: ty().checkbox,
                  style: r
                    ? {
                        backgroundImage: "url(/assets/images/icon_tick_w.svg)",
                        backgroundColor: "#212529",
                        borderColor: "#212529",
                      }
                    : null,
                }),
                (0, er.jsx)("div", {
                  ref: o,
                  dangerouslySetInnerHTML: {
                    __html: ex.Z.sanitize(
                      a(
                        "apikey.modal.init.notice",
                        e6.Z.getPPTosInterpolationObject(["ppUrl", "tosUrl"], l)
                      ),
                      "a"
                    ),
                  },
                }),
              ],
            }),
            (0, er.jsx)($.Z, {
              className: ty().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: function () {
                return u(!0);
              },
              children: a("apikey.modal.init.button"),
            }),
          ],
        });
      }
      function tj(e) {
        var t,
          n,
          a,
          i = e.runNext,
          r = (0, P.Z)(),
          o = (0, v.useRouter)(),
          s = (0, f.I0)(),
          u = (0, h.PC)().t,
          d = (0, _.useState)(!1),
          p = d[0],
          m = d[1],
          g = (0, _.useState)(null),
          y = g[0],
          k = g[1],
          b = (0, _.useState)(T.x5.generate_api_key),
          j = b[0],
          w = b[1],
          D = (0, _.useState)(null),
          S = D[0],
          A = D[1],
          I = (0, _.useState)(null),
          R = I[0],
          E = I[1],
          Z = (0, _.useState)(null),
          O = Z[0],
          M = Z[1],
          B = (0, f.v9)(function (e) {
            return e.api;
          }),
          F = (0, f.v9)(function (e) {
            return e.user;
          }),
          K = F.apiKeys,
          z = K.list,
          G = K.systemTimeStamp,
          U = (0, tv.Z)().checkTriedStatus,
          q = (0, ei.Z)().isDesktop,
          W =
            ((t = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), s((0, N.kh)());
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            });
        (0, _.useEffect)(
          function () {
            null != B && B.initOK && null != B && B.authOK && W();
          },
          [null == B ? void 0 : B.initOK, null == B ? void 0 : B.authOK]
        ),
          (0, _.useEffect)(
            function () {
              i && W();
            },
            [i]
          );
        var Q = (0, _.useMemo)(
            function () {
              return r <= parseInt(H()["width-lg"]);
            },
            [r]
          ),
          X =
            ((n = (0, c.Z)(
              l().mark(function e() {
                var t, n;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        (t = V()(F, "userInfo.userId")),
                          (n = tk.ZP.getParsedItem(tk.XC.initApiKey)) && n[t]
                            ? w(T.x5.generate_api_key)
                            : w(T.x5.init_api_key),
                          m(!0);
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          J =
            ((a = (0, c.Z)(
              l().mark(function e() {
                var t, n, a;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!(ej()(j, T.x5.secret_api_key) && ej()(O, null))) {
                          e.next = 9;
                          break;
                        }
                        return (
                          (e.next = 3),
                          U({ moduleType: ev.ft.aiApi, setMessageAction: !1 })
                        );
                      case 3:
                        (n = (t = e.sent).showMessage),
                          (a = t.amount),
                          n ? (M(a), w(T.x5.first_time_entry)) : m(!1),
                          (e.next = 10);
                        break;
                      case 9:
                        m(!1);
                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            });
        (0, _.useEffect)(
          function () {
            var e,
              t =
                ((e = (0, c.Z)(
                  l().mark(function e(t) {
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (
                              !ej()(t.target.className, te().modalContainer)
                            ) {
                              e.next = 3;
                              break;
                            }
                            return (e.next = 3), J();
                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function (t) {
                  return e.apply(this, arguments);
                });
            return (
              document.addEventListener("click", t),
              function () {
                document.removeEventListener("click", t);
              }
            );
          },
          [j]
        );
        var Y = function (e, t) {
            return ej()(e, null) ? t : G > e ? T.mP.expired : t;
          },
          ee = function (e, t) {
            var n = Y(e, t);
            return u("my.account.apikey.table.key.".concat(n));
          },
          et = function (e) {
            switch (e) {
              case T.mP.active:
                return te().active;
              case T.mP.inactive:
              default:
                return te().disabled;
            }
          },
          en = function (e) {
            var t = e.getFullYear(),
              n = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec",
              ][e.getMonth()],
              a = e.getDate();
            return "".concat(n, " ").concat(a, ", ").concat(t);
          },
          ea = function (e) {
            A(z[e]), w(T.x5.edit_api_key), m(!0);
          },
          ec = function (e) {
            E(e), s((0, x.Xt)({ show: !0, type: "delete.apikey" }));
          };
        return (
          (0, _.useEffect)(
            function () {
              F.deleteApiKeyConfirmed &&
                (s((0, N.df)(R)), E(null), s((0, N.VS)(!1)));
            },
            [F.deleteApiKeyConfirmed]
          ),
          (0, er.jsxs)("div", {
            className: "".concat(te().container),
            children: [
              (0, er.jsxs)("div", {
                className: te().apiKeyContainer,
                children: [
                  (0, er.jsx)("h1", {
                    className: te().apiKeyTitle,
                    children: u("my.account.apikey.title"),
                  }),
                  (0, er.jsx)("p", {
                    className: te().apiKeyDescription,
                    children: L()(z)
                      ? u("my.account.apikey.no.key.desc")
                      : u("my.account.apikey.desc"),
                  }),
                  (0, er.jsx)("div", {
                    children: q
                      ? (0, er.jsx)("table", {
                          className: te().apiKeyTable,
                          children: (0, er.jsxs)("tbody", {
                            children: [
                              (0, er.jsxs)("tr", {
                                children: [
                                  (0, er.jsx)("th", {
                                    className: te().apiKeyTableHeader,
                                    children: u(
                                      "my.account.apikey.table.header.api.key"
                                    ),
                                  }),
                                  (0, er.jsx)("th", {
                                    className: te().apiKeyTableHeader,
                                    children: u(
                                      "my.account.account.credit.usage.description"
                                    ),
                                  }),
                                  (0, er.jsx)("th", {
                                    className: te().apiKeyTableHeader,
                                    children: u(
                                      "my.account.apikey.table.header.status"
                                    ),
                                  }),
                                  (0, er.jsx)("th", {
                                    className: te().apiKeyTableHeader,
                                    children: u(
                                      "my.account.apikey.table.key.create"
                                    ),
                                  }),
                                  (0, er.jsx)("th", {
                                    className: ""
                                      .concat(te().apiKeyTableHeader, " ")
                                      .concat(te().border),
                                    children: u(
                                      "my.account.apikey.table.key.expire"
                                    ),
                                  }),
                                  (0, er.jsx)("th", {
                                    className: te().apiKeyTableHeader,
                                    children: u(
                                      "my.account.apikey.table.header.operation"
                                    ),
                                  }),
                                ],
                              }),
                              (function (e) {
                                if (!(!e || L()(e)))
                                  return (0, er.jsx)(er.Fragment, {
                                    children: e.map(function (e, t) {
                                      return (0, er.jsxs)(
                                        "tr",
                                        {
                                          children: [
                                            (0, er.jsx)("td", {
                                              className: te().name,
                                              children: e.name,
                                            }),
                                            (0, er.jsx)("td", {
                                              className: te().desc,
                                              children: e.desc,
                                            }),
                                            (0, er.jsx)("td", {
                                              className: et(
                                                Y(e.expiry, e.status)
                                              ),
                                              children: ee(e.expiry, e.status),
                                            }),
                                            (0, er.jsx)("td", {
                                              children: en(
                                                new Date(e.createdTime)
                                              ),
                                            }),
                                            (0, er.jsx)("td", {
                                              className: te().border,
                                              children: e.expiry
                                                ? en(new Date(e.expiry))
                                                : "-",
                                            }),
                                            (0, er.jsx)("td", {
                                              children: (0, er.jsxs)("div", {
                                                className: te().control,
                                                children: [
                                                  (0, er.jsx)($.Z, {
                                                    className: te().editButton,
                                                    onClick: function () {
                                                      ea(t);
                                                    },
                                                    children:
                                                      u("my.account.me.edit"),
                                                  }),
                                                  (0, er.jsx)("img", {
                                                    src: "/assets/images/account/btn_trash.svg",
                                                    className: te().deleteIcon,
                                                    onClick: function () {
                                                      ec(e.id);
                                                    },
                                                    alt: "delete",
                                                  }),
                                                ],
                                              }),
                                            }),
                                          ],
                                        },
                                        t
                                      );
                                    }),
                                  });
                              })(z),
                            ],
                          }),
                        })
                      : (function (e) {
                          if (!(!e || L()(e)))
                            return (0, er.jsx)(er.Fragment, {
                              children: e.map(function (e, t) {
                                return (0, er.jsxs)(
                                  "div",
                                  {
                                    className: te().apiBox,
                                    children: [
                                      (0, er.jsxs)("div", {
                                        className: te().header,
                                        children: [
                                          (0, er.jsx)("div", {
                                            className: te().desc,
                                            children: e.desc,
                                          }),
                                          (0, er.jsxs)("div", {
                                            className: te().control,
                                            children: [
                                              (0, er.jsx)($.Z, {
                                                className: te().editButton,
                                                onClick: function () {
                                                  ea(t);
                                                },
                                                children:
                                                  u("my.account.me.edit"),
                                              }),
                                              (0, er.jsx)("img", {
                                                src: "/assets/images/account/btn_trash.svg",
                                                className: te().deleteIcon,
                                                onClick: function () {
                                                  ec(e.id);
                                                },
                                                alt: "delete",
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                      (0, er.jsxs)("div", {
                                        className: te().contentContainer,
                                        children: [
                                          (0, er.jsxs)("div", {
                                            className: te().rowType1,
                                            children: [
                                              (0, er.jsx)("div", {
                                                className: "".concat(
                                                  te().contentTitle
                                                ),
                                                children: u(
                                                  "my.account.apikey.table.header.api.key"
                                                ),
                                              }),
                                              (0, er.jsx)("div", {
                                                className: ""
                                                  .concat(te().content, " ")
                                                  .concat(te().name),
                                                children: e.name,
                                              }),
                                            ],
                                          }),
                                          Q &&
                                            (0, er.jsx)("div", {
                                              className: te().line,
                                            }),
                                          (0, er.jsxs)("div", {
                                            className: te().rowType2,
                                            children: [
                                              (0, er.jsxs)("div", {
                                                className: te().rowType1,
                                                children: [
                                                  (0, er.jsx)("div", {
                                                    className: "".concat(
                                                      te().contentTitle
                                                    ),
                                                    children: u(
                                                      "my.account.apikey.table.header.status"
                                                    ),
                                                  }),
                                                  (0, er.jsx)("div", {
                                                    className: ""
                                                      .concat(te().content, " ")
                                                      .concat(
                                                        et(
                                                          Y(e.expiry, e.status)
                                                        )
                                                      ),
                                                    children: ee(
                                                      e.expiry,
                                                      e.status
                                                    ),
                                                  }),
                                                ],
                                              }),
                                              (0, er.jsxs)("div", {
                                                className: te().rowType1,
                                                children: [
                                                  (0, er.jsx)("div", {
                                                    className: "".concat(
                                                      te().contentTitle
                                                    ),
                                                    children: u(
                                                      "my.account.apikey.table.key.create"
                                                    ),
                                                  }),
                                                  (0, er.jsx)("div", {
                                                    className: "".concat(
                                                      te().content
                                                    ),
                                                    children: en(
                                                      new Date(e.createdTime)
                                                    ),
                                                  }),
                                                ],
                                              }),
                                              (0, er.jsxs)("div", {
                                                className: te().rowType1,
                                                children: [
                                                  (0, er.jsx)("div", {
                                                    className: "".concat(
                                                      te().contentTitle
                                                    ),
                                                    children: u(
                                                      "my.account.apikey.table.key.expire"
                                                    ),
                                                  }),
                                                  (0, er.jsx)("div", {
                                                    className: "".concat(
                                                      te().content
                                                    ),
                                                    children: e.expiry
                                                      ? en(new Date(e.expiry))
                                                      : "-",
                                                  }),
                                                ],
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  },
                                  t
                                );
                              }),
                            });
                        })(z),
                  }),
                  (0, er.jsxs)($.Z, {
                    className: te().generateButton,
                    hoverClass: "hover-46e4fa",
                    touchClass: "touch-46e4fa",
                    onClick: X,
                    children: [
                      (0, er.jsx)("img", {
                        src: "/assets/images/account/apikey/icon_add.svg",
                        className: te().addIcon,
                      }),
                      u("my.account.apikey.button.generate"),
                    ],
                  }),
                ],
              }),
              (0, er.jsxs)("div", {
                className: te().apiDocumentContainer,
                children: [
                  (0, er.jsx)("h1", {
                    className: te().apiDocumentTitle,
                    children: u("my.account.apikey.document.title"),
                  }),
                  (0, er.jsx)("p", {
                    className: te().apiDocumentDescription,
                    children: u("my.account.apikey.document.desc"),
                  }),
                  (0, er.jsx)($.Z, {
                    className: te().documentButton,
                    hoverClass: "hover-with-border-46e4fa",
                    touchClass: "touch-with-border-46e4fa",
                    onClick: function () {
                      C.Z.push(o, "/document/index.html");
                    },
                    children: u("my.account.apikey.document.button"),
                  }),
                ],
              }),
              p &&
                (0, er.jsx)("div", {
                  className: te().modalContainer,
                  children: (0, er.jsxs)("div", {
                    className: (function () {
                      switch (j) {
                        case T.x5.init_api_key:
                          return te().init_api_key;
                        case T.x5.generate_api_key:
                          return te().generate_api_key;
                        case T.x5.secret_api_key:
                          return te().secret_api_key;
                        case T.x5.edit_api_key:
                          return te().edit_api_key;
                        case T.x5.first_time_entry:
                          return te().first_time_entry;
                        default:
                          return te().generate_api_key;
                      }
                    })(),
                    children: [
                      ej()(j, T.x5.init_api_key)
                        ? (0, er.jsx)(tb, { setOpen: m, setModalStatus: w })
                        : null,
                      ej()(j, T.x5.first_time_entry)
                        ? (0, er.jsx)(ta, { setOpen: m, amount: O })
                        : null,
                      ej()(j, T.x5.generate_api_key)
                        ? (0, er.jsx)(td, {
                            setOpen: m,
                            setModalStatus: w,
                            setKeys: k,
                          })
                        : null,
                      ej()(j, T.x5.secret_api_key)
                        ? (0, er.jsx)(th, { keys: y, handleCancel: J })
                        : null,
                      ej()(j, T.x5.edit_api_key)
                        ? (0, er.jsx)(tx, { setOpen: m, apiData: S })
                        : null,
                      !ej()(j, T.x5.secret_api_key) &&
                        (0, er.jsx)("img", {
                          src: "/assets/images/icon_close.svg",
                          className: te().closeIcon,
                          onClick: function () {
                            m(!1);
                          },
                        }),
                    ],
                  }),
                }),
            ],
          })
        );
      }
      var tw = n(19161),
        tC = n(23276),
        tN = n(66482),
        tD = n.n(tN),
        tS = n(99995),
        tT = n(54240),
        tA = n(78362),
        tI = n(66227),
        tR = n(21804),
        tE = n(64716),
        tP = n(67260),
        tZ = n(64505),
        tO = n.n(tZ),
        tM = n(82344),
        tB = n(22892),
        tH = n(34737),
        tF = n(72760),
        tL = n(11151),
        tK = n(52619),
        tV = n(13311),
        tz = n.n(tV),
        tG = n(40554),
        tU = n.n(tG);
      function tq(e) {
        var t,
          n,
          a,
          i,
          r = e.moduleType,
          o = e.handlePackDeleted,
          s = void 0 === o ? function () {} : o,
          u = e.handleCreditDeleted,
          d = void 0 === u ? function () {} : u,
          p = (0, _.useState)(null),
          m = p[0],
          h = p[1],
          v = (0, _.useState)(null),
          g = v[0],
          y = v[1],
          k = (0, f.I0)(),
          b = (0, f.v9)(function (e) {
            return e.avatar;
          }),
          j = (0, f.v9)(function (e) {
            return e.avatarCredit;
          }),
          w = (0, f.v9)(function (e) {
            return e.aiHeadshot;
          }),
          C = (0, f.v9)(function (e) {
            return e.aiHeadshotCredit;
          });
        (0, _.useEffect)(
          function () {
            r === ev.ft.avatar && b.deleteAvatarConfirmed && m && N();
          },
          [r, b.deleteAvatarConfirmed, m]
        ),
          (0, _.useEffect)(
            function () {
              r === ev.ft.avatar && j.deleteAvatarConfirmed && g && D();
            },
            [r, j.deleteAvatarConfirmed, g]
          ),
          (0, _.useEffect)(
            function () {
              r === ev.ft.headshot && w.deleteAiHeadshotConfirmed && m && S();
            },
            [r, w.deleteAiHeadshotConfirmed, m]
          ),
          (0, _.useEffect)(
            function () {
              r === ev.ft.headshot && C.deleteAiHeadshotConfirmed && g && T();
            },
            [r, C.deleteAiHeadshotConfirmed, g]
          );
        var N =
            ((t = (0, c.Z)(
              l().mark(function e() {
                var t, n, a, i;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          k((0, tF.dj)(!1)),
                          (t = b.packList),
                          (a = (n = tz()(t, function (e) {
                            return e.orderId === m;
                          })).effect),
                          (i = n.orderId),
                          (e.next = 6),
                          k((0, tF.cl)(a, i))
                        );
                      case 6:
                        k((0, tF.gx)(!0)), h(null), s();
                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          D =
            ((n = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        k((0, tL.lf)(!1)), k((0, eg.Iu)([g])), y(null), d();
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          S =
            ((a = (0, c.Z)(
              l().mark(function e() {
                var t, n, a, i;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          k((0, tH.JO)(!1)),
                          (t = w.packList),
                          (a = (n = tz()(t, function (e) {
                            return e.orderId === m;
                          })).effect),
                          (i = n.orderId),
                          (e.next = 6),
                          k((0, tH.HW)(a, i))
                        );
                      case 6:
                        k((0, tH.zN)(!0)), h(null), s();
                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
          T =
            ((i = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        k((0, tK.Ni)(!1)), k((0, eg.Fu)([g])), y(null), d();
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
          A = function (e) {
            if (r === ev.ft.avatar) {
              if (e === tB.A.pack) return "delete.avatar";
              if (e === tB.A.credit) return "delete.avatar.credit";
            } else {
              if (r !== ev.ft.headshot) return "";
              if (e === tB.A.pack) return "delete.aiHeadshot.pack";
              if (e === tB.A.credit) return "delete.aiHeadshot.credit";
            }
          };
        return {
          handleCellDeleteButtonClick: function (e) {
            var t = e.isPackMode,
              n = e.isCreditMode,
              a = A(t ? tB.A.pack : tB.A.credit);
            if (t)
              h(V()(e, "orderId", null)), k((0, x.Xt)({ show: !0, type: a }));
            else if (n) {
              var i = V()(e, "historyId", null);
              y(tU()(i)), k((0, x.Xt)({ show: !0, type: a }));
            }
          },
        };
      }
      var tW = n(18557),
        tQ = n.n(tW),
        tX = eC()(6),
        tJ = eC()(6);
      function tY() {
        return (0, er.jsx)("div", {
          className: tQ().packs,
          children: tX.map(function (e) {
            return (0, er.jsxs)(
              "div",
              {
                className: tQ().pack,
                children: [
                  (0, er.jsxs)("div", {
                    className: tQ().packHeader,
                    children: [
                      (0, er.jsx)("div", {
                        className: "".concat(
                          tQ().packTitle,
                          " shimmer-skeleton"
                        ),
                      }),
                      (0, er.jsx)("div", {
                        className: "".concat(
                          tQ().deleteIcon,
                          " shimmer-skeleton"
                        ),
                      }),
                    ],
                  }),
                  (0, er.jsx)("div", {
                    className: tQ().row,
                    children: tJ.map(function (e) {
                      return (0,
                      er.jsx)("div", { className: "".concat(tQ().cell, " shimmer-skeleton"), children: (0, er.jsx)("div", { className: tQ().cellPaddingTop }) }, e);
                    }),
                  }),
                ],
              },
              e
            );
          }),
        });
      }
      var t$ = n(95381),
        t0 = n.n(t$);
      function t1(e) {
        var t = e.moduleType,
          n = (0, v.useRouter)(),
          a = (0, h.PC)().t,
          i = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "/assets/images/account/aiTools/avatar/avatar_img_area.png"
                : t === ev.ft.headshot
                ? "/assets/images/account/aiTools/aiHeadshot/aiHeadshot_img_area.png"
                : "";
            },
            [t]
          ),
          r = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? a("avatar.tool.no.avatar")
                : t === ev.ft.headshot
                ? a("headshot.tool.no.headshot")
                : "";
            },
            [t]
          ),
          c = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "/avatar/create"
                : t === ev.ft.headshot
                ? "/ai-headshot-generator/create"
                : "";
            },
            [t]
          );
        return (0, er.jsx)("div", {
          className: t0().container,
          children: (0, er.jsxs)("div", {
            className: t0().flex,
            children: [
              (0, er.jsx)("img", { src: i, className: t0().emptyImg }),
              (0, er.jsx)("div", { className: t0().emptyText, children: r }),
              (0, er.jsx)("button", {
                className: t0().createButton,
                onClick: function () {
                  C.Z.push(n, c);
                },
                children: a("avatar.tool.create.button"),
              }),
            ],
          }),
        });
      }
      var t2 = n(74786),
        t4 = n.n(t2);
      function t6() {
        var e = (0, h.PC)().t;
        return (0, er.jsxs)("div", {
          className: t4().pack,
          children: [
            (0, er.jsx)("div", {
              className: t4().packHeader,
              children: (0, er.jsx)("div", {
                className: t4().packTitle,
                children: "-",
              }),
            }),
            (0, er.jsx)("div", {
              className: "".concat(t4().row, " ").concat(t4().processing),
              children: (0, er.jsx)("div", {
                className: t4().content,
                children: (0, er.jsxs)("div", {
                  className: t4().leftBlock,
                  children: [
                    (0, er.jsx)("img", {
                      src: "/assets/images/account/aiTools/yce_aiTools_loading.png",
                      className: t4().loading,
                    }),
                    (0, er.jsxs)("div", {
                      className: t4().textContainer,
                      children: [
                        (0, er.jsx)("div", {
                          className: t4().title,
                          children: e("avatar.tool.creating.checking.payment"),
                        }),
                        (0, er.jsx)("div", {
                          className: t4().description,
                          children: e(
                            "avatar.tool.creating.checking.payment.1"
                          ),
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            }),
          ],
        });
      }
      var t3 = n(15216),
        t8 = n.n(t3);
      function t5(e) {
        var t = e.moduleType,
          n = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "click_avatar_thumbnail"
                : t === ev.ft.headshot
                ? "click_aiHeadshot_thumbnail"
                : t === ev.ft.avtV3Img
                ? "click_aiStudio_thumbnail"
                : void 0;
            },
            [t]
          );
        return {
          sendGAEvent: function (e) {
            switch (e) {
              case T.k.running:
              case T.k.fail:
                (0, W.z)(n, { status: "not_ready" });
                break;
              case T.k.success:
                (0, W.z)(n, { status: "ready" });
            }
          },
        };
      }
      function t9(e) {
        var t = e.moduleType,
          n = e.result,
          a = n.packIndex,
          i = V()(n, "estDueTs", 60),
          r = (0, h.PC)().t,
          c = t5({ moduleType: t }).sendGAEvent,
          o = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? r("avatar.pack.number", { number: a + 1 })
                : t === ev.ft.headshot
                ? r("ai.headshot.pack.title") +
                  " - " +
                  r("ai.headshot.pack.number", { number: a + 1 })
                : void 0;
            },
            [t]
          ),
          s = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? r("avatar.tool.creating.avatars")
                : t === ev.ft.headshot
                ? r("aiheadshot.tool.creating.aiheadshot")
                : void 0;
            },
            [t]
          );
        return (0, er.jsxs)("div", {
          className: t8().pack,
          children: [
            (0, er.jsx)("div", {
              className: t8().packHeader,
              children: (0, er.jsx)("div", {
                className: t8().packTitle,
                children: o,
              }),
            }),
            (0, er.jsx)("div", {
              className: "".concat(t8().row, " ").concat(t8().processing),
              children: (0, er.jsxs)("div", {
                className: t8().content,
                onClick: function () {
                  return c(T.k.running);
                },
                children: [
                  (0, er.jsxs)("div", {
                    className: t8().leftBlock,
                    children: [
                      (0, er.jsx)("img", {
                        src: "/assets/images/account/aiTools/yce_aiTools_loading.png",
                        className: t8().loading,
                      }),
                      (0, er.jsxs)("div", {
                        className: t8().textContainer,
                        children: [
                          (0, er.jsx)("div", {
                            className: t8().title,
                            children: s,
                          }),
                          (0, er.jsx)("div", {
                            className: t8().description,
                            children: r("avatar.tool.creating.avatars.1"),
                          }),
                          (0, er.jsx)("div", {
                            className: t8().description,
                            children: r("avatar.tool.creating.avatars.2"),
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, er.jsx)("div", {
                    className: t8().rightBlock,
                    children: r("avatar.tool.minutes.left", {
                      minutes: Math.ceil(i / 60),
                    }),
                  }),
                ],
              }),
            }),
          ],
        });
      }
      var t7 = n(27243),
        ne = n.n(t7),
        nt = n(7739),
        nn = n.n(nt);
      function na(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, a = Array(t); n < t; n++) a[n] = e[n];
        return a;
      }
      var ni = function (e) {
        var t = nn()(e, "style_id"),
          n = Object.keys(t),
          a = [],
          i = e.length;
        if (i <= 6) return e;
        for (; a.length < 6 && i > 0; ) {
          var r,
            c = (function (e, t) {
              var n =
                ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                e["@@iterator"];
              if (!n) {
                if (
                  Array.isArray(e) ||
                  (n = (function (e, t) {
                    if (e) {
                      if ("string" == typeof e) return na(e, t);
                      var n = Object.prototype.toString.call(e).slice(8, -1);
                      if (
                        ("Object" === n &&
                          e.constructor &&
                          (n = e.constructor.name),
                        "Map" === n || "Set" === n)
                      )
                        return Array.from(e);
                      if (
                        "Arguments" === n ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                      )
                        return na(e, t);
                    }
                  })(e))
                ) {
                  n && (e = n);
                  var a = 0,
                    i = function () {};
                  return {
                    s: i,
                    n: function () {
                      return a >= e.length
                        ? { done: !0 }
                        : { done: !1, value: e[a++] };
                    },
                    e: function (e) {
                      throw e;
                    },
                    f: i,
                  };
                }
                throw TypeError(
                  "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              }
              var r,
                c = !0,
                o = !1;
              return {
                s: function () {
                  n = n.call(e);
                },
                n: function () {
                  var e = n.next();
                  return (c = e.done), e;
                },
                e: function (e) {
                  (o = !0), (r = e);
                },
                f: function () {
                  try {
                    c || null == n.return || n.return();
                  } finally {
                    if (o) throw r;
                  }
                },
              };
            })(n);
          try {
            for (c.s(); !(r = c.n()).done; ) {
              var o = r.value;
              if (t[o].length > 0 && (a.push(t[o].shift()), i--, a.length >= 6))
                break;
            }
          } catch (s) {
            c.e(s);
          } finally {
            c.f();
          }
        }
        return a;
      };
      function nr(e) {
        var t = e.moduleType,
          n = e.result,
          a = e.redDotOrderIds,
          i = e.redDotCreditIds,
          r = e.handleCellDeleteButtonClick,
          c = e.index,
          o = n.packIndex,
          s = n.orderId,
          l = n.historyId,
          u = (0, v.useRouter)(),
          d = (0, h.PC)().t,
          p = t5({ moduleType: t }).sendGAEvent,
          m = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? d("avatar.pack.number", { number: o + 1 })
                : t === ev.ft.headshot
                ? d("ai.headshot.pack.title") +
                  " - " +
                  d("ai.headshot.pack.number", { number: o + 1 })
                : void 0;
            },
            [t]
          ),
          f = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "/avatar/view"
                : t === ev.ft.headshot
                ? "/ai-headshot-generator/view"
                : void 0;
            },
            [t]
          ),
          x = (0, _.useMemo)(
            function () {
              var e = n.isPackMode,
                t = n.isCreditMode;
              return e ? j()(a, s) : t ? c < I()(i) : void 0;
            },
            [a, s, c]
          ),
          g = (0, _.useMemo)(
            function () {
              return ni(V()(n, "results.0.data", []));
            },
            [n]
          ),
          y = function () {
            var e = n.isCreditMode,
              t = n.isPackMode;
            p(T.k.success),
              e
                ? C.Z.push(u, f, { historyId: l })
                : t && C.Z.push(u, f, { orderId: s });
          };
        return (0, er.jsxs)("div", {
          className: ne().pack,
          children: [
            (0, er.jsxs)("div", {
              className: ne().packHeader,
              children: [
                (0, er.jsxs)("div", {
                  className: ne().packTitle,
                  children: [
                    m,
                    x && (0, er.jsx)("span", { className: ne().redDot }),
                  ],
                }),
                (0, er.jsx)("img", {
                  src: "/assets/images/account/btn_trash.svg",
                  className: ne().deleteButton,
                  onClick: function () {
                    return r(n);
                  },
                }),
              ],
            }),
            (0, er.jsx)("div", {
              className: ne().row,
              children: g.map(function (e, t) {
                return (0,
                er.jsx)("div", { className: ne().thumbnailBlock, onClick: y, children: (0, er.jsx)("div", { className: ne().paddingTop, children: (0, er.jsx)(eI.Z, { src: e.thumbUrl, skeletonClass: ne().thumbnailSkeleton, imageClass: ne().thumbnail }) }) }, "image-".concat(e.dstId));
              }),
            }),
          ],
        });
      }
      var nc = n(60903),
        no = n.n(nc),
        ns = {
          getHeadshotErrorMessage: function (e, t) {
            var n = V()(e, "error", "");
            return t(
              "error_no_face" === n
                ? "headshot.tool.creating.fail.no.face"
                : "error_no_shoulder" === n
                ? "headshot.tool.creating.fail.no.shoulder"
                : "error_insufficient_landmarks" === n
                ? "headshot.tool.creating.fail.no.face.landmarks"
                : "headshot.tool.creating.fail"
            );
          },
          getHeadshotContentPadding: function (e) {
            return [
              "error_no_face",
              "error_no_shoulder",
              "error_insufficient_landmarks",
            ].includes(V()(e, "error", ""))
              ? { padding: "28px 50px" }
              : { padding: "40px 50px" };
          },
        },
        nl = n(89122),
        nu = n(52628),
        nd = n.n(nu);
      function np(e) {
        var t = e.moduleType,
          n = e.orderId,
          a = e.result,
          i = a.packIndex,
          r = (0, v.useRouter)(),
          c = t5({ moduleType: t }).sendGAEvent,
          o = (0, h.PC)().t,
          s = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? o("avatar.pack.number", { number: i + 1 })
                : t === ev.ft.headshot
                ? o("ai.headshot.pack.title") +
                  " - " +
                  o("ai.headshot.pack.number", { number: i + 1 })
                : void 0;
            },
            [t]
          ),
          l = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? o("avatar.tool.creating.fail")
                : t === ev.ft.headshot
                ? ns.getHeadshotErrorMessage(a, o) ||
                  o("headshot.tool.creating.fail")
                : void 0;
            },
            [t, a, o]
          ),
          u = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "/avatar/create/(".concat(nd()(nl.Z).join("|"), ")")
                : t === ev.ft.headshot
                ? "/ai-headshot-generator/create/(".concat(
                    nd()(nl.Z).join("|"),
                    ")"
                  )
                : void 0;
            },
            [t]
          ),
          d = (0, _.useMemo)(
            function () {
              return t === ev.ft.avatar
                ? "/avatar/create"
                : t === ev.ft.headshot
                ? "/ai-headshot-generator/create"
                : void 0;
            },
            [t]
          );
        return (0, er.jsxs)("div", {
          className: no().pack,
          children: [
            (0, er.jsx)("div", {
              className: no().packHeader,
              children: (0, er.jsx)("div", {
                className: no().packTitle,
                children: s,
              }),
            }),
            (0, er.jsxs)("div", {
              className: no().failContent,
              style: ns.getHeadshotContentPadding(a),
              onClick: function () {
                return c(T.k.fail);
              },
              children: [
                (0, er.jsxs)("div", {
                  className: no().leftBlock,
                  children: [
                    (0, er.jsx)("img", {
                      src: "/assets/images/account/aiTools/yce_aiTools_failed.svg",
                      className: no().loading,
                    }),
                    (0, er.jsx)("div", {
                      className: no().textContainer,
                      children: (0, er.jsx)("div", {
                        className: no().title,
                        children: (0, er.jsx)("div", {
                          className: no().titleFlex,
                          dangerouslySetInnerHTML: {
                            __html: ex.Z.sanitize(l, "br.span"),
                          },
                        }),
                      }),
                    }),
                  ],
                }),
                (0, er.jsx)("div", {
                  className: no().rightBlock,
                  children: (0, er.jsx)($.Z, {
                    className: no().retryButton,
                    hoverClass: "hover-with-border-46e4fa",
                    touchClass: "touch-with-border-46e4fa",
                    onClick: function () {
                      var e = RegExp(u).test(r.asPath);
                      C.Z.push(r, d, { orderId: n }, e);
                    },
                    children: o("avatar.tool.creating.fail.button"),
                  }),
                }),
              ],
            }),
          ],
        });
      }
      function nm(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, a = Array(t); n < t; n++) a[n] = e[n];
        return a;
      }
      n(89734), n(31351), n(12571), n(50361), n(35161);
      var nh = ev.ft.avatar;
      function n_(e) {
        var t,
          n,
          a,
          i,
          r,
          o = e.showLoadingSkeleton,
          s = e.avatarLoadedData,
          u = e.showAvatarRedDotOrderIds,
          d = e.setShowAvatarRedDotOrderIds,
          p = e.showAvatarCreditRedDot,
          m = e.setShowAvatarCreditRedDot,
          h = (0, _.useState)(!1),
          x = h[0],
          g = h[1],
          y = (0, v.useRouter)(),
          k = (0, _.useRef)(null),
          b = (0, _.useRef)(null),
          j = (0, f.v9)(function (e) {
            return e.avatar;
          }),
          C = j.newTaskRunning,
          N = (0, f.v9)(function (e) {
            return e.user;
          }),
          D = V()(N, "userInfo.userId", null),
          S = (0, tM.Z)({ moduleType: nh }).isPackOrderInProcess,
          A = (0, w.Z)({
            localStorageKey: tk.XC.avatarSubsProcessStartTime,
          }).isCheckingTimeExpired,
          I = tq({
            moduleType: nh,
            handlePackDeleted: (function (e) {
              function t() {
                return e.apply(this, arguments);
              }
              return (
                (t.toString = function () {
                  return e.toString();
                }),
                t
              );
            })(function () {
              return Z();
            }),
            handleCreditDeleted: (function (e) {
              function t() {
                return e.apply(this, arguments);
              }
              return (
                (t.toString = function () {
                  return e.toString();
                }),
                t
              );
            })(function () {
              return O();
            }),
          }).handleCellDeleteButtonClick;
        (0, _.useEffect)(
          function () {
            y.isReady && N.checked && (!A() || C ? g(!0) : g(!1));
          },
          [y.isReady, N.checked, S, j.packResults, C]
        ),
          (0, _.useEffect)(function () {
            return (
              window.addEventListener("beforeunload", P),
              function () {
                window.removeEventListener("beforeunload", P),
                  R(),
                  d([]),
                  m([]),
                  E();
              }
            );
          }, []);
        var R =
            ((t = (0, c.Z)(
              l().mark(function e() {
                var t, n, a, i;
                return l().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2), (0, eA.Os)(eA.H$.yceAvatarPackRedDot)
                          );
                        case 2:
                          if ((t = e.sent)) {
                            e.next = 5;
                            break;
                          }
                          return e.abrupt("return");
                        case 5:
                          (n = (function (e, t) {
                            var n =
                              ("undefined" != typeof Symbol &&
                                e[Symbol.iterator]) ||
                              e["@@iterator"];
                            if (!n) {
                              if (
                                Array.isArray(e) ||
                                (n = (function (e, t) {
                                  if (e) {
                                    if ("string" == typeof e) return nm(e, t);
                                    var n = Object.prototype.toString
                                      .call(e)
                                      .slice(8, -1);
                                    if (
                                      ("Object" === n &&
                                        e.constructor &&
                                        (n = e.constructor.name),
                                      "Map" === n || "Set" === n)
                                    )
                                      return Array.from(e);
                                    if (
                                      "Arguments" === n ||
                                      /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                        n
                                      )
                                    )
                                      return nm(e, t);
                                  }
                                })(e))
                              ) {
                                n && (e = n);
                                var a = 0,
                                  i = function () {};
                                return {
                                  s: i,
                                  n: function () {
                                    return a >= e.length
                                      ? { done: !0 }
                                      : { done: !1, value: e[a++] };
                                  },
                                  e: function (e) {
                                    throw e;
                                  },
                                  f: i,
                                };
                              }
                              throw TypeError(
                                "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                              );
                            }
                            var r,
                              c = !0,
                              o = !1;
                            return {
                              s: function () {
                                n = n.call(e);
                              },
                              n: function () {
                                var e = n.next();
                                return (c = e.done), e;
                              },
                              e: function (e) {
                                (o = !0), (r = e);
                              },
                              f: function () {
                                try {
                                  c || null == n.return || n.return();
                                } finally {
                                  if (o) throw r;
                                }
                              },
                            };
                          })(u)),
                            (e.prev = 6),
                            n.s();
                        case 8:
                          if ((a = n.n()).done) {
                            e.next = 20;
                            break;
                          }
                          return (
                            (i = a.value),
                            (e.prev = 10),
                            (e.next = 13),
                            t.putData(i, T.k.success)
                          );
                        case 13:
                          e.next = 18;
                          break;
                        case 15:
                          (e.prev = 15),
                            (e.t0 = e.catch(10)),
                            console.error(
                              "Failed to put data for orderId: ".concat(i),
                              e.t0
                            );
                        case 18:
                          e.next = 8;
                          break;
                        case 20:
                          e.next = 25;
                          break;
                        case 22:
                          (e.prev = 22), (e.t1 = e.catch(6)), n.e(e.t1);
                        case 25:
                          return (e.prev = 25), n.f(), e.finish(25);
                        case 28:
                          t.close();
                        case 29:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [
                    [6, 22, 25, 28],
                    [10, 15],
                  ]
                );
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          E =
            ((n = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (0, eA.tp)(eA.H$.yceAvatarCreditRedDot, D)
                        );
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          P =
            ((a = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), R();
                      case 2:
                        return (e.next = 4), E();
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
          Z =
            ((i = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
          O =
            ((r = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), E();
                      case 2:
                        m([]);
                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return r.apply(this, arguments);
            }),
          M = function (e) {
            var t = e.isCreditMode,
              n = e.isPackMode;
            return t
              ? (null == e ? void 0 : e.status) === T.k.success
              : n
              ? (null == e ? void 0 : e.packStatus) === T.k.success
              : void 0;
          },
          B = function (e) {
            var t = e.isCreditMode,
              n = e.isPackMode;
            return t
              ? (null == e ? void 0 : e.status) === T.k.running
              : n
              ? (null == e ? void 0 : e.packStatus) === T.k.running
              : void 0;
          };
        return o
          ? (0, er.jsx)(tY, {})
          : L()(s) && A()
          ? (0, er.jsx)(t1, { moduleType: nh })
          : (0, er.jsx)("div", {
              className: tO().container,
              ref: k,
              children: (0, er.jsx)("div", {
                className: tO().packsContainer,
                ref: b,
                children: (0, er.jsxs)("div", {
                  className: tO().packs,
                  children: [
                    x && (0, er.jsx)(t6, {}),
                    s.map(function (e, t) {
                      return (0,
                      er.jsx)(_.Fragment, { children: B(e) ? (0, er.jsx)(t9, { moduleType: nh, result: e }) : M(e) ? (0, er.jsx)(nr, { moduleType: nh, result: e, redDotOrderIds: u, redDotCreditIds: p, handleCellDeleteButtonClick: I, index: t }) : (0, er.jsx)(np, { moduleType: nh, orderId: e.orderId, result: e }) }, e.packIndex);
                    }),
                  ],
                }),
              }),
            });
      }
      var nf = n(41581),
        nx = n.n(nf);
      function nv(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, a = Array(t); n < t; n++) a[n] = e[n];
        return a;
      }
      n(18721), n(6162), n(84486);
      var ng = ev.ft.headshot;
      function ny(e) {
        var t,
          n,
          a,
          i,
          r,
          o = e.showLoadingSkeleton,
          s = e.aiHeadshotLoadedData,
          u = e.showAiHeadshotRedDotOrderIds,
          d = e.setShowAiHeadshotRedDotOrderIds,
          p = e.showAiHeadshotCreditRedDot,
          m = e.setShowAiHeadshotCreditRedDot,
          h = (0, _.useState)(!1),
          x = h[0],
          g = h[1],
          y = (0, v.useRouter)(),
          k = (0, _.useRef)(null),
          b = (0, _.useRef)(null),
          j = (0, f.v9)(function (e) {
            return e.aiHeadshot;
          }),
          C = j.newTaskRunning,
          N = (0, f.v9)(function (e) {
            return e.user;
          }),
          D = V()(N, "userInfo.userId", null),
          S = (0, tM.Z)({ moduleType: ng }).isPackOrderInProcess,
          A = (0, w.Z)({
            localStorageKey: tk.XC.aiHeadshotSubsProcessStartTime,
          }).isCheckingTimeExpired,
          I = tq({
            moduleType: ng,
            handlePackDeleted: (function (e) {
              function t() {
                return e.apply(this, arguments);
              }
              return (
                (t.toString = function () {
                  return e.toString();
                }),
                t
              );
            })(function () {
              return Z();
            }),
            handleCreditDeleted: (function (e) {
              function t() {
                return e.apply(this, arguments);
              }
              return (
                (t.toString = function () {
                  return e.toString();
                }),
                t
              );
            })(function () {
              return O();
            }),
          }).handleCellDeleteButtonClick;
        (0, _.useEffect)(
          function () {
            y.isReady && N.checked && (!A() || C ? g(!0) : g(!1));
          },
          [y.isReady, N.checked, S, j.packResults, C]
        ),
          (0, _.useEffect)(function () {
            return (
              window.addEventListener("beforeunload", P),
              function () {
                window.removeEventListener("beforeunload", P),
                  R(),
                  d([]),
                  m([]),
                  E();
              }
            );
          }, []);
        var R =
            ((t = (0, c.Z)(
              l().mark(function e() {
                var t, n, a, i;
                return l().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            (0, eA.Os)(eA.H$.yceAiHeadshotPackRedDot)
                          );
                        case 2:
                          if ((t = e.sent)) {
                            e.next = 5;
                            break;
                          }
                          return e.abrupt("return");
                        case 5:
                          (n = (function (e, t) {
                            var n =
                              ("undefined" != typeof Symbol &&
                                e[Symbol.iterator]) ||
                              e["@@iterator"];
                            if (!n) {
                              if (
                                Array.isArray(e) ||
                                (n = (function (e, t) {
                                  if (e) {
                                    if ("string" == typeof e) return nv(e, t);
                                    var n = Object.prototype.toString
                                      .call(e)
                                      .slice(8, -1);
                                    if (
                                      ("Object" === n &&
                                        e.constructor &&
                                        (n = e.constructor.name),
                                      "Map" === n || "Set" === n)
                                    )
                                      return Array.from(e);
                                    if (
                                      "Arguments" === n ||
                                      /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                        n
                                      )
                                    )
                                      return nv(e, t);
                                  }
                                })(e))
                              ) {
                                n && (e = n);
                                var a = 0,
                                  i = function () {};
                                return {
                                  s: i,
                                  n: function () {
                                    return a >= e.length
                                      ? { done: !0 }
                                      : { done: !1, value: e[a++] };
                                  },
                                  e: function (e) {
                                    throw e;
                                  },
                                  f: i,
                                };
                              }
                              throw TypeError(
                                "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                              );
                            }
                            var r,
                              c = !0,
                              o = !1;
                            return {
                              s: function () {
                                n = n.call(e);
                              },
                              n: function () {
                                var e = n.next();
                                return (c = e.done), e;
                              },
                              e: function (e) {
                                (o = !0), (r = e);
                              },
                              f: function () {
                                try {
                                  c || null == n.return || n.return();
                                } finally {
                                  if (o) throw r;
                                }
                              },
                            };
                          })(u)),
                            (e.prev = 6),
                            n.s();
                        case 8:
                          if ((a = n.n()).done) {
                            e.next = 20;
                            break;
                          }
                          return (
                            (i = a.value),
                            (e.prev = 10),
                            (e.next = 13),
                            t.putData(i, T.k.success)
                          );
                        case 13:
                          e.next = 18;
                          break;
                        case 15:
                          (e.prev = 15),
                            (e.t0 = e.catch(10)),
                            console.error(
                              "Failed to put data for orderId: ".concat(i),
                              e.t0
                            );
                        case 18:
                          e.next = 8;
                          break;
                        case 20:
                          e.next = 25;
                          break;
                        case 22:
                          (e.prev = 22), (e.t1 = e.catch(6)), n.e(e.t1);
                        case 25:
                          return (e.prev = 25), n.f(), e.finish(25);
                        case 28:
                          t.close();
                        case 29:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [
                    [6, 22, 25, 28],
                    [10, 15],
                  ]
                );
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          E =
            ((n = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (0, eA.tp)(eA.H$.yceAiHeadshotCreditRedDot, D)
                        );
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          P =
            ((a = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), R();
                      case 2:
                        return (e.next = 4), E();
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
          Z =
            ((i = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
          O =
            ((r = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), E();
                      case 2:
                        m([]);
                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return r.apply(this, arguments);
            }),
          M = function (e) {
            var t = e.isCreditMode,
              n = e.isPackMode;
            return t
              ? (null == e ? void 0 : e.status) === T.k.success
              : n
              ? (null == e ? void 0 : e.packStatus) === T.k.success
              : void 0;
          },
          B = function (e) {
            var t = e.isCreditMode,
              n = e.isPackMode;
            return t
              ? (null == e ? void 0 : e.status) === T.k.running
              : n
              ? (null == e ? void 0 : e.packStatus) === T.k.running
              : void 0;
          };
        return o
          ? (0, er.jsx)(tY, {})
          : L()(s) && A()
          ? (0, er.jsx)(t1, { moduleType: ev.ft.headshot })
          : (0, er.jsx)("div", {
              className: nx().container,
              ref: k,
              children: (0, er.jsx)("div", {
                className: nx().packsContainer,
                ref: b,
                children: (0, er.jsxs)("div", {
                  className: nx().packs,
                  children: [
                    x && (0, er.jsx)(t6, {}),
                    s.map(function (e, t) {
                      return (0,
                      er.jsx)(_.Fragment, { children: B(e) ? (0, er.jsx)(t9, { moduleType: ng, result: e }) : M(e) ? (0, er.jsx)(nr, { moduleType: ng, result: e, redDotOrderIds: u, redDotCreditIds: p, handleCellDeleteButtonClick: I, index: t }) : (0, er.jsx)(np, { moduleType: ng, orderId: e.orderId, result: e }) }, e.packIndex);
                    }),
                  ],
                }),
              }),
            });
      }
      var nk = n(12497),
        nb = n.n(nk),
        nj = n(23387);
      function nw(e) {
        var t,
          n,
          a,
          i,
          r = e.data,
          o = e.showAiStudioRedDot,
          s = e.setShowAiStudioRedDot,
          u = e.initialized,
          d = e.diffLength,
          p = (0, h.PC)().t,
          m = (0, f.I0)(),
          g = (0, v.useRouter)(),
          y = (0, _.useRef)(null),
          k = (0, f.v9)(function (e) {
            return e.user;
          }),
          b = V()(k, "userInfo.userId", null),
          j = (0, f.v9)(function (e) {
            return e.aiStudio;
          }),
          w = j.pollingList,
          N = j.pollingData,
          D = (0, _.useState)(null),
          S = D[0],
          T = D[1];
        (0, _.useEffect)(function () {
          return (
            window.addEventListener("beforeunload", E),
            function () {
              window.removeEventListener("beforeunload", E),
                R(),
                s([]),
                A(),
                I();
            }
          );
        }, []);
        var A =
            ((t = (0, c.Z)(
              l().mark(function e() {
                var t;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (t = new eA.ZP(eA.H$.yceAiStudioCompletedTask)),
                          (e.next = 3),
                          t.delete()
                        );
                      case 3:
                        return (e.next = 5), t.close();
                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          I =
            ((n = (0, c.Z)(
              l().mark(function e() {
                var t;
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (t = new eA.ZP(eA.H$.yceAiStudioTask2HistoryList)),
                          (e.next = 3),
                          t.delete()
                        );
                      case 3:
                        return (e.next = 5), t.close();
                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          R =
            ((a = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2), (0, eA.tp)(eA.H$.yceAiStudioRedDot, b)
                        );
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
          E =
            ((i = (0, c.Z)(
              l().mark(function e() {
                return l().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), R();
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
          P = function (e) {
            C.Z.push(g, "/ai-portrait-generator/view", { historyId: e });
          },
          O = function (e) {
            T(e), m((0, x.Xt)({ show: !0, type: "delete.aiStudio.pack" }));
          };
        (0, _.useEffect)(
          function () {
            var e,
              t =
                ((e = (0, c.Z)(
                  l().mark(function e() {
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if ((m((0, nj.il)(!1)), !S)) {
                              e.next = 6;
                              break;
                            }
                            return m((0, eg.DL)([S])), (e.next = 5), R();
                          case 5:
                            s([]);
                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function () {
                  return e.apply(this, arguments);
                });
            j.deleteAiStudioConfirmed && t(), T(null);
          },
          [j.deleteAiStudioConfirmed]
        );
        var M = o.length;
        return (0, er.jsx)(er.Fragment, {
          children: u
            ? (0, er.jsx)(er.Fragment, {
                children:
                  w.length > 0 || r.length > 0
                    ? (0, er.jsx)("div", {
                        className: nb().container,
                        children: (0, er.jsx)("div", {
                          className: nb().packsContainer,
                          children: (0, er.jsxs)("div", {
                            className: nb().packs,
                            children: [
                              (0, Z.Z)(w)
                                .reverse()
                                .map(function (e, t) {
                                  var n = V()(N, e, null),
                                    a = V()(n, "result.estDueTs", null);
                                  return (0,
                                  er.jsxs)("div", { className: nb().pack, children: [(0, er.jsx)("div", { className: nb().packHeader }), (0, er.jsx)("div", { className: "".concat(nb().row, " ").concat(nb().processing), ref: y, children: (0, er.jsxs)("div", { className: nb().content, children: [(0, er.jsxs)("div", { className: "".concat(nb().leftBlock), children: [(0, er.jsx)("img", { src: "/assets/images/account/aiTools/yce_aiTools_loading.png", className: nb().loading }), (0, er.jsxs)("div", { className: nb().textContainer, children: [(0, er.jsx)("div", { className: nb().title, children: p("aiheadshot.tool.creating.aiheadshot") }), (0, er.jsx)("div", { className: nb().description, children: p("avatar.tool.creating.avatars.1") }), (0, er.jsx)("div", { className: nb().description, children: p("video.editing.creating.video") })] })] }), a && (0, er.jsx)("div", { className: nb().rightBlock, children: p(a < 60 ? "avatar.tool.within.a.minute.left" : 60 === a ? "avatar.tool.minute.left" : "avatar.tool.minutes.left", { minutes: Math.ceil(a / 60) }) })] }) })] }, "r" + t);
                                }),
                              Array.from({ length: d }).map(function (e, t) {
                                return (0, er.jsxs)(
                                  "div",
                                  {
                                    className: tQ().pack,
                                    children: [
                                      (0, er.jsxs)("div", {
                                        className: tQ().packHeader,
                                        children: [
                                          (0, er.jsx)("div", {
                                            className: "".concat(
                                              tQ().packTitle,
                                              " shimmer-skeleton"
                                            ),
                                          }),
                                          (0, er.jsx)("div", {
                                            className: "".concat(
                                              tQ().deleteIcon,
                                              " shimmer-skeleton"
                                            ),
                                          }),
                                        ],
                                      }),
                                      (0, er.jsx)("div", {
                                        className: tQ().row,
                                        children: eC()(6).map(function (e) {
                                          return (0,
                                          er.jsx)("div", { className: "".concat(tQ().cell, " shimmer-skeleton"), children: (0, er.jsx)("div", { className: tQ().cellPaddingTop }) }, e);
                                        }),
                                      }),
                                    ],
                                  },
                                  t
                                );
                              }),
                              r.map(function (e, t) {
                                var n = V()(e, "result.results.0.data", []);
                                return (0, er.jsxs)(
                                  "div",
                                  {
                                    className: "".concat(nb().pack),
                                    children: [
                                      (0, er.jsxs)("div", {
                                        className: nb().packHeader,
                                        children: [
                                          (0, er.jsxs)("div", {
                                            className: nb().packTitle,
                                            children: [
                                              p(
                                                "my.account.history.tab.ai.studio"
                                              ),
                                              " - ",
                                              p("ai.headshot.pack.number", {
                                                number: r.length - t,
                                              }),
                                              t < M - d &&
                                                (0, er.jsx)("span", {
                                                  className: nb().redDot,
                                                }),
                                            ],
                                          }),
                                          (0, er.jsx)("img", {
                                            src: "/assets/images/account/btn_trash.svg",
                                            className: nb().deleteButton,
                                            onClick: function () {
                                              return O(e.id);
                                            },
                                          }),
                                        ],
                                      }),
                                      (0, er.jsx)("div", {
                                        className: "".concat(nb().row),
                                        onClick: function () {
                                          return P(e.id);
                                        },
                                        children: ni(n).map(function (e) {
                                          return (0,
                                          er.jsx)("div", { className: nb().thumbnailBlock, children: (0, er.jsx)("div", { className: nb().paddingTop, children: (0, er.jsx)(eI.Z, { src: e.thumbUrl, imageClass: nb().thumbnail }) }) }, "image-".concat(t, "-").concat(e.resIdx));
                                        }),
                                      }),
                                    ],
                                  },
                                  "r" + t
                                );
                              }),
                            ],
                          }),
                        }),
                      })
                    : (0, er.jsx)("div", {
                        className: nb().noAvatarContainer,
                        children: (0, er.jsxs)("div", {
                          className: nb().flex,
                          children: [
                            (0, er.jsx)("img", {
                              src: "/assets/images/account/aiTools/aiStudio/AI_studio_img_area.png",
                              className: nb().noAvatarImg,
                            }),
                            (0, er.jsx)("div", {
                              className: nb().noAvatarText,
                              children: p("ai.studio.tool.no.ai.studio"),
                            }),
                            (0, er.jsx)("button", {
                              className: nb().createButton,
                              onClick: function () {
                                return C.Z.push(
                                  g,
                                  "/ai-portrait-generator/create"
                                );
                              },
                              children: p("avatar.tool.create.button"),
                            }),
                          ],
                        }),
                      }),
              })
            : (0, er.jsx)(tY, {}),
        });
      }
      var nC =
        ((i = {}),
        (0, o.Z)(i, T._G.avatar, {
          basePath: "/account/artwork",
          pathSuffix: "?type=avatar",
          queryKey: "type",
          queryValue: "avatar",
        }),
        (0, o.Z)(i, T._G.aiHeadshot, {
          basePath: "/account/artwork",
          pathSuffix: "?type=headshot",
          queryKey: "type",
          queryValue: "headshot",
        }),
        (0, o.Z)(i, T._G.aiStudio, {
          basePath: "/account/artwork",
          pathSuffix: "?type=aistudio",
          queryKey: "type",
          queryValue: "aistudio",
        }),
        i);
      function nN(e) {
        var t = e.setShowAvatarRedDotOrderIds,
          n = e.showAvatarRedDotOrderIds,
          a = e.showAiHeadshotRedDotOrderIds,
          i = e.setShowAiHeadshotRedDotOrderIds,
          r = e.showAiStudioRedDot,
          c = e.setShowAiStudioRedDot,
          o = e.showAvatarCreditRedDot,
          s = e.setShowAvatarCreditRedDot,
          l = e.showAiHeadshotCreditRedDot,
          u = e.setShowAiHeadshotCreditRedDot,
          d = e.aiToolstab,
          p = e.setAiToolsTab,
          m = (0, _.useMemo)(
            function () {
              return ej()(d, T._G.avatar);
            },
            [d]
          ),
          f = (0, _.useMemo)(
            function () {
              return ej()(d, T._G.aiHeadshot);
            },
            [d]
          ),
          x = (0, _.useMemo)(
            function () {
              return ej()(d, T._G.aiStudio);
            },
            [d]
          ),
          v = (0, _.useRef)(!1),
          g = (0, h.PC)(),
          y = g.t,
          k = g.locale,
          b = (0, tS.Z)({ isAvatarCredit: m }),
          j = b.avatarCreditDataInitialized,
          w = b.filteredData4AvatarCredit;
        b.diffLengthForAvatarCredit;
        var C = (0, tT.Z)(),
          N = C.avatarPackDataInitialized,
          D = C.filteredData4AvatarPack,
          S = (0, tA.Z)({
            isAvatar: m,
            creditData: w,
            creditDataInitialized: j,
            packData: D,
            packDataInitialized: N,
          }),
          A = S.avatarLoadedData,
          R = S.showAvatarLoadingSkeleton,
          E = (0, tI.Z)({ isAiHeadshotCredit: f }),
          P = E.aiHeadshotCreditDataInitialized,
          Z = E.filteredData4AiHeadshotCredit;
        E.diffLengthForAiHeadshotCredit;
        var O = (0, tR.Z)(),
          M = O.aiHeadshotPackDataInitialized,
          B = O.filteredData4AiHeadshotPack,
          H = (0, tE.Z)({
            isAiHeadshot: f,
            creditData: Z,
            creditDataInitialized: P,
            packData: B,
            packDataInitialized: M,
          }),
          F = H.aiHeadshotLoadedData,
          L = H.showAiHeadshotLoadingSkeleton,
          K = (0, tP.Z)({ isAiStudio: x }),
          V = K.aiStudioDataInitialized,
          z = K.filteredData4AiStudio,
          G = K.diffLengthForAiStudio,
          U = eq({ tabMap: nC, setTab: p, isManualChange: v }).handleSetTab,
          q = [
            {
              name: y("header.items.product.avatar.for.feature.panel"),
              isActive: m,
              tabKey: T._G.avatar,
              showRedDot: I()(n) || I()(o) > 0,
            },
            {
              name: y("my.account.history.tab.ai.headshot.generator"),
              isActive: f,
              tabKey: T._G.aiHeadshot,
              showRedDot: I()(a) || I()(l) > 0,
            },
            {
              name: y("my.account.history.tab.ai.studio"),
              isActive: x,
              tabKey: T._G.aiStudio,
              showRedDot: I()(r) > 0,
            },
          ],
          W = (0, _.useMemo)(
            function () {
              return "pt" === k ? tD().specialTabs : "";
            },
            [k]
          ),
          Q = (0, _.useMemo)(
            function () {
              return "pt" === k ? tD().specialTab : "";
            },
            [k]
          );
        return (0, er.jsxs)("div", {
          className: tD().container,
          children: [
            (0, er.jsx)("div", {
              className: tD().tabHeader,
              children: (0, er.jsx)("div", {
                className: "".concat(tD().tabs, " ").concat(W),
                children: q.map(function (e, t) {
                  return (0, er.jsxs)(
                    "div",
                    {
                      className: ""
                        .concat(tD().tab, " ")
                        .concat(Q, " ")
                        .concat(e.isActive && tD().tabActive),
                      onClick: function () {
                        return U(e.tabKey);
                      },
                      children: [
                        e.name,
                        e.showRedDot &&
                          (0, er.jsx)("span", { className: tD().redDot }),
                      ],
                    },
                    t
                  );
                }),
              }),
            }),
            (0, er.jsx)("div", {
              className: tD().cellsContainer,
              children: (0, er.jsxs)("div", {
                className: tD().cells,
                children: [
                  m &&
                    (0, er.jsx)(n_, {
                      showLoadingSkeleton: R,
                      avatarLoadedData: A,
                      setShowAvatarRedDotOrderIds: t,
                      showAvatarRedDotOrderIds: n,
                      showAvatarCreditRedDot: o,
                      setShowAvatarCreditRedDot: s,
                    }),
                  f &&
                    (0, er.jsx)(ny, {
                      showLoadingSkeleton: L,
                      aiHeadshotLoadedData: F,
                      showAiHeadshotRedDotOrderIds: a,
                      setShowAiHeadshotRedDotOrderIds: i,
                      showAiHeadshotCreditRedDot: l,
                      setShowAiHeadshotCreditRedDot: u,
                    }),
                  x &&
                    (0, er.jsx)(nw, {
                      data: z,
                      showAiStudioRedDot: r,
                      setShowAiStudioRedDot: c,
                      initialized: V,
                      diffLength: G,
                    }),
                ],
              }),
            }),
          ],
        });
      }
      var nD = n(92181),
        nS = n(45820),
        nT = n(46009),
        nA = n(83493),
        nI = n(54818),
        nR = n(25915),
        nE = n(28510),
        nP = n(15850),
        nZ =
          ((r = {}),
          (0, o.Z)(r, T.gP.account, {
            basePath: "/account",
            pathSuffix: "",
            queryKey: "",
            queryValue: "",
          }),
          (0, o.Z)(r, T.gP.gallery, {
            basePath: "/account",
            pathSuffix: "/gallery",
            queryKey: "",
            queryValue: "",
          }),
          (0, o.Z)(r, T.gP.aiTools, {
            basePath: "/account",
            pathSuffix: "/artwork",
            queryKey: "",
            queryValue: "",
          }),
          (0, o.Z)(r, T.gP.settings, {
            basePath: "/account",
            pathSuffix: "/settings",
            queryKey: "",
            queryValue: "",
          }),
          (0, o.Z)(r, T.gP.apikey, {
            basePath: "/account",
            pathSuffix: "/apikey",
            queryKey: "",
            queryValue: "",
          }),
          r);
      function nO(e) {
        var t,
          n,
          a,
          i,
          r,
          o,
          s,
          u,
          y,
          b,
          A,
          R,
          Z,
          O,
          M,
          B,
          H,
          F,
          L,
          K,
          V,
          z = e.cmsUseCaseMenu,
          G = (0, h.PC)().t,
          U = (0, f.I0)(),
          q = (0, _.useState)(!1),
          W = q[0],
          Q = q[1],
          X = (0, _.useState)(!1),
          J = X[0],
          Y = X[1],
          $ = (0, _.useState)(T._G.avatar),
          ee = $[0],
          et = $[1],
          en = (0, _.useRef)(null),
          ea = (0, _.useRef)(null),
          ei = (0, _.useRef)(null),
          ec = (0, _.useRef)(null),
          eo = (0, _.useRef)(null),
          es = (0, _.useRef)(null),
          el = (0, _.useRef)(null),
          ed = (0, _.useRef)(null),
          ep = (0, _.useRef)(null),
          em = (0, _.useRef)(null),
          eh = (0, P.Z)(),
          e_ = (0, v.useRouter)(),
          ef = e_.asPath,
          ex = ((a =
            void 0 ===
            (n = {
              cb:
                ((t = (0, c.Z)(
                  l().mark(function e() {
                    var t = arguments;
                    return l().wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (!(t.length > 0 && void 0 !== t[0] && t[0])) {
                              e.next = 8;
                              break;
                            }
                            return (e.next = 4), tw.Z.sleep(500);
                          case 4:
                            return (e.next = 6), U((0, N.OZ)());
                          case 6:
                            return (e.next = 8), U((0, N.LP)());
                          case 8:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  })
                )),
                function () {
                  return t.apply(this, arguments);
                }),
            }.cb)
              ? null
              : n),
          (i = (0, D.Z)().isInSubscriptionFunc),
          (o = (r = (0, w.Z)()).setSubscriptionProcessStartTime),
          (s = r.clearSubscriptionProcessStartTime),
          (u = r.sendSubscriptionSuccessEvent),
          (y = r.sendSubscriptionTrackLog),
          (b = (0, v.useRouter)()),
          (A = (0, f.I0)()),
          (R = (0, f.v9)(function (e) {
            return e.user;
          })),
          (O = (Z = (0, _.useState)(!1))[0]),
          (M = Z[1]),
          (0, _.useEffect)(
            function () {
              if (b.isReady) {
                var e = b.query,
                  t = e.upgrade,
                  n = e.subscribe,
                  a = e.pay,
                  i = e.groupId,
                  r = (0, g.Z)(e, S);
                if (t || n || a) {
                  var c = k()(
                    { upgrade: t, subscribe: n, pay: a },
                    function (e) {
                      return "true" === e;
                    }
                  );
                  if (j()(["upgrade", "subscribe", "pay"], c)) {
                    if ((A((0, x.Iq)(!0)), !R.checked)) return;
                    y("endCheckOut"),
                      o(),
                      setTimeout(function () {
                        H(i, function () {
                          return F(c, i);
                        });
                      }, 3e3),
                      C.Z.shallowReplace(b, r);
                  }
                }
              }
            },
            [b.isReady, R.checked]
          ),
          (B = (0, c.Z)(
            l().mark(function e(t) {
              var n,
                a = arguments;
              return l().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (n =
                          a.length > 1 && void 0 !== a[1]
                            ? a[1]
                            : function () {}),
                        (e.next = 3),
                        A((0, N.Io)())
                      );
                    case 3:
                      if (!i(e.sent.results, t)) {
                        e.next = 11;
                        break;
                      }
                      return A((0, x.Iq)(!1)), e.abrupt("return", n && n());
                    case 11:
                      setTimeout(
                        (0, c.Z)(
                          l().mark(function e() {
                            return l().wrap(function (e) {
                              for (;;)
                                switch ((e.prev = e.next)) {
                                  case 0:
                                    return (e.next = 2), H(t, n);
                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                          })
                        ),
                        3e3
                      );
                    case 12:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          )),
          (H = function (e) {
            return B.apply(this, arguments);
          }),
          (F = function (e, t) {
            var n = L(e);
            A((0, x.CH)({ type: n, show: !0 })),
              s(),
              u({}, t),
              y("subscribed"),
              M(!0),
              a && a(!0);
          }),
          (L = function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "";
            switch (e) {
              case "subscribe":
                return e;
              case "upgrade":
                return "upgraded";
              case "pay":
                return "pay.as.you.go";
              default:
                return "";
            }
          }),
          { reGetSubData: O, setReGetSubData: M }).reGetSubData,
          ev = (0, tC.Z)(),
          eg = ev.updateSourcePage,
          ey = ev.updateSourceButton4PricingIcon,
          ek = (0, nI.Z)(),
          eb = ek.showAvatarRedDot,
          ew = ek.showAiHeadshotRedDot,
          eC = ek.setShowAvatarRedDot,
          eN = ek.setShowAiHeadshotRedDot,
          eD = (0, nD.Z)(),
          eS = eD.showVideoEnhanceRedDot,
          eT = eD.setShowVideoEnhanceRedDot,
          eA = (0, nE.Z)(),
          eI = eA.showAiVideoFiltersRedDot,
          eR = eA.setShowAiVideoFiltersRedDot,
          eE = (0, nP.Z)(),
          eP = eE.showVideoFaceSwapRedDot,
          eZ = eE.setShowVideoFaceSwapRedDot,
          eO = (0, nS.Z)(),
          eM = eO.showAiStudioRedDot,
          eB = eO.setShowAiStudioRedDot,
          eH = (0, nT.Z)(),
          eF = eH.showAvatarCreditRedDot,
          eL = eH.setShowAvatarCreditRedDot,
          eK = (0, nA.Z)(),
          eV = eK.showAiHeadshotCreditRedDot,
          ez = eK.setShowAiHeadshotCreditRedDot,
          eG = (0, nR.Z)().isGuest;
        (0, _.useEffect)(function () {
          eg(), ey();
        }, []);
        var eU = (0, _.useMemo)(
            function () {
              return j()(ef, T.gP.gallery)
                ? T.gP.gallery
                : j()(ef, T.gP.aiTools)
                ? T.gP.aiTools
                : j()(ef, T.gP.settings)
                ? T.gP.settings
                : j()(ef, T.gP.apikey)
                ? T.gP.apikey
                : T.gP.account;
            },
            [ef]
          ),
          eW = eq({ tabMap: nZ, querySwitch: !1 }).handleSetTab;
        (0, _.useEffect)(
          function () {
            if (e_.isReady && eG) {
              var e,
                t = (e_.query || {}).locale,
                n = "/".concat(
                  (void 0 === t ? "en-us" : t).replace("en-us", "")
                );
              null !== (e = window) &&
                void 0 !== e &&
                e.location &&
                setTimeout(function () {
                  return (window.location.href = n);
                }, 500);
            }
          },
          [e_.isReady, eG]
        ),
          (0, _.useEffect)(
            function () {
              e_.isReady && en && en.current && en.current.scrollTo(0, 0);
            },
            [e_.isReady, eU]
          );
        var eQ = E()(function () {
          if (en.current) {
            var e = en.current.offsetHeight,
              t = en.current.offsetTop + e,
              n = window.scrollY + window.innerHeight;
            n > t - 160 &&
              ej()(eU, T.gP.gallery) &&
              (Q(!0),
              setTimeout(function () {
                Q(!1);
              }, 1e3)),
              n > t - 1e3 &&
                ej()(eU, T.gP.apikey) &&
                (Y(!0),
                setTimeout(function () {
                  Y(!1);
                }, 1e3));
          }
        }, 100);
        (0, _.useEffect)(
          function () {
            return (
              window.addEventListener("scroll", eQ),
              function () {
                return window.removeEventListener("scroll", eQ);
              }
            );
          },
          [eQ]
        );
        var eJ = !1,
          eY = tw.Z.isTouchDevice(),
          e$ = (0, _.useMemo)(
            function () {
              if (!ea || !ea.current || !ec || !ec.current) return !1;
              var e = ea.current.getBoundingClientRect().width;
              return ec.current.getBoundingClientRect().width > e;
            },
            [eh, G]
          );
        (0, _.useEffect)(
          function () {
            e$
              ? (ea.current.style.cursor = "grab")
              : (ea.current.style.cursor = "default");
          },
          [eY, e$, eh]
        );
        var e0 = function () {
          e$ && !eY && ((eJ = !1), (ea.current.style.cursor = "grab"));
        };
        (0, _.useEffect)(
          function () {
            var e = {
              account: eo,
              gallery: es,
              artwork: el,
              settings: ed,
              apikey: ep,
            }[eU];
            if (e && e.current && ec && ec.current && ea && ea.current) {
              var t = e.current.getBoundingClientRect(),
                n = t.x - ec.current.getBoundingClientRect().left;
              (em.current.style.left = "".concat(n, "px")),
                (em.current.style.width = "".concat(t.width, "px")),
                ea.current.scrollTo({
                  left: n - 20,
                  top: 0,
                  behavior: "smooth",
                });
            }
          },
          [eU, eh, G]
        );
        var e1 = (0, _.forwardRef)(function (e, t) {
          var n = e.tabKey,
            a = e.label,
            i = e.showRedDot;
          return (0, er.jsxs)("div", {
            className: ""
              .concat(d().tab, " ")
              .concat(ej()(eU, n) ? d().activeTab : ""),
            ref: t,
            onClick: function () {
              return eW(n);
            },
            children: [
              G(a),
              i && (0, er.jsx)("span", { className: d().redDot }),
            ],
          });
        });
        return (
          (e1.displayName = "Tab"),
          (0, er.jsxs)("div", {
            className: d().myAccountPage,
            children: [
              (0, er.jsx)(p.Z, {
                showAvatarRedDotOrderIds: eb,
                showAiHeadshotRedDotOrderIds: ew,
                showVideoEnhanceRedDotFromAccountPage: eS,
                showAiVideoFiltersRedDotFromAccountPage: eI,
                showVideoFaceSwapRedDot: eP,
                showAiStudioRedDotFromAccountPage: eM,
                showAvatarCreditRedDotFromAccountPage: eF,
                showAiHeadshotCreditRedDotFromAccountPage: eV,
                cmsUseCaseMenu: z,
              }),
              (0, er.jsxs)("div", {
                id: "yce-account-page-container",
                className: d().container,
                ref: en,
                children: [
                  (0, er.jsx)("div", { className: d().fakeTop }),
                  (0, er.jsx)("div", {
                    className: d().top,
                    ref: ea,
                    onMouseDown: function (e) {
                      e.preventDefault(),
                        e$ &&
                          !eY &&
                          ((eJ = !0),
                          (K = e.pageX - ea.current.offsetLeft),
                          (V = ea.current.scrollLeft),
                          (ea.current.style.cursor = "grabbing"));
                    },
                    onMouseLeave: e0,
                    onMouseUp: e0,
                    onMouseMove: function (e) {
                      if ((e.preventDefault(), eJ && e$ && !eY)) {
                        var t = e.pageX - ea.current.offsetLeft;
                        ea.current.scrollLeft = V - (t - K);
                      }
                    },
                    children: (0, er.jsxs)("div", {
                      className: d().tabs,
                      ref: ec,
                      children: [
                        (0, er.jsx)(e1, {
                          tabKey: T.gP.account,
                          label: "my.account.tabs.me",
                          ref: eo,
                        }),
                        (0, er.jsx)(e1, {
                          tabKey: T.gP.gallery,
                          label: "my.account.tabs.history",
                          ref: es,
                          showRedDot: I()(eS) > 0 || I()(eI) > 0 || I()(eP) > 0,
                        }),
                        (0, er.jsx)(e1, {
                          tabKey: T.gP.aiTools,
                          label: "my.account.tabs.aitools",
                          ref: el,
                          showRedDot:
                            I()(eb) > 0 ||
                            I()(ew) > 0 ||
                            I()(eM) > 0 ||
                            I()(eF) > 0 ||
                            I()(eV) > 0,
                        }),
                        (0, er.jsx)(e1, {
                          tabKey: T.gP.apikey,
                          label: "my.account.tabs.apikey",
                          ref: ep,
                        }),
                        (0, er.jsx)(e1, {
                          tabKey: T.gP.settings,
                          label: "my.account.tabs.settings",
                          ref: ed,
                        }),
                        (0, er.jsx)("span", {
                          className: d().indicator,
                          ref: em,
                        }),
                      ],
                    }),
                  }),
                  (0, er.jsxs)("div", {
                    className: d().bottom,
                    ref: ei,
                    children: [
                      ej()(eU, T.gP.account)
                        ? (0, er.jsx)(eu, { reGetSubData: ex })
                        : null,
                      ej()(eU, T.gP.gallery)
                        ? (0, er.jsx)(eX, {
                            runNext: W,
                            showVideoEnhanceRedDot: eS,
                            showAiVideoFiltersRedDot: eI,
                            showVideoFaceSwapRedDot: eP,
                            setShowVideoEnhanceRedDot: eT,
                            setShowAiVideoFiltersRedDot: eR,
                            setShowVideoFaceSwapRedDot: eZ,
                          })
                        : null,
                      ej()(eU, T.gP.aiTools)
                        ? (0, er.jsx)(nN, {
                            setShowAvatarRedDotOrderIds: eC,
                            showAvatarRedDotOrderIds: eb,
                            setShowAiHeadshotRedDotOrderIds: eN,
                            showAiHeadshotRedDotOrderIds: ew,
                            aiToolstab: ee,
                            setAiToolsTab: et,
                            showAiStudioRedDot: eM,
                            setShowAiStudioRedDot: eB,
                            showAvatarCreditRedDot: eF,
                            setShowAvatarCreditRedDot: eL,
                            showAiHeadshotCreditRedDot: eV,
                            setShowAiHeadshotCreditRedDot: ez,
                          })
                        : null,
                      ej()(eU, T.gP.settings)
                        ? (0, er.jsx)(e9, {
                            showFillEmailDialog: function () {
                              U((0, x.Xt)({ show: !0, type: "fill.email" }));
                            },
                          })
                        : null,
                      ej()(eU, T.gP.apikey)
                        ? (0, er.jsx)(tj, { runNext: J })
                        : null,
                    ],
                  }),
                  (0, er.jsx)(m.Z, {}),
                ],
              }),
            ],
          })
        );
      }
    },
    67260: function (e, t, n) {
      "use strict";
      var a = n(50029),
        i = n(87794),
        r = n.n(i),
        c = n(67294),
        o = n(9473),
        s = n(94319),
        l = n(89984),
        u = n(9585),
        d = n(14293),
        p = n.n(d),
        m = n(41609),
        h = n.n(m),
        _ = n(84238),
        f = n.n(_),
        x = n(91966),
        v = n.n(x);
      t.Z = function (e) {
        var t = e.isAiStudio,
          n = (0, c.useState)(!0),
          i = n[0],
          d = n[1],
          m = (0, c.useState)(!1),
          _ = m[0],
          x = m[1],
          g = (0, c.useState)([]),
          y = g[0],
          k = g[1],
          b = (0, c.useState)(!1),
          j = b[0],
          w = b[1],
          C = (0, c.useRef)({}),
          N = (0, o.I0)(),
          D = (0, o.v9)(function (e) {
            return e.api;
          }),
          S = (0, o.v9)(function (e) {
            return e.task;
          }),
          T = (0, o.v9)(function (e) {
            return e.aiStudio;
          }),
          A = T.successResults,
          I = T.lastSuccessResults,
          R = S.history4AiStudio,
          E = R.seq,
          P = R.data,
          Z =
            (null == D ? void 0 : D.initOK) && (null == D ? void 0 : D.authOK),
          O = v()(A, I).length,
          M = (0, s.Z)(P, _).results;
        return (
          (0, c.useEffect)(
            function () {
              var e,
                n =
                  ((e = (0, a.Z)(
                    r().mark(function e() {
                      return r().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (e.next = 2), N((0, u.n3)(18));
                            case 2:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              if (Z && t && !_) {
                if (i) {
                  n(), d(!1);
                  return;
                }
                E ? n() : p()(E) && x(!0);
              }
            },
            [Z, E, i, t]
          ),
          (0, c.useEffect)(
            function () {
              var e,
                t =
                  ((e = (0, a.Z)(
                    r().mark(function e() {
                      return r().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              A.forEach(
                                (function () {
                                  var e = (0, a.Z)(
                                    r().mark(function e(t, n) {
                                      return r().wrap(function (e) {
                                        for (;;)
                                          switch ((e.prev = e.next)) {
                                            case 0:
                                              if (C.current[t]) {
                                                e.next = 4;
                                                break;
                                              }
                                              return (
                                                (C.current[t] = !0),
                                                (e.next = 4),
                                                N(
                                                  (0, u.Zu)(t, l.ft.avtV3Img, n)
                                                )
                                              );
                                            case 4:
                                            case "end":
                                              return e.stop();
                                          }
                                      }, e);
                                    })
                                  );
                                  return function (t, n) {
                                    return e.apply(this, arguments);
                                  };
                                })()
                              );
                            case 1:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  )),
                  function () {
                    return e.apply(this, arguments);
                  });
              _ && f()(A) > 0 && t();
            },
            [_, A]
          ),
          (0, c.useEffect)(
            function () {
              Z &&
                t &&
                _ &&
                (k(
                  M.filter(function (e) {
                    var t, n, a;
                    return !h()(
                      null == e
                        ? void 0
                        : null === (t = e.result) || void 0 === t
                        ? void 0
                        : null === (n = t.results) || void 0 === n
                        ? void 0
                        : null === (a = n[0]) || void 0 === a
                        ? void 0
                        : a.data
                    );
                  })
                ),
                w(!0));
            },
            [Z, t, _, M]
          ),
          {
            filteredData4AiStudio: y,
            aiStudioDataInitialized: j,
            diffLengthForAiStudio: O,
          }
        );
      };
    },
    43070: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return s;
        },
      });
      var a = n(67294),
        i = n(11163),
        r = n(54555),
        c = n(7146),
        o = n(85893);
      function s(e) {
        var t = e.inputRef,
          n = e.handleInputFileChange,
          s = e.customAccept,
          l = void 0 === s ? null : s,
          u = (0, i.useRouter)(),
          d = (0, a.useMemo)(
            function () {
              return (
                l ||
                (u.pathname.match(/video-enhancer-ai/) ||
                u.pathname.match(/ai-video-filters/)
                  ? c.e.join(",")
                  : r.e.join(","))
              );
            },
            [u.pathname, l]
          );
        return (0, o.jsx)("input", {
          ref: t,
          type: "file",
          accept: d,
          style: { display: "none" },
          onChange: void 0 === n ? function () {} : n,
        });
      }
    },
    82344: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return o;
        },
      });
      var a = n(67294),
        i = n(9473),
        r = n(31170),
        c = n(89984);
      function o(e) {
        var t = e.moduleType,
          n = c.ZP.moduleTypeToLocalStorageType(t),
          o = (0, a.useState)(null),
          s = o[0],
          l = o[1],
          u = (0, a.useRef)(null),
          d = (0, r.Z)({ localStorageKey: n }).isCheckingTimeExpired,
          p = (0, i.v9)(function (e) {
            return e.user;
          });
        (0, a.useEffect)(function () {
          return function () {
            u.current && clearTimeout(u.current);
          };
        }, []),
          (0, a.useEffect)(
            function () {
              p.checked && m();
            },
            [p.checked]
          );
        var m = function e() {
          var t = d();
          l(!t), t || (u.current = setTimeout(e, 1e3));
        };
        return { isPackOrderInProcess: s };
      }
    },
    4098: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        myAccountPage: "my-account-page_myAccountPage__ily0X",
        container: "my-account-page_container__cWy8M",
        fakeTop: "my-account-page_fakeTop__d2BMz",
        top: "my-account-page_top__sJAKS",
        bottom: "my-account-page_bottom__JQ4Lt",
        title: "my-account-page_title__O_IjP",
        tabs: "my-account-page_tabs___Ou_K",
        tab: "my-account-page_tab__HtDfz",
        activeTab: "my-account-page_activeTab__vKnF0",
        redDot: "my-account-page_redDot__LE8nc",
        indicator: "my-account-page_indicator__PcT0L",
      };
    },
    96173: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "account_container__EWe37",
        userContainer: "account_userContainer__apbCT",
        emailLabel: "account_emailLabel__1l2No",
        email: "account_email__lWGIx",
        emailUnverified: "account_emailUnverified__OHrxE",
        flexL: "account_flexL__fgUxe",
        top: "account_top__GScgT",
        bottom: "account_bottom__MHJnW",
        subscriptionContainer: "account_subscriptionContainer__cSV1D",
        creditContainer: "account_creditContainer__3xIFX",
        bottomTitle: "account_bottomTitle__5V42A",
        topTitle: "account_topTitle__iiRmn",
        subscription: "account_subscription__tMyXZ",
        creditBox: "account_creditBox___qttQ",
        subscriptionPlanBox: "account_subscriptionPlanBox__ZCFD8",
        noSubscription: "account_noSubscription__2SPPf",
        noSubscription4Dynamic: "account_noSubscription4Dynamic__Peezf",
        subscriptionBox: "account_subscriptionBox__z0ZCu",
        marginBottom: "account_marginBottom__swpOb",
        boxTitle: "account_boxTitle__JDQFX",
        boxTitle4dpi150: "account_boxTitle4dpi150__AvMF3",
        subscriptionFeature: "account_subscriptionFeature__U1t94",
        subscriptionFeatureItem: "account_subscriptionFeatureItem__i1g9x",
        text: "account_text__QOFb_",
        subscriptionFeature4Dynamic:
          "account_subscriptionFeature4Dynamic__cQutR",
        icon: "account_icon__LgMry",
        monthly: "account_monthly__9DUFY",
        hasDueDateTitle: "account_hasDueDateTitle__iLeCL",
        planDueDate: "account_planDueDate__ouX1E",
        hasDueDate: "account_hasDueDate__xH5Ai",
        expire: "account_expire___MeUb",
        boxSmallTitle: "account_boxSmallTitle__Qk8LB",
        page: "account_page__jUUxz",
        prev: "account_prev__e_j2x",
        next: "account_next__ZJcr0",
        disable: "account_disable__fVYvm",
        flex: "account_flex__pgnJC",
        credit: "account_credit__FGQvC",
        line: "account_line__F9lhD",
        button: "account_button__R3rMp",
        noSubButton: "account_noSubButton__r_y9r",
        bottomTitleContainer: "account_bottomTitleContainer__azdDG",
        table: "account_table__nMQIF",
        tableHeader: "account_tableHeader__k161n",
        alignLeft: "account_alignLeft__5mC_H",
        tableRow: "account_tableRow___Q13U",
        border: "account_border__rxR9x",
        relative: "account_relative__8f5mV",
        date: "account_date__yNT62",
        description: "account_description__EFJMI",
        positive: "account_positive__uKr0P",
        negative: "account_negative__cyibq",
        blue: "account_blue__R1F1a",
        breakWord: "account_breakWord__oPC8K",
        noDataText: "account_noDataText__t4SZq",
        textLeft: "account_textLeft__8TeSK",
        skeletonContainer: "account_skeletonContainer__tR1bh",
        skeleton: "account_skeleton__vjtlT",
        shimmer: "account_shimmer__Ifdu8",
        skeletonCircle: "account_skeletonCircle__6lHiC",
      };
    },
    41581: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "ai-headshot_container__CytQ7",
        packsContainer: "ai-headshot_packsContainer__3fNRQ",
        packs: "ai-headshot_packs__JuWRO",
      };
    },
    12497: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "ai-studio_container__Zhd8_",
        packsContainer: "ai-studio_packsContainer__kIjby",
        packs: "ai-studio_packs__JGh0d",
        pack: "ai-studio_pack__daHs_",
        packHeader: "ai-studio_packHeader__52kMs",
        packTitle: "ai-studio_packTitle__1js0A",
        redDot: "ai-studio_redDot__A4MtP",
        deleteButton: "ai-studio_deleteButton__UIR4k",
        row: "ai-studio_row__9YjmS",
        processing: "ai-studio_processing__T5JCb",
        thumbnailBlock: "ai-studio_thumbnailBlock__rwoOV",
        paddingTop: "ai-studio_paddingTop__QJS_2",
        thumbnail: "ai-studio_thumbnail__upU94",
        thumbnailSkeleton: "ai-studio_thumbnailSkeleton__sVF3O",
        content: "ai-studio_content__JcdxB",
        leftBlock: "ai-studio_leftBlock__0M2wf",
        loading: "ai-studio_loading__cIc9B",
        textContainer: "ai-studio_textContainer__UprF0",
        title: "ai-studio_title__v8FsU",
        description: "ai-studio_description__hMCJQ",
        rightBlock: "ai-studio_rightBlock__WNjQ_",
        noAvatarContainer: "ai-studio_noAvatarContainer__jQPZV",
        flex: "ai-studio_flex__pnvxZ",
        noAvatarImg: "ai-studio_noAvatarImg__epw6p",
        noAvatarText: "ai-studio_noAvatarText__zyDNW",
        createButton: "ai-studio_createButton__8TJ_k",
      };
    },
    66482: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "ai-tools_container__XDzKf",
        tabHeader: "ai-tools_tabHeader__XKV3V",
        tabs: "ai-tools_tabs__KMIRd",
        specialTabs: "ai-tools_specialTabs__aS6XC",
        tab: "ai-tools_tab__Uc5xe",
        specialTab: "ai-tools_specialTab__fYECx",
        tabActive: "ai-tools_tabActive__A6gfD",
        redDot: "ai-tools_redDot__WheA2",
        header: "ai-tools_header__zHqYz",
        headerBottom: "ai-tools_headerBottom__OlV2d",
        icon: "ai-tools_icon__h88d2",
        tip: "ai-tools_tip__6rV1Z",
        editButton: "ai-tools_editButton__q7ZwE",
        deleteButton: "ai-tools_deleteButton__EcWpk",
        downloadButton: "ai-tools_downloadButton__2O_gd",
        label: "ai-tools_label__o2L7D",
        checkbox: "ai-tools_checkbox__6hjBI",
        checkboxChecked: "ai-tools_checkboxChecked__V3MCT",
        helper: "ai-tools_helper__10Pj6",
        flex: "ai-tools_flex__G0HfG",
        cells: "ai-tools_cells__LbK4G",
        cell: "ai-tools_cell__iuHU3",
        imageContainer: "ai-tools_imageContainer__hPr9d",
        checkmark: "ai-tools_checkmark__xx5zN",
        checkmarkChecked: "ai-tools_checkmarkChecked__jXFQY",
        thumbnailContainer: "ai-tools_thumbnailContainer__c_ydC",
        thumbnail4Group: "ai-tools_thumbnail4Group__s0_3G",
        thumbnail: "ai-tools_thumbnail__H0W7d",
        moduleTypeContainer: "ai-tools_moduleTypeContainer__4_U44",
        moduleName: "ai-tools_moduleName__cRt32",
        skeleton: "ai-tools_skeleton__qKxKX",
      };
    },
    64505: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "avatar_container___zbpu",
        packsContainer: "avatar_packsContainer__aURUj",
        packs: "avatar_packs__oGQB_",
      };
    },
    74786: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        pack: "checking-payment-pack_pack__MAw3s",
        packHeader: "checking-payment-pack_packHeader__eqzej",
        packTitle: "checking-payment-pack_packTitle__nvll_",
        row: "checking-payment-pack_row__Og77U",
        processing: "checking-payment-pack_processing__QZ4Nu",
        content: "checking-payment-pack_content__ltk9p",
        leftBlock: "checking-payment-pack_leftBlock__MBJ96",
        loading: "checking-payment-pack_loading__2xC06",
        textContainer: "checking-payment-pack_textContainer__MG56Z",
        title: "checking-payment-pack_title__TRni0",
        description: "checking-payment-pack_description__cXxPu",
      };
    },
    95381: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "empty-content_container__6MKKJ",
        flex: "empty-content_flex__bPfaL",
        emptyImg: "empty-content_emptyImg__d_oud",
        emptyText: "empty-content_emptyText__1WNQ7",
        createButton: "empty-content_createButton__k89RP",
      };
    },
    60903: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        pack: "failed-pack_pack__4Q5Vl",
        packHeader: "failed-pack_packHeader__XWYub",
        packTitle: "failed-pack_packTitle__a4qu4",
        failContent: "failed-pack_failContent___e3a6",
        leftBlock: "failed-pack_leftBlock__I7Pme",
        loading: "failed-pack_loading__Yw1bn",
        textContainer: "failed-pack_textContainer__GXZEa",
        title: "failed-pack_title___pTT5",
        titleFlex: "failed-pack_titleFlex__FAJQP",
        rightBlock: "failed-pack_rightBlock__iZiU_",
        retryButton: "failed-pack_retryButton__HaalJ",
      };
    },
    18557: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        packs: "loading-skeleton_packs__U8LSg",
        pack: "loading-skeleton_pack__W33i0",
        packHeader: "loading-skeleton_packHeader__zVr1r",
        packTitle: "loading-skeleton_packTitle__U4u4_",
        deleteIcon: "loading-skeleton_deleteIcon__e97_D",
        row: "loading-skeleton_row__mI1S0",
        cell: "loading-skeleton_cell__5sBMj",
        cellPaddingTop: "loading-skeleton_cellPaddingTop__iOlKH",
      };
    },
    15216: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        pack: "running-pack_pack__ylWmO",
        packHeader: "running-pack_packHeader__4qnuQ",
        packTitle: "running-pack_packTitle__rAONZ",
        row: "running-pack_row__MgHp_",
        processing: "running-pack_processing__x4zGr",
        content: "running-pack_content__R6Jhi",
        leftBlock: "running-pack_leftBlock__xvFOl",
        loading: "running-pack_loading__FNdEn",
        textContainer: "running-pack_textContainer__qcTTQ",
        title: "running-pack_title__Sl8nk",
        description: "running-pack_description__mtJJc",
        rightBlock: "running-pack_rightBlock__FrG9L",
      };
    },
    27243: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        pack: "success-pack_pack__q9gnh",
        packHeader: "success-pack_packHeader__DRKkA",
        packTitle: "success-pack_packTitle___oNmw",
        redDot: "success-pack_redDot__c15vI",
        deleteButton: "success-pack_deleteButton__JBLwf",
        row: "success-pack_row__N_PVC",
        thumbnailBlock: "success-pack_thumbnailBlock__yaPoA",
        paddingTop: "success-pack_paddingTop___29EV",
        thumbnail: "success-pack_thumbnail__ZDXr9",
        thumbnailSkeleton: "success-pack_thumbnailSkeleton__rale9",
      };
    },
    29273: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "api-key_container__6nAIW",
        apiDocumentTitle: "api-key_apiDocumentTitle__9osLY",
        apiKeyTitle: "api-key_apiKeyTitle__2NQ3l",
        apiDocumentDescription: "api-key_apiDocumentDescription___9k9v",
        apiKeyDescription: "api-key_apiKeyDescription__IV1HO",
        apiKeyTable: "api-key_apiKeyTable__rRimS",
        border: "api-key_border__nKsQm",
        apiKeyTableHeader: "api-key_apiKeyTableHeader__rsu4I",
        apiBox: "api-key_apiBox__LcTjD",
        header: "api-key_header__KlG11",
        control: "api-key_control__tApOT",
        editButton: "api-key_editButton__Ujo3I",
        deleteIcon: "api-key_deleteIcon__p0xlP",
        rowType2: "api-key_rowType2__fF5ta",
        rowType1: "api-key_rowType1__oU9so",
        contentContainer: "api-key_contentContainer___zKGJ",
        contentTitle: "api-key_contentTitle__4L6cc",
        content: "api-key_content__BTKrj",
        name: "api-key_name__93qLD",
        desc: "api-key_desc__K9R5N",
        line: "api-key_line____r7S",
        active: "api-key_active__4JWF2",
        documentButton: "api-key_documentButton__K7qs0",
        generateButton: "api-key_generateButton__1Wcmt",
        addIcon: "api-key_addIcon__9hx62",
        apiDocumentContainer: "api-key_apiDocumentContainer__UWYyi",
        modalContainer: "api-key_modalContainer__rNwjM",
        first_time_entry: "api-key_first_time_entry__PyYRy",
        edit_api_key: "api-key_edit_api_key__DS3Yk",
        secret_api_key: "api-key_secret_api_key__8Gony",
        generate_api_key: "api-key_generate_api_key__8Vttm",
        init_api_key: "api-key_init_api_key__R7icT",
        closeIcon: "api-key_closeIcon__LyofG",
      };
    },
    82603: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "edit-apikey-modal_container__3D7r_",
        title: "edit-apikey-modal_title__Sibbc",
        secretKey: "edit-apikey-modal_secretKey__xi4Eq",
        statusContainer: "edit-apikey-modal_statusContainer__gsPox",
        statusTitle: "edit-apikey-modal_statusTitle__6YIdo",
        radioContainer: "edit-apikey-modal_radioContainer__vx24d",
        radioOuter: "edit-apikey-modal_radioOuter__n3zpv",
        radioOuterChecked: "edit-apikey-modal_radioOuterChecked__5Ky_Y",
        radioInner: "edit-apikey-modal_radioInner__fP7U9",
        radioInnerChecked: "edit-apikey-modal_radioInnerChecked__uK7mz",
        inputContainer: "edit-apikey-modal_inputContainer__sEEKS",
        expireDateContainer: "edit-apikey-modal_expireDateContainer__5cXXe",
        expireDaeTitle: "edit-apikey-modal_expireDaeTitle__nDAEC",
        input: "edit-apikey-modal_input__x2zRD",
        dateIcon: "edit-apikey-modal_dateIcon__O5Ql8",
        checkmarkContainer: "edit-apikey-modal_checkmarkContainer__KsiSw",
        checkboxContainer: "edit-apikey-modal_checkboxContainer__0OFTq",
        checkboxContainerBackground:
          "edit-apikey-modal_checkboxContainerBackground__glYSM",
        checkboxChecked: "edit-apikey-modal_checkboxChecked__JGuLT",
        textarea: "edit-apikey-modal_textarea__nMCdB",
        commonButton: "edit-apikey-modal_commonButton__OatTT",
        disabled: "edit-apikey-modal_disabled__D9pMS",
      };
    },
    86340: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        close: "first-time-entry-modal_close__v_Dda",
        checkbox: "first-time-entry-modal_checkbox__t02db",
        container: "first-time-entry-modal_container__pQBGP",
        title: "first-time-entry-modal_title__nbti2",
        content: "first-time-entry-modal_content__ee357",
        agreement: "first-time-entry-modal_agreement__VuhfP",
        button: "first-time-entry-modal_button__o_LuM",
      };
    },
    18344: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "generate-apikey-modal_container__Ac_ED",
        title: "generate-apikey-modal_title__Somdw",
        inputContainer: "generate-apikey-modal_inputContainer__IyMxJ",
        expireDateContainer: "generate-apikey-modal_expireDateContainer__tSHwO",
        expireDaeTitle: "generate-apikey-modal_expireDaeTitle__b2VaE",
        input: "generate-apikey-modal_input__PrqFy",
        dateIcon: "generate-apikey-modal_dateIcon__IWgoB",
        checkmarkContainer: "generate-apikey-modal_checkmarkContainer__FQEPQ",
        checkboxContainer: "generate-apikey-modal_checkboxContainer__9FDpA",
        checkboxContainerBackground:
          "generate-apikey-modal_checkboxContainerBackground__3tCPZ",
        checkboxChecked: "generate-apikey-modal_checkboxChecked__6TJy_",
        textarea: "generate-apikey-modal_textarea__VQU4U",
        commonButton: "generate-apikey-modal_commonButton__ekGdn",
        disabled: "generate-apikey-modal_disabled__R8XZ9",
      };
    },
    44517: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        close: "init-apikey-modal_close__8U55z",
        checkbox: "init-apikey-modal_checkbox__R13tl",
        container: "init-apikey-modal_container___b_GT",
        title: "init-apikey-modal_title__zVVQf",
        content: "init-apikey-modal_content__Z8Emh",
        agreement: "init-apikey-modal_agreement__WFWgM",
        button: "init-apikey-modal_button__PaLkl",
      };
    },
    86240: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "secret-apikey-modal_container___pQdS",
        title: "secret-apikey-modal_title__SSOa_",
        subtitle: "secret-apikey-modal_subtitle__IC_IU",
        keyContainer: "secret-apikey-modal_keyContainer__z6tJC",
        copyIcon: "secret-apikey-modal_copyIcon__Ig1g_",
        key: "secret-apikey-modal_key__E6zra",
        desc: "secret-apikey-modal_desc__F3kGr",
        buttonContainer: "secret-apikey-modal_buttonContainer__Hh8_A",
        spaceBetween: "secret-apikey-modal_spaceBetween__sDOR3",
        button: "secret-apikey-modal_button__pnUmf",
        copyContainer: "secret-apikey-modal_copyContainer__6_PkK",
        copiedTip: "secret-apikey-modal_copiedTip__B4bVm",
        tipText: "secret-apikey-modal_tipText__EpCE8",
        copied: "secret-apikey-modal_copied__wsgVJ",
        fadeIn: "secret-apikey-modal_fadeIn__KrdUN",
        fadeOut: "secret-apikey-modal_fadeOut__h9cft",
      };
    },
    77030: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        accIcon: "userInformation_accIcon__zdZvl",
        accIconMarginRightLarge:
          "userInformation_accIconMarginRightLarge__87Dyg",
        accIconLarge: "userInformation_accIconLarge__MscOu",
        accName: "userInformation_accName__Ezdfl",
        userNameInAccount: "userInformation_userNameInAccount__ZXR8w",
        userNameInSettings: "userInformation_userNameInSettings__LovOB",
        email: "userInformation_email__XIn90",
        flexL: "userInformation_flexL__WRAlT",
        flexLAlignCenter: "userInformation_flexLAlignCenter__kV6Xp",
      };
    },
    17911: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "empty-content_container__Pw3vz",
        flex: "empty-content_flex__aAtFO",
        emptyImg: "empty-content_emptyImg__0PaEi",
        emptyText: "empty-content_emptyText__TMC7I",
        createButton: "empty-content_createButton__pA9sL",
      };
    },
    38498: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "gallery_container__j47Ma",
        tabHeader: "gallery_tabHeader__gqz0i",
        tabs: "gallery_tabs__CwRF0",
        tab: "gallery_tab__M4P32",
        specialTab: "gallery_specialTab__whoJW",
        tabActive: "gallery_tabActive__6iOsM",
        header: "gallery_header__qrx_a",
        headerBottom: "gallery_headerBottom__w4uJv",
        icon: "gallery_icon__mEDMR",
        tip: "gallery_tip__Aoo5C",
        editButton: "gallery_editButton__2Zwo_",
        deleteButton: "gallery_deleteButton__63zzn",
        downloadButton: "gallery_downloadButton__8s3FL",
        label: "gallery_label__mtYPX",
        checkbox: "gallery_checkbox__h6RQY",
        checkboxChecked: "gallery_checkboxChecked__dv4qP",
        helper: "gallery_helper__2A6wh",
        flex: "gallery_flex__Z2GTH",
        cells: "gallery_cells__U5RXO",
        cell: "gallery_cell__Uakvn",
        imageContainer: "gallery_imageContainer__DO2LS",
        checkmark: "gallery_checkmark__9rPYR",
        checkmarkChecked: "gallery_checkmarkChecked___sIFB",
        thumbnailContainer: "gallery_thumbnailContainer__Y962J",
        thumbnail4Group: "gallery_thumbnail4Group__nlPfV",
        thumbnail: "gallery_thumbnail__dzo52",
        moduleTypeContainer: "gallery_moduleTypeContainer__qQS3X",
        moduleName: "gallery_moduleName__xNiGU",
        skeleton: "gallery_skeleton__5UElx",
        videoEditingLinkContainer: "gallery_videoEditingLinkContainer__5kvF9",
        videoEditingLink: "gallery_videoEditingLink__LUJ5E",
        arrowIcon: "gallery_arrowIcon__WDGZb",
        redDot: "gallery_redDot__Mvy8_",
      };
    },
    74398: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "general-cell_container__fYdt5",
        tabHeader: "general-cell_tabHeader__v8Xo6",
        tabs: "general-cell_tabs__2bepU",
        tab: "general-cell_tab__oHtBA",
        tabActive: "general-cell_tabActive__R9Nn6",
        header: "general-cell_header__D5YpN",
        headerBottom: "general-cell_headerBottom__yz03Q",
        icon: "general-cell_icon__5i275",
        tip: "general-cell_tip__a_Mbu",
        editButton: "general-cell_editButton__pAVDQ",
        deleteButton: "general-cell_deleteButton__GKa8C",
        downloadButton: "general-cell_downloadButton__tStqB",
        label: "general-cell_label__MxvFM",
        checkbox: "general-cell_checkbox__3HUQ2",
        checkboxChecked: "general-cell_checkboxChecked__iu7kz",
        helper: "general-cell_helper__OCPlL",
        flex: "general-cell_flex__wm5cz",
        cells: "general-cell_cells__h6duT",
        cell: "general-cell_cell__xtmEc",
        imageContainer: "general-cell_imageContainer__O9mkW",
        checkmark: "general-cell_checkmark__xcViB",
        checkmarkChecked: "general-cell_checkmarkChecked__DAGZY",
        thumbnailContainer: "general-cell_thumbnailContainer__ojb1I",
        thumbnail4Group: "general-cell_thumbnail4Group__8Pl8E",
        thumbnail: "general-cell_thumbnail__fRK98",
        moduleTypeContainer: "general-cell_moduleTypeContainer__DtWNq",
        moduleName: "general-cell_moduleName__5vN6e",
        skeleton: "general-cell_skeleton__giZPP",
        videoEditingLinkContainer:
          "general-cell_videoEditingLinkContainer__IgjpU",
        videoEditingLink: "general-cell_videoEditingLink__iZsqY",
        arrowIcon: "general-cell_arrowIcon__9jA2k",
        redDot: "general-cell_redDot__qeKo8",
      };
    },
    95475: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        moduleTypeWrapper: "module-type-icon_moduleTypeWrapper__eWTBu",
        customModuleTypeWrapper:
          "module-type-icon_customModuleTypeWrapper__1teqZ",
        moduleTypeIcon: "module-type-icon_moduleTypeIcon__UVXay",
        invert: "module-type-icon_invert__tgukf",
      };
    },
    34394: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "video-editing_container__QBu1c",
        packsContainer: "video-editing_packsContainer__PZWuF",
        packs: "video-editing_packs__4UjAu",
        pack: "video-editing_pack__ac72u",
        packHeader: "video-editing_packHeader__7F_44",
        packTitle: "video-editing_packTitle__tb14q",
        row: "video-editing_row__rgd_q",
        rowWithCursorPointer: "video-editing_rowWithCursorPointer__tw8rZ",
        leftBlock: "video-editing_leftBlock__plPrB",
        imageContainer: "video-editing_imageContainer__bUjjc",
        image: "video-editing_image__09b5s",
        rightBlock: "video-editing_rightBlock__8lZFK",
        rightBlock4Running: "video-editing_rightBlock4Running__s9RBC",
        loading: "video-editing_loading__OwGAD",
        textContainer: "video-editing_textContainer__EC_7k",
        title: "video-editing_title__JOx7c",
        titleFlex: "video-editing_titleFlex__9_ZK5",
        description: "video-editing_description__SWZk3",
        timeLeft: "video-editing_timeLeft__BQsgL",
        iconContainer: "video-editing_iconContainer__c15To",
        icon: "video-editing_icon__KoBKN",
        videoInfoText: "video-editing_videoInfoText__KPMxh",
        bottomIconContainer: "video-editing_bottomIconContainer__9otBT",
        bottomIcon: "video-editing_bottomIcon__H70tM",
        redDot: "video-editing_redDot__WyAcQ",
        checkmark: "video-editing_checkmark__7_Atu",
        checkmarkBackground: "video-editing_checkmarkBackground__p_UbG",
        checkmarkChecked: "video-editing_checkmarkChecked__kGl_8",
        editing: "video-editing_editing__rcyXm",
        disabled: "video-editing_disabled__cYVHJ",
      };
    },
    18567: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        contactUs: "settings_contactUs__D5wje",
        container: "settings_container__eZMrZ",
        userContainer: "settings_userContainer__OI_Ss",
        emailContainer: "settings_emailContainer__1_cNf",
        emailLabel: "settings_emailLabel__cmFxQ",
        email: "settings_email__uCjSp",
        textFieldContainer: "settings_textFieldContainer__lcheo",
        submit: "settings_submit___o7EC",
        edit: "settings_edit__b_hhd",
        emailUnverified: "settings_emailUnverified__XDCQp",
        resentEmail: "settings_resentEmail__scMiE",
        resetPassword: "settings_resetPassword__pFz_2",
        agreement: "settings_agreement__jiDMu",
        footer: "settings_footer__Kh8SE",
        logout: "settings_logout__Mj_Dn",
        divider: "settings_divider__t6aEj",
        accPanel: "settings_accPanel__D2N5d",
        deleteUser: "settings_deleteUser__NuJRv",
        flexL: "settings_flexL__R427N",
        flexC: "settings_flexC__XD2B_",
        textField: "settings_textField__UjaAk",
        textFieldLabel: "settings_textFieldLabel__p4EB2",
        textFieldInput: "settings_textFieldInput__6441J",
        redDot: "settings_redDot__6JSgH",
      };
    },
  },
]);
