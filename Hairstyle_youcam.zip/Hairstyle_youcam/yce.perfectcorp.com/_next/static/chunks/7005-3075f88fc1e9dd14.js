(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7005],
  {
    98110: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return m;
        },
      });
      var r = n(59499),
        o = n(67294),
        i = n(19161),
        s = n(91747),
        a = n.n(s),
        c = { prevX: 0, prevY: 0, dx: 0, dy: 0, t: 0 },
        u = null,
        l = n(85893);
      function d(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function f(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? d(Object(n), !0).forEach(function (t) {
                (0, r.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : d(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var p = { top: 0, left: 0, x: 0, y: 0 },
        m = (0, o.forwardRef)(function (e, t) {
          var n,
            r,
            s,
            d,
            m,
            _,
            h = e.children,
            g = e.wrapperClass,
            x = e.enableDrag,
            v = void 0 === x ? { x: !1, y: !1 } : x,
            b = e.onScroll,
            y = e.onWheel,
            w = e.onTouchMove,
            j = e.id,
            C = (0, o.useState)(!1),
            S = C[0],
            T = C[1],
            k = (0, o.useState)(!1),
            P = k[0],
            I = k[1],
            Z = (0, o.useState)(f({}, p)),
            N = Z[0],
            M = Z[1],
            B = (0, o.useRef)(null),
            R =
              ((r = (n = { dragRef: B, enableDrag: v }).dragRef),
              (s = n.enableDrag),
              (d = function () {
                m(),
                  Date.now() - c.t > 200 ||
                    (u = requestAnimationFrame(function () {
                      return _(0.95);
                    }));
              }),
              (m = function () {
                cancelAnimationFrame(u), (u = null);
              }),
              (_ = function e() {
                var t =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 0.95,
                  n = c,
                  o = n.dx,
                  i = n.dy,
                  a = Math.abs(o),
                  l = Math.abs(i),
                  d = Math.min(Math.pow(a + l, 0.5) / 3, 0.95);
                s.x && a * t > 0.5 && (r.current.scrollLeft -= o * t),
                  s.y && l * t > 0.5 && (r.current.scrollTop -= i * t),
                  Math.abs(t) > 0.1 &&
                    (u = requestAnimationFrame(function () {
                      return e(t * d);
                    }));
              }),
              {
                handlePointerDownForMomentum: function (e) {
                  var t, n;
                  m(),
                    (c = a()({ prevX: e.clientX, prevY: e.clientY }, c)),
                    null === (t = e.target) ||
                      void 0 === t ||
                      null === (n = t.setPointerCapture) ||
                      void 0 === n ||
                      n.call(t, e.pointerId);
                },
                handlePointerMoveForMomentum: function (e) {
                  var t = e.clientX - c.prevX,
                    n = e.clientY - c.prevY,
                    r = Date.now();
                  c = {
                    prevX: e.clientX,
                    prevY: e.clientY,
                    dx: t,
                    dy: n,
                    t: r,
                  };
                },
                handlePointerUpForMomentum: function (e) {
                  var t, n;
                  d(),
                    null === (t = e.target) ||
                      void 0 === t ||
                      null === (n = t.releasePointerCapture) ||
                      void 0 === n ||
                      n.call(t, e.pointerId);
                },
              }),
            E = R.handlePointerDownForMomentum,
            D = R.handlePointerMoveForMomentum,
            O = R.handlePointerUpForMomentum,
            F = (0, o.useMemo)(
              function () {
                return (
                  !i.Z.isTouchDevice() &&
                  !!(null != B && B.current) &&
                  (v.x || v.y)
                );
              },
              [v, null == B ? void 0 : B.current]
            );
          return (
            (0, o.useImperativeHandle)(t, function () {
              return { elementRef: B, element: B.current, moved: P };
            }),
            (0, l.jsx)("div", {
              ref: B,
              className: "hidden-scrollbar ".concat(void 0 === g ? "" : g),
              onPointerDown: function (e) {
                var t, n;
                F &&
                  !S &&
                  (I(!1),
                  T(!0),
                  M({
                    left: B.current.scrollLeft,
                    top: B.current.scrollTop,
                    x: e.clientX,
                    y: e.clientY,
                  }),
                  E(e),
                  null === (t = e.target) ||
                    void 0 === t ||
                    null === (n = t.setPointerCapture) ||
                    void 0 === n ||
                    n.call(t, e.pointerId));
              },
              onPointerMove: function (e) {
                if (F && S) {
                  var t = B.current.clientWidth < B.current.scrollWidth,
                    n = B.current.clientHeight < B.current.scrollHeight,
                    r = e.clientX - N.x,
                    o = e.clientY - N.y;
                  t && v.x && ((B.current.scrollLeft = N.left - r), P || I(!0)),
                    n && v.y && ((B.current.scrollTop = N.top - o), P || I(!0)),
                    D(e);
                }
              },
              onPointerUp: function (e) {
                var t, n;
                F &&
                  S &&
                  (T(!1),
                  M(f({}, p)),
                  O(e),
                  null === (t = e.target) ||
                    void 0 === t ||
                    null === (n = t.releasePointerCapture) ||
                    void 0 === n ||
                    n.call(t, e.pointerId));
              },
              onScroll: void 0 === b ? function () {} : b,
              onWheel: void 0 === y ? function () {} : y,
              onTouchMove: void 0 === w ? function () {} : w,
              id: j,
              children: h,
            })
          );
        });
    },
    90219: function (e, t, n) {
      "use strict";
      n.d(t, {
        $J: function () {
          return w;
        },
        RU: function () {
          return j;
        },
        ZP: function () {
          return C;
        },
      });
      var r = n(50029),
        o = n(87794),
        i = n.n(o),
        s = n(67294),
        a = n(13311),
        c = n.n(a),
        u = n(10928),
        l = n.n(u),
        d = n(52353),
        f = n.n(d),
        p = n(30998),
        m = n.n(p),
        _ = n(41526),
        h = n(24193),
        g = n(89984),
        x = n(6031),
        v = n(18224),
        b = n(90869),
        y = n.n(b),
        w = "YCE-ai-video-filters-style-selection-container",
        j = "yce-ai-video-filters-subcategory-";
      function C(e) {
        var t,
          n = e.moduleType,
          o = (0, v.Z)().isDesktop,
          a = o ? w : "YCE-result-photo-container",
          u = (0, s.useState)(null),
          d = u[0],
          p = u[1],
          b = (0, s.useState)(null),
          C = b[0],
          S = b[1],
          T = (0, s.useState)(!0),
          k = T[0],
          P = T[1],
          I = (0, s.useState)(!0),
          Z = I[0],
          N = I[1],
          M = (0, s.useState)(!1),
          B = M[0],
          R = M[1],
          E = (0, h.Z)({
            categorytype: x.UI[g.ft.aiVideoFilters],
            contenttype: x.IJ[g.ft.aiVideoFilters],
            run: n === g.ft.aiVideoFilters,
          }).groups,
          D = (0, _.Z)({
            groups: E,
            queryStylesList: n === g.ft.aiVideoFilters,
            queryStylesListByGroup: !0,
          }).groupStyles,
          O = m()(D, function (e) {
            return e.groupId === d;
          }),
          F = function (e, t) {
            "tab" === e && t !== d
              ? (H(!0, !1), p(t))
              : "subCategory" === e
              ? (H(!0, !1), p(t))
              : "autoChangeSubCategory" === e && (H(!1, void 0), p(t));
          };
        (0, s.useEffect)(
          function () {
            if (d) {
              if (!o && !B) {
                R(!0);
                return;
              }
              W();
            }
          },
          [d, O]
        );
        var z = function () {
            var e = document.querySelectorAll(".group-item"),
              t = document.querySelector(".".concat(y().groups)),
              n = e[O];
            if (t && n && !o) {
              var r = t.getBoundingClientRect(),
                i = n.getBoundingClientRect().left - r.left,
                s = t.scrollLeft + i - t.clientWidth / 2 + n.clientWidth / 2;
              t.scrollTo({ left: s, behavior: "smooth" });
            }
          },
          A = function (e) {
            if (e) {
              var t = document.getElementById(
                "ai-video-filters-style-selection-sticky"
              );
              if (o) e.scrollIntoView({ behavior: "smooth", block: "start" });
              else {
                var n,
                  r = t.offsetHeight || 0,
                  i =
                    null === (n = document) || void 0 === n
                      ? void 0
                      : n.getElementById("YCE-result-photo-container");
                if (!i) return;
                var s = i.getBoundingClientRect().top,
                  a = e.getBoundingClientRect().top - s + i.scrollTop - r;
                i.scrollTo({ top: a, behavior: "smooth" });
              }
            }
          },
          W = function () {
            if (d && k) {
              var e = document.querySelectorAll('div[id^="'.concat(j, '"]')),
                t = document.getElementById("".concat(j).concat(d));
              if (e && t) {
                if ((z(), t === e[0])) {
                  if (!document.getElementById(a)) return;
                  A(t);
                } else A(t);
              }
            }
          },
          L =
            ((t = (0, r.Z)(
              i().mark(function e(t) {
                var n, r, o, s, u;
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (Z) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        if ((r = document.getElementById(a))) {
                          e.next = 5;
                          break;
                        }
                        return e.abrupt("return");
                      case 5:
                        if (
                          ((o = r.querySelectorAll(
                            'div[id^="'.concat(j, '"]')
                          )),
                          (s =
                            r.scrollHeight - r.scrollTop <= r.clientHeight + 5
                              ? l()(o)
                              : c()(o, function (e) {
                                  return (
                                    e.getBoundingClientRect().bottom - 450 > 0
                                  );
                                })))
                        ) {
                          e.next = 11;
                          break;
                        }
                        return e.abrupt("return");
                      case 11:
                        if (
                          (u = parseInt(
                            null === (n = s.dataset) || void 0 === n
                              ? void 0
                              : n.id
                          )) !== d
                        ) {
                          e.next = 14;
                          break;
                        }
                        return e.abrupt("return");
                      case 14:
                        F("autoChangeSubCategory", u), z();
                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
          H = function () {
            var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : void 0,
              t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : void 0;
            f()(e) || P(e), f()(t) || N(t);
          };
        return {
          selectedGroupId: d,
          selectedGroupStyleIds: C,
          setSelectedGroupId: p,
          setSelectedGroupStyleIds: S,
          updateAutoStates: H,
          handleAutoChangeActiveSubCategory: L,
          groups: E,
          groupStyles: D,
          onSubCategorySelect: F,
        };
      }
    },
    72658: function (e, t, n) {
      "use strict";
      n.d(t, {
        N: function () {
          return M;
        },
        e: function () {
          return k;
        },
      });
      var r = n(58499),
        o = n.n(r),
        i = n(67294),
        s = n(9473),
        a = n(79336),
        c = n(18224),
        u = n(30351),
        l = n(45790),
        d = n.n(l),
        f = n(42621),
        p = n(11163),
        m = n(27361),
        _ = n.n(m);
      function h() {
        var e = (0, c.Z)().isDesktop,
          t = (0, p.useRouter)(),
          n = (0, i.useMemo)(
            function () {
              return _()(t, "query.locale", "en-us");
            },
            [t]
          );
        return {
          uploadButtonStyles: (0, i.useMemo)(
            function () {
              return e
                ? {}
                : ["ja", "fr", "pt", "it"].includes(n)
                ? { fontSize: "12px", lineHeight: "14px" }
                : ["de", "es"].includes(n)
                ? { fontSize: "14px", lineHeight: "14px" }
                : {};
            },
            [e, n]
          ),
        };
      }
      var g = n(84338),
        x = n(45395),
        v = n(89984),
        b = n(85893);
      function y(e) {
        var t = e.handleInputClick,
          n = (0, i.useRef)(null),
          r = (0, g.PC)().t,
          o = (0, f.Z)(),
          a = o.setNextRatio,
          u = o.setCanvasDirty,
          l = h().uploadButtonStyles,
          p = (0, s.v9)(function (e) {
            return e.info;
          }),
          m = (0, s.v9)(function (e) {
            return e.result;
          }),
          y = p.moduleType,
          w = m.zoomExtents,
          j = m.images,
          C = m.general,
          S = m.imageSize,
          T = w.max,
          k = w.min,
          P = w.now,
          I = C.isCreator,
          Z = (0, c.Z)().isDesktop,
          N = (0, i.useMemo)(
            function () {
              return j.ready;
            },
            [j.ready]
          ),
          M = (0, i.useMemo)(
            function () {
              var e = _()(S, "after.width") || 0,
                t = _()(S, "before.width") || 0;
              return e || t;
            },
            [N, S]
          ),
          B = (0, i.useMemo)(
            function () {
              var e = _()(S, "after.height") || 0,
                t = _()(S, "before.height") || 0;
              return e || t;
            },
            [N, S]
          );
        (0, i.useEffect)(
          function () {
            n &&
              n.current &&
              (n.current.style.backgroundSize = "".concat(
                ((P - k) * 100) / (T - k),
                "% 100%"
              ));
          },
          [T, k, P]
        );
        var R = function (e) {
          N && a(Math.min(T, Math.max(k, e)));
        };
        return (0, b.jsxs)("div", {
          className: ""
            .concat(d().container, " ")
            .concat(I ? "" : d().containerForViewer),
          children: [
            I &&
              (0, b.jsxs)("div", {
                className: d().sizes,
                children: [
                  (0, b.jsxs)("span", {
                    className: d().size,
                    children: [r("result.width"), ":"],
                  }),
                  " ",
                  (0, b.jsx)("div", {
                    className: d().width,
                    children: M + r("result.size.unit"),
                  }),
                  (0, b.jsx)("span", { style: { marginRight: "25px" } }),
                  (0, b.jsxs)("span", {
                    className: d().size,
                    children: [r("result.height"), ":"],
                  }),
                  " ",
                  (0, b.jsx)("div", {
                    className: d().height,
                    children: B + r("result.size.unit"),
                  }),
                ],
              }),
            (0, b.jsxs)("div", {
              className: d().zoomSliderContainer,
              children: [
                (0, b.jsx)("div", {
                  className: ""
                    .concat(d().button, " ")
                    .concat(N ? "" : d().disabled),
                  onClick: function () {
                    return R(P - 20);
                  },
                  children: (0, b.jsx)("img", {
                    className: d().icon,
                    src: "/assets/images/icon_minus.svg",
                    alt: "zoom out button",
                  }),
                }),
                (0, b.jsx)("input", {
                  ref: n,
                  className: ""
                    .concat(d().slider, " ")
                    .concat(N ? "" : d().hideSliderThumb),
                  type: "range",
                  min: k,
                  max: T,
                  step: 0.1,
                  value: P || 0,
                  onChange: function (e) {
                    a(parseFloat(e.target.value));
                  },
                }),
                (0, b.jsx)("div", {
                  className: ""
                    .concat(d().button, " ")
                    .concat(N ? "" : d().disabled),
                  onClick: function () {
                    return R(P + 20);
                  },
                  children: (0, b.jsx)("img", {
                    className: d().icon,
                    src: "/assets/images/icon_plus.svg",
                    alt: "zoom in button",
                  }),
                }),
                (0, b.jsxs)("div", {
                  className: ""
                    .concat(d().number, " ")
                    .concat(N && P ? "" : d().disabled),
                  children: [N ? (P || 0).toFixed(0) : 0, "%"],
                }),
                (0, b.jsx)("img", {
                  className: d().reset,
                  src: "/assets/images/btn_3lv_bottom_reset_size.svg",
                  alt: "reset button",
                  onClick: function () {
                    N && u(!0, "reset");
                  },
                }),
              ],
            }),
            (0, b.jsxs)("div", {
              className: "".concat(d().sizesSmallScreen),
              children: [
                N && M ? M : "",
                r("result.width.small.screen"),
                " x ",
                N && B ? B : "",
                r("result.height.small.screen"),
              ],
            }),
            Z &&
              (0, b.jsx)(x.Z, {
                className: ""
                  .concat(d().upload, " ")
                  .concat(I ? "" : d().uploadForViewer),
                hoverClass: "hover-with-border-15171f",
                touchClass: "touch-with-border-15171f",
                onClick: t,
                style: l,
                children:
                  y === v.ft.muTransfer
                    ? (0, b.jsx)(b.Fragment, {
                        children: r(
                          "makeup.transfer.results.empty.result.button"
                        ),
                      })
                    : (0, b.jsx)(b.Fragment, {
                        children: r("result.upload.new"),
                      }),
              }),
          ],
        });
      }
      function w(e) {
        var t = e.handleInputClick,
          n = (0, i.useRef)(null),
          r = (0, g.PC)().t,
          o = (0, f.Z)().setProductConfig,
          a = h().uploadButtonStyles,
          c = (0, s.v9)(function (e) {
            return e.info;
          }),
          u = (0, s.v9)(function (e) {
            return e.result;
          }),
          l = c.moduleType,
          p = u.general,
          m = u.productConfig,
          y = p.isCreator,
          w = (0, i.useMemo)(
            function () {
              return _()(m, "".concat(l, ".resultImageZoomExtents"), {});
            },
            [l, m]
          ),
          j = w.min,
          C = void 0 === j ? 0 : j,
          S = w.max,
          T = void 0 === S ? 0 : S,
          k = w.now,
          P = void 0 === k ? 0 : k,
          I = w.fit,
          Z = void 0 === I ? 0 : I,
          N = (0, i.useMemo)(
            function () {
              return _()(w, "width", 0);
            },
            [w]
          ),
          M = (0, i.useMemo)(
            function () {
              return _()(w, "height", 0);
            },
            [w]
          ),
          B = (0, i.useMemo)(
            function () {
              return "".concat(((P - C) * 100) / (T - C), "% 100%");
            },
            [C, T, P]
          ),
          R = function (e) {
            o(l, {
              resultImageZoomExtents: { now: Math.min(T, Math.max(C, e)) },
            });
          };
        return (0, b.jsxs)("div", {
          className: ""
            .concat(d().container, " ")
            .concat(y ? "" : d().containerForViewer),
          children: [
            y &&
              (0, b.jsxs)("div", {
                className: d().sizes,
                children: [
                  (0, b.jsxs)("span", {
                    className: d().size,
                    children: [r("result.width"), ":"],
                  }),
                  " ",
                  (0, b.jsx)("div", {
                    className: d().width,
                    children: N + r("result.size.unit"),
                  }),
                  (0, b.jsx)("span", { style: { marginRight: "25px" } }),
                  (0, b.jsxs)("span", {
                    className: d().size,
                    children: [r("result.height"), ":"],
                  }),
                  " ",
                  (0, b.jsx)("div", {
                    className: d().height,
                    children: M + r("result.size.unit"),
                  }),
                ],
              }),
            (0, b.jsxs)("div", {
              className: d().zoomSliderContainer,
              children: [
                (0, b.jsx)("div", {
                  className: d().button,
                  onClick: function () {
                    return R(P - 20);
                  },
                  children: (0, b.jsx)("img", {
                    className: d().icon,
                    src: "/assets/images/icon_minus.svg",
                    alt: "zoom out button",
                  }),
                }),
                (0, b.jsx)("input", {
                  ref: n,
                  className: d().slider,
                  type: "range",
                  min: C,
                  max: T,
                  step: 10,
                  value: P || 0,
                  onChange: function (e) {
                    o(l, {
                      resultImageZoomExtents: {
                        now: Math.round(parseFloat(e.target.value)),
                      },
                    });
                  },
                  style: { backgroundSize: B },
                }),
                (0, b.jsx)("div", {
                  className: d().button,
                  onClick: function () {
                    return R(P + 20);
                  },
                  children: (0, b.jsx)("img", {
                    className: d().icon,
                    src: "/assets/images/icon_plus.svg",
                    alt: "zoom in button",
                  }),
                }),
                (0, b.jsxs)("div", {
                  className: d().number,
                  children: [P.toFixed(0), "%"],
                }),
                (0, b.jsx)("img", {
                  className: d().reset,
                  src: "/assets/images/btn_3lv_bottom_reset_size.svg",
                  alt: "reset button",
                  onClick: function () {
                    o(l, { resultImageZoomExtents: { now: Z } });
                  },
                }),
              ],
            }),
            (0, b.jsxs)("div", {
              className: "".concat(d().sizesSmallScreen),
              children: [
                N,
                r("result.width.small.screen"),
                " x ",
                M,
                r("result.height.small.screen"),
              ],
            }),
            (0, b.jsx)(x.Z, {
              className: ""
                .concat(d().upload, " ")
                .concat(y ? "" : d().uploadForViewer),
              hoverClass: "hover-with-border-15171f",
              touchClass: "touch-with-border-15171f",
              onClick: t,
              style: a,
              children:
                l === v.ft.muTransfer
                  ? (0, b.jsx)(b.Fragment, {
                      children: r(
                        "makeup.transfer.results.empty.result.button"
                      ),
                    })
                  : (0, b.jsx)(b.Fragment, {
                      children: r("result.upload.new"),
                    }),
            }),
          ],
        });
      }
      function j(e) {
        var t = e.handleInputClick,
          n = (0, s.v9)(function (e) {
            return e.info;
          }),
          r = (0, s.v9)(function (e) {
            return e.result;
          }),
          o = n.moduleType,
          a = r.productConfig,
          u = r.general.isCreator,
          l = (0, c.Z)(),
          f = l.isDesktop,
          p = l.isMobile,
          m = (0, i.useMemo)(
            function () {
              return _()(a, "".concat(o, ".resultImageZoomExtents.show"), !1)
                ? "image"
                : "canvas";
            },
            [o, a]
          );
        return (0, b.jsxs)(b.Fragment, {
          children: [
            !f &&
              (0, b.jsx)(x.Z, {
                className: ""
                  .concat(d().upload, " ")
                  .concat(u ? "" : d().uploadForViewer),
                hoverClass: "hover-with-border-15171f",
                touchClass: "touch-with-border-15171f",
                onClick: t,
                children: (0, b.jsx)("img", {
                  className: d().uploadIcon,
                  src: "/assets/images/icon_upload_mb.png",
                  alt: "",
                }),
              }),
            "canvas" === m
              ? !p && (0, b.jsx)(y, { handleInputClick: t })
              : (0, b.jsx)(w, { handleInputClick: t }),
          ],
        });
      }
      var C = n(43070),
        S = n(18901),
        T = n(19126);
      function k() {
        var e = (0, i.useRef)(null),
          t = (0, u.Z)({ inputRef: e }),
          n = t.handleInputClick,
          r = t.handleInputFileChange,
          l = (0, a.Z)(),
          d = l.isInSharePage,
          f = l.canShowFeaturesPanel,
          p = l.isBottomBlockHidden,
          m = (0, c.Z)().isDesktop,
          _ = (0, s.v9)(function (e) {
            return e.info;
          }).moduleType,
          h = (0, i.useMemo)(
            function () {
              return (
                !!_ &&
                !d &&
                !![
                  v.ft.enhance,
                  v.ft.sod,
                  v.ft.colorize,
                  v.ft.lighting,
                  v.ft.resizeImage,
                  v.ft.objRemoval,
                  v.ft.colorCorrection,
                ].includes(_)
              );
            },
            [_, d]
          );
        return (0, b.jsxs)(b.Fragment, {
          children: [
            (0, b.jsxs)("div", {
              className: o().container,
              children: [
                (0, b.jsxs)("div", {
                  className: ""
                    .concat(o().bottomBlock, " ")
                    .concat(p ? o().bottomBlockHidden : ""),
                  children: [
                    (0, b.jsx)(j, { handleInputClick: n }),
                    !m && f && (0, b.jsx)(S.E, {}),
                  ],
                }),
                h && (0, b.jsx)(T.Z, { onlyCheckLogin: !0 }),
              ],
            }),
            (0, b.jsx)(C.Z, { inputRef: e, handleInputFileChange: r }),
          ],
        });
      }
      var P = n(83099),
        I = n.n(P),
        Z = n(23560),
        N = n.n(Z);
      function M(e) {
        var t = e.children,
          n = e.custom,
          r = ((void 0 === n ? {} : n) || {}).onUploadButtonClicked,
          o = (0, i.useRef)(null),
          s = (0, u.Z)({ inputRef: o }),
          l = s.handleInputClick,
          d = s.handleInputFileChange,
          f = (0, a.Z)().canShowFeaturesPanel;
        return (0, c.Z)().isDesktop
          ? null
          : (0, b.jsxs)("div", {
              className: I().container,
              children: [
                (0, b.jsx)(x.Z, {
                  className: ""
                    .concat(I().button, " ")
                    .concat(I().uploadButton),
                  hoverClass: "hover-46e4fa",
                  touchClass: "touch-46e4fa",
                  onClick: function () {
                    N()(r) ? r() : l();
                  },
                  children: (0, b.jsx)("img", {
                    className: I().uploadIcon,
                    src: "/assets/images/icon_upload_mb.png",
                    alt: "",
                  }),
                }),
                t,
                f && (0, b.jsx)(S.E, { align: "right" }),
                (0, b.jsx)(C.Z, { inputRef: o, handleInputFileChange: d }),
              ],
            });
      }
    },
    18901: function (e, t, n) {
      "use strict";
      n.d(t, {
        y: function () {
          return d;
        },
        E: function () {
          return g;
        },
      });
      var r = n(59062),
        o = n.n(r),
        i = n(67294),
        s = n(42621),
        a = n(82358),
        c = n(84338),
        u = n(14798),
        l = n(85893);
      function d() {
        var e = (0, i.useState)(!1),
          t = e[0],
          n = e[1],
          r = (0, c.PC)().t,
          d = (0, s.Z)().setCanvasDirty,
          f = (0, a.Z)(),
          p = f.canCrossPromote,
          m = f.features,
          _ = f.handleFeatureClicked,
          h = f.getProductImageSrc;
        (0, i.useEffect)(
          function () {
            g(Date.now());
          },
          [t]
        );
        var g = function e(t) {
            Date.now() - t > 600 ||
              (d(!0),
              setTimeout(function () {
                return e(t);
              }, 10));
          },
          x = function (e) {
            switch (e) {
              case u.G2.photoEditing:
                return r("header.items.product.group.ai.editing.and.enhance");
              case u.G2.genAi:
                return r("header.items.product.group.ai.generator");
              case u.G2.basicEditing:
                return r("header.items.product.group.basic.editing");
              case u.G2.faceAi:
                return r("header.items.product.group.face.ai");
              case u.G2.portraitAi:
                return r("header.items.product.group.ai.portrait");
              case u.G2.videoEditing:
                return r("header.items.product.group.ai.video.editing");
              default:
                return "";
            }
          };
        return (0, l.jsxs)("div", {
          className: ""
            .concat(o().container, " ")
            .concat(t ? o().containerCollapsed : ""),
          children: [
            (0, l.jsxs)("div", {
              className: "".concat(o().featuresPanel, " hidden-scrollbar"),
              children: [
                (0, l.jsx)("div", {
                  className: o().title,
                  children: r("result.features.panel.title"),
                }),
                m.map(function (e) {
                  var t = e.key,
                    n = e.products,
                    i = x(t);
                  return (0, l.jsxs)(
                    "div",
                    {
                      children: [
                        i &&
                          (0, l.jsx)("div", {
                            className: o().category,
                            children: i,
                          }),
                        n.map(function (e, t) {
                          return (0, l.jsxs)(
                            "div",
                            {
                              className: ""
                                .concat(o().product, " ")
                                .concat(p ? "" : o().productDisabled, " ")
                                .concat(i || 0 !== t ? "" : o().addPadding),
                              onClick: function () {
                                return _(e);
                              },
                              children: [
                                (0, l.jsx)("img", {
                                  className: o().productIcon,
                                  src: h(e),
                                }),
                                (0, l.jsx)("div", {
                                  className: o().productText,
                                  children: r(
                                    "header.items.product.".concat(e)
                                  ),
                                }),
                              ],
                            },
                            e
                          );
                        }),
                      ],
                    },
                    t
                  );
                }),
              ],
            }),
            (0, l.jsx)("div", {
              className: o().controlBackground,
              style: {
                backgroundImage:
                  "url(/assets/images/cross-promote/dt_bg_panel_arrow.png)",
              },
              onClick: function () {
                return n(function (e) {
                  return !e;
                });
              },
              children: (0, l.jsx)("img", {
                className: ""
                  .concat(o().control, " ")
                  .concat(t ? o().controlCollapsed : ""),
                src: "/assets/images/cross-promote/dt_btn_arrow.png",
              }),
            }),
          ],
        });
      }
      var f = n(57115),
        p = n.n(f),
        m = n(98110),
        _ = n(84238),
        h = n.n(_);
      function g(e) {
        var t = e.align,
          n = (0, i.useState)(!0),
          r = n[0],
          o = n[1],
          s = (0, i.useRef)(null),
          u = (0, c.PC)(),
          d = u.t,
          f = u.locale,
          _ = (0, a.Z)(),
          g = _.canCrossPromote,
          x = _.features,
          v = _.handleFeatureClicked,
          b = _.getProductImageSrc,
          y = (0, i.useMemo)(
            function () {
              return "ja" === f;
            },
            [f]
          ),
          w = function () {
            return o(function (e) {
              return !e;
            });
          },
          j = function (e) {
            var t;
            (null != s &&
              null !== (t = s.current) &&
              void 0 !== t &&
              t.moved) ||
              (v(e), w());
          };
        return (0, l.jsxs)("div", {
          className:
            "left" === (void 0 === t ? "right" : t)
              ? p().containerLeft
              : p().containerRight,
          children: [
            (0, l.jsxs)("div", {
              className: ""
                .concat(p().triggerButton, " ")
                .concat(y ? p().triggerButtonSmallText : ""),
              onClick: w,
              children: [
                (0, l.jsx)("img", {
                  className: p().arrowIcon,
                  src: "/assets/images/cross-promote/mb_btn_arrow.png",
                  alt: "",
                }),
                d("result.features.panel.button.more"),
              ],
            }),
            (0, l.jsxs)("div", {
              className: ""
                .concat(p().featuresPanel, " ")
                .concat(r ? p().featuresPanelCollapsed : ""),
              children: [
                (0, l.jsx)("div", {
                  className: p().productTitle,
                  children: d("result.features.panel.title"),
                }),
                (0, l.jsx)(m.Z, {
                  ref: s,
                  wrapperClass: p().products,
                  enableDrag: { x: !0 },
                  children:
                    h()(x) &&
                    x.map(function (e) {
                      return e.products.map(function (e) {
                        return (0, l.jsxs)(
                          "div",
                          {
                            className: ""
                              .concat(p().product, " ")
                              .concat(g ? "" : p().productDisabled),
                            onClick: function () {
                              return j(e);
                            },
                            children: [
                              (0, l.jsx)("div", {
                                className: p().productIconWrapper,
                                children: (0, l.jsx)("img", {
                                  className: p().productIcon,
                                  src: b(e),
                                  draggable: !1,
                                  alt: "",
                                }),
                              }),
                              (0, l.jsx)("div", {
                                className: p().productText,
                                children: d("header.items.product.".concat(e)),
                              }),
                            ],
                          },
                          e
                        );
                      });
                    }),
                }),
                (0, l.jsx)("div", {
                  className: p().controlBackground,
                  style: {
                    backgroundImage:
                      "url(/assets/images/cross-promote/mb_bg_panel_arrow.png)",
                  },
                  onClick: w,
                  children: (0, l.jsx)("img", {
                    className: p().control,
                    src: "/assets/images/cross-promote/mb_btn_arrow.png",
                  }),
                }),
              ],
            }),
            (0, l.jsx)("div", {
              className: ""
                .concat(p().mask, " ")
                .concat(r ? p().maskCollapsed : ""),
              onClick: w,
            }),
          ],
        });
      }
    },
    82358: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return _;
        },
      });
      var r = n(27812),
        o = n(67294),
        i = n(9473),
        s = n(42621),
        a = n(27623),
        c = n(25915),
        u = n(89984),
        l = n(43263),
        d = n(84238),
        f = n.n(d),
        p = n(63105),
        m = n.n(p);
      function _() {
        var e = (0, s.Z)().setFeaturesPanel,
          t = (0, a.Z)(),
          n = t.isGenerativeAI,
          d = t.isBasicEditing,
          p = (0, c.Z)().isGuest,
          _ = (0, i.I0)(),
          h = (0, i.v9)(function (e) {
            return e.info;
          }),
          g = (0, i.v9)(function (e) {
            return e.share;
          }),
          x = h.moduleType,
          v = g.downloadFileId,
          b = g.downloadUrl,
          y = g.srcFileId,
          w = g.srcUrl,
          j = g.compressedYCEData,
          C = (0, o.useMemo)(
            function () {
              return (
                !!(
                  ([u.ft.objRemoval].includes(x) && j.base64) ||
                  n ||
                  d ||
                  [u.ft.lighting, u.ft.outPaint, u.ft.objReplace, u.ft.faceSwap]
                    .concat((0, r.Z)(u.Sl))
                    .includes(x)
                ) || (u.Sl.includes(x) ? b : v || b || y || w)
              );
            },
            [v, b, y, w, j, x, n, d]
          );
        return {
          canCrossPromote: C,
          features: (0, o.useMemo)(
            function () {
              var e = u.Sl.includes(x)
                ? u.ZP.getCrossPromoteFeatures4VideoTypes(x)
                : u.ZP.getCrossPromoteFeatures(x);
              return m()(e, function (e) {
                return f()(e.products) > 0;
              });
            },
            [x]
          ),
          handleFeatureClicked: function (t) {
            if (C) {
              if (p) {
                _((0, l.eh)(!0));
                return;
              }
              var n = u.ZP.crossPromoteTypeToModuleType(t);
              e(n.moduleType, n.sodType, t);
            }
          },
          getProductImageSrc: function (e) {
            return e === u.T_[u.ft.aiPortrait]
              ? "/assets/images/cross-promote/icon_mb_".concat(
                  u.T_[u.ft.txt2Img].replaceAll(".", "-"),
                  ".png"
                )
              : "/assets/images/cross-promote/icon_mb_".concat(
                  e.replaceAll(".", "-"),
                  ".png"
                );
          },
        };
      }
    },
    43070: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return c;
        },
      });
      var r = n(67294),
        o = n(11163),
        i = n(54555),
        s = n(7146),
        a = n(85893);
      function c(e) {
        var t = e.inputRef,
          n = e.handleInputFileChange,
          c = e.customAccept,
          u = void 0 === c ? null : c,
          l = (0, o.useRouter)(),
          d = (0, r.useMemo)(
            function () {
              return (
                u ||
                (l.pathname.match(/video-enhancer-ai/) ||
                l.pathname.match(/ai-video-filters/)
                  ? s.e.join(",")
                  : i.e.join(","))
              );
            },
            [l.pathname, u]
          );
        return (0, a.jsx)("input", {
          ref: t,
          type: "file",
          accept: d,
          style: { display: "none" },
          onChange: void 0 === n ? function () {} : n,
        });
      }
    },
    90440: function (e, t, n) {
      "use strict";
      n.d(t, {
        gQ: function () {
          return L;
        },
        kV: function () {
          return z;
        },
        Sz: function () {
          return Y;
        },
        eQ: function () {
          return et;
        },
      });
      var r = n(64440),
        o = n.n(r),
        i = n(67294),
        s = n(9473),
        a = n(40025),
        c = n(42621),
        u = n(27812),
        l = n(89984);
      function d() {
        var e = (0, s.v9)(function (e) {
            return e.info;
          }),
          t = (0, s.v9)(function (e) {
            return e.share;
          }),
          n = (0, s.v9)(function (e) {
            return e.result;
          }),
          r = (0, s.v9)(function (e) {
            return e.yceData;
          }),
          o = e.moduleType,
          a = t.compressedYCEData,
          c = t.downloadFileId,
          d = n.featuresPanel,
          f = (0, i.useMemo)(
            function () {
              return (
                !(
                  !d.moduleType ||
                  (o === l.ft.txt2Img &&
                    [l.ft.faceSwap]
                      .concat((0, u.Z)(l.qu))
                      .includes(d.moduleType)) ||
                  (o === l.ft.muTransfer && l.qu.includes(d.moduleType)) ||
                  (o === l.ft.faceSwap && l.qu.includes(d.moduleType))
                ) &&
                !l.Sl.includes(o) &&
                [
                  l.ft.videoSr,
                  l.ft.aiVideoFilters,
                  l.ft.muTransfer,
                  l.ft.faceShapeDetector,
                  l.ft.faceSwap,
                  l.ft.txt2Img,
                  l.ft.aiPortrait,
                ]
                  .concat((0, u.Z)(l.qu), [
                    l.ft.headshot,
                    l.ft.avtV3Img,
                    l.ft.avatar,
                  ])
                  .includes(d.moduleType)
              );
            },
            [d.moduleType, o]
          ),
          p = (0, i.useMemo)(
            function () {
              return (
                !f &&
                !!o &&
                (!![
                  l.ft.enhance,
                  l.ft.sod,
                  l.ft.colorize,
                  l.ft.colorCorrection,
                ].includes(o) ||
                  (!!l.ft.objRemoval && !!c))
              );
            },
            [f, o, c]
          ),
          m = (0, i.useMemo)(
            function () {
              return (
                !f &&
                !!o &&
                !!(
                  !c &&
                  !(null != r && r.base64) &&
                  !(null != a && a.base64) &&
                  [l.ft.lighting, l.ft.txt2Img]
                    .concat(
                      (0, u.Z)(l.qu),
                      [l.ft.muTransfer, l.ft.faceSwap],
                      (0, u.Z)(l.Sl)
                    )
                    .includes(o)
                )
              );
            },
            [f, o, c, r, a]
          );
        return {
          isScenario1: p,
          isScenario2: (0, i.useMemo)(
            function () {
              return (
                !f &&
                !m &&
                !!o &&
                !!(
                  !c &&
                  [
                    l.ft.lighting,
                    l.ft.outPaint,
                    l.ft.cropPhoto,
                    l.ft.resizeImage,
                    l.ft.flipAndRotateImage,
                  ]
                    .concat((0, u.Z)(l.qu), [
                      l.ft.muTransfer,
                      l.ft.objReplace,
                      l.ft.objRemoval,
                      l.ft.faceSwap,
                    ])
                    .includes(o)
                )
              );
            },
            [f, m, o, c]
          ),
          isScenario3: (0, i.useMemo)(
            function () {
              return (
                !f &&
                !m &&
                !!o &&
                !!(
                  c &&
                  [
                    l.ft.lighting,
                    l.ft.outPaint,
                    l.ft.cropPhoto,
                    l.ft.resizeImage,
                    l.ft.flipAndRotateImage,
                  ]
                    .concat(
                      (0, u.Z)(l.qu),
                      [
                        l.ft.muTransfer,
                        l.ft.objReplace,
                        l.ft.txt2Img,
                        l.ft.faceSwap,
                      ],
                      (0, u.Z)(l.Sl)
                    )
                    .includes(o)
                )
              );
            },
            [f, m, o, c]
          ),
          isScenario4: f,
          isScenarioEmptyResult: m,
          isNextFeatureScenario4: function (e) {
            return [
              l.ft.videoSr,
              l.ft.aiVideoFilters,
              l.ft.avatar,
              l.ft.txt2Img,
            ]
              .concat((0, u.Z)(l.qu), [l.ft.muTransfer, l.ft.headshot])
              .includes(e.moduleType);
          },
        };
      }
      var f = n(18224),
        p = n(49114),
        m = n(84338),
        _ = n(26186),
        h = n(72809),
        g = n.n(h),
        x = n(45395),
        v = n(43263),
        b = n(85893);
      function y() {
        var e = (0, m.PC)().t,
          t = (0, a.Z)().applyBeforeImage,
          n = (0, c.Z)().setNextStepDialogOpened,
          r = (0, s.I0)();
        return (0, b.jsxs)("div", {
          className: g().buttons,
          children: [
            (0, b.jsx)(x.Z, {
              className: g().buttonBlue,
              hoverClass: "hover-with-border-46e4fa",
              touchClass: "touch-with-border-46e4fa",
              onClick: function () {
                r((0, v.QO)("chain")), n(!1);
              },
              children: e("message.dialog.button.after.features.panel"),
            }),
            (0, b.jsx)(x.Z, {
              className: g().buttonWhite,
              hoverClass: "hover-with-border-46e4fa",
              touchClass: "touch-with-border-46e4fa",
              onClick: function () {
                t(), n(!1);
              },
              children: e("message.dialog.button.before.features.panel"),
            }),
          ],
        });
      }
      var w = n(50029),
        j = n(87794),
        C = n.n(j),
        S = n(85098),
        T = n.n(S),
        k = n(11163),
        P = n(20327),
        I = n(15613),
        Z = n(48956),
        N = n(1848),
        M = n(72880);
      function B() {
        var e,
          t = (0, m.PC)().t,
          n = (0, c.Z)(),
          r = n.setFeaturesPanel,
          o = n.setNextStepDialogOpened,
          a = (0, P.Z)(),
          d = a.apiInitAndAuth,
          f = a.initState,
          p = (0, k.useRouter)(),
          _ = (0, s.I0)(),
          h = (0, s.v9)(function (e) {
            return e.result;
          }).featuresPanel,
          g = (0, i.useMemo)(
            function () {
              if (!h.moduleType) return "";
              var e = l.ZP.moduleTypeToURL(h.moduleType);
              return [l.ft.txt2Img, l.ft.aiPortrait]
                .concat((0, u.Z)(l.qu), [l.ft.muTransfer, l.ft.faceSwap])
                .includes(h.moduleType)
                ? "".concat(e, "/result-photo")
                : e;
            },
            [h.moduleType]
          ),
          v = (0, i.useMemo)(
            function () {
              return (
                !!h.moduleType &&
                [l.ft.txt2Img]
                  .concat((0, u.Z)(l.qu), [l.ft.muTransfer, l.ft.faceSwap])
                  .includes(h.moduleType)
              );
            },
            [h.moduleType]
          ),
          y =
            ((e = (0, w.Z)(
              C().mark(function e() {
                return C().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        o(!1),
                          setTimeout(
                            (0, w.Z)(
                              C().mark(function e() {
                                var t, n;
                                return C().wrap(function (e) {
                                  for (;;)
                                    switch ((e.prev = e.next)) {
                                      case 0:
                                        return (e.next = 2), d();
                                      case 2:
                                        return (e.next = 4), f();
                                      case 4:
                                        return (e.next = 6), _((0, N.F0)());
                                      case 6:
                                        return (e.next = 8), _((0, M.Q$)());
                                      case 8:
                                        v &&
                                          _(
                                            (0, M.g5)({
                                              initialized: !0,
                                              isCreator: !0,
                                            })
                                          ),
                                          r(),
                                          I.Z.push(p, g, p.query),
                                          (t = h.moduleType),
                                          (n = h.sodType),
                                          _(
                                            (0, Z.Bs)({
                                              moduleType: t,
                                              sodType: n,
                                            })
                                          );
                                      case 13:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e);
                              })
                            ),
                            400
                          );
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return e.apply(this, arguments);
            });
        return (0, b.jsxs)("div", {
          className: T().buttons,
          children: [
            (0, b.jsx)(x.Z, {
              className: T().buttonWhite,
              hoverClass: "hover-with-border-46e4fa",
              touchClass: "touch-with-border-46e4fa",
              onClick: function () {
                o(!1), setTimeout(r, 400);
              },
              children: t("my.account.history.cancel"),
            }),
            (0, b.jsx)(x.Z, {
              className: T().buttonBlue,
              hoverClass: "hover-with-border-46e4fa",
              touchClass: "touch-with-border-46e4fa",
              onClick: y,
              children: t("message.dialog.button.discard"),
            }),
          ],
        });
      }
      var R = n(48403),
        E = n.n(R),
        D = n(84486),
        O = n.n(D),
        F = { Ai: "AI" };
      function z() {
        var e,
          t,
          n,
          r,
          u = (0, a.Z)(),
          h = u.applyBeforeImage,
          g = u.applyAfterImageWithoutDownload,
          x = u.redirectToProductPage,
          v = u.applyAfterVideoWithoutDownload,
          w = (0, c.Z)(),
          j = w.setFeaturesPanel,
          C = w.setNextStepDialogOpened,
          S = d(),
          T = S.isScenario1,
          k = S.isScenario2,
          P = S.isScenario3,
          I = S.isScenario4,
          Z = S.isScenarioEmptyResult,
          N =
            ((e = (0, f.Z)().isMobile),
            (n = (t = d()).isScenario1),
            (r = t.isScenario4),
            {
              modalStyle: (0, i.useMemo)(
                function () {
                  return n
                    ? {
                        padding: e ? "15px 23px" : "35px 30px",
                        color: "#212529",
                        width: "fit-content",
                      }
                    : r
                    ? {
                        padding: "30px 23px 15px",
                        color: "#212529",
                        width: "100%",
                        maxWidth: "446px",
                      }
                    : void 0;
                },
                [n, r, e]
              ),
              containerClass: (0, i.useMemo)(
                function () {
                  return n
                    ? o().scenario1Container
                    : r
                    ? o().scenario4Container
                    : void 0;
                },
                [n, r]
              ),
              descClass: (0, i.useMemo)(
                function () {
                  return n ? o().scenario1Desc : r ? o().scenario4Desc : void 0;
                },
                [n, r]
              ),
            }),
          M = N.modalStyle,
          R = N.containerClass,
          D = N.descClass,
          z = (0, m.PC)().t,
          A = (0, s.v9)(function (e) {
            return e.result;
          }),
          W = (0, s.v9)(function (e) {
            return e.info;
          }),
          L = A.featuresPanel,
          H = A.general,
          V = L.productType,
          q = H.nextStepDialogOpened,
          U = W.moduleType,
          G = (0, i.useMemo)(
            function () {
              return V ? z("header.items.product.".concat(V)) : "";
            },
            [V]
          ),
          Y = (0, i.useMemo)(
            function () {
              if (!G || I) return "";
              var e = E()(
                z("message.dialog.title.features.panel", { product: G })
              );
              return (
                O()(F, function (t, n) {
                  e = e.replaceAll(n, t);
                }),
                e
              );
            },
            [G, I]
          ),
          Q = (0, i.useMemo)(
            function () {
              return T
                ? z("message.dialog.desc.features.panel")
                : I
                ? z("message.dialog.desc.tool.page.to.product.page")
                : "";
            },
            [T, I]
          ),
          K = (0, i.useMemo)(
            function () {
              return T;
            },
            [T]
          ),
          J = (0, i.useMemo)(
            function () {
              return q && (T || I);
            },
            [q, T, I]
          );
        (0, i.useEffect)(
          function () {
            q && L.moduleType && Z && (x(), C(!1));
          },
          [q, L.moduleType, Z]
        ),
          (0, i.useEffect)(
            function () {
              q && L.moduleType && k && (h(), C(!1));
            },
            [q, L.moduleType, k]
          ),
          (0, i.useEffect)(
            function () {
              q &&
                L.moduleType &&
                P &&
                (l.Sl.includes(U) ? v() : g(X()), C(!1));
            },
            [q, L.moduleType, P]
          ),
          (0, i.useEffect)(
            function () {
              L.moduleType && C(!0);
            },
            [L.moduleType]
          );
        var X = function () {
            return U === l.ft.txt2Img ? { isFromTextToImage: !0 } : {};
          },
          $ = function () {
            C(!1), setTimeout(j, 400);
          };
        return (0, b.jsx)(_.Z, {
          opened: J,
          customStyles: M,
          handleClose: $,
          showModalScaleTransition: !0,
          children: (0, b.jsxs)("div", {
            className: R,
            children: [
              !!Y && (0, b.jsx)("div", { className: o().title, children: Y }),
              (0, b.jsx)("div", {
                className: D,
                dangerouslySetInnerHTML: { __html: p.Z.sanitize(Q, "br") },
              }),
              T && (0, b.jsx)(y, {}),
              I && (0, b.jsx)(B, {}),
              K &&
                (0, b.jsx)("div", {
                  className: o().close,
                  style: {
                    backgroundImage: "url(/assets/images/icon_close.svg)",
                  },
                  onClick: $,
                }),
            ],
          }),
        });
      }
      var A = n(86985),
        W = n.n(A);
      function L(e) {
        var t = e.showCloseButton,
          n = e.handleClick,
          r = void 0 === n ? function () {} : n,
          o = (0, m.PC)().t,
          a = (0, s.I0)(),
          c =
            (0, s.v9)(function (e) {
              return e.ui;
            }).faceDetectMessageDialog || {},
          u = c.show,
          l = c.type,
          d = void 0 === l ? "" : l,
          f = c.error,
          h = void 0 === f ? "" : f;
        (0, i.useEffect)(function () {
          window.test = function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "no.face";
            a((0, v.am)({ show: !0, type: e }));
          };
        }, []);
        var g = (0, i.useMemo)(
            function () {
              return o("face.detect.error.".concat(d, ".title"));
            },
            [d]
          ),
          y = (0, i.useMemo)(
            function () {
              return o("face.detect.error.".concat(d, ".subtitle"));
            },
            [d]
          ),
          w = (0, i.useMemo)(
            function () {
              return o("face.detect.error.button.reselect");
            },
            [d]
          ),
          j = (0, i.useMemo)(function () {
            return {
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "flex-start",
              padding: "20px 40px",
              maxWidth: "500px",
            };
          }, []),
          C = function () {
            a((0, v.am)({ show: !1, type: d, error: h })),
              setTimeout(function () {
                (0, v.am)({ show: !1, type: "", error: "" });
              }, 400);
          };
        return (0, b.jsxs)(_.Z, {
          opened: void 0 !== u && u,
          customStyles: j,
          handleClose: C,
          children: [
            (0, b.jsx)("div", {
              className: W().title,
              dangerouslySetInnerHTML: { __html: p.Z.sanitize(g, "br") },
            }),
            (0, b.jsx)("div", {
              className: W().desc,
              dangerouslySetInnerHTML: { __html: p.Z.sanitize(y, "b.br") },
            }),
            (0, b.jsx)(x.Z, {
              className: W().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: function () {
                C(),
                  setTimeout(function () {
                    r(h);
                  }, 400);
              },
              children: w,
            }),
            (void 0 === t || t) &&
              (0, b.jsx)("div", {
                className: W().close,
                style: {
                  backgroundImage: "url(/assets/images/icon_close.svg)",
                },
                onClick: C,
              }),
          ],
        });
      }
      var H = n(22902),
        V = n.n(H),
        q = n(19161),
        U = n(27361),
        G = n.n(U);
      function Y(e) {
        var t,
          n = e.showCloseButton,
          r = e.autoCloseOnButtonClicked,
          o = void 0 === r || r,
          a = e.handleClick,
          u = void 0 === a ? function () {} : a,
          l = (0, m.PC)().t,
          d = (0, s.v9)(function (e) {
            return e.result.errorMessageModal;
          }),
          f = G()(d, "show", !1),
          h =
            G()(d, "title") ||
            "message.dialog.title.text.to.image.engine.error",
          g = G()(d, "content", ""),
          v = G()(d, "button") || "general.OK",
          y = {
            modalStyle: (0, i.useMemo)(function () {
              return {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "flex-start",
                padding: "30px 23px 15px",
                maxWidth: "500px",
              };
            }, []),
          }.modalStyle,
          j = (0, c.Z)().setShowErrorMessageDialog,
          S =
            ((t = (0, w.Z)(
              C().mark(function e() {
                return C().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return j({ show: !1 }), (e.next = 3), q.Z.sleep(400);
                      case 3:
                        j({ show: !1, title: "", content: "", button: "" });
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            });
        return (0, b.jsxs)(_.Z, {
          opened: f,
          customStyles: y,
          handleClose: S,
          children: [
            (0, b.jsx)("div", {
              className: V().title,
              dangerouslySetInnerHTML: { __html: p.Z.sanitize(l(h), "br") },
            }),
            (0, b.jsx)("div", {
              className: V().desc,
              dangerouslySetInnerHTML: { __html: p.Z.sanitize(l(g), "b.br") },
            }),
            (0, b.jsx)(x.Z, {
              className: V().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: function () {
                o && S(), setTimeout(u, 400);
              },
              children: l(v),
            }),
            (void 0 === n || n) &&
              (0, b.jsx)("img", {
                className: V().close,
                src: "/assets/images/icon_close.svg",
                onClick: S,
              }),
          ],
        });
      }
      var Q = n(90030),
        K = n.n(Q),
        J = n(55961),
        X = n(59944),
        $ = n(56979),
        ee = {
          getErrorMessageByErrorType: function (e, t) {
            switch (t) {
              case "exceed_max_filesize":
                return e("error.message.exceed.max.filesize");
              case "invalid_parameter":
              case "error_download_image":
              case "error_download_mask":
              case "error_download_video":
              case "error_inference":
              case "exceed_nsfw_retry_limits":
              case "error_upload":
              case "error_unexpected_video_duration":
              case "unknown_internal_error":
              default:
                return e("error.message.unknown.internal.error");
              case "error_decode_image":
                return e("error.message.error.decode.image");
              case "error_decode_mask":
                return e("error.message.error.decode.mask");
              case "error_decode_video":
                return e("error.message.error.decode.video");
              case "error_nsfw_content_detected":
                return e("error.message.error.nsfw.content.detected");
              case "error_no_face":
                return e("error.message.error.no.face");
              case "error_pose":
                return e("error.message.error.pose");
              case "error_face_parsing":
                return e("error.message.error.face.parsing");
              case "error_multiple_people":
                return e("error.message.error.multiple.people");
              case "error_no_shoulder":
                return e("error.message.error.no.shoulder");
              case "error_large_face_angle":
                return e("error.message.error.large.face.angle");
              case "error_insufficient_landmarks":
                return e("error.message.error.insufficient.landmarks");
              case "error_hair_too_short":
                return e("error.message.error.hair.too.short");
              case "error_bald_image":
                return e("error.message.error.bald.image");
            }
          },
        };
      function et() {
        var e = (0, i.useState)(!1),
          t = e[0],
          n = e[1],
          r = (0, m.PC)().t,
          o = (0, s.v9)(function (e) {
            return e.task.processFail;
          }),
          a = (0, s.v9)(function (e) {
            return e.task.failResponse;
          }),
          u = G()(a, "result.error"),
          l = ee.getErrorMessageByErrorType(r, u),
          d = (0, s.I0)(),
          f = {
            modalStyle: (0, i.useMemo)(function () {
              return {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "flex-start",
                padding: "30px 23px 15px",
                maxWidth: "500px",
              };
            }, []),
          }.modalStyle,
          h = (0, J.Z)();
        h.hasEmptyPage, h.toFunctionHomePage;
        var g = (0, c.Z)().cancelTaskProcessType,
          y = (0, X.Z)().pricingModalPopUp;
        (0, i.useEffect)(
          function () {
            o && (w(), j() && n(!0));
          },
          [o]
        );
        var w = function () {
            d((0, v.Iq)(!1)), g();
          },
          j = function () {
            return "Token insufficiency" !== u || (y($.k.outOfCredit), !1);
          },
          C = function () {
            n(!1);
          };
        return (0, b.jsxs)(_.Z, {
          opened: t,
          customStyles: f,
          handleClose: C,
          children: [
            (0, b.jsx)("div", {
              className: K().title,
              dangerouslySetInnerHTML: {
                __html: p.Z.sanitize(
                  r("message.dialog.title.text.to.image.engine.error"),
                  "br"
                ),
              },
            }),
            (0, b.jsx)("div", {
              className: K().desc,
              dangerouslySetInnerHTML: { __html: p.Z.sanitize(l, "b.br") },
            }),
            (0, b.jsx)(x.Z, {
              className: K().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: C,
              children: r("general.OK"),
            }),
            (0, b.jsx)("img", {
              className: K().close,
              src: "/assets/images/icon_close.svg",
              onClick: C,
            }),
          ],
        });
      }
    },
    88146: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return f;
        },
      });
      var r = n(67294),
        o = n(9473),
        i = n(84806),
        s = n(28953),
        a = n(72880),
        c = n(27361),
        u = n.n(c),
        l = n(45220),
        d = n.n(l);
      function f() {
        var e = (0, i.Z)(),
          t = e.isNotProd,
          n = e.isTest,
          c = (0, o.v9)(function (e) {
            return e.result;
          }),
          l = (0, o.v9)(function (e) {
            return e.task;
          }),
          f = c.task,
          p = f.processing,
          m = f.processType,
          _ = l.taskResult,
          h = (0, r.useMemo)(
            function () {
              return p && m === a.rh.processing;
            },
            [p, m]
          ),
          g = (0, r.useMemo)(
            function () {
              return u()(_, "queueLen", null);
            },
            [_]
          ),
          x = (0, r.useMemo)(
            function () {
              return u()(_, "queuePos", null);
            },
            [_]
          ),
          v = (0, r.useMemo)(
            function () {
              return u()(_, "estDueTs", null);
            },
            [_]
          ),
          b = (0, r.useMemo)(
            function () {
              return s.ZP.getParsedItem(s.XC.debug.showTaskQueue, !1);
            },
            [_]
          );
        return {
          canShowQueueMessage: (0, r.useMemo)(
            function () {
              return n
                ? h && !d()(g) && !d()(x)
                : t && b && h && !d()(g) && !d()(x);
            },
            [t, h, g, x, b]
          ),
          queueLen: g,
          queuePos: x,
          estDueTs: v,
        };
      }
    },
    53841: function (e, t) {
      "use strict";
      t.Z = {
        showGuideline: "show-guideline",
        processImage: "process-image",
        showFreeGift: "show-free-gift",
      };
    },
    55961: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return d;
        },
      });
      var r = n(9473),
        o = n(11163),
        i = n(67294),
        s = n(96453),
        a = n(25915),
        c = n(15613),
        u = n(89984),
        l = n(43263);
      function d() {
        var e = (0, s.Z)().isInSubscription,
          t = (0, a.Z)().isGuest,
          n = (0, o.useRouter)(),
          d = (0, r.I0)(),
          f = (0, r.v9)(function (e) {
            return e.info;
          });
        return {
          handleWatermarkClick: function () {
            e || c.Z.push(n, "/pricing");
          },
          handleGuestClickLoginFuntion: function () {
            t && d((0, l.eh)(!0));
          },
          toFunctionHomePage: function () {
            var e = f.moduleType,
              t = f.sodType,
              r = u.ZP.moduleTypeToURL(e, t);
            c.Z.push(n, r);
          },
          isLoginUser: (0, a.Z)().isLoginUser,
          hasEmptyPage: (0, i.useMemo)(
            function () {
              return ![
                u.ft.enhance,
                u.ft.colorize,
                u.ft.colorCorrection,
                u.ft.outPaint,
                u.ft.objReplace,
                u.ft.objRemoval,
                u.ft.sod,
                u.ft.cropPhoto,
                u.ft.flipAndRotateImage,
                u.ft.resizeImage,
              ].includes(f.moduleType);
            },
            [f.moduleType]
          ),
        };
      }
    },
    30351: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return x;
        },
      });
      var r = n(50029),
        o = n(87794),
        i = n.n(o),
        s = n(1864),
        a = n.n(s),
        c = n(11163),
        u = n(9473),
        l = n(42621),
        d = n(41379),
        f = n(95229),
        p = n(20327),
        m = n(89984),
        _ = n(15613),
        h = n(53841),
        g = n(1189);
      function x(e) {
        var t,
          n = e.inputRef,
          o = (0, p.Z)().initNewUplaodTask,
          s = (0, f.Z)().storeData,
          x = (0, d.Z)({ canDrop: !1 }).showUserConsentIfNecessary,
          v = (0, l.Z)().setProductConfig,
          b = (0, c.useRouter)(),
          y = (0, u.v9)(function (e) {
            return e.info;
          }),
          w = y.moduleType,
          j = y.sodType;
        return {
          handleInputClick: function () {
            m.qu.includes(w)
              ? v(w, { hairStyleStep: h.Z.showGuideline })
              : w === m.ft.muTransfer
              ? v(w, { step: g.Z.showGuideline })
              : x(function () {
                  null == n || n.current.click();
                });
          },
          handleInputFileChange:
            ((t = (0, r.Z)(
              i().mark(function e(t) {
                var n, r, c;
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((n = t.target.files[0]),
                          (t.target.value = ""),
                          !b.pathname.match(/\/share-result-photo/))
                        ) {
                          e.next = 9;
                          break;
                        }
                        return (e.next = 6), s(n);
                      case 6:
                        return (
                          (c = (r = m.ZP.moduleTypeToURL(w, j))
                            ? a().join(r, "result-photo")
                            : "/"),
                          e.abrupt("return", _.Z.push(b, c))
                        );
                      case 9:
                        return (e.next = 11), o(n);
                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
        };
      }
    },
    6899: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return eQ;
        },
      });
      var r = n(50029),
        o = n(87794),
        i = n.n(o),
        s = n(99831),
        a = n.n(s),
        c = n(37865),
        u = n.n(c),
        l = n(29501),
        d = n.n(l),
        f = n(67294),
        p = n(9473),
        m = n(11163),
        _ = n(42621),
        h = n(20327),
        g = n(55961),
        x = RegExp(/\/result-photo$/),
        v = n(79336),
        b = n(54473),
        y = n(27623),
        w = n(18224),
        j = n(14448),
        C = n(48956),
        S = n(72880),
        T = n(1848),
        k = n(9585),
        P = n(43263),
        I = n(15259),
        Z = n(63482),
        N = n(22467),
        M = n(1955),
        B = (0, M.Z)(function () {
          return Promise.all([n.e(7865), n.e(4264)]).then(n.bind(n, 33945));
        }),
        R = (0, M.Z)(function () {
          return Promise.all([n.e(7865), n.e(4350)]).then(n.bind(n, 92100));
        }),
        E = (0, M.Z)(function () {
          return Promise.all([n.e(5498), n.e(2637), n.e(1444)]).then(
            n.bind(n, 42769)
          );
        }),
        D = (0, M.Z)(function () {
          return Promise.all([n.e(5498), n.e(1834), n.e(2637), n.e(7291)]).then(
            n.bind(n, 59353)
          );
        }),
        O = (0, M.Z)(function () {
          return n.e(3205).then(n.bind(n, 13205));
        }),
        F = (0, M.Z)(function () {
          return Promise.all([n.e(7865), n.e(4796)]).then(n.bind(n, 75643));
        }),
        z = (0, M.Z)(function () {
          return Promise.all([
            n.e(6126),
            n.e(6066),
            n.e(7817),
            n.e(8269),
            n.e(9422),
            n.e(4892),
          ]).then(n.bind(n, 30430));
        }),
        A = (0, M.Z)(function () {
          return Promise.all([n.e(6126), n.e(6066), n.e(8269), n.e(1297)]).then(
            n.bind(n, 500)
          );
        }),
        W = (0, M.Z)(function () {
          return Promise.all([n.e(5498), n.e(2637), n.e(1910)]).then(
            n.bind(n, 3673)
          );
        }),
        L = (0, M.Z)(function () {
          return Promise.all([
            n.e(5498),
            n.e(6126),
            n.e(6066),
            n.e(2637),
            n.e(9642),
          ]).then(n.bind(n, 49070));
        }),
        H = (0, M.Z)(function () {
          return Promise.all([
            n.e(5498),
            n.e(7817),
            n.e(2637),
            n.e(9422),
            n.e(913),
          ]).then(n.bind(n, 40195));
        }),
        V = (0, M.Z)(function () {
          return Promise.all([n.e(6126), n.e(6066), n.e(8269), n.e(1443)]).then(
            n.bind(n, 66055)
          );
        }),
        q = (0, M.Z)(function () {
          return Promise.all([n.e(7865), n.e(54)]).then(n.bind(n, 93676));
        }),
        U = (0, M.Z)(function () {
          return n.e(9187).then(n.bind(n, 9187));
        }),
        G = (0, M.Z)(function () {
          return Promise.all([n.e(8269), n.e(8712), n.e(4133)]).then(
            n.bind(n, 58744)
          );
        }),
        Y = (0, M.Z)(function () {
          return Promise.all([n.e(6126), n.e(5113)]).then(n.bind(n, 25113));
        }),
        Q = (0, M.Z)(function () {
          return n.e(9916).then(n.bind(n, 69916));
        }),
        K = (0, M.Z)(function () {
          return n.e(9365).then(n.bind(n, 99365));
        }),
        J = n(97221),
        X = n(16714),
        $ = n.n(X),
        ee = n(88146),
        et = n(84338),
        en = n(49114),
        er = n(89984),
        eo = n(45220),
        ei = n.n(eo),
        es = n(27361),
        ea = n.n(es),
        ec = n(85893);
      function eu() {
        var e = (0, f.useState)(!1),
          t = e[0],
          n = e[1],
          r = (0, f.useState)(0),
          o = r[0],
          i = r[1],
          s = (0, f.useRef)(null),
          a = (0, et.PC)().t,
          c = (0, ee.Z)(),
          u = c.canShowQueueMessage,
          l = c.queueLen,
          d = c.queuePos,
          m = c.estDueTs,
          _ = (0, p.v9)(function (e) {
            return e.info;
          }),
          h = (0, p.v9)(function (e) {
            return e.result;
          }),
          g = h.images,
          x = h.task,
          v = x.processing,
          b = x.processType,
          y = (0, f.useMemo)(
            function () {
              var e = _.moduleType;
              return ea()(h, "productConfig.".concat(e, ".fromHistory"), !1);
            },
            [
              null == _ ? void 0 : _.moduleType,
              null == h ? void 0 : h.productConfig,
            ]
          ),
          w = (0, f.useMemo)(
            function () {
              return v && b === S.rh.uploading;
            },
            [v, b]
          ),
          j = (0, f.useMemo)(
            function () {
              return v && b === S.rh.processing;
            },
            [v, b]
          ),
          C = (0, f.useMemo)(
            function () {
              return !v && b === S.rh.success;
            },
            [v, b]
          ),
          T = (0, f.useMemo)(
            function () {
              return w
                ? "uploading"
                : j
                ? "processing"
                : C
                ? "success"
                : "status";
            },
            [w, j, C]
          ),
          k = (0, f.useMemo)(
            function () {
              var e = _.moduleType;
              return y
                ? a("loading.processing.title.videoSr.from.history")
                : e === er.ft.txt2Img
                ? a("loading.processing.title.txt2Img")
                : e === er.ft.muTransfer && j
                ? a("loading.processing.title.muTransfer")
                : e === er.ft.faceSwap && j
                ? a("loading.processing.title.face.swap")
                : C
                ? e === er.ft.lighting && ei()(g.after)
                  ? a("loading.success.title.sod")
                  : a("loading.success.title.".concat(e)) ||
                    a("loading.success.title.sod")
                : j
                ? a("loading.processing.title")
                : w
                ? a("loading.uploading.title")
                : void 0;
            },
            [v, b, _.moduleType, y]
          ),
          P = (0, f.useMemo)(
            function () {
              return _.moduleType === er.ft.faceSwap && j;
            },
            [_.moduleType, j]
          ),
          I = (0, f.useMemo)(
            function () {
              var e = _.moduleType;
              return y
                ? ""
                : e === er.ft.txt2Img
                ? a("loading.processing.subtitle.txt2Img")
                : (e === er.ft.muTransfer || e === er.ft.faceSwap) && j
                ? a("loading.processing.subtitle.muTransfer")
                : C
                ? ""
                : j
                ? e !== er.ft.lighting || g.beforeLoaded
                  ? (0, ec.jsx)("div", {
                      dangerouslySetInnerHTML: {
                        __html: en.Z.sanitize(
                          a(
                            "loading.processing.subtitle."
                              .concat(_.moduleType)
                              .concat(_.sodType || "")
                          ),
                          "br"
                        ),
                      },
                    })
                  : ""
                : b === S.rh.uploading
                ? a("loading.uploading.subtitle")
                : void 0;
            },
            [v, b, _.moduleType, y]
          );
        (0, f.useEffect)(
          function () {
            if (_.moduleType === er.ft.aiVideoFilters) {
              N(), i(0), n(!1);
              return;
            }
            v || b
              ? v || b !== S.rh.success
                ? v && _.moduleType !== er.ft.videoSr && n(!0)
                : setTimeout(function () {
                    N(), i(0), n(!1);
                  }, 1e3)
              : (N(), i(0), n(!1));
          },
          [v, b, _.moduleType]
        ),
          (0, f.useEffect)(
            function () {
              if (w) N(), Z(0 === o ? 0 : o, 0, 20);
              else if (j) {
                if ((N(), m)) {
                  var e = 0 === o ? 0 : o;
                  Z(e, e, 0 === d ? 90 : 60);
                } else {
                  N();
                  var t = 0 === o ? 0 : o;
                  Z(t, t, 30);
                }
              } else C ? (N(), Z(o, 99, 100)) : i(0);
            },
            [w, j, C, d, m]
          );
        var Z = function e(t, n, r) {
            var o =
              arguments.length > 3 && void 0 !== arguments[3]
                ? arguments[3]
                : 0.1;
            if (t >= r) {
              i(r);
              return;
            }
            i(t);
            var a = o * Math.pow((r - t) / (r - n), 0.6 + (d ? d / 1 : 0));
            s.current = setTimeout(function () {
              return e(t + a, n, r);
            }, 10 + Math.random());
          },
          N = function () {
            s.current && (clearTimeout(s.current), (s.current = null));
          };
        return t
          ? (0, ec.jsx)("div", {
              className: $().container,
              children: (0, ec.jsxs)("div", {
                className: $().content,
                children: [
                  (0, ec.jsx)("div", {
                    id: T,
                    className: ""
                      .concat($().title, " ")
                      .concat(P ? $().smallerTitleOnPad : ""),
                    children: k,
                  }),
                  (0, ec.jsx)("div", { className: $().subtitle, children: I }),
                  (0, ec.jsxs)("div", {
                    className: $().progress,
                    children: [
                      (0, ec.jsx)("div", {
                        className: $().progressBarBackground,
                        children: (0, ec.jsx)("div", {
                          className: $().progressBar,
                          style: { width: o + "%" },
                        }),
                      }),
                      (0, ec.jsxs)("div", {
                        className: $().progressText,
                        children: [parseInt(o), "%"],
                      }),
                    ],
                  }),
                  u &&
                    (0, ec.jsxs)("div", {
                      className: $().taskQueue,
                      children: [
                        "Task Queue Position: ",
                        "".concat(d, " / ").concat(l),
                      ],
                    }),
                ],
              }),
            })
          : null;
      }
      var el = n(59499),
        ed = n(4400),
        ef = n.n(ed),
        ep = n(61020);
      function em(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      var e_ = ef()({ storeAsString: !0 });
      function eh(e) {
        var t = e.cmsUseCaseMenu,
          n = (0, p.v9)(function (e) {
            return e;
          });
        return (
          (0, f.useEffect)(function () {
            return (
              JSON.parse("false") && console.log("redux: ", e_.stringify(n)),
              function () {}
            );
          }, []),
          (0, ec.jsxs)("div", {
            style: { width: "100%", height: "calc(100% - 64px)" },
            children: [
              (0, ec.jsx)(J.Z, { cmsUseCaseMenu: t }),
              (0, ec.jsx)(
                ep.Z,
                (function (e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2
                      ? em(Object(n), !0).forEach(function (t) {
                          (0, el.Z)(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : em(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                })(
                  {
                    id: "oops",
                    title: "invalid.other.title",
                    desc: "invalid.other.desc",
                    button: "general.return.to.home.button",
                  },
                  e
                )
              ),
            ],
          })
        );
      }
      var eg = n(70482),
        ex = n(86391),
        ev = n(61701),
        eb = n.n(ev),
        ey = n(45395),
        ew = n(18446),
        ej = n.n(ew),
        eC = n(41609),
        eS = n.n(eC),
        eT = n(15447),
        ek = n(56338),
        eP = n(17268),
        eI = n(93539),
        eZ = n(23276),
        eN = n(29040),
        eM = n(55246),
        eB = n(95861),
        eR = n(53492),
        eE = n.n(eR),
        eD = n(13472);
      function eO(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function eF(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? eO(Object(n), !0).forEach(function (t) {
                (0, el.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : eO(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function ez() {
        var e = (0, w.Z)().isDesktop,
          t = (0, f.useState)(!1),
          n = t[0],
          o = t[1],
          s = (0, f.useState)(!1),
          a = s[0],
          c = s[1],
          u = (0, f.useState)(!1),
          l = u[0],
          d = u[1],
          _ = (0, f.useState)(null),
          h = _[0],
          g = _[1],
          x = (0, f.useState)(!1),
          v = x[0],
          b = x[1],
          y = (0, f.useState)(""),
          j = y[0],
          C = y[1],
          S = (0, f.useState)("USD"),
          T = S[0],
          k = S[1],
          I = (0, et.PC)(),
          Z = I.t,
          N = I.locale,
          M = (0, p.I0)(),
          B = (0, m.useRouter)(),
          R = (0, p.v9)(function (e) {
            return e.info;
          }),
          E = (0, p.v9)(function (e) {
            return e.ui;
          }),
          D = (0, p.v9)(function (e) {
            return e.share;
          }),
          O = (0, p.v9)(function (e) {
            return e.api;
          }),
          F = E.discountModalOpened,
          z = ea()(R, "moduleType", null),
          A = ea()(R, "sodType", null),
          W = ea()(D, "sodConfig", null),
          L = er.ZP.getModuleType(z, A, W),
          H = (0, eZ.Z)({ plan: h, currency: T, handleClose: ee }),
          V = H.getSourceButton4DiscountModal,
          q = H.getSelectedGroupId,
          U = H.getSelectedProductName4GA,
          G = H.toCheckout,
          Y = H.handlePushDataLayer,
          Q = (0, eI.Z)(!0).subDataResult,
          K = (0, ek.Z)(),
          J = K.getProductFeatureDiscount,
          X = K.getProductDiscountWithoutExpired,
          $ = (0, eM.Z)().getProduct,
          ee = function () {
            o(!1),
              setTimeout(function () {
                M((0, P.Fs)(!1)), c(!1), d(!1);
              }, 300);
          },
          en = function (e, t) {
            var n = e.map(function (e, n) {
                var r;
                return (
                  (r = t[n]),
                  e
                    .map(function (e) {
                      var t = r ? J(e) : X(e);
                      return eS()(t)
                        ? null
                        : eF(eF({}, e), {}, { promotion: t });
                    })
                    .filter(Boolean)
                );
              }),
              r = !eS()(n[0]) || !eS()(n[1]),
              o = !eS()(n[0]) && !eS()(n[1]);
            if (!r) {
              ee();
              return;
            }
            if (eS()(n[0]) || o) {
              if (eS()(n[1]) || !Q.isValid) {
                ee();
                return;
              }
              g(n[1][0]), C(eN.kW.ENH_PAYS_TKN), b(!1);
            } else g(n[0][0]), C(eN.kW.ENH_SUB_TKN), Q.isValid ? b(!0) : b(!1);
            d(!0), c(!0);
          };
        (0, f.useEffect)(
          function () {
            var t,
              n =
                ((t = (0, r.Z)(
                  i().mark(function e() {
                    var t, n, r, o, s;
                    return i().wrap(
                      function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (e.prev = 0),
                                (e.next = 3),
                                $(!1, eD.R.abtestPricing)
                              );
                            case 3:
                              (t = e.sent.map(function (e) {
                                return eN.ZP.filterDiscountPlan({
                                  product: e,
                                  discountType: "".concat(L, "Disc"),
                                });
                              })),
                                (n = [!0, !0]),
                                eS()(t[0]) &&
                                  ((r = O.products[eN.kW.ENH_SUB_TKN].defDisc),
                                  (t[0] = r),
                                  (n[0] = !1)),
                                eS()(t[1]) &&
                                  ((o = O.products[eN.kW.ENH_PAYS_TKN].defDisc),
                                  (t[1] = o),
                                  (n[1] = !1)),
                                (s = ea()(
                                  Q.subData,
                                  "productDetail.info.customInfo.tokenInfo.amount",
                                  0
                                )),
                                en(
                                  [eN.ZP.filterSubAndAmount(t[0], s), t[1]],
                                  n
                                ),
                                (e.next = 17);
                              break;
                            case 13:
                              (e.prev = 13),
                                (e.t0 = e.catch(0)),
                                console.error("Error fetching products:", e.t0),
                                ee();
                            case 17:
                            case "end":
                              return e.stop();
                          }
                      },
                      e,
                      null,
                      [[0, 13]]
                    );
                  })
                )),
                function () {
                  return t.apply(this, arguments);
                });
            F && e && L ? Q.init && n() : ee();
          },
          [e, F, L, Q.init]
        ),
          (0, f.useEffect)(
            function () {
              if (null != O && O.initOK) {
                var e = ea()(O, "initResult.misc.country", null);
                (eB.SZ.includes(e) || eB.b1.includes(e)) &&
                  k(
                    2 === e.length
                      ? eE().getCurrencyByAlpha2(e)
                      : eE().getCurrencyByAlpha3(e)
                  );
              }
            },
            [null == O ? void 0 : O.initOK]
          );
        var eo = (0, f.useMemo)(
            function () {
              return ej()(ea()(h, "info.cycle"), 12);
            },
            [h]
          ),
          ei = (0, f.useMemo)(
            function () {
              if (a) {
                var e = (0, eT.T5)(h, T),
                  t = (0, eT.jK)(null == e ? void 0 : e.currency),
                  n = parseFloat(null == e ? void 0 : e.amount),
                  r =
                    (null == h ? void 0 : h.promotion) ||
                    ea()(h, "info.promotions[0]"),
                  o = parseInt(ea()(r, "discount.value") || 0),
                  i = (0, eT.ak)(
                    (n * (100 - o)) / 100,
                    null == e ? void 0 : e.currency
                  );
                return {
                  currencySymbol: t,
                  price: n,
                  discount: o,
                  discountPrice: i,
                };
              }
            },
            [a, h, N]
          );
        return ((0, f.useEffect)(
          function () {
            R.moduleType && a && ee();
          },
          [R.moduleType, R.sodType]
        ),
        (0, f.useEffect)(
          function () {
            l &&
              setTimeout(function () {
                o(!0);
              }, 300);
          },
          [l]
        ),
        (0, f.useEffect)(
          function () {
            l && (0, eP.z)("ToolPromoDialogImpression", { source: B.asPath });
          },
          [l]
        ),
        l && F)
          ? (0, ec.jsxs)("div", {
              className: ""
                .concat(eb().container, " ")
                .concat(n ? eb().show : ""),
              children: [
                (0, ec.jsx)("div", {
                  className: eb().title,
                  children: Z("discount.modal.title"),
                }),
                (0, ec.jsxs)("div", {
                  className: eb().discount,
                  children: [
                    (0, ec.jsxs)("span", {
                      className: eb().percent,
                      children: [null == ei ? void 0 : ei.discount, "%"],
                    }),
                    Z("discount.modal.off"),
                  ],
                }),
                (0, ec.jsx)("div", { className: eb().line }),
                (0, ec.jsxs)("div", {
                  children: [
                    (0, ec.jsxs)("div", {
                      className: eb().planRow1,
                      children: [
                        h &&
                          (0, ec.jsxs)("div", {
                            className: eb().planName,
                            children: [
                              h.info.customInfo.tokenInfo.amount,
                              " ",
                              Z(
                                ej()(j, eN.kW.ENH_SUB_TKN)
                                  ? "pricing.credit.plan.credits.mo"
                                  : "pricing.credit.plan.credits"
                              ),
                            ],
                          }),
                        (0, ec.jsxs)("div", {
                          className: eb().price,
                          children: [
                            null == ei ? void 0 : ei.currencySymbol,
                            null == ei ? void 0 : ei.price,
                          ],
                        }),
                      ],
                    }),
                    (0, ec.jsxs)("div", {
                      className: eb().planRow2,
                      children: [
                        eo
                          ? (0, ec.jsx)("div", {
                              className: eb().billed,
                              children: Z(
                                "pricing.credit.plan.billed.annually"
                              ),
                            })
                          : (0, ec.jsx)("div", {}),
                        (0, ec.jsxs)("div", {
                          className: eb().discountPrice,
                          children: [
                            null == ei ? void 0 : ei.currencySymbol,
                            null == ei ? void 0 : ei.discountPrice,
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                (0, ec.jsx)(ey.Z, {
                  className: eb().button,
                  onClick: function () {
                    return G({
                      sourceButtonValue: V(),
                      needLoginPopup: !1,
                      forceNoUpgrade: !1,
                      product_id: U(q()),
                      customFunc: Y,
                    });
                  },
                  children: Z(
                    v
                      ? "my.account.subscription.upgrade"
                      : "discount.modal.button"
                  ),
                }),
                (0, ec.jsx)("div", {
                  className: eb().close,
                  style: {
                    backgroundImage: "url(/assets/images/icon_close.svg)",
                  },
                  onClick: ee,
                }),
              ],
            })
          : null;
      }
      var eA = n(72658),
        eW = n(90440),
        eL = n(18901),
        eH = n(19161),
        eV = n(78569),
        eq = n(45270),
        eU = n(13311),
        eG = n.n(eU),
        eY = n(90219);
      function eQ(e) {
        var t,
          n,
          o,
          s,
          c,
          l,
          M,
          X,
          $,
          ee,
          et,
          en,
          eo,
          ei,
          es,
          el,
          ed,
          ef,
          ep = e.id,
          em = e.cmsContent,
          e_ = e.cmsUseCaseMenu,
          ev = e.cmsAnalyzerPreview,
          eb = (0, f.useState)(!1),
          ey = eb[0],
          ew = eb[1],
          eC = (0, f.useRef)(null),
          eS = (0, p.I0)(),
          eT = (0, m.useRouter)(),
          ek = (0, p.v9)(function (e) {
            return e.info;
          }),
          eP = (0, p.v9)(function (e) {
            return e.api;
          }),
          eI = (0, p.v9)(function (e) {
            return e.upload;
          }),
          eZ = (0, p.v9)(function (e) {
            return e.task;
          }),
          eN = (0, p.v9)(function (e) {
            return e.share;
          }),
          eM = (0, p.v9)(function (e) {
            return e.ui;
          }),
          eB = (0, p.v9)(function (e) {
            return e.result;
          }),
          eR = (0, p.v9)(function (e) {
            return e.user;
          }),
          eE = (0, p.v9)(function (e) {
            return e.cms;
          }),
          eD = ek.moduleType,
          eO = ek.sodType,
          eF = eP.initFail,
          eU = eP.getUploadUrlFail;
        eZ.processFail;
        var eQ = eN.shareFail,
          eK = eN.getInfoFail,
          eJ = eI.uploadFail,
          eX = eE.allButtons,
          e$ = eE.currentButtons,
          e0 = (0, h.Z)().initPage,
          e1 = (0, g.Z)().toFunctionHomePage,
          e2 = (0, _.Z)().setTaskFailed,
          e4 = (0, v.Z)(),
          e9 = e4.isInSharePage,
          e6 = e4.canShowFeaturesPanel,
          e8 = e4.isBottomBlockHidden,
          e3 = e4.hideModuleName,
          e5 = e4.needAppendSignUpPromotePadding,
          e7 = (0, y.Z)().isBasicEditing,
          te = (0, w.Z)().isDesktop,
          tt = (0, b.Z)().checkTriedStatus,
          tn = (0, j.Z)({ content: em, moduleType: eV.I[eD] }).isLoaded;
        (t = (0, m.useRouter)()),
          (n = (0, f.useRef)(!1)),
          (o = (0, f.useRef)(!1)),
          (s = (0, p.v9)(function (e) {
            return e.share;
          })),
          (c = (0, p.v9)(function (e) {
            return e.yceData;
          })),
          (l = (0, p.v9)(function (e) {
            return e.task;
          })),
          (M = c.base64),
          (X = s.srcFileId),
          ($ = s.previewFileId),
          (ee = s.previewUrl),
          (et = s.compressedYCEData),
          (en = s.modelId),
          (eo = l.processing),
          (ei = (0, f.useMemo)(
            function () {
              return !!t.isReady && x.test(t.pathname);
            },
            [t.isReady, t.pathname]
          )),
          (0, f.useEffect)(function () {
            return (
              window.addEventListener("beforeunload", es),
              function () {
                removeEventListener("beforeunload", es);
              }
            );
          }, []),
          (0, f.useEffect)(
            function () {
              t.isReady && t.beforePopState(el);
            },
            [t]
          ),
          (0, f.useEffect)(
            function () {
              ei && (M || X || $ || ee || et.base64 || en || eo)
                ? (o.current = !0)
                : (o.current = !1);
            },
            [ei, M, X, $, ee, et, en, eo]
          ),
          (es = function (e) {
            if (o.current) return e.preventDefault(), (e.returnValue = null);
          }),
          (el = function () {
            var e, t;
            if (n.current) {
              n.current = !n.current;
              return;
            }
            return (
              (n.current = !n.current),
              history.forward(),
              null === (e = window) ||
                void 0 === e ||
                null === (t = e.location) ||
                void 0 === t ||
                t.reload(),
              !1
            );
          }),
          (ed = (0, p.I0)()),
          (0, f.useEffect)(function () {
            return function () {
              ed((0, S.Q$)()),
                ed((0, k.xs)()),
                ed((0, T.F0)()),
                ed((0, I.wF)()),
                ed((0, N.NU)()),
                ed((0, P.Fs)(!1)),
                ed((0, Z.$2)(!1)),
                ed((0, C.Bs)({ moduleType: null, sodType: null }));
            };
          }, []);
        var tr = (0, eY.ZP)({ moduleType: eD }),
          to = tr.updateAutoStates,
          ti = tr.handleAutoChangeActiveSubCategory,
          ts = tr.selectedGroupId,
          ta = tr.selectedGroupStyleIds,
          tc = tr.setSelectedGroupId,
          tu = tr.setSelectedGroupStyleIds,
          tl = tr.groups,
          td = tr.groupStyles,
          tf = tr.onSubCategorySelect,
          tp = (0, f.useMemo)(
            function () {
              return eT.isReady && eR.checked;
            },
            [eT.isReady, eR.checked]
          ),
          tm = (0, f.useMemo)(
            function () {
              return ea()(u(), eD, u().default);
            },
            [eD]
          ),
          t_ = (0, f.useMemo)(
            function () {
              var e = ea()(d(), eD, d().default);
              return e9
                ? (e += " ".concat(d().mainBlockForShare))
                : (e5 && (e += " ".concat(d().signUpPromotePadding)), e);
            },
            [eD, e5, e9]
          );
        (0, f.useEffect)(function () {
          tg(), th();
          var e = document.querySelector("html");
          return (
            (e.style.overscrollBehavior = "none"),
            function () {
              var t, n, r, o, i;
              (e.style.overscrollBehavior = "unset"),
                null === (t = window) ||
                  void 0 === t ||
                  null === (n = t.document) ||
                  void 0 === n ||
                  null === (r = n.body) ||
                  void 0 === r ||
                  null === (o = r.classList) ||
                  void 0 === o ||
                  null === (i = o.remove) ||
                  void 0 === i ||
                  i.call(o, "body-result-photo-ios-15");
            }
          );
        }, []),
          (0, f.useEffect)(
            function () {
              tp &&
                e0(function () {
                  return ew(!0);
                });
            },
            [tp]
          ),
          (0, f.useEffect)(
            function () {
              ey &&
                (eQ || eK || eF || eU || eJ) &&
                (e2(S.wt.imageProcessingFail), eS((0, P.Iq)(!1)));
            },
            [eQ, eK, eF, eU, eJ]
          ),
          (0, f.useEffect)(
            function () {
              if (tn && eV.I[eD] !== (null == e$ ? void 0 : e$.moduleType)) {
                var e = eG()(eX, function (e) {
                  return e.moduleType === eD;
                });
                eS((0, eq.e3)(eV.I[eD], e));
              }
            },
            [eD, tn]
          );
        var th = function () {
            var e, t, n, r, o;
            eH.Z.isIOsVersion(15) &&
              (null === (e = window) ||
                void 0 === e ||
                null === (t = e.document) ||
                void 0 === t ||
                null === (n = t.body) ||
                void 0 === n ||
                null === (r = n.classList) ||
                void 0 === r ||
                null === (o = r.add) ||
                void 0 === o ||
                o.call(r, "body-result-photo-ios-15"));
          },
          tg =
            ((ef = (0, r.Z)(
              i().mark(function e() {
                var t;
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((t = ea()(ek, "accType")),
                          !(ej()(eD, er.ft.txt2Img) && !ej()(t, "guest")))
                        ) {
                          e.next = 4;
                          break;
                        }
                        return (e.next = 4), tt({});
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return ef.apply(this, arguments);
            }),
          tx = (0, f.useCallback)(
            function () {
              if (ey) {
                if (ep && eD !== er.ft.faceSwap)
                  return (0, ec.jsx)(B, { id: ep, isBottomBlockHidden: e8 });
                if (eD === er.ft.enhance) return (0, ec.jsx)(R, {});
                if (eD === er.ft.objRemoval) return (0, ec.jsx)(E, {});
                if (eD === er.ft.sod) return (0, ec.jsx)(D, {});
                else if (eD === er.ft.colorize) return (0, ec.jsx)(O, {});
                else if (eD === er.ft.lighting) return (0, ec.jsx)(F, {});
                else if (eD === er.ft.txt2Img) return (0, ec.jsx)(z, {});
                else if (er.qu.includes(eD)) return (0, ec.jsx)(A, {});
                else if (eD === er.ft.outPaint) return (0, ec.jsx)(L, {});
                else if (e7) return (0, ec.jsx)(W, {});
                else if (eD === er.ft.objReplace) return (0, ec.jsx)(H, {});
                else if (eD === er.ft.muTransfer) return (0, ec.jsx)(V, {});
                else if (eD === er.ft.colorCorrection)
                  return (0, ec.jsx)(q, {});
                else if (eD === er.ft.videoSr) return (0, ec.jsx)(U, {});
                else if (eD === er.ft.aiVideoFilters)
                  return (0, ec.jsx)(Q, {
                    updateAutoStates: to,
                    handleAutoChangeActiveSubCategory: ti,
                    groups: tl,
                    groupStyles: td,
                    selectedGroupId: ts,
                    selectedGroupStyleIds: ta,
                    setSelectedGroupId: tc,
                    setSelectedGroupStyleIds: tu,
                    onSubCategorySelect: tf,
                  });
                else if (eD === er.ft.faceShapeDetector)
                  return (0, ec.jsx)(G, {
                    cmsContent: em,
                    cmsAnalyzerPreview: ev,
                  });
                else if (eD === er.ft.faceSwap)
                  return (0, ec.jsx)(Y, { id: ep });
                else if (eD === er.ft.faceSwapVid) return (0, ec.jsx)(K, {});
                return null;
              }
            },
            [ep, ey, eD, eO, e8, ts, ta, tl, td, te]
          );
        if (eB.task.failed)
          return (0, ec.jsx)("div", {
            className: a().otherInvalidContainer,
            children: (0, ec.jsx)("div", {
              className: a().otherInvalid,
              children: (0, ec.jsx)(eh, {
                handleButtonClick: e1,
                cmsUseCaseMenu: e_,
              }),
            }),
          });
        var tv = function (e) {
          eD === er.ft.aiVideoFilters && e && e();
        };
        return (0, ec.jsxs)("div", {
          className: a().fullContainer,
          children: [
            (0, ec.jsx)(J.Z, { cmsUseCaseMenu: e_ }),
            (0, ec.jsxs)("div", {
              id: "YCE-result-photo-container",
              ref: eC,
              className: "".concat(tm, " hidden-scrollbar"),
              onWheel: function () {
                return tv(function () {
                  return to(void 0, !0);
                });
              },
              onTouchMove: function () {
                return tv(function () {
                  return to(void 0, !0);
                });
              },
              onScroll: function () {
                return tv(ti);
              },
              children: [
                (0, ec.jsx)(eu, {}),
                !e3 && (0, ec.jsx)(ex.Z, {}),
                (0, ec.jsxs)("div", {
                  id: "YCE-result-photo-main-block",
                  className: t_,
                  children: [te && e6 && (0, ec.jsx)(eL.y, {}), tx()],
                }),
                !e8 && (0, ec.jsx)(eA.e, {}),
              ],
            }),
            (0, ec.jsx)(eg.Z, {}),
            (0, ec.jsx)(eW.kV, {}),
            (0, ec.jsx)(eW.eQ, {}),
            eM.discountModalOpened && (0, ec.jsx)(ez, {}),
            (0, ec.jsx)("iframe", {
              id: "yce-result-download-iframe",
              style: { display: "none" },
            }),
          ],
        });
      }
    },
    1189: function (e, t) {
      "use strict";
      t.Z = {
        showGuideline: "show-guideline",
        showRefGuideline: "show-ref-guideline",
        processImage: "process-image",
        showFreeGift: "show-free-gift",
      };
    },
    90869: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "sidebar_container__oKdGo",
        sticky: "sidebar_sticky__TlAP1",
        title: "sidebar_title__hbP1V",
        desc: "sidebar_desc__8XcF3",
        scrollable: "sidebar_scrollable__cmCNd",
        groups: "sidebar_groups__7uKGZ",
        groupPadding: "sidebar_groupPadding__f2kMg",
        group: "sidebar_group__f2F_F",
        groupActive: "sidebar_groupActive__mr34P",
        stylesContainer: "sidebar_stylesContainer__iZuWC",
        stylesBlock: "sidebar_stylesBlock__yDTy5",
        groupContainer: "sidebar_groupContainer__QLY9V",
        styleFlexBox: "sidebar_styleFlexBox__r32Az",
        styleOuterWrapper: "sidebar_styleOuterWrapper__Y0Y17",
        styleOuterWrapperActive: "sidebar_styleOuterWrapperActive__8XKHz",
        styleInnerWrapper: "sidebar_styleInnerWrapper__hwFPb",
        stylePaddingTop: "sidebar_stylePaddingTop__DJ7_S",
        imageBlock: "sidebar_imageBlock__FPL5H",
        styleImage: "sidebar_styleImage__SvS5f",
        downloadBlock: "sidebar_downloadBlock__cRlUN",
        buttonsBlock: "sidebar_buttonsBlock__5USOO",
        uploadButton: "sidebar_uploadButton___nOo_",
        uploadIcon: "sidebar_uploadIcon__OaSIT",
        downloadButton: "sidebar_downloadButton___cv_t",
        downloadButtonActive: "sidebar_downloadButtonActive__Hb9m1",
        buttonText: "sidebar_buttonText__UXGx8",
        creditText: "sidebar_creditText__Qtsgg",
        loadingIcon: "sidebar_loadingIcon__b2cfm",
        loadingIconActive: "sidebar_loadingIconActive__Gbt_D",
      };
    },
    83099: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "bottom-block-type-1_container__HiRvq",
        uploadIcon: "bottom-block-type-1_uploadIcon__tOmDo",
        button: "bottom-block-type-1_button__fvj44",
        uploadButton: "bottom-block-type-1_uploadButton__XojjE",
      };
    },
    58499: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "default-bottom-block_container__ThoVd",
        bottomBlock: "default-bottom-block_bottomBlock__k96BU",
        bottomBlockHidden: "default-bottom-block_bottomBlockHidden__fYkWR",
      };
    },
    61701: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        close: "discount-modal_close__Ke_3B",
        container: "discount-modal_container__SNgOG",
        show: "discount-modal_show__xXgDP",
        title: "discount-modal_title__t6UN2",
        discount: "discount-modal_discount__lgolJ",
        percent: "discount-modal_percent__wrMpH",
        line: "discount-modal_line__n2b6M",
        planRow1: "discount-modal_planRow1__YEszy",
        planName: "discount-modal_planName__aizxO",
        price: "discount-modal_price__DWTrH",
        planRow2: "discount-modal_planRow2__HsZ8C",
        billed: "discount-modal_billed__jKj06",
        discountPrice: "discount-modal_discountPrice__9gCTE",
        button: "discount-modal_button__kH7E_",
      };
    },
    59062: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "features-panel-dt_container__CY9Kg",
        containerCollapsed: "features-panel-dt_containerCollapsed__6kJmi",
        featuresPanel: "features-panel-dt_featuresPanel__Aojex",
        title: "features-panel-dt_title__yBOLj",
        category: "features-panel-dt_category__H_Zk2",
        product: "features-panel-dt_product__cjqxd",
        productDisabled: "features-panel-dt_productDisabled__28vXI",
        productIcon: "features-panel-dt_productIcon__roqHe",
        productText: "features-panel-dt_productText__GwYrM",
        controlBackground: "features-panel-dt_controlBackground__qqmJA",
        control: "features-panel-dt_control__jHchI",
        controlCollapsed: "features-panel-dt_controlCollapsed__CVUSu",
        addPadding: "features-panel-dt_addPadding__ZZNAr",
      };
    },
    57115: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        containerLeft: "features-panel-mb_containerLeft__rn9Kt",
        containerRight: "features-panel-mb_containerRight__MvlNw",
        triggerButton: "features-panel-mb_triggerButton__jgqF_",
        triggerButtonSmallText:
          "features-panel-mb_triggerButtonSmallText__m9aKW",
        arrowIcon: "features-panel-mb_arrowIcon__S_hNY",
        featuresPanel: "features-panel-mb_featuresPanel__wG5Yn",
        featuresPanelCollapsed:
          "features-panel-mb_featuresPanelCollapsed___oO5C",
        products: "features-panel-mb_products__FK0sP",
        product: "features-panel-mb_product__2icg4",
        productDisabled: "features-panel-mb_productDisabled__RqhTe",
        productTitle: "features-panel-mb_productTitle__nwQtW",
        productIconWrapper: "features-panel-mb_productIconWrapper__wEv5q",
        productIcon: "features-panel-mb_productIcon__Aq6OR",
        productText: "features-panel-mb_productText__bd1s6",
        controlBackground: "features-panel-mb_controlBackground__BoL4L",
        control: "features-panel-mb_control__o8Gxf",
        mask: "features-panel-mb_mask__Kx7o4",
        maskCollapsed: "features-panel-mb_maskCollapsed__bnQjl",
      };
    },
    86985: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        title: "face-detect_title__pepbr",
        desc: "face-detect_desc__i6F1D",
        button: "face-detect_button__CrW89",
        close: "face-detect_close__RgyBX",
      };
    },
    72809: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        buttons: "scenario1_buttons__hev6h",
        buttonWhite: "scenario1_buttonWhite__zVDbi",
        buttonBlue: "scenario1_buttonBlue__nsw9n",
        close: "scenario1_close__ymDUJ",
      };
    },
    85098: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        buttons: "scenario4_buttons__crLgZ",
        buttonWhite: "scenario4_buttonWhite__kI8xJ",
        buttonBlue: "scenario4_buttonBlue__4xUyB",
      };
    },
    64440: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        scenario1Container: "features-panel_scenario1Container__fxJIx",
        scenario4Container: "features-panel_scenario4Container__wELtE",
        title: "features-panel_title__QBUK_",
        scenario1Desc: "features-panel_scenario1Desc__Gk_c8",
        scenario4Desc: "features-panel_scenario4Desc__2lTP8",
        close: "features-panel_close__myrlL",
      };
    },
    22902: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        title: "per-module-error_title__CRlWT",
        desc: "per-module-error_desc___0C3I",
        button: "per-module-error_button__B1fvo",
        close: "per-module-error_close__ZoYBq",
      };
    },
    90030: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        title: "server-error_title__weLCi",
        desc: "server-error_desc__IxaEV",
        button: "server-error_button__dCxJH",
        close: "server-error_close__CX1pX",
      };
    },
    16714: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "process-status_container__0AaoC",
        "fade-in": "process-status_fade-in__W_s4o",
        content: "process-status_content__A8fAV",
        title: "process-status_title__392Ix",
        smallerTitleOnPad: "process-status_smallerTitleOnPad__7YhBZ",
        subtitle: "process-status_subtitle__ijhPh",
        icon: "process-status_icon__4DJS3",
        progress: "process-status_progress__k39_f",
        progressBarBackground: "process-status_progressBarBackground__EIFBQ",
        progressBar: "process-status_progressBar__2CyyT",
        blink: "process-status_blink__1gx1P",
        progressText: "process-status_progressText__RVXOH",
        taskQueue: "process-status_taskQueue__zuQs3",
      };
    },
    45790: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "zoom-slider_container__LngRp",
        containerForViewer: "zoom-slider_containerForViewer__VIPRs",
        transparent: "zoom-slider_transparent__E63lm",
        sizes: "zoom-slider_sizes__pVDxG",
        width: "zoom-slider_width__MmPQ1",
        height: "zoom-slider_height__ek_l8",
        sizesSmallScreen: "zoom-slider_sizesSmallScreen__QE2rA",
        size: "zoom-slider_size___HbC_",
        zoomSliderContainer: "zoom-slider_zoomSliderContainer__p2cgP",
        slider: "zoom-slider_slider__A9CeO",
        hideSliderThumb: "zoom-slider_hideSliderThumb__jaBZF",
        button: "zoom-slider_button__olJBy",
        disabled: "zoom-slider_disabled__ZASHf",
        number: "zoom-slider_number__vHUpb",
        icon: "zoom-slider_icon__bilnD",
        reset: "zoom-slider_reset__f9ubK",
        upload: "zoom-slider_upload__1QKQI",
        uploadIcon: "zoom-slider_uploadIcon__Z5u2e",
        uploadForViewer: "zoom-slider_uploadForViewer__Sr55D",
      };
    },
    37865: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        default: "index-container_default__zz8p_",
        enhance: "index-container_enhance__awOlY",
        sod: "index-container_sod___RQh8",
        colorize: "index-container_colorize__sCAJx",
        colorCorrection: "index-container_colorCorrection__VhPx3",
        lighting: "index-container_lighting__CJtyG",
        outPaint: "index-container_outPaint__QRdI6",
        objReplace: "index-container_objReplace__7XmiF",
        objRemoval: "index-container_objRemoval__uHv_P",
        cropPhoto: "index-container_cropPhoto__ssn_v",
        flipAndRotateImage: "index-container_flipAndRotateImage__d9qFB",
        resizeImage: "index-container_resizeImage__sVIu5",
        muTransfer: "index-container_muTransfer__rs1VW",
        videoSr: "index-container_videoSr__9Qvu0",
        videoTrans: "index-container_videoTrans__RWslM",
        txt2Img: "index-container_txt2Img__sJe9l",
        hairStyle: "index-container_hairStyle__fTlsl",
        hairExt: "index-container_hairExt__cJ88Q",
        hairBang: "index-container_hairBang__po4Fc",
        hairVol: "index-container_hairVol__mf7Gt",
        faceSwap: "index-container_faceSwap__0UYW_",
        faceSwapVid: "index-container_faceSwapVid__xmat7",
        faceShapeDetector: "index-container_faceShapeDetector__5sQY8",
      };
    },
    29501: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        default: "index-main-block_default__UJ9n1",
        signUpPromotePadding: "index-main-block_signUpPromotePadding__cucoz",
        enhance: "index-main-block_enhance__Q9wnh",
        mainBlockForShare: "index-main-block_mainBlockForShare__12yuQ",
        videoSr: "index-main-block_videoSr__WQ8b_",
        videoTrans: "index-main-block_videoTrans__AJpES",
        sod: "index-main-block_sod__dujNw",
        colorize: "index-main-block_colorize__hW3hI",
        colorCorrection: "index-main-block_colorCorrection__2SELy",
        lighting: "index-main-block_lighting__0LJV0",
        outPaint: "index-main-block_outPaint__2QAJ2",
        objReplace: "index-main-block_objReplace__mKCho",
        objRemoval: "index-main-block_objRemoval__R1dJ8",
        cropPhoto: "index-main-block_cropPhoto__RBmSC",
        flipAndRotateImage: "index-main-block_flipAndRotateImage__b0LXP",
        resizeImage: "index-main-block_resizeImage__iH1s9",
        txt2Img: "index-main-block_txt2Img__RWG7A",
        hairStyle: "index-main-block_hairStyle__2Ttuh",
        hairExt: "index-main-block_hairExt__JTDTI",
        hairBang: "index-main-block_hairBang__rRJaH",
        faceShapeDetector: "index-main-block_faceShapeDetector__IKF4W",
        faceSwap: "index-main-block_faceSwap__eosns",
        faceSwapVid: "index-main-block_faceSwapVid__XvzA8",
        muTransfer: "index-main-block_muTransfer__t0Tp7",
      };
    },
    99831: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        fullContainer: "result-page_fullContainer__ce0qf",
        otherInvalidContainer: "result-page_otherInvalidContainer__EACm8",
        otherInvalid: "result-page_otherInvalid__XK0sj",
      };
    },
    92703: function (e, t, n) {
      "use strict";
      var r = n(50414);
      function o() {}
      function i() {}
      (i.resetWarningCache = o),
        (e.exports = function () {
          function e(e, t, n, o, i, s) {
            if (s !== r) {
              var a = Error(
                "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
              );
              throw ((a.name = "Invariant Violation"), a);
            }
          }
          function t() {
            return e;
          }
          e.isRequired = e;
          var n = {
            array: e,
            bigint: e,
            bool: e,
            func: e,
            number: e,
            object: e,
            string: e,
            symbol: e,
            any: e,
            arrayOf: t,
            element: e,
            elementType: e,
            instanceOf: t,
            node: e,
            objectOf: t,
            oneOf: t,
            oneOfType: t,
            shape: t,
            exact: t,
            checkPropTypes: i,
            resetWarningCache: o,
          };
          return (n.PropTypes = n), n;
        });
    },
    45697: function (e, t, n) {
      e.exports = n(92703)();
    },
    50414: function (e) {
      "use strict";
      e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    },
    68356: function (e, t, n) {
      "use strict";
      var r =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            };
      function o(e, t) {
        if (!(e instanceof t))
          throw TypeError("Cannot call a class as a function");
      }
      function i(e, t) {
        if (!e)
          throw ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t && ("object" == typeof t || "function" == typeof t) ? t : e;
      }
      function s(e, t) {
        if ("function" != typeof t && null !== t)
          throw TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
      var a = n(67294),
        c = n(45697),
        u = [],
        l = [];
      function d(e) {
        var t = e(),
          n = { loading: !0, loaded: null, error: null };
        return (
          (n.promise = t
            .then(function (e) {
              return (n.loading = !1), (n.loaded = e), e;
            })
            .catch(function (e) {
              throw ((n.loading = !1), (n.error = e), e);
            })),
          n
        );
      }
      function f(e) {
        var t = { loading: !1, loaded: {}, error: null },
          n = [];
        try {
          Object.keys(e).forEach(function (r) {
            var o = d(e[r]);
            o.loading
              ? (t.loading = !0)
              : ((t.loaded[r] = o.loaded), (t.error = o.error)),
              n.push(o.promise),
              o.promise
                .then(function (e) {
                  t.loaded[r] = e;
                })
                .catch(function (e) {
                  t.error = e;
                });
          });
        } catch (r) {
          t.error = r;
        }
        return (
          (t.promise = Promise.all(n)
            .then(function (e) {
              return (t.loading = !1), e;
            })
            .catch(function (e) {
              throw ((t.loading = !1), e);
            })),
          t
        );
      }
      function p(e, t) {
        return a.createElement(e && e.__esModule ? e.default : e, t);
      }
      function m(e, t) {
        if (!t.loading)
          throw Error("react-loadable requires a `loading` component");
        var d,
          f,
          m = Object.assign(
            {
              loader: null,
              loading: null,
              delay: 200,
              timeout: null,
              render: p,
              webpack: null,
              modules: null,
            },
            t
          ),
          _ = null;
        function h() {
          return _ || (_ = e(m.loader)), _.promise;
        }
        return (
          u.push(h),
          "function" == typeof m.webpack &&
            l.push(function () {
              var e;
              if (
                ((e = m.webpack),
                "object" === r(n.m) &&
                  e().every(function (e) {
                    return void 0 !== e && void 0 !== n.m[e];
                  }))
              )
                return h();
            }),
          (f = d =
            (function (t) {
              function n(r) {
                o(this, n);
                var s = i(this, t.call(this, r));
                return (
                  (s.retry = function () {
                    s.setState({ error: null, loading: !0, timedOut: !1 }),
                      (_ = e(m.loader)),
                      s._loadModule();
                  }),
                  h(),
                  (s.state = {
                    error: _.error,
                    pastDelay: !1,
                    timedOut: !1,
                    loading: _.loading,
                    loaded: _.loaded,
                  }),
                  s
                );
              }
              return (
                s(n, t),
                (n.preload = function () {
                  return h();
                }),
                (n.prototype.componentWillMount = function () {
                  (this._mounted = !0), this._loadModule();
                }),
                (n.prototype._loadModule = function () {
                  var e = this;
                  if (
                    (this.context.loadable &&
                      Array.isArray(m.modules) &&
                      m.modules.forEach(function (t) {
                        e.context.loadable.report(t);
                      }),
                    _.loading)
                  ) {
                    "number" == typeof m.delay &&
                      (0 === m.delay
                        ? this.setState({ pastDelay: !0 })
                        : (this._delay = setTimeout(function () {
                            e.setState({ pastDelay: !0 });
                          }, m.delay))),
                      "number" == typeof m.timeout &&
                        (this._timeout = setTimeout(function () {
                          e.setState({ timedOut: !0 });
                        }, m.timeout));
                    var t = function () {
                      e._mounted &&
                        (e.setState({
                          error: _.error,
                          loaded: _.loaded,
                          loading: _.loading,
                        }),
                        e._clearTimeouts());
                    };
                    _.promise
                      .then(function () {
                        t();
                      })
                      .catch(function (e) {
                        t();
                      });
                  }
                }),
                (n.prototype.componentWillUnmount = function () {
                  (this._mounted = !1), this._clearTimeouts();
                }),
                (n.prototype._clearTimeouts = function () {
                  clearTimeout(this._delay), clearTimeout(this._timeout);
                }),
                (n.prototype.render = function () {
                  return this.state.loading || this.state.error
                    ? a.createElement(m.loading, {
                        isLoading: this.state.loading,
                        pastDelay: this.state.pastDelay,
                        timedOut: this.state.timedOut,
                        error: this.state.error,
                        retry: this.retry,
                      })
                    : this.state.loaded
                    ? m.render(this.state.loaded, this.props)
                    : null;
                }),
                n
              );
            })(a.Component)),
          (d.contextTypes = {
            loadable: c.shape({ report: c.func.isRequired }),
          }),
          f
        );
      }
      function _(e) {
        return m(d, e);
      }
      _.Map = function (e) {
        if ("function" != typeof e.render)
          throw Error(
            "LoadableMap requires a `render(loaded, props)` function"
          );
        return m(f, e);
      };
      var h = (function (e) {
        function t() {
          return o(this, t), i(this, e.apply(this, arguments));
        }
        return (
          s(t, e),
          (t.prototype.getChildContext = function () {
            return { loadable: { report: this.props.report } };
          }),
          (t.prototype.render = function () {
            return a.Children.only(this.props.children);
          }),
          t
        );
      })(a.Component);
      function g(e) {
        for (var t = []; e.length; ) {
          var n = e.pop();
          t.push(n());
        }
        return Promise.all(t).then(function () {
          if (e.length) return g(e);
        });
      }
      (h.propTypes = { report: c.func.isRequired }),
        (h.childContextTypes = {
          loadable: c.shape({ report: c.func.isRequired }).isRequired,
        }),
        (_.Capture = h),
        (_.preloadAll = function () {
          return new Promise(function (e, t) {
            g(u).then(e, t);
          });
        }),
        (_.preloadReady = function () {
          return new Promise(function (e, t) {
            g(l).then(e, e);
          });
        }),
        (e.exports = _);
    },
  },
]);
