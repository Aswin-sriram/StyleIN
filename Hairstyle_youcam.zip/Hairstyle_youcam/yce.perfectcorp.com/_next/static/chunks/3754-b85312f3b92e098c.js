(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3754],
  {
    93754: function (e, r, t) {
      "use strict";
      t.d(r, {
        Z: function () {
          return j;
        },
      });
      var n = t(59499),
        o = t(63285),
        i = t.n(o),
        a = t(67294),
        c = t(11163),
        p = t(84338),
        s = t(54555),
        u = t(7146),
        d = t(50029),
        l = t(87794),
        h = t.n(l),
        f = t(37565),
        m = t.n(f),
        v = t(9473),
        w = t(43263),
        g = t(15613),
        _ = t(67822),
        x = t(85893);
      function k(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          r &&
            (n = n.filter(function (r) {
              return Object.getOwnPropertyDescriptor(e, r).enumerable;
            })),
            t.push.apply(t, n);
        }
        return t;
      }
      function b(e) {
        var r = e.buttonStyle,
          t = e.showUserConsentIfNecessary,
          o = void 0 === t ? function () {} : t,
          i = (0, _.Z)().cameraEnabled,
          a = (0, p.PC)().t,
          s = (0, c.useRouter)(),
          u = (0, v.I0)(),
          l = function () {
            o(
              (0, d.Z)(
                h().mark(function e() {
                  return h().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), u((0, w.Gh)({ photoTaker: !0 }));
                        case 2:
                          g.Z.push(s, "/face-shape-detector/result-photo");
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )
            );
          };
        return i
          ? (0, x.jsx)("div", {
              className: "".concat(m().photoTakerOuterWrapper),
              style: { backgroundColor: "#FFFFFF", zIndex: 0 },
              onClick: function () {
                l();
              },
              children: (0, x.jsxs)("div", {
                className: m().photoTakerInnerWrapper,
                children: [
                  (0, x.jsx)("img", {
                    className: m().cameraImage,
                    src: "/assets/images/moduleBanner/btn_camera.png",
                  }),
                  (0, x.jsx)("div", {
                    className: m().flex,
                    children: (0, x.jsx)("div", {
                      className: "".concat(m().chooseFileButton),
                      style: (function (e) {
                        for (var r = 1; r < arguments.length; r++) {
                          var t = null != arguments[r] ? arguments[r] : {};
                          r % 2
                            ? k(Object(t), !0).forEach(function (r) {
                                (0, n.Z)(e, r, t[r]);
                              })
                            : Object.getOwnPropertyDescriptors
                            ? Object.defineProperties(
                                e,
                                Object.getOwnPropertyDescriptors(t)
                              )
                            : k(Object(t)).forEach(function (r) {
                                Object.defineProperty(
                                  e,
                                  r,
                                  Object.getOwnPropertyDescriptor(t, r)
                                );
                              });
                        }
                        return e;
                      })({ backgroundColor: "#03ade2" }, void 0 === r ? {} : r),
                      children: a("webtry.take.photo"),
                    }),
                  }),
                ],
              }),
            })
          : null;
      }
      function y(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          r &&
            (n = n.filter(function (r) {
              return Object.getOwnPropertyDescriptor(e, r).enumerable;
            })),
            t.push.apply(t, n);
        }
        return t;
      }
      function j(e) {
        var r = e.fromHomePage,
          t = void 0 !== r && r,
          o = e.dragging,
          d = void 0 !== o && o,
          l = e.handleDragLeave,
          h = e.cancelDefault,
          f = e.handleDrop,
          m = e.handleInputClick,
          v = void 0 === m ? function () {} : m,
          w = e.handleInputFileChange,
          g = e.buttonText,
          _ = e.buttonStyle,
          k = void 0 === _ ? {} : _,
          j = e.buttonDescriptionText,
          F = void 0 === j ? "" : j,
          O = e.videoImage,
          C = e.showPhotoTakerType,
          I = void 0 !== C && C,
          W = e.isHideUploadPhotoType,
          D = e.showUserConsentIfNecessary,
          P = (0, a.useRef)(null),
          T = (0, p.PC)().t,
          N = (0, c.useRouter)(),
          E = (0, a.useMemo)(
            function () {
              var e = N.pathname;
              return e.match(/\/video-enhancer-ai/) ||
                e.match(/\/ai-video-filters/)
                ? u.e.join(",")
                : s.e.join(",");
            },
            [N.pathname]
          );
        return (0, x.jsxs)(x.Fragment, {
          children: [
            !(void 0 !== W && W) &&
              (0, x.jsx)("div", {
                className: ""
                  .concat(i().dropOuterWrapper, " ")
                  .concat(t && i().outerWrapperForHome, " ")
                  .concat(I && i().width100),
                onClick: function () {
                  return v(P);
                },
                onDragLeave: void 0 === l ? function () {} : l,
                onDragOver: void 0 === h ? function () {} : h,
                onDrop: void 0 === f ? function () {} : f,
                style: {
                  backgroundColor: d ? "#EDF8F9" : "#FFFFFF",
                  zIndex: d ? 8 : 0,
                },
                children: (0, x.jsxs)("div", {
                  className: ""
                    .concat(i().dropInnerWrapper, " ")
                    .concat(t && i().innerWrapperForHome, " ")
                    .concat(I && i().dropInnerWrapper4PhotoTaker),
                  style: {
                    border: "1px dashed ".concat(d ? "#03ADE2" : "#9B9B9B"),
                  },
                  children: [
                    (0, x.jsxs)("div", {
                      className: ""
                        .concat(i().dropContentWrapper, " ")
                        .concat(I && i().width100),
                      children: [
                        void 0 !== O && O
                          ? (0, x.jsx)("img", {
                              className: i().dropImage4Video,
                              src: "/assets/images/moduleBanner/yce_viedo_icon.png",
                              width: 50,
                              height: 40,
                            })
                          : (0, x.jsx)("img", {
                              className: t
                                ? i().dropImageForHome
                                : i().dropImage,
                              src: "/assets/images/moduleBanner/icon_file_empty.svg",
                              width: 40,
                              height: 50,
                            }),
                        (0, x.jsxs)("div", {
                          className: I ? i().flex : "",
                          children: [
                            (0, x.jsx)("div", {
                              className: ""
                                .concat(i().chooseFileButton, " ")
                                .concat(t && i().chooseFileButtonForHome),
                              style: (function (e) {
                                for (var r = 1; r < arguments.length; r++) {
                                  var t =
                                    null != arguments[r] ? arguments[r] : {};
                                  r % 2
                                    ? y(Object(t), !0).forEach(function (r) {
                                        (0, n.Z)(e, r, t[r]);
                                      })
                                    : Object.getOwnPropertyDescriptors
                                    ? Object.defineProperties(
                                        e,
                                        Object.getOwnPropertyDescriptors(t)
                                      )
                                    : y(Object(t)).forEach(function (r) {
                                        Object.defineProperty(
                                          e,
                                          r,
                                          Object.getOwnPropertyDescriptor(t, r)
                                        );
                                      });
                                }
                                return e;
                              })(
                                { backgroundColor: d ? "#46E4FA" : "#03ade2" },
                                k
                              ),
                              children: void 0 === g ? "" : g,
                            }),
                            !t &&
                              (0, x.jsx)("div", {
                                className: i().dropText,
                                children: T("webtry.drop.it.here"),
                              }),
                          ],
                        }),
                      ],
                    }),
                    F &&
                      (0, x.jsxs)("div", {
                        className: i().dropDescriptionWrapper,
                        children: [
                          (0, x.jsx)("div", { className: i().hr }),
                          (0, x.jsx)("div", {
                            className: i().dropDescription,
                            children: F,
                          }),
                        ],
                      }),
                  ],
                }),
              }),
            I
              ? (0, x.jsx)(b, {
                  buttonStyle: k,
                  showPhotoTakerType: I,
                  showUserConsentIfNecessary: void 0 === D ? function () {} : D,
                })
              : null,
            (0, x.jsx)("input", {
              id: "yce-upload",
              ref: P,
              type: "file",
              accept: E,
              style: { display: "none" },
              onChange: void 0 === w ? function () {} : w,
            }),
          ],
        });
      }
    },
    67822: function (e, r, t) {
      "use strict";
      t.d(r, {
        Z: function () {
          return d;
        },
      });
      var n = t(50029),
        o = t(87794),
        i = t.n(o),
        a = t(67294),
        c = t(19161),
        p = t(41609),
        s = t.n(p),
        u = { video: { facingMode: "user" }, audio: !1 };
      function d() {
        var e,
          r,
          t,
          o,
          p,
          d = (0, a.useState)(null),
          l = d[0],
          h = d[1],
          f = (0, a.useRef)(null),
          m = (0, a.useRef)(!1);
        (0, a.useEffect)(function () {
          var e, r, t;
          return (
            v(),
            null === (e = window.navigator) ||
              void 0 === e ||
              null === (r = e.mediaDevices) ||
              void 0 === r ||
              null === (t = r.addEventListener) ||
              void 0 === t ||
              t.call(r, "devicechange", v),
            function () {
              var e, r, t;
              null === (e = window.navigator) ||
                void 0 === e ||
                null === (r = e.mediaDevices) ||
                void 0 === r ||
                null === (t = r.removeEventListener) ||
                void 0 === t ||
                t.call(r, "devicechange", v);
            }
          );
        }, []);
        var v =
            ((e = (0, n.Z)(
              i().mark(function e() {
                var r,
                  t,
                  n,
                  o = arguments;
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (r = o.length > 0 && void 0 !== o[0] ? o[0] : 5),
                          (e.next = 3),
                          navigator.mediaDevices.enumerateDevices()
                        );
                      case 3:
                        (t = e.sent.filter(function (e) {
                          return "videoinput" === e.kind;
                        })),
                          (n = !s()(t)) || r <= 0
                            ? h(n)
                            : setTimeout(function () {
                                return v(r - 1);
                              }, 50);
                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
          w =
            ((r = (0, n.Z)(
              i().mark(function e(r) {
                var t;
                return i().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (l) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt("return", null);
                        case 2:
                          return (
                            (e.prev = 2),
                            (e.next = 5),
                            navigator.mediaDevices.getUserMedia(r || u)
                          );
                        case 5:
                          return (t = e.sent), e.abrupt("return", t);
                        case 9:
                          return (
                            (e.prev = 9),
                            (e.t0 = e.catch(2)),
                            console.log("error in getCameraStream:", e.t0),
                            e.abrupt("return", null)
                          );
                        case 13:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[2, 9]]
                );
              })
            )),
            function (e) {
              return r.apply(this, arguments);
            }),
          g = function (e) {
            window._tempCanvas ||
              (window._tempCanvas = document.createElement("canvas"));
            var r = k(e.videoWidth, e.videoHeight),
              t = r.width,
              n = r.height,
              o = window._tempCanvas;
            (o.width = t), (o.height = n);
            var i = o.getContext("2d"),
              a = function r() {
                if (!b()) {
                  var t = k(e.videoWidth, e.videoHeight),
                    n = t.width,
                    a = t.height;
                  (o.width = n),
                    (o.height = a),
                    i.drawImage(
                      e,
                      0,
                      0,
                      e.videoWidth,
                      e.videoHeight,
                      0,
                      0,
                      o.width,
                      o.height
                    ),
                    (f.current = window.requestAnimationFrame(r));
                }
              };
            return (
              e.addEventListener("play", function () {
                f.current = window.requestAnimationFrame(a);
              }),
              window._tempCanvas.captureStream().getVideoTracks()[0]
            );
          },
          _ =
            ((t = (0, n.Z)(
              i().mark(function e(r) {
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (l) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return", null);
                      case 2:
                        return (e.next = 4), y();
                      case 4:
                        return e.abrupt("return", g(r));
                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
          x =
            ((o = (0, n.Z)(
              i().mark(function e(r) {
                var t, n, o, a, c, p, s;
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), y();
                      case 2:
                        return (
                          window._tempCanvas ||
                            (window._tempCanvas =
                              document.createElement("canvas")),
                          (n = (t = k(r.width, r.height)).width),
                          (o = t.height),
                          ((a = window._tempCanvas).width = n),
                          (a.height = o),
                          (c = a.getContext("2d")),
                          (p = function e() {
                            if (!b()) {
                              var t = k(r.width, r.height),
                                n = t.width,
                                o = t.height;
                              (a.width = n),
                                (a.height = o),
                                c.drawImage(
                                  r,
                                  0,
                                  0,
                                  r.width,
                                  r.height,
                                  0,
                                  0,
                                  a.width,
                                  a.height
                                ),
                                (f.current = window.requestAnimationFrame(e));
                            }
                          }),
                          (f.current = window.requestAnimationFrame(p)),
                          (s = window._tempCanvas.captureStream()),
                          e.abrupt("return", s.getVideoTracks()[0])
                        );
                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return o.apply(this, arguments);
            }),
          k = function (e, r) {
            return e >= r && e > 768
              ? { width: 768, height: (768 * r) / e }
              : r > e && r > 768
              ? { height: 768, width: (768 * e) / r }
              : { width: e, height: r };
          },
          b = function () {
            return !!m.current && ((m.current = !1), (f.current = null), !0);
          },
          y =
            ((p = (0, n.Z)(
              i().mark(function e() {
                return i().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!(null !== f.current && !m.current)) {
                          e.next = 4;
                          break;
                        }
                        return (m.current = !0), (e.next = 4), c.Z.sleep(100);
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return p.apply(this, arguments);
            });
        return {
          cameraEnabled: l,
          getCameraStream: w,
          getVideoStreamTrack: _,
          getImageStreamTrack: x,
          clearAnimationFrame: y,
          afterFaceAttributePredictionCompleted: function () {
            y(),
              window._tempCanvas &&
                ((window._tempCanvas.width = 1),
                (window._tempCanvas.height = 1));
          },
        };
      }
    },
    63285: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        dropOuterWrapper: "file-picker_dropOuterWrapper__MMnwz",
        outerWrapperForHome: "file-picker_outerWrapperForHome__0LKgI",
        dropInnerWrapper4PhotoTaker:
          "file-picker_dropInnerWrapper4PhotoTaker__QJuhG",
        dropInnerWrapper: "file-picker_dropInnerWrapper__4Lwl_",
        innerWrapperForHome: "file-picker_innerWrapperForHome__h_jsg",
        dropImage: "file-picker_dropImage__BMJ2s",
        dropImageForHome: "file-picker_dropImageForHome__wfECT",
        dropImage4Video: "file-picker_dropImage4Video__0P1u_",
        dropContentWrapper: "file-picker_dropContentWrapper__I2nXk",
        width100: "file-picker_width100__8wgqn",
        chooseFileButton: "file-picker_chooseFileButton__H7pL8",
        chooseFileButtonForHome: "file-picker_chooseFileButtonForHome__8cmT5",
        dropText: "file-picker_dropText__SWoB5",
        dropDescriptionWrapper: "file-picker_dropDescriptionWrapper__COsnq",
        hr: "file-picker_hr__4XyIU",
        dropDescription: "file-picker_dropDescription__blJ4v",
        flex: "file-picker_flex__9ILUP",
      };
    },
    37565: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        photoTakerOuterWrapper: "photo-taker_photoTakerOuterWrapper__t64eC",
        photoTakerInnerWrapper: "photo-taker_photoTakerInnerWrapper__X2mR_",
        cameraImage: "photo-taker_cameraImage__RMp51",
        flex: "photo-taker_flex__iXZBD",
        chooseFileButton: "photo-taker_chooseFileButton__XcELU",
      };
    },
  },
]);
