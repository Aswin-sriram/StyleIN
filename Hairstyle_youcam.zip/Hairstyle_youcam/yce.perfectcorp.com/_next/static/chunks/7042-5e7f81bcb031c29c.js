(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7042],
  {
    22892: function (t, e, n) {
      "use strict";
      n.d(e, {
        A: function () {
          return a;
        },
        Z: function () {
          return o;
        },
      });
      var r = n(67294),
        a = { pack: "pack", credit: "credit" };
      function o(t) {
        var e = t.orderId,
          n = t.historyId,
          o = t.taskId,
          i = t.packInfo,
          u = t.creditInfo,
          c = (0, r.useMemo)(
            function () {
              return e ? a.pack : n || o ? a.credit : null;
            },
            [e, n, o]
          ),
          s = (0, r.useMemo)(
            function () {
              return c === a.pack ? i : c === a.credit ? u : {};
            },
            [c, i, u]
          );
        return { mode: c, dataInfo: s };
      }
    },
    35699: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return v;
        },
      });
      var r = n(27812),
        a = n(80481),
        o = n.n(a),
        i = n(67294),
        u = n(96026),
        c = n.n(u),
        s = n(1469),
        f = n.n(s),
        l = n(711),
        d = n.n(l),
        p = n(85893);
      function v(t) {
        var e = t.src,
          n = t.skeletonClass,
          a = t.imageClass,
          u = void 0 === a ? "" : a,
          s = t.alwaysShowLoading,
          l = t.transitionDisabled,
          v = t.onlyOneImage,
          h = void 0 !== v && v,
          b = t.onLoad,
          O = t.alt,
          y = void 0 === O ? "" : O,
          g = t.crossOrigin,
          k = void 0 === g ? "anonymous" : g,
          m = (0, i.useState)([null, null]),
          w = m[0],
          P = m[1],
          j = (0, i.useState)([!1, !1]),
          S = j[0],
          D = j[1],
          I = (0, i.useState)(-1),
          E = I[0],
          C = I[1];
        (0, i.useEffect)(
          function () {
            if (e) {
              if (h) {
                x(0, !1), P([e]), C(0);
                return;
              }
              var t = (E + 1) % 2,
                n = (0, r.Z)(w);
              w[t] !== e ? x(t, !1) : x(t, !0), (n[t] = e), P(n), C(t);
            }
          },
          [e]
        );
        var x = function (t) {
          var e =
            !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
          D(function (n) {
            var a = (0, r.Z)(n);
            return (a[t] = e), a;
          });
        };
        return (0, p.jsxs)(p.Fragment, {
          children: [
            c()(h ? 1 : 2).map(function (t) {
              return (
                w[t] &&
                (0, p.jsx)(
                  "img",
                  {
                    loading: "lazy",
                    className: ""
                      .concat(f()(u) ? u[t] : u, " ")
                      .concat(o().image, " ")
                      .concat(
                        E !== t || s
                          ? l && d()(S)
                            ? o().fadeOutWithoutTransition
                            : o().fadeOut
                          : l && d()(S)
                          ? o().fadeInWithoutTransition
                          : o().fadeIn
                      ),
                    crossOrigin: k,
                    src: w[t],
                    onLoad: function () {
                      x(t), b && b();
                    },
                    draggable: !1,
                    alt: y,
                  },
                  t
                )
              );
            }),
            (0, p.jsx)("div", {
              className: ""
                .concat(o().skeleton, " ")
                .concat(void 0 === n ? "" : n, " ")
                .concat(
                  S[E] && !s ? o().skeletonHidden : "",
                  " shimmer-skeleton"
                ),
            }),
          ],
        });
      }
    },
    41379: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return E;
        },
      });
      var r = n(27812),
        a = n(59499),
        o = n(50029),
        i = n(87794),
        u = n.n(i),
        c = n(1864),
        s = n.n(c),
        f = n(27957),
        l = n.n(f),
        d = n(67294),
        p = n(11163),
        v = n(9473),
        h = n(30978),
        b = n(20327),
        O = n(81386),
        y = n(48956),
        g = n(22467),
        k = n(43263),
        m = n(54555),
        w = n(15613),
        P = n(89984),
        j = n(19161),
        S = n(23560),
        D = n.n(S);
      function I(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function E() {
        var t,
          e,
          n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          i = n.containerRef,
          c = n.moduleType,
          f = n.sodType,
          S = n.canDrop,
          E = (0, d.useState)(!1),
          C = E[0],
          x = E[1],
          T = (0, d.useState)(!1),
          Z = T[0],
          M = T[1],
          _ = (0, d.useState)(!1),
          H = _[0],
          A = _[1],
          L = (0, d.useRef)(null),
          R = (0, d.useRef)(null),
          N = (0, h.Z)({ moduleType: c }).needToShowGuideline,
          z = (0, b.Z)().initNewUplaodTask,
          F = (0, O.Z)().showUserConsent,
          G = (0, p.useRouter)(),
          U = (0, v.I0)(),
          K = (0, v.v9)(function (t) {
            return t.info;
          }),
          V = (0, v.v9)(function (t) {
            return t.net;
          }),
          W = (0, v.v9)(function (t) {
            return t.ui;
          }),
          B = K.userConsentConfirmed,
          X = V.online,
          q = W.showUserConsentModal,
          Y = (0, d.useMemo)(
            function () {
              return (
                null != G &&
                !!G.pathname &&
                (!!P.ZP.isVideoType(c) ||
                  G.pathname.match(/\/video-enhancer-ai/))
              );
            },
            [null == G ? void 0 : G.pathname, c]
          );
        (0, d.useEffect)(
          function () {
            !q && C && tn(B);
          },
          [q]
        ),
          (0, d.useEffect)(
            function () {
              if (Z) {
                var t, e, n, r;
                null == i ||
                  null === (t = i.current) ||
                  void 0 === t ||
                  null === (e = t.parentNode) ||
                  void 0 === e ||
                  null === (n = e.classList) ||
                  void 0 === n ||
                  null === (r = n.add) ||
                  void 0 === r ||
                  r.call(n, l().fadeoutActive);
              }
            },
            [Z]
          );
        var Q =
            ((t = (0, o.Z)(
              u().mark(function t(e) {
                var n,
                  r,
                  o,
                  i,
                  s,
                  l,
                  d = arguments;
                return u().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        if (
                          ((n = d.length > 1 && void 0 !== d[1] ? d[1] : {}), e)
                        ) {
                          t.next = 3;
                          break;
                        }
                        return t.abrupt("return");
                      case 3:
                        if (!Y) {
                          t.next = 11;
                          break;
                        }
                        return (
                          U((0, y.Bs)({ moduleType: c, sodType: f })),
                          (t.next = 7),
                          z(e)
                        );
                      case 7:
                        if (!$) {
                          t.next = 9;
                          break;
                        }
                        return t.abrupt("return");
                      case 9:
                        t.next = 17;
                        break;
                      case 11:
                        return (
                          (r = e.name),
                          (o = e.lastModified),
                          (i = e.size),
                          (s = e.type),
                          (t.next = 14),
                          m.Z.blobToBase64(e)
                        );
                      case 14:
                        (l = (function (t) {
                          for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {};
                            e % 2
                              ? I(Object(n), !0).forEach(function (e) {
                                  (0, a.Z)(t, e, n[e]);
                                })
                              : Object.getOwnPropertyDescriptors
                              ? Object.defineProperties(
                                  t,
                                  Object.getOwnPropertyDescriptors(n)
                                )
                              : I(Object(n)).forEach(function (e) {
                                  Object.defineProperty(
                                    t,
                                    e,
                                    Object.getOwnPropertyDescriptor(n, e)
                                  );
                                });
                          }
                          return t;
                        })(
                          {
                            base64: t.sent,
                            name: r,
                            lastModified: o,
                            size: i,
                            type: s,
                          },
                          n
                        )),
                          U((0, g.a_)(l));
                      case 17:
                        tt();
                      case 18:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
          $ = (0, d.useMemo)(
            function () {
              return !!G.isReady && RegExp(/\/result-photo$/).test(G.pathname);
            },
            [G.isReady, G.pathname]
          ),
          J = function () {
            var t = s().join(P.ZP.moduleTypeToURL(c, f), "/result-photo");
            w.Z.push(G, t);
          },
          tt =
            ((e = (0, o.Z)(
              u().mark(function t() {
                return u().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          U((0, y.Bs)({ moduleType: c, sodType: f })),
                          M(!0),
                          (t.next = 4),
                          j.Z.sleep(500)
                        );
                      case 4:
                        J();
                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
          te = (0, d.useCallback)(
            function () {
              var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : function () {};
              if (!F) {
                t();
                return;
              }
              x(!0), U((0, k._k)(!0)), (L.current = t);
            },
            [F]
          ),
          tn = (0, d.useCallback)(function (t) {
            t && D()(L.current) && L.current(), x(!1), (L.current = null);
          }, []),
          tr = function (t) {
            (null == t ? void 0 : t.target) === R.current &&
              ((R.current = null), A(!1));
          },
          ta = function (t) {
            return t.preventDefault(), t.stopPropagation(), !1;
          };
        return {
          fadeOut: Z,
          handleInputClick: function () {
            var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : null;
            [].concat((0, r.Z)(P.qu), [P.ft.muTransfer]).includes(c) && N()
              ? tt()
              : [P.ft.faceSwap, P.ft.faceSwapVid].includes(c)
              ? (tt(), U((0, k.Gh)({ fromProductPage: !0 })))
              : te(function () {
                  var e;
                  null == t ||
                    null === (e = t.current) ||
                    void 0 === e ||
                    e.click();
                });
          },
          handleInputFileChange: function (t) {
            var e = t.target.files[0];
            (t.target.value = ""), Q(e);
          },
          processImageData: Q,
          goToResultPage: J,
          showUserConsentIfNecessary: te,
          setModuleTypeAndGoToResultPage: tt,
          isVideoPage: Y,
          dropMethods:
            void 0 === S || S
              ? {
                  handleDragEnter: function (t) {
                    X && ((R.current = t.target), A(!0));
                  },
                  handleDragLeave: tr,
                  handleDrop: function (t) {
                    ta(t);
                    var e = t.dataTransfer.files[0];
                    tr(t),
                      e &&
                        te(function () {
                          Q(e);
                        });
                  },
                  cancelDefault: ta,
                  dragging: H,
                }
              : {},
        };
      }
    },
    64716: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return O;
        },
      });
      var r = n(59499),
        a = n(67294),
        o = n(84238),
        i = n.n(o),
        u = n(23493),
        c = n.n(u);
      n(50361);
      var s = n(57043),
        f = n.n(s);
      n(12571), n(84486);
      var l = n(35161),
        d = n.n(l),
        p = n(27361),
        v = n.n(p);
      function h(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function b(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? h(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : h(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function O(t) {
        var e = t.isAiHeadshot,
          n = t.creditData,
          r = t.creditDataInitialized,
          o = t.packData,
          u = t.packDataInitialized,
          s = (0, a.useState)(6),
          l = s[0],
          p = s[1],
          h = (0, a.useMemo)(
            function () {
              return !r || !u;
            },
            [r, u]
          ),
          O = (0, a.useMemo)(
            function () {
              return i()(n) + i()(o);
            },
            [n, o]
          ),
          y = (0, a.useMemo)(
            function () {
              if (h) return [];
              var t = i()(o),
                e = d()(n, function (e) {
                  return b(b({}, e), {}, { packIndex: e.packIndex + t });
                });
              return f()(e, o);
            },
            [n, o, h]
          ),
          g = (0, a.useMemo)(
            function () {
              return y.slice(0, l);
            },
            [y, l]
          );
        (0, a.useEffect)(
          function () {
            return (
              e && window.addEventListener("scroll", k),
              function () {
                return window.removeEventListener("scroll", k);
              }
            );
          },
          [e, O]
        );
        var k = (0, a.useCallback)(
            c()(function () {
              if (window && e) {
                var t = document.getElementById("yce-account-page-container");
                if (t) {
                  var n = t.offsetHeight,
                    r = t.offsetTop;
                  window.scrollY + window.innerHeight > r + n - m() &&
                    p(function (t) {
                      return Math.min(t + 3, O);
                    });
                }
              }
            }, 500),
            [e, O]
          ),
          m = function () {
            var t = document.getElementById("yce-footer-container");
            return t ? v()(t, "clientHeight", 500) : 500;
          };
        return {
          aiHeadshotCombinedData: y,
          aiHeadshotLoadedData: g,
          showAiHeadshotLoadingSkeleton: h,
        };
      }
    },
    78362: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return O;
        },
      });
      var r = n(59499),
        a = n(67294),
        o = n(84238),
        i = n.n(o),
        u = n(23493),
        c = n.n(u);
      n(50361);
      var s = n(57043),
        f = n.n(s);
      n(12571), n(84486);
      var l = n(35161),
        d = n.n(l),
        p = n(27361),
        v = n.n(p);
      function h(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function b(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? h(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : h(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function O(t) {
        var e = t.isAvatar,
          n = t.creditData,
          r = t.creditDataInitialized,
          o = t.packData,
          u = t.packDataInitialized,
          s = (0, a.useState)(6),
          l = s[0],
          p = s[1],
          h = (0, a.useMemo)(
            function () {
              return !r || !u;
            },
            [r, u]
          ),
          O = (0, a.useMemo)(
            function () {
              return i()(n) + i()(o);
            },
            [n, o]
          ),
          y = (0, a.useMemo)(
            function () {
              if (h) return [];
              var t = i()(o),
                e = d()(n, function (e) {
                  return b(b({}, e), {}, { packIndex: e.packIndex + t });
                });
              return f()(e, o);
            },
            [n, o, h]
          ),
          g = (0, a.useMemo)(
            function () {
              return y.slice(0, l);
            },
            [y, l]
          );
        (0, a.useEffect)(
          function () {
            return (
              window.addEventListener("scroll", k),
              function () {
                return window.removeEventListener("scroll", k);
              }
            );
          },
          [e, O]
        );
        var k = (0, a.useCallback)(
            c()(function () {
              if (window && e) {
                var t = document.getElementById("yce-account-page-container");
                if (t) {
                  var n = t.offsetHeight,
                    r = t.offsetTop;
                  window.scrollY + window.innerHeight > r + n - m() &&
                    p(function (t) {
                      return Math.min(t + 3, O);
                    });
                }
              }
            }, 100),
            [e, O]
          ),
          m = function () {
            var t = document.getElementById("yce-footer-container");
            return t ? v()(t, "clientHeight", 500) : 500;
          };
        return {
          avatarCombinedData: y,
          avatarLoadedData: g,
          showAvatarLoadingSkeleton: h,
        };
      }
    },
    66227: function (t, e, n) {
      "use strict";
      var r = n(59499),
        a = n(50029),
        o = n(87794),
        i = n.n(o),
        u = n(67294),
        c = n(9473),
        s = n(94319),
        f = n(10147),
        l = n(19161),
        d = n(89984),
        p = n(99404),
        v = n(9585),
        h = n(14293),
        b = n.n(h),
        O = n(41609),
        y = n.n(O),
        g = n(84238),
        k = n.n(g),
        m = n(91966),
        w = n.n(m),
        P = n(63105),
        j = n.n(P),
        S = n(35161),
        D = n.n(S),
        I = n(27361),
        E = n.n(I),
        C = n(64721),
        x = n.n(C),
        T = n(57043),
        Z = n.n(T);
      function M(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function _(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? M(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : M(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      e.Z = function (t) {
        var e = t.isAiHeadshotCredit,
          n = (0, u.useState)(!0),
          r = n[0],
          o = n[1],
          h = (0, u.useState)(!1),
          O = h[0],
          g = h[1],
          m = (0, u.useState)([]),
          P = m[0],
          S = m[1],
          I = (0, u.useState)(!1),
          C = I[0],
          T = I[1],
          M = (0, u.useRef)({}),
          H = (0, c.I0)(),
          A = (0, c.v9)(function (t) {
            return t.api;
          }),
          L = (0, c.v9)(function (t) {
            return t.task;
          }),
          R = (0, c.v9)(function (t) {
            return t.aiHeadshotCredit;
          }),
          N = R.successResults,
          z = R.lastSuccessResults,
          F = L.history4AiHeadshotCredit,
          G = F.seq,
          U = F.data,
          K =
            (null == A ? void 0 : A.initOK) && (null == A ? void 0 : A.authOK),
          V = w()(N, z).length,
          W = (0, s.Z)(U, O),
          B = W.results,
          X = W.isFetched,
          q = (0, f.Z)({ reduxState: R }).runningTaskData;
        (0, u.useEffect)(
          function () {
            var t,
              n =
                ((t = (0, a.Z)(
                  i().mark(function t() {
                    return i().wrap(function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            return (t.next = 2), H((0, v.jN)(18));
                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                  })
                )),
                function () {
                  return t.apply(this, arguments);
                });
            if (K && e && !O) {
              if (r) {
                n(), o(!1);
                return;
              }
              G ? n() : b()(G) && g(!0);
            }
          },
          [K, G, r, e]
        ),
          (0, u.useEffect)(
            function () {
              var t,
                e =
                  ((t = (0, a.Z)(
                    i().mark(function t() {
                      var n,
                        r = arguments;
                      return i().wrap(function (t) {
                        for (;;)
                          switch ((t.prev = t.next)) {
                            case 0:
                              if (
                                !(
                                  (n =
                                    r.length > 0 && void 0 !== r[0]
                                      ? r[0]
                                      : 0) >= 10
                                )
                              ) {
                                t.next = 3;
                                break;
                              }
                              return t.abrupt("return");
                            case 3:
                              N.forEach(
                                (function () {
                                  var t = (0, a.Z)(
                                    i().mark(function t(r, a) {
                                      return i().wrap(function (t) {
                                        for (;;)
                                          switch ((t.prev = t.next)) {
                                            case 0:
                                              if (M.current[r]) {
                                                t.next = 11;
                                                break;
                                              }
                                              return (
                                                (t.next = 3),
                                                H(
                                                  (0, v.ud)(r, d.ft.headshot, a)
                                                )
                                              );
                                            case 3:
                                              if (t.sent) {
                                                t.next = 10;
                                                break;
                                              }
                                              return (
                                                (t.next = 7), l.Z.sleep(500)
                                              );
                                            case 7:
                                              e(n + 1), (t.next = 11);
                                              break;
                                            case 10:
                                              M.current[r] = !0;
                                            case 11:
                                            case "end":
                                              return t.stop();
                                          }
                                      }, t);
                                    })
                                  );
                                  return function (e, n) {
                                    return t.apply(this, arguments);
                                  };
                                })()
                              );
                            case 4:
                            case "end":
                              return t.stop();
                          }
                      }, t);
                    })
                  )),
                  function () {
                    return t.apply(this, arguments);
                  });
              O && k()(N) > 0 && e();
            },
            [O, N]
          ),
          (0, u.useEffect)(
            function () {
              if (K && e && O && X) {
                var t = Y(q, B),
                  n = j()(t, function (t) {
                    var e, n, r, a;
                    return (
                      (null == t
                        ? void 0
                        : null === (e = t.result) || void 0 === e
                        ? void 0
                        : e.status) === p.k.running ||
                      !y()(
                        null == t
                          ? void 0
                          : null === (n = t.result) || void 0 === n
                          ? void 0
                          : null === (r = n.results) || void 0 === r
                          ? void 0
                          : null === (a = r[0]) || void 0 === a
                          ? void 0
                          : a.data
                      )
                    );
                  }),
                  r = k()(n);
                S(
                  D()(n, function (t, e) {
                    return _(
                      _({}, E()(t, "result", {})),
                      {},
                      {
                        isCreditMode: !0,
                        historyId: E()(t, "id"),
                        packIndex: r - e - 1,
                      }
                    );
                  })
                ),
                  T(!0);
              }
            },
            [K, e, O, X, B, q]
          );
        var Y = function (t, e) {
          var n = D()(e, function (t) {
              return E()(t, "result.sessionId");
            }),
            r = j()(t, function (t) {
              return !x()(n, E()(t, "result.sessionId"));
            });
          return Z()(r, e);
        };
        return {
          filteredData4AiHeadshotCredit: P,
          aiHeadshotCreditDataInitialized: C,
          diffLengthForAiHeadshotCredit: V,
          restartAiHeadshotCreditListHistory: function () {
            H((0, v.y9)()), o(!0), g(!1), S([]), T(!1);
          },
        };
      };
    },
    21804: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return g;
        },
      });
      var r = n(59499),
        a = n(67294),
        o = n(9473),
        i = n(99404),
        u = n(27361),
        c = n.n(u),
        s = n(89734),
        f = n.n(s),
        l = n(63105),
        d = n.n(l);
      n(23493);
      var p = n(84238),
        v = n.n(p),
        h = n(41609),
        b = n.n(h);
      function O(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function y(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? O(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : O(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function g() {
        var t = (0, o.v9)(function (t) {
          return t.aiHeadshot;
        });
        return {
          aiHeadshotPackDataInitialized: (0, a.useMemo)(
            function () {
              return t.isPackPolling;
            },
            [t.isPackPolling]
          ),
          filteredData4AiHeadshotPack: (0, a.useMemo)(
            function () {
              var e = t.packList,
                n = t.packResults.map(function (t, n) {
                  var r = c()(e, "".concat(n, ".effect")),
                    a = c()(e, "".concat(n, ".subscriptionStatus")),
                    o = c()(t, "status");
                  return y(
                    y({}, t),
                    {},
                    { packSubscriptionStatus: a, packStatus: o, effect: r }
                  );
                }),
                r = f()(n, function (t) {
                  return t.subStart
                    ? -t.subStart
                    : t.startTs
                    ? -t.startTs
                    : -Number.MAX_SAFE_INTEGER;
                }),
                a = d()(r, function (t) {
                  var e = t.packSubscriptionStatus,
                    n = t.packStatus,
                    r = c()(t, "results", []),
                    a = c()(r, "0.data", []);
                  return (
                    !(n === i.k.success && b()(a)) &&
                    (e !== i.HK.CONSUMED || n !== i.k.invalidTask) &&
                    ((e === i.HK.ACTIVE && n !== i.k.running) ||
                      n !== i.k.invalidTask)
                  );
                }),
                o = v()(a);
              return a.map(function (t, e) {
                return y({ isPackMode: !0, packIndex: o - e - 1 }, t);
              });
            },
            [t.packResults, t.packList]
          ),
        };
      }
    },
    99995: function (t, e, n) {
      "use strict";
      var r = n(59499),
        a = n(50029),
        o = n(87794),
        i = n.n(o),
        u = n(67294),
        c = n(9473),
        s = n(94319),
        f = n(10147),
        l = n(19161),
        d = n(89984),
        p = n(99404),
        v = n(9585),
        h = n(14293),
        b = n.n(h),
        O = n(41609),
        y = n.n(O),
        g = n(84238),
        k = n.n(g),
        m = n(91966),
        w = n.n(m),
        P = n(63105),
        j = n.n(P),
        S = n(35161),
        D = n.n(S),
        I = n(27361),
        E = n.n(I),
        C = n(64721),
        x = n.n(C),
        T = n(57043),
        Z = n.n(T);
      function M(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function _(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? M(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : M(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      e.Z = function (t) {
        var e = t.isAvatarCredit,
          n = (0, u.useState)(!0),
          r = n[0],
          o = n[1],
          h = (0, u.useState)(!1),
          O = h[0],
          g = h[1],
          m = (0, u.useState)([]),
          P = m[0],
          S = m[1],
          I = (0, u.useState)(!1),
          C = I[0],
          T = I[1],
          M = (0, u.useRef)({}),
          H = (0, c.I0)(),
          A = (0, c.v9)(function (t) {
            return t.api;
          }),
          L = (0, c.v9)(function (t) {
            return t.task;
          }),
          R = (0, c.v9)(function (t) {
            return t.avatarCredit;
          }),
          N = R.successResults,
          z = R.lastSuccessResults,
          F = L.history4AvatarCredit,
          G = F.seq,
          U = F.data,
          K =
            (null == A ? void 0 : A.initOK) && (null == A ? void 0 : A.authOK),
          V = w()(N, z).length,
          W = (0, s.Z)(U, O),
          B = W.results,
          X = W.isFetched,
          q = (0, f.Z)({ reduxState: R }).runningTaskData;
        (0, u.useEffect)(
          function () {
            var t,
              n =
                ((t = (0, a.Z)(
                  i().mark(function t() {
                    return i().wrap(function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            return (t.next = 2), H((0, v.l1)(18));
                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                  })
                )),
                function () {
                  return t.apply(this, arguments);
                });
            if (K && e && !O) {
              if (r) {
                n(), o(!1);
                return;
              }
              G ? n() : b()(G) && g(!0);
            }
          },
          [K, G, r, e]
        ),
          (0, u.useEffect)(
            function () {
              var t,
                e =
                  ((t = (0, a.Z)(
                    i().mark(function t() {
                      var n,
                        r = arguments;
                      return i().wrap(function (t) {
                        for (;;)
                          switch ((t.prev = t.next)) {
                            case 0:
                              if (
                                !(
                                  (n =
                                    r.length > 0 && void 0 !== r[0]
                                      ? r[0]
                                      : 0) >= 10
                                )
                              ) {
                                t.next = 3;
                                break;
                              }
                              return t.abrupt("return");
                            case 3:
                              N.forEach(
                                (function () {
                                  var t = (0, a.Z)(
                                    i().mark(function t(r, a) {
                                      return i().wrap(function (t) {
                                        for (;;)
                                          switch ((t.prev = t.next)) {
                                            case 0:
                                              if (M.current[r]) {
                                                t.next = 11;
                                                break;
                                              }
                                              return (
                                                (t.next = 3),
                                                H(
                                                  (0, v.ut)(r, d.ft.avtV3Art, a)
                                                )
                                              );
                                            case 3:
                                              if (t.sent) {
                                                t.next = 10;
                                                break;
                                              }
                                              return (
                                                (t.next = 7), l.Z.sleep(500)
                                              );
                                            case 7:
                                              e(n + 1), (t.next = 11);
                                              break;
                                            case 10:
                                              M.current[r] = !0;
                                            case 11:
                                            case "end":
                                              return t.stop();
                                          }
                                      }, t);
                                    })
                                  );
                                  return function (e, n) {
                                    return t.apply(this, arguments);
                                  };
                                })()
                              );
                            case 4:
                            case "end":
                              return t.stop();
                          }
                      }, t);
                    })
                  )),
                  function () {
                    return t.apply(this, arguments);
                  });
              O && k()(N) > 0 && e();
            },
            [O, N]
          ),
          (0, u.useEffect)(
            function () {
              if (K && e && O && X) {
                var t = Y(q, B),
                  n = j()(t, function (t) {
                    var e, n, r, a;
                    return (
                      (null == t
                        ? void 0
                        : null === (e = t.result) || void 0 === e
                        ? void 0
                        : e.status) === p.k.running ||
                      !y()(
                        null == t
                          ? void 0
                          : null === (n = t.result) || void 0 === n
                          ? void 0
                          : null === (r = n.results) || void 0 === r
                          ? void 0
                          : null === (a = r[0]) || void 0 === a
                          ? void 0
                          : a.data
                      )
                    );
                  }),
                  r = k()(n);
                S(
                  D()(n, function (t, e) {
                    return _(
                      _({}, E()(t, "result", {})),
                      {},
                      {
                        isCreditMode: !0,
                        historyId: E()(t, "id"),
                        packIndex: r - e - 1,
                      }
                    );
                  })
                ),
                  T(!0);
              }
            },
            [K, e, O, X, B, q]
          );
        var Y = function (t, e) {
          var n = D()(e, function (t) {
              return E()(t, "result.sessionId");
            }),
            r = j()(t, function (t) {
              return !x()(n, E()(t, "result.sessionId"));
            });
          return Z()(r, e);
        };
        return {
          filteredData4AvatarCredit: P,
          avatarCreditDataInitialized: C,
          diffLengthForAvatarCredit: V,
          restartAvatarCreditListHistory: function () {
            H((0, v.EP)()), o(!0), g(!1), S([]), T(!1);
          },
        };
      };
    },
    54240: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return g;
        },
      });
      var r = n(59499),
        a = n(67294),
        o = n(9473),
        i = n(99404),
        u = n(27361),
        c = n.n(u),
        s = n(89734),
        f = n.n(s),
        l = n(63105),
        d = n.n(l);
      n(23493);
      var p = n(84238),
        v = n.n(p),
        h = n(41609),
        b = n.n(h);
      function O(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function y(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? O(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : O(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function g() {
        var t = (0, o.v9)(function (t) {
          return t.avatar;
        });
        return {
          avatarPackDataInitialized: (0, a.useMemo)(
            function () {
              return t.isPackPolling;
            },
            [t.isPackPolling]
          ),
          filteredData4AvatarPack: (0, a.useMemo)(
            function () {
              var e = t.packList,
                n = t.packResults.map(function (t, n) {
                  var r = c()(e, "".concat(n, ".effect")),
                    a = c()(e, "".concat(n, ".subscriptionStatus")),
                    o = c()(t, "status");
                  return y(
                    y({}, t),
                    {},
                    { packSubscriptionStatus: a, packStatus: o, effect: r }
                  );
                }),
                r = f()(n, function (t) {
                  return t.subStart
                    ? -t.subStart
                    : t.startTs
                    ? -t.startTs
                    : -Number.MAX_SAFE_INTEGER;
                }),
                a = d()(r, function (t) {
                  var e = t.packSubscriptionStatus,
                    n = t.packStatus,
                    r = c()(t, "results", []),
                    a = c()(r, "0.data", []);
                  return (
                    !(n === i.k.success && b()(a)) &&
                    (e !== i.HK.CONSUMED || n !== i.k.invalidTask) &&
                    ((e === i.HK.ACTIVE && n !== i.k.running) ||
                      n !== i.k.invalidTask)
                  );
                }),
                o = v()(a);
              return a.map(function (t, e) {
                return y({ isPackMode: !0, packIndex: o - e - 1 }, t);
              });
            },
            [t.packResults, t.packList]
          ),
        };
      }
    },
    10147: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return v;
        },
      });
      var r = n(67294);
      n(35161);
      var a = n(27361),
        o = n.n(a),
        i = n(63105),
        u = n.n(i),
        c = n(41609),
        s = n.n(c);
      n(57043);
      var f = n(52628),
        l = n.n(f),
        d = n(89734),
        p = n.n(d);
      function v(t) {
        var e = t.reduxState;
        return {
          runningTaskData: (0, r.useMemo)(
            function () {
              var t = (e || {}).pollingData,
                n = l()(t),
                r = u()(n, function (t) {
                  return !s()(t);
                });
              return p()(r, function (t) {
                return -o()(t, "result.startTs", 0);
              });
            },
            [null == e ? void 0 : e.pollingData]
          ),
        };
      }
    },
    30978: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return s;
        },
      });
      var r = n(9473),
        a = n(67294),
        o = n(28953),
        i = n(89984),
        u = n(27361),
        c = n.n(u);
      function s(t) {
        var e = t.moduleType,
          n = (0, r.v9)(function (t) {
            return t.user;
          }),
          u = (0, a.useMemo)(
            function () {
              return i.qu.includes(e)
                ? o.XC.doNotShowHairStylePhotoGuideline
                : e === i.ft.muTransfer
                ? o.XC.doNotShowMakeupTransferPhotoGuideline
                : e === i.ft.faceSwap
                ? o.XC.doNotShowFaceSwapPhotoGuideline
                : e === i.ft.faceSwapVid
                ? o.XC.doNotShowFaceSwapVidPhotoGuideline
                : e === i.ft.faceShapeDetector
                ? o.XC.doNotShowFaceShapeDetectorPhotoGuideline
                : void 0;
            },
            [e]
          );
        return {
          needToShowGuideline: (0, a.useCallback)(
            function () {
              if (!n.checked) return !1;
              var t = c()(n, "userInfo.userId", -1),
                e = o.ZP.getParsedItem(u, {});
              return !c()(e, t, !1);
            },
            [n, u]
          ),
        };
      }
    },
    81386: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return u;
        },
      });
      var r = n(67294),
        a = n(9473),
        o = n(27361),
        i = n.n(o);
      function u() {
        var t = (0, a.v9)(function (t) {
            return t.info;
          }),
          e = (0, a.v9)(function (t) {
            return t.user;
          }),
          n = t.userConsentConfirmed,
          o = e.userInfo;
        return {
          showUserConsent: (0, r.useMemo)(
            function () {
              return !(n || i()(o, "info.consent.confirmed", !1));
            },
            [n, o]
          ),
        };
      }
    },
    80481: function (t) {
      t.exports = {
        image: "image-lazy-load_image__uCL3_",
        fadeIn: "image-lazy-load_fadeIn__H_IZW",
        fadeInWithoutTransition:
          "image-lazy-load_fadeInWithoutTransition__sQ1IA",
        fadeOut: "image-lazy-load_fadeOut__UC5d6",
        fadeOutWithoutTransition:
          "image-lazy-load_fadeOutWithoutTransition__ojk9M",
        skeleton: "image-lazy-load_skeleton__yW7tq",
        skeletonHidden: "image-lazy-load_skeletonHidden__vdyYt",
      };
    },
    27957: function (t) {
      t.exports = { fadeoutActive: "use-handle-file_fadeoutActive__bC4YP" };
    },
  },
]);
