(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1516],
  {
    79325: function (e, t, n) {
      "use strict";
      var r = n(1955);
      t.Z = (0, r.Z)(function () {
        return Promise.all([n.e(3213), n.e(7374)]).then(n.bind(n, 33213));
      });
    },
    10196: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return b;
        },
      });
      var r = n(59499),
        o = n(67294),
        i = n(35121),
        a = n.n(i),
        c = n(84338),
        s = n(28953),
        u = n(49114),
        l = n(19161),
        p = n(27361),
        d = n.n(p),
        f = n(9473),
        h = n(85893);
      function m(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function y(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? m(Object(n), !0).forEach(function (t) {
                (0, r.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : m(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function b() {
        var e = (0, o.useState)(!1),
          t = e[0],
          n = e[1],
          i = (0, c.PC)(),
          p = i.t,
          m = i.locale,
          b = (0, f.v9)(function (e) {
            return e.user;
          }),
          v = d()(b, "userInfo.userId", "");
        if (
          ((0, o.useEffect)(
            function () {
              if (v) {
                var e = s.ZP.getParsedItem(s.XC.visitCount, {}),
                  t = d()(e, v);
                if (!t) {
                  var o,
                    i,
                    a = y(y({}, e), {}, (0, r.Z)({}, v, { visitCount: 1 }));
                  null === (o = window) ||
                    void 0 === o ||
                    null === (i = o.localStorage) ||
                    void 0 === i ||
                    i.setItem(s.XC.visitCount, JSON.stringify(a));
                  return;
                }
                var c = d()(t, s.XC.visitCount, 0);
                if (1 === c) {
                  var u,
                    l,
                    p = y(y({}, e), {}, (0, r.Z)({}, v, { visitCount: 2 }));
                  null === (u = window) ||
                    void 0 === u ||
                    null === (l = u.localStorage) ||
                    void 0 === l ||
                    l.setItem(s.XC.visitCount, JSON.stringify(p)),
                    n(!0);
                } else {
                  var f,
                    h,
                    m = y(y({}, e), {}, (0, r.Z)({}, v, { visitCount: c + 1 }));
                  null === (f = window) ||
                    void 0 === f ||
                    null === (h = f.localStorage) ||
                    void 0 === h ||
                    h.setItem(s.XC.visitCount, JSON.stringify(m)),
                    n(!1);
                }
              }
            },
            [v]
          ),
          !(l.Z.isIOs() || l.Z.isAndroid() || l.Z.isIPad() || l.Z.isIPhone()) &&
            t)
        )
          return (0, h.jsxs)("div", {
            className: ["fr", "es", "pt", "it", "de"].includes(m)
              ? a().containerSpecial
              : a().container,
            children: [
              (0, h.jsx)("div", {
                className: a().close,
                onClick: function () {
                  n(!1);
                },
                children: (0, h.jsx)("img", {
                  src: "/assets/images/bookMarkHint/bookmark_icon_close.svg",
                  alt: "close",
                }),
              }),
              (0, h.jsx)("div", {
                className: a().content,
                dangerouslySetInnerHTML: {
                  __html: u.Z.sanitize(
                    p("bookmark.hint", {
                      keyboardShortcut:
                        "mac" === l.Z.getOS()
                          ? "<span>Command + D</span>"
                          : "<span>Ctrl + D</span>",
                    }),
                    "span"
                  ),
                },
              }),
            ],
          });
      }
    },
    43570: function (e, t, n) {
      "use strict";
      var r = n(27812),
        o = n(27361),
        i = n.n(o),
        a = n(18721),
        c = n.n(a),
        s = n(84238),
        u = n.n(s);
      t.Z = {
        sectionCombine: function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = e.cmsFeatureBanner,
            n = e.cmsContent,
            o = e.combineTopBanner,
            a = e.cmsGridModule,
            s = void 0 === a ? null : a,
            l = i()(n, "attributes"),
            p = [];
          u()(t) && ((t.__component = "featureBanner"), p.push(t)),
            void 0 !== o &&
              o &&
              c()(l, "topBanner") &&
              ((l.topBanner.__component = "topBanner"), p.push(l.topBanner)),
            s && ((s.__component = "gridModule"), p.push(s));
          var d = i()(l, "sections", []);
          return p.push.apply(p, (0, r.Z)(d)), p;
        },
        transformFeatureBanner: function (e, t) {
          var n,
            r =
              null == e
                ? void 0
                : null === (n = e.pathname) || void 0 === n
                ? void 0
                : n.replace("/[locale]", ""),
            o = RegExp(/https?:\/\/[^/]+(\/[^?#]*)/),
            a = i()(t, "attributes.cta.link", "").match(o);
          return r === (a ? a[1] : i()(t, "attributes.cta.link"))
            ? null
            : (u()(t) && (t.__component = "featureBanner"), t);
        },
      };
    },
    92734: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          __N_SSG: function () {
            return B;
          },
          default: function () {
            return R;
          },
        });
      var r = n(78614),
        o = n(21319),
        i = n(59499),
        a = n(67294),
        c = n(9473),
        s = n(92792),
        u = n(31127),
        l = n(41379),
        p = n(17268),
        d = n(43570),
        f = n(57203),
        h = n(89984),
        m = n(84338),
        y = n(78569),
        b = n(23354),
        v = n(35218),
        g = n(97221),
        O = n(79325),
        _ = n(26927),
        C = n(93754),
        w = n(10196),
        j = n(43263),
        S = n(66683),
        P = n(14448),
        k = n(27361),
        x = n.n(k),
        Z = n(41609),
        T = n.n(Z),
        M = n(85893);
      function E(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function I(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? E(Object(n), !0).forEach(function (t) {
                (0, i.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : E(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function D(e) {
        var t = e.cmsFeatureBanner,
          n = e.cmsUseCaseMenu,
          r = e.cmsGridModule,
          o = (0, u.Z)({ content: e.cmsContent, type: y.I[h.ft.home] }),
          i = o.cmsContent,
          k = o.isLoaded;
        (0, P.Z)({ content: i, moduleType: y.I[h.ft.home] }).isLoaded;
        var Z = (0, a.useRef)(null),
          E = (0, m.PC)().t,
          D = (0, c.I0)(),
          B = (0, c.v9)(function (e) {
            return e.ui;
          }),
          R = (0, c.v9)(function (e) {
            return e.user;
          }),
          F = (0, s.Z)(),
          N = (0, l.Z)({
            containerRef: Z,
            moduleType: h.ft.enhance,
            sodType: null,
          }),
          U = N.handleInputClick,
          G = N.handleInputFileChange,
          L = N.dropMethods,
          q = (0, c.v9)(function (e) {
            return e.info;
          });
        (0, a.useEffect)(function () {
          var e = f.ZP[h.ft.home];
          D((0, S.YS)(e)), (0, p.z)("functionImpression", { functionType: e });
        }, []),
          (0, a.useEffect)(
            function () {
              R.checked && B.crossPageState && W();
            },
            [R.checked, B.crossPageState]
          );
        var W = function () {
            var e = A();
            if (e) {
              var t = H(e);
              D((0, j.CH)({ show: !0, type: t, originalType: e })),
                D((0, j.Gh)(null));
            }
          },
          A = function () {
            var e = B.crossPageState;
            return null != e && e.verified
              ? "verified"
              : null != e && e.passwordChanged
              ? "passwordChanged"
              : null != e && e.forceShowSignInSuccess
              ? "forceShowSignInSuccess"
              : "";
          },
          H = function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "";
            switch (e) {
              case "verified":
                return e;
              case "passwordChanged":
                return "password.changed";
              case "forceShowSignInSuccess":
                return "log.in";
              default:
                return "";
            }
          },
          X = (0, a.useCallback)(
            function () {
              if (!k || !i) return [];
              var e = x()(r, "attributes.sections");
              return "guest" === q.accType || T()(e)
                ? d.Z.sectionCombine({
                    cmsFeatureBanner: t,
                    cmsContent: i,
                    combineTopBanner: !0,
                    cmsGridModule: r,
                  })
                : d.Z.sectionCombine({ cmsFeatureBanner: t, cmsGridModule: r });
            },
            [i, k, q]
          ),
          J = function () {
            return {
              dropMethods: L,
              component: (0, M.jsx)(
                C.Z,
                I(
                  I({ fromHomePage: !0 }, L),
                  {},
                  {
                    handleInputClick: U,
                    handleInputFileChange: G,
                    buttonText: E("webtry.home.try.enhance"),
                  }
                )
              ),
            };
          },
          Y = !k || !i;
        return (0, M.jsxs)(b.Z, {
          children: [
            (0, M.jsx)(g.Z, { cmsUseCaseMenu: n }),
            (0, M.jsx)("div", {
              ref: Z,
              children: Y
                ? (0, M.jsx)(_.Z, {})
                : X().map(function (e, t) {
                    return (0,
                    M.jsx)("div", { className: "strapiContainer", children: (0, M.jsx)(v.Z, { content: e, width: F, productPage: "home", getFilePickerComponent: J }) }, "home-strapi-sec".concat(t));
                  }),
            }),
            !Y && (0, M.jsx)(w.Z, {}),
            !Y && (0, M.jsx)(O.Z, {}),
          ],
        });
      }
      var B = !0;
      function R(e) {
        var t = e.publicDomain,
          n = e.cmsContent,
          i = e.cmsFeatureBanner,
          a = e.cmsUseCaseMenu,
          c = e.cmsGridModule,
          s = e.isReady,
          u = x()(e, "locale", "en-us"),
          l = r.Z.getPageMeta({
            locale: u,
            url: t,
            pathname: "",
            cmsContent: n,
          });
        return (0, M.jsx)(M.Fragment, {
          children: (0, M.jsx)(o.Z, {
            pageMeta: l,
            isReady: s,
            cmsContent: n,
            children: (0, M.jsx)(D, {
              cmsContent: n,
              cmsFeatureBanner: i,
              cmsGridModule: c,
              cmsUseCaseMenu: a,
            }),
          }),
        });
      }
    },
    35121: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        containerSpecial: "web-bookmark-hint_containerSpecial__UEYt9",
        container: "web-bookmark-hint_container__hrtWe",
        close: "web-bookmark-hint_close__UUPMB",
        content: "web-bookmark-hint_content__M6oLR",
      };
    },
    92703: function (e, t, n) {
      "use strict";
      var r = n(50414);
      function o() {}
      function i() {}
      (i.resetWarningCache = o),
        (e.exports = function () {
          function e(e, t, n, o, i, a) {
            if (a !== r) {
              var c = Error(
                "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
              );
              throw ((c.name = "Invariant Violation"), c);
            }
          }
          function t() {
            return e;
          }
          e.isRequired = e;
          var n = {
            array: e,
            bigint: e,
            bool: e,
            func: e,
            number: e,
            object: e,
            string: e,
            symbol: e,
            any: e,
            arrayOf: t,
            element: e,
            elementType: e,
            instanceOf: t,
            node: e,
            objectOf: t,
            oneOf: t,
            oneOfType: t,
            shape: t,
            exact: t,
            checkPropTypes: i,
            resetWarningCache: o,
          };
          return (n.PropTypes = n), n;
        });
    },
    45697: function (e, t, n) {
      e.exports = n(92703)();
    },
    50414: function (e) {
      "use strict";
      e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    },
    68356: function (e, t, n) {
      "use strict";
      var r =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            };
      function o(e, t) {
        if (!(e instanceof t))
          throw TypeError("Cannot call a class as a function");
      }
      function i(e, t) {
        if (!e)
          throw ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t && ("object" == typeof t || "function" == typeof t) ? t : e;
      }
      function a(e, t) {
        if ("function" != typeof t && null !== t)
          throw TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
      var c = n(67294),
        s = n(45697),
        u = [],
        l = [];
      function p(e) {
        var t = e(),
          n = { loading: !0, loaded: null, error: null };
        return (
          (n.promise = t
            .then(function (e) {
              return (n.loading = !1), (n.loaded = e), e;
            })
            .catch(function (e) {
              throw ((n.loading = !1), (n.error = e), e);
            })),
          n
        );
      }
      function d(e) {
        var t = { loading: !1, loaded: {}, error: null },
          n = [];
        try {
          Object.keys(e).forEach(function (r) {
            var o = p(e[r]);
            o.loading
              ? (t.loading = !0)
              : ((t.loaded[r] = o.loaded), (t.error = o.error)),
              n.push(o.promise),
              o.promise
                .then(function (e) {
                  t.loaded[r] = e;
                })
                .catch(function (e) {
                  t.error = e;
                });
          });
        } catch (r) {
          t.error = r;
        }
        return (
          (t.promise = Promise.all(n)
            .then(function (e) {
              return (t.loading = !1), e;
            })
            .catch(function (e) {
              throw ((t.loading = !1), e);
            })),
          t
        );
      }
      function f(e, t) {
        return c.createElement(e && e.__esModule ? e.default : e, t);
      }
      function h(e, t) {
        if (!t.loading)
          throw Error("react-loadable requires a `loading` component");
        var p,
          d,
          h = Object.assign(
            {
              loader: null,
              loading: null,
              delay: 200,
              timeout: null,
              render: f,
              webpack: null,
              modules: null,
            },
            t
          ),
          m = null;
        function y() {
          return m || (m = e(h.loader)), m.promise;
        }
        return (
          u.push(y),
          "function" == typeof h.webpack &&
            l.push(function () {
              var e;
              if (
                ((e = h.webpack),
                "object" === r(n.m) &&
                  e().every(function (e) {
                    return void 0 !== e && void 0 !== n.m[e];
                  }))
              )
                return y();
            }),
          (d = p =
            (function (t) {
              function n(r) {
                o(this, n);
                var a = i(this, t.call(this, r));
                return (
                  (a.retry = function () {
                    a.setState({ error: null, loading: !0, timedOut: !1 }),
                      (m = e(h.loader)),
                      a._loadModule();
                  }),
                  y(),
                  (a.state = {
                    error: m.error,
                    pastDelay: !1,
                    timedOut: !1,
                    loading: m.loading,
                    loaded: m.loaded,
                  }),
                  a
                );
              }
              return (
                a(n, t),
                (n.preload = function () {
                  return y();
                }),
                (n.prototype.componentWillMount = function () {
                  (this._mounted = !0), this._loadModule();
                }),
                (n.prototype._loadModule = function () {
                  var e = this;
                  if (
                    (this.context.loadable &&
                      Array.isArray(h.modules) &&
                      h.modules.forEach(function (t) {
                        e.context.loadable.report(t);
                      }),
                    m.loading)
                  ) {
                    "number" == typeof h.delay &&
                      (0 === h.delay
                        ? this.setState({ pastDelay: !0 })
                        : (this._delay = setTimeout(function () {
                            e.setState({ pastDelay: !0 });
                          }, h.delay))),
                      "number" == typeof h.timeout &&
                        (this._timeout = setTimeout(function () {
                          e.setState({ timedOut: !0 });
                        }, h.timeout));
                    var t = function () {
                      e._mounted &&
                        (e.setState({
                          error: m.error,
                          loaded: m.loaded,
                          loading: m.loading,
                        }),
                        e._clearTimeouts());
                    };
                    m.promise
                      .then(function () {
                        t();
                      })
                      .catch(function (e) {
                        t();
                      });
                  }
                }),
                (n.prototype.componentWillUnmount = function () {
                  (this._mounted = !1), this._clearTimeouts();
                }),
                (n.prototype._clearTimeouts = function () {
                  clearTimeout(this._delay), clearTimeout(this._timeout);
                }),
                (n.prototype.render = function () {
                  return this.state.loading || this.state.error
                    ? c.createElement(h.loading, {
                        isLoading: this.state.loading,
                        pastDelay: this.state.pastDelay,
                        timedOut: this.state.timedOut,
                        error: this.state.error,
                        retry: this.retry,
                      })
                    : this.state.loaded
                    ? h.render(this.state.loaded, this.props)
                    : null;
                }),
                n
              );
            })(c.Component)),
          (p.contextTypes = {
            loadable: s.shape({ report: s.func.isRequired }),
          }),
          d
        );
      }
      function m(e) {
        return h(p, e);
      }
      m.Map = function (e) {
        if ("function" != typeof e.render)
          throw Error(
            "LoadableMap requires a `render(loaded, props)` function"
          );
        return h(d, e);
      };
      var y = (function (e) {
        function t() {
          return o(this, t), i(this, e.apply(this, arguments));
        }
        return (
          a(t, e),
          (t.prototype.getChildContext = function () {
            return { loadable: { report: this.props.report } };
          }),
          (t.prototype.render = function () {
            return c.Children.only(this.props.children);
          }),
          t
        );
      })(c.Component);
      function b(e) {
        for (var t = []; e.length; ) {
          var n = e.pop();
          t.push(n());
        }
        return Promise.all(t).then(function () {
          if (e.length) return b(e);
        });
      }
      (y.propTypes = { report: s.func.isRequired }),
        (y.childContextTypes = {
          loadable: s.shape({ report: s.func.isRequired }).isRequired,
        }),
        (m.Capture = y),
        (m.preloadAll = function () {
          return new Promise(function (e, t) {
            b(u).then(e, t);
          });
        }),
        (m.preloadReady = function () {
          return new Promise(function (e, t) {
            b(l).then(e, e);
          });
        }),
        (e.exports = m);
    },
    36864: function (e, t, n) {
      "use strict";
      function r() {
        return (r =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }).apply(this, arguments);
      }
      n.d(t, {
        Z: function () {
          return r;
        },
      });
    },
  },
]);
