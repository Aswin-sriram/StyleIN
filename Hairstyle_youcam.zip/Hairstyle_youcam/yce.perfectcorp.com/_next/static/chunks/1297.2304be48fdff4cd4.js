(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1297],
  {
    70433: function (e) {
      e.exports = function (e, t) {
        return e < t;
      };
    },
    67762: function (e) {
      e.exports = function (e, t) {
        for (var n, r = -1, o = e.length; ++r < o; ) {
          var a = t(e[r]);
          void 0 !== a && (n = void 0 === n ? a : n + a);
        }
        return n;
      };
    },
    10752: function (e, t, n) {
      var r = n(21078),
        o = n(35161),
        a = 1 / 0;
      e.exports = function (e, t) {
        return r(o(e, t), a);
      };
    },
    22762: function (e, t, n) {
      var r = n(56029),
        o = n(11243),
        a = n(70433);
      e.exports = function (e, t) {
        return e && e.length ? r(e, o(t, 2), a) : void 0;
      };
    },
    73303: function (e, t, n) {
      var r = n(11243),
        o = n(67762);
      e.exports = function (e, t) {
        return e && e.length ? o(e, r(t, 2)) : 0;
      };
    },
    500: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          default: function () {
            return nn;
          },
        });
      var r = n(50029),
        o = n(87794),
        a = n.n(o),
        c = n(97098),
        i = n.n(c),
        s = n(9473),
        u = n(67294),
        l = n(27812),
        d = n(16835),
        f = n(59499),
        p = n(57632),
        h = n(42621),
        m = n(95229),
        g = n(36175),
        b = n(54473),
        v = n(95045),
        x = n(38437),
        y = n(30978),
        _ = n(36722),
        w = n(44248),
        I = n(46661),
        S = n(54555),
        j = n(75818),
        k = n(19161),
        C = n(89984),
        P = n(53841),
        R = n(72880),
        Z = n(22467),
        F = n(9585),
        O = n(63482),
        T = n(43263),
        B = n(57291),
        N = n(27361),
        M = n.n(N),
        E = n(84238),
        D = n.n(E),
        A = n(63105),
        U = n.n(A),
        W = n(35161),
        G = n.n(W),
        L = n(78718),
        H = n.n(L),
        z = n(96026),
        Y = n.n(z),
        X = n(12571),
        K = n.n(X),
        V = n(41609),
        Q = n.n(V),
        q = n(22762),
        J = n.n(q),
        $ = n(66913),
        ee = n.n($),
        et = n(50361),
        en = n.n(et),
        er = n(84486),
        eo = n.n(er),
        ea = n(85564),
        ec = n.n(ea),
        ei = n(13311),
        es = n.n(ei),
        eu = n(89734),
        el = n.n(eu);
      function ed(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function ef(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? ed(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : ed(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var ep = { taskRunning: !1, params: {}, taskResult: {}, updating: !1 },
        eh = n(18224),
        em = n(25915);
      function eg(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function eb(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? eg(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : eg(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var ev = { rectScale: 0, showMask: !1, showHint: !1, hasShowed: !1 },
        ex = n(17268),
        ey = n(57203),
        e_ = n(32295),
        ew = n(29065),
        eI = n.n(ew),
        eS = n(11163),
        ej = n(41379),
        ek = n(20327),
        eC = n(49114),
        eP = n(34645),
        eR = n(28953),
        eZ = n(84338),
        eF = n(45395),
        eO = n(85893);
      function eT(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function eB(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? eT(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : eT(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var eN = {
          good: [
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_good_01.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_good_02.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_good_03.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_good_04.jpg",
          ],
          bad: [
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_bad_01.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_bad_02.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_bad_03.jpg",
            "/assets/images/hairStyle/img_ycp_hairstyle_eg_bad_04.jpg",
          ],
        },
        eM = { doNotShowAgain: !0 };
      function eE() {
        var e,
          t,
          n = (0, u.useState)(!1),
          o = n[0],
          c = n[1],
          i = (0, u.useState)(eM),
          l = i[0],
          d = i[1],
          p = (0, u.useRef)(null),
          m = (0, eZ.PC)().t,
          g = (0, ej.Z)({ canDrop: !1 }).showUserConsentIfNecessary,
          b = (0, h.Z)(),
          v = b.setProductConfig,
          x = b.setBeforeImage,
          _ = (0, ek.Z)().initNewUplaodTask,
          w = (0, eS.useRouter)(),
          I = (0, s.v9)(function (e) {
            return e.yceData;
          }),
          j = (0, s.v9)(function (e) {
            return e.user;
          }),
          k = (0, s.v9)(function (e) {
            return e.result;
          }),
          R = (0, s.v9)(function (e) {
            return e.info;
          }),
          Z = k.productConfig,
          F = M()(R, "moduleType", C.ft.hairStyle),
          O = (0, y.Z)({ moduleType: F }).needToShowGuideline,
          T = (0, u.useMemo)(
            function () {
              return (
                M()(Z, "".concat(F, ".hairStyleStep"), "") === P.Z.showGuideline
              );
            },
            [Z, F]
          ),
          B = (0, u.useMemo)(
            function () {
              return M()(j, "userInfo.userId", "-1");
            },
            [j]
          ),
          N = (0, u.useMemo)(
            function () {
              return !!I.base64;
            },
            [I]
          );
        (0, u.useEffect)(
          function () {
            E();
          },
          [T]
        ),
          (0, u.useEffect)(
            function () {
              o && d(eM);
            },
            [o]
          );
        var E = function () {
            T && O()
              ? o || c(!0)
              : T
              ? (v(F, { hairStyleStep: null }), W())
              : o && c(!1);
          },
          D = function (e) {
            d(function (t) {
              return eB(eB({}, t), {}, (0, f.Z)({}, e, !t[e]));
            });
          },
          A = function () {
            if (O() && M()(l, "doNotShowAgain")) {
              var e = eR.ZP.getParsedItem(
                eR.XC.doNotShowHairStylePhotoGuideline,
                {}
              );
              (e[B] = !0),
                eR.ZP.updateObjectInfo(
                  eR.XC.doNotShowHairStylePhotoGuideline,
                  e
                );
            }
          },
          U = function () {
            v(F, { hairStyleStep: null });
          },
          W = function () {
            g(function () {
              N ? L() : p.current.click();
            });
          },
          G =
            ((e = (0, r.Z)(
              a().mark(function e(t) {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (t) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        L(t);
                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (t) {
              return e.apply(this, arguments);
            }),
          L =
            ((t = (0, r.Z)(
              a().mark(function e(t) {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          x(null, null),
                          (e.next = 3),
                          _(t, { keepResultStates: !0 })
                        );
                      case 3:
                        v(F, { hairStyleStep: P.Z.processImage });
                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            });
        return (0, eO.jsxs)("div", {
          className: ""
            .concat(eI().container, " ")
            .concat(o ? eI().containerOpened : "", " hidden-scrollbar"),
          onClick: U,
          children: [
            (0, eO.jsxs)("div", {
              className: "".concat(eI().modal, " hidden-scrollbar"),
              onClick: function (e) {
                return e.stopPropagation();
              },
              children: [
                (0, eO.jsx)("div", {
                  className: eI().title,
                  children: m("makeup.transfer.upload.guideline.title"),
                }),
                (0, eO.jsx)("div", {
                  className: eI().exampleContainer,
                  children: ["good", "bad"].map(function (e) {
                    return (0, eO.jsxs)(
                      "div",
                      {
                        className: eI().allContainer,
                        children: [
                          (0, eO.jsxs)("div", {
                            className:
                              "good" === e
                                ? ""
                                    .concat(eI().allBorder, " ")
                                    .concat(eI().goodBorder)
                                : "bad" === e
                                ? ""
                                    .concat(eI().allBorder, " ")
                                    .concat(eI().badBorder)
                                : void 0,
                            children: [
                              (0, eO.jsx)("div", {
                                className: eI().exampleTitle,
                                children: m(
                                  "avatar.pet.tool.upload.guideline.".concat(
                                    e,
                                    ".title"
                                  )
                                ),
                              }),
                              (0, eO.jsx)("div", {
                                className: eI().exampleDesc,
                                children: m(
                                  "hair.style.upload.guideline.".concat(
                                    e,
                                    ".desc"
                                  )
                                ),
                              }),
                            ],
                          }),
                          (0, eO.jsx)("div", {
                            className: eI().exampleImageBlock,
                            children: M()(eN, e, []).map(function (t) {
                              return (0,
                              eO.jsxs)("div", { className: eI().exampleImageWrapper, children: [(0, eO.jsx)("img", { className: eI().exampleImage, src: t, alt: "" }), (0, eO.jsx)("img", { className: eI().qualityIcon, src: "/assets/images/hairStyle/btn_ycp_hairstyle_".concat(e, ".png"), alt: "" })] }, t);
                            }),
                          }),
                        ],
                      },
                      e
                    );
                  }),
                }),
                (0, eO.jsxs)("div", {
                  className: eI().doNotShowAgainWrapper,
                  onClick: function () {
                    return D("doNotShowAgain");
                  },
                  children: [
                    (0, eO.jsx)("div", {
                      className: eI().checkbox,
                      style: l.doNotShowAgain
                        ? {
                            backgroundImage:
                              "url(/assets/images/icon_tick_w.svg)",
                            backgroundColor: "#212529",
                            borderColor: "#212529",
                          }
                        : null,
                    }),
                    (0, eO.jsx)("div", {
                      className: eI().doNotShowAgain,
                      children: m(
                        "hair.style.upload.guideline.do.not.show.again"
                      ),
                    }),
                  ],
                }),
                (0, eO.jsx)(eF.Z, {
                  className: eI().button,
                  hoverClass: "hover-46e4fa",
                  touchClass: "touch-46e4fa",
                  onClick: W,
                  children: N
                    ? m("general.continue.2")
                    : m("hair.style.upload.guideline.upload.image"),
                }),
                (0, eO.jsx)("div", {
                  className: eI().tosContainer,
                  dangerouslySetInnerHTML: {
                    __html: eC.Z.sanitize(
                      m(
                        "headshot.terms",
                        eP.Z.getPPTosInterpolationObject(["ppUrl", "tosUrl"], w)
                      ),
                      "a"
                    ),
                  },
                }),
                (0, eO.jsx)("div", {
                  className: eI().close,
                  style: {
                    backgroundImage: "url(/assets/images/icon_close.svg)",
                  },
                  onClick: U,
                }),
              ],
            }),
            (0, eO.jsx)("input", {
              id: "yce-upload",
              ref: p,
              type: "file",
              accept: S.e.join(","),
              style: { display: "none" },
              onChange: function (e) {
                A(), v(F, { hairStyleStep: null });
                var t = e.target.files[0];
                (e.target.value = ""), G(t);
              },
              onClick: function (e) {
                return e.stopPropagation();
              },
            }),
          ],
        });
      }
      var eD = n(22559),
        eA = n.n(eD),
        eU = n(92792);
      function eW(e) {
        var t,
          n,
          r,
          o,
          a,
          c,
          i,
          s,
          l,
          f,
          p = e.handleUploadButtonClick,
          h = (0, u.useRef)(null),
          m = (0, u.useRef)(null),
          g = (0, u.useRef)(null),
          b = (0, eZ.PC)().t;
        return (
          (n = (t = { containerRef: h, innerContainerRef: m, buttonRef: g })
            .containerRef),
          (r = t.innerContainerRef),
          (o = t.buttonRef),
          (a = (0, eU.Z)({ useHeight: !0 })),
          (i = (c = (0, d.Z)(a, 2))[0]),
          (s = c[1]),
          (l = (0, eh.Z)().isMobile),
          (0, u.useEffect)(function () {
            f();
          }, []),
          (0, u.useEffect)(
            function () {
              f();
            },
            [i, s]
          ),
          (f = function () {
            if (null != n && n.current && null != o && o.current) {
              var e = "none" === o.current.style.display ? (l ? 55 : 70) : 10,
                t = n.current.clientHeight;
              r.current.clientHeight + e > t
                ? (o.current.style.display = "none")
                : (o.current.style.display = null);
            }
          }),
          (0, eO.jsx)("div", {
            ref: h,
            className: eA().container,
            children: (0, eO.jsxs)("div", {
              ref: m,
              className: eA().innerContainer,
              children: [
                (0, eO.jsx)("img", {
                  className: eA().image,
                  src: "/assets/images/txt2Img/img_empty.png",
                  alt: "",
                }),
                (0, eO.jsx)("div", {
                  className: eA().desc,
                  dangerouslySetInnerHTML: {
                    __html: eC.Z.sanitize(
                      b("hair.style.results.empty.result.desc"),
                      "br"
                    ),
                  },
                }),
                (0, eO.jsx)(eF.Z, {
                  ref: g,
                  className: eA().button,
                  hoverClass: "hover-46e4fa",
                  touchClass: "touch-46e4fa",
                  onClick: p,
                  children: b("hair.style.results.empty.result.button"),
                }),
              ],
            }),
          })
        );
      }
      var eG = n(56568),
        eL = n.n(eG),
        eH = n(26186);
      function ez() {
        var e = (0, u.useState)(!1),
          t = e[0],
          n = e[1],
          r = (0, eZ.PC)().t,
          o = (0, h.Z)().setProductConfig,
          a = (0, s.v9)(function (e) {
            return e.result;
          }),
          c = (0, s.v9)(function (e) {
            return e.info;
          }),
          i = a.productConfig,
          l = M()(c, "moduleType", C.ft.hairStyle),
          d = (0, u.useMemo)(
            function () {
              return M()(i, "".concat(l, ".faceDetectError"), "");
            },
            [i]
          );
        (0, u.useEffect)(
          function () {
            d && n(!0);
          },
          [d]
        );
        var f = function () {
          n(!1),
            setTimeout(function () {
              o(l, { faceDetectError: null });
            }, 400);
        };
        return (0, eO.jsxs)(eH.Z, {
          opened: t,
          handleClose: function () {
            f();
          },
          customStyles: {
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px 40px",
            maxWidth: "unset",
            width: "unset",
          },
          children: [
            (0, eO.jsx)("div", {
              className: eL().title,
              children: r("invalid.other.title"),
            }),
            (0, eO.jsx)("div", { className: eL().desc, children: d }),
            (0, eO.jsx)(eF.Z, {
              className: eL().button,
              hoverClass: "hover-46e4fa",
              touchClass: "touch-46e4fa",
              onClick: function () {
                f(), o(l, { hairStyleStep: P.Z.showGuideline });
              },
              children: r("hair.style.results.face.detect.error.button"),
            }),
          ],
        });
      }
      var eY = n(44324),
        eX = n.n(eY),
        eK = n(35045),
        eV = n.n(eK),
        eQ = n(55926),
        eq = n.n(eQ),
        eJ = n(38883),
        e$ = n.n(eJ);
      function e0() {
        return (0, eO.jsxs)("div", {
          className: eq().tabs,
          children: [
            Y()(2).map(function (e) {
              return (0,
              eO.jsx)("div", { className: "".concat(eq().tab, " ").concat(e$().tab, " shimmer-skeleton") }, e);
            }),
            (0, eO.jsx)("div", {
              className: ""
                .concat(eq().indicatorBottom, " ")
                .concat(e$().indicatorBottom),
            }),
          ],
        });
      }
      var e1 = n(20328),
        e2 = n.n(e1),
        e4 = n(30998),
        e6 = n.n(e4),
        e3 = n(18446),
        e5 = n.n(e3),
        e8 = n(29010);
      function e9(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function e7(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? e9(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : e9(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function te(e) {
        var t,
          n = e.paramsState,
          r = e.settingsState,
          o = e.setSettingsState,
          a = e.canShowThumbnails,
          c = e.resultsState,
          i = e.lastStyles,
          l = r.activeTab,
          d = r.activeGender,
          p = n.groups,
          h = n.groupStyles,
          m = (0, u.useRef)(null),
          g = (0, u.useRef)([]),
          b = (0, u.useRef)(null),
          v = (0, eU.Z)(),
          x = (0, eZ.PC)().locale,
          y = (0, u.useMemo)(
            function () {
              return e8.Z.convertACMSLanguageType(x);
            },
            [x]
          ),
          _ = (0, u.useState)(!0),
          w = _[0],
          I = _[1],
          S = (0, s.v9)(function (e) {
            return e.info;
          }),
          j = (0, s.v9)(function (e) {
            return e.result;
          }),
          k = S.moduleType,
          P = j.productConfig,
          R = (0, u.useMemo)(
            function () {
              return M()(P, "".concat(C.ft.hairStyle, ".selectedStyle"), {});
            },
            [P]
          ),
          Z = function (e, t) {
            var n =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : "en";
            return {
              name: M()(
                es()(e, function (e) {
                  return e.lang === t;
                }),
                "name",
                ""
              ),
              name4Compare: M()(
                es()(e, function (e) {
                  return e.lang === n;
                }),
                "name",
                ""
              ),
            };
          },
          F = (0, u.useMemo)(
            function () {
              var e;
              return null == p
                ? void 0
                : null === (e = p.paramGroups) || void 0 === e
                ? void 0
                : e.map(function (e) {
                    var t,
                      n = Z(null == e ? void 0 : e.i18n, y);
                    return {
                      groupName: n.name,
                      groupName4Compare: n.name4Compare,
                      subCategories:
                        null == (t = null == e ? void 0 : e.subCategoryList)
                          ? void 0
                          : t.map(function (e) {
                              var t = Z(null == e ? void 0 : e.i18n, y);
                              return {
                                subCategoryName: t.name,
                                subCategoryName4Compare: t.name4Compare,
                                subCategoryItems:
                                  (null == e ? void 0 : e.items) || [],
                              };
                            }),
                    };
                  });
            },
            [p, y]
          ),
          O = (0, u.useMemo)(
            function () {
              var e = M()(F, "[".concat(l, "].subCategories"), []);
              return 1 >= D()(e) ? null : e;
            },
            [F, l]
          ),
          T = (0, u.useMemo)(
            function () {
              return !!D()(F);
            },
            [F]
          ),
          B = M()(c, "generatedResults", []),
          N = M()(c, "imagePreviewIndex", 0),
          E = M()(B, "".concat(N, ".selectedFaceIndex"), 0),
          A = M()(B, "".concat(N, ".faceInfos.").concat(E, ".gender"), null),
          U =
            ((t = {}),
            (0, f.Z)(t, C.ft.hairStyle, "Styles"),
            (0, f.Z)(t, C.ft.hairBang, "Bangs"),
            (0, f.Z)(t, C.ft.hairExt, "Extension"),
            (0, f.Z)(t, C.ft.hairVol, "Volume"),
            t),
          W = function () {
            var e = e6()(F, { groupName4Compare: U[k] });
            o(function (t) {
              return e7(e7({}, t), {}, { activeTab: e });
            });
          },
          G = function (e) {
            var t = e6()(F, { groupName4Compare: U[k] }),
              n = M()(F, "[".concat(t, "].subCategories"), []);
            if (1 >= D()(n)) {
              o(function (e) {
                return e7(e7({}, e), {}, { activeTab: t, activeGender: 0 });
              });
              return;
            }
            if ("male" === e || "female" === e) {
              var r = n.findIndex(function (t) {
                return (
                  t.subCategoryName4Compare.toUpperCase() === e.toUpperCase()
                );
              });
              o(function (e) {
                return e7(
                  e7({}, e),
                  {},
                  { activeTab: t, activeGender: -1 !== r ? r : 0 }
                );
              });
            }
          };
        (0, u.useEffect)(
          function () {
            !w && Q()(B) && I(!0);
          },
          [B]
        ),
          (0, u.useEffect)(
            function () {
              if (T) {
                var e = R.pocId,
                  t = R.pocGroupId;
                if (!(e && t && !e5()(i, [R]) && D()(h)) || !w) {
                  if (w && Q()(B)) {
                    W(), I(!1);
                    return;
                  }
                  w && !Q()(B) && (G(A), I(!1));
                }
              }
            },
            [B, O, T]
          ),
          (0, u.useEffect)(
            function () {
              T && setTimeout(L, 10);
            },
            [T, l, v]
          );
        var L = function () {
            if (
              null != m &&
              m.current &&
              null != b &&
              b.current &&
              D()(null == g ? void 0 : g.current) &&
              e2()(l) &&
              D()(null == g ? void 0 : g.current) === D()(F)
            ) {
              var e = m.current.getBoundingClientRect().left,
                t = g.current[l].getBoundingClientRect(),
                n = t.left,
                r = t.width;
              (b.current.style.width = "".concat(r - 4, "px")),
                (b.current.style.transform = "translate3d(".concat(
                  n - e + 2,
                  "px, 0, 0)"
                ));
            }
          },
          H = function (e) {
            o(function (t) {
              return e7(e7({}, t), {}, { activeTab: e, activeGender: 0 });
            }),
              I(!1);
          },
          z = function (e) {
            o(function (t) {
              return e7(e7({}, t), {}, { activeGender: e });
            });
          };
        return (0, eO.jsx)("div", {
          className: ""
            .concat(eq().tabsPadding, " ")
            .concat(a ? eq().tabsPaddingThumbnails : ""),
          children: T
            ? (0, eO.jsxs)(eO.Fragment, {
                children: [
                  (0, eO.jsxs)("div", {
                    ref: m,
                    className: "".concat(eq().tabs),
                    children: [
                      F.map(function (e, t) {
                        return (0, eO.jsx)(
                          "div",
                          {
                            ref: function (e) {
                              return (g.current[t] = e);
                            },
                            className: ""
                              .concat(eq().tab, " ")
                              .concat(l === t ? eq().activeTab : ""),
                            onClick: function () {
                              return H(t);
                            },
                            children: e.groupName,
                          },
                          t
                        );
                      }),
                      (0, eO.jsx)("div", { ref: b, className: eq().indicator }),
                      (0, eO.jsx)("div", { className: eq().indicatorBottom }),
                    ],
                  }),
                  O &&
                    (0, eO.jsx)("div", {
                      className: eq().genderTabs,
                      children: O.map(function (e, t) {
                        return (0, eO.jsx)(
                          eF.Z,
                          {
                            className: ""
                              .concat(eq().genderTab, " ")
                              .concat(d === t ? eq().activeGenderTab : ""),
                            onClick: function () {
                              return z(t);
                            },
                            children: e.subCategoryName,
                          },
                          t
                        );
                      }),
                    }),
                ],
              })
            : (0, eO.jsx)(e0, {}),
        });
      }
      var tt = n(21135),
        tn = n.n(tt),
        tr = n(4538),
        to = n.n(tr),
        ta = n(3625),
        tc = n.n(ta);
      function ti() {
        return (0, eO.jsx)(eO.Fragment, {
          children: Y()(20).map(function (e, t) {
            return (0,
            eO.jsxs)("div", { className: to().styleContainer, children: [(0, eO.jsx)("div", { className: "".concat(to().outerWrapper, " ").concat(tc().outerWrapper), children: (0, eO.jsx)("div", { className: to().paddingTop, children: (0, eO.jsx)("div", { className: "".concat(to().innerWrapper, " shimmer-skeleton") }) }) }), (0, eO.jsx)("div", { className: tc().styleDescWrapper, children: (0, eO.jsx)("div", { className: "".concat(to().styleDesc, " ").concat(tc().styleDesc, " shimmer-skeleton") }) })] }, t);
          }),
        });
      }
      var ts = n(35699);
      function tu(e) {
        var t = e.style,
          n = e.isStyleActive,
          r = e.handleStyleClick,
          o = e.acmsLang,
          a = t.isBestMatch,
          c = (0, u.useMemo)(
            function () {
              return M()(t, "thumbnail");
            },
            [t]
          ),
          i = (0, u.useMemo)(
            function () {
              var e = es()(null == t ? void 0 : t.i18n, function (e) {
                return e.lang === o;
              });
              return M()(e, "name");
            },
            [t, o]
          );
        return (0, eO.jsxs)("div", {
          className: to().styleContainer,
          children: [
            (0, eO.jsx)("div", {
              className: ""
                .concat(to().outerWrapper, " ")
                .concat(n(t) ? to().outerWrapperActive : ""),
              onClick: function () {
                return r(t);
              },
              children: (0, eO.jsxs)("div", {
                className: to().paddingTop,
                children: [
                  (0, eO.jsxs)("div", {
                    className: to().innerWrapper,
                    id: "".concat(t.id),
                    children: [
                      (0, eO.jsx)(ts.Z, {
                        src: c,
                        skeletonClass: null,
                        imageClass: to().image,
                      }),
                      (0, eO.jsx)("div", {
                        className: to().checkbox,
                        children: (0, eO.jsx)(tl, { checked: n(t) }),
                      }),
                    ],
                  }),
                  void 0 !== a &&
                    a &&
                    (0, eO.jsx)("img", {
                      className: to().bestMatchIcon,
                      src: "/assets/images/faceShapeDetector/ico_best.png",
                      alt: "",
                    }),
                ],
              }),
            }),
            (0, eO.jsx)("div", {
              className: "".concat(to().styleDesc),
              children: i,
            }),
          ],
        });
      }
      function tl(e) {
        var t = e.checked;
        return (0, eO.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 24 24",
          fill: "none",
          children: [
            (0, eO.jsx)("circle", {
              cx: "12",
              cy: "12",
              r: "11.1",
              fill: t ? "#212529" : "none",
              stroke: "white",
              strokeWidth: "1.8",
            }),
            t &&
              (0, eO.jsx)("path", {
                d: "M8.39999 12.1091L10.7261 14.4L15.6 9.6",
                stroke: "white",
                strokeWidth: "1.8",
                strokeLinecap: "round",
              }),
          ],
        });
      }
      function td(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function tf(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? td(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : td(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function tp(e) {
        var t = e.paramsState,
          n = e.settingsState,
          r = e.setSettingsState,
          o = e.selectedStylesCount,
          a = e.lastStyles,
          c = e.setLastStyles,
          i = t.groupStyles,
          d = n.activeTab,
          f = n.activeGender,
          p = void 0 === f ? 0 : f,
          h = n.selectedStyles,
          m = (0, s.I0)(),
          g = (0, eZ.PC)().t,
          b = (0, eS.useRouter)().query.locale,
          v = (0, s.v9)(function (e) {
            return e.result;
          }).productConfig,
          x = (0, u.useState)(!0),
          y = x[0],
          _ = x[1],
          w = (0, u.useMemo)(
            function () {
              return e8.Z.convertACMSLanguageType(b);
            },
            [b]
          ),
          I = (0, u.useMemo)(
            function () {
              return M()(
                v,
                "".concat(C.ft.hairStyle, ".recommendedGroupStyles"),
                []
              );
            },
            [v]
          ),
          S = (0, u.useMemo)(
            function () {
              return M()(v, "".concat(C.ft.hairStyle, ".selectedStyle"), {});
            },
            [v]
          ),
          j = function (e, t, n) {
            for (var r = 0; r < e.length; r++) {
              var o = e[r];
              if (Array.isArray(o))
                for (var a = 0; a < o.length; a++) {
                  var c = o[a];
                  if (Array.isArray(c)) {
                    for (var i = 0; i < c.length; i++)
                      if (c[i].pocId === t && c[i].pocGroupId === n)
                        return [r, a];
                  } else if (o[a].pocId === t && o[a].pocGroupId === n)
                    return [r, a];
                }
              else if (o.pocId === t && o.pocGroupId === n) return [r, 0];
            }
            return null;
          };
        (0, u.useEffect)(
          function () {
            var e = S.pocId,
              t = S.pocGroupId;
            if (y && e && t && !e5()(a, [S]) && D()(i) && y) {
              var n = j(i, e, t);
              n
                ? (r(function (e) {
                    return tf(
                      tf({}, e),
                      {},
                      {
                        selectedStyles: [S],
                        activeTab: n[0],
                        activeGender: n[1],
                      }
                    );
                  }),
                  c([S]))
                : r(function (e) {
                    return tf(
                      tf({}, e),
                      {},
                      { selectedStyles: [S], activeTab: 0, activeGender: 0 }
                    );
                  }),
                _(!1);
            }
          },
          [S, i, y]
        );
        var k = (0, u.useMemo)(
            function () {
              if (Q()(I)) return [];
              var e = M()(
                  i,
                  "".concat(d, ".").concat(p, ".0.pocGroupId"),
                  null
                ),
                t = U()(I, function (t) {
                  return t.pocGroupId === e;
                }),
                n = {},
                r = G()(t, function (e) {
                  return (n[e.pocId] = e.isBestMatch), e.pocId;
                }),
                o = M()(i, "".concat(d, ".").concat(p), []),
                a = U()(o, function (e) {
                  return r.includes(e.pocId);
                }).sort(function (e, t) {
                  return r.indexOf(e.pocId) - r.indexOf(t.pocId);
                });
              return G()(a, function (e) {
                return tf(tf({}, e), {}, { isBestMatch: n[e.pocId] });
              });
            },
            [I, d, p, i]
          ),
          P = (0, u.useMemo)(
            function () {
              var e = M()(i, "".concat(d, ".").concat(p), []),
                t = G()(k, function (e) {
                  return e.pocId;
                });
              return U()(e, function (e) {
                return !t.includes(e.pocId);
              });
            },
            [d, p, i, k]
          ),
          R = (0, u.useMemo)(
            function () {
              return !Q()(k);
            },
            [k]
          ),
          Z = (0, u.useMemo)(
            function () {
              return !!D()(i);
            },
            [i]
          ),
          F = function (e) {
            var t = e.pocGroupId,
              n = e.pocId;
            if (O(e)) {
              var a = U()(h, function (e) {
                return e.pocGroupId !== t || e.pocId !== n;
              });
              r(function (e) {
                return tf(tf({}, e), {}, { selectedStyles: a });
              });
            } else {
              var c = U()(h, function (e) {
                return e.pocGroupId === t;
              });
              Q()(c)
                ? r(function (t) {
                    return tf(
                      tf({}, t),
                      {},
                      { selectedStyles: [].concat((0, l.Z)(c), [e]) }
                    );
                  })
                : 10 === o
                ? m((0, T.Xt)({ show: !0, type: "hair.style.limit.exceed" }))
                : r(function (t) {
                    return tf(
                      tf({}, t),
                      {},
                      { selectedStyles: [].concat((0, l.Z)(c), [e]) }
                    );
                  });
            }
          },
          O = function (e) {
            var t = e.pocGroupId,
              n = e.pocId;
            return !!D()(
              es()(h, function (e) {
                return e.pocGroupId === t && e.pocId === n;
              })
            );
          };
        return (0, eO.jsx)("div", {
          className: tn().container,
          children: Z
            ? (0, eO.jsxs)("div", {
                className: tn().stylesContainter,
                children: [
                  R &&
                    (0, eO.jsxs)(eO.Fragment, {
                      children: [
                        (0, eO.jsx)("div", {
                          className: tn().stylesTitle,
                          children: g(
                            "hair.style.settings.recommended.hair.style"
                          ),
                        }),
                        (0, eO.jsx)("div", {
                          className: tn().stylesBlock,
                          children: k.map(function (e, t) {
                            return (0,
                            eO.jsx)(tu, { style: e, isStyleActive: O, handleStyleClick: F, acmsLang: w }, t);
                          }),
                        }),
                        (0, eO.jsx)("div", {
                          className: ""
                            .concat(tn().stylesTitle, " ")
                            .concat(tn().marginTop20),
                          children: g("hair.style.settings.other.hair.style"),
                        }),
                      ],
                    }),
                  (0, eO.jsx)("div", {
                    className: tn().stylesBlock,
                    children: P.map(function (e, t) {
                      return (0,
                      eO.jsx)(tu, { style: e, isStyleActive: O, handleStyleClick: F, acmsLang: w }, t);
                    }),
                  }),
                ],
              })
            : (0, eO.jsx)("div", {
                className: tn().stylesBlock,
                children: (0, eO.jsx)(ti, {}),
              }),
        });
      }
      var th = n(19126),
        tm = n(72658),
        tg = n(24193),
        tb = n(41526),
        tv = n(6031),
        tx = n(88147);
      function ty() {
        var e = (0, u.useState)(tv.$j.hairExt),
          t = e[0],
          n = e[1],
          r = (0, u.useState)(!1),
          o = r[0],
          a = r[1],
          c = (0, u.useState)(!1),
          i = c[0],
          s = c[1];
        (0, u.useEffect)(function () {
          return (
            n(
              eR.ZP.getParsedItem(
                eR.XC.debug.hairStyle.preAlphaContentSubType,
                tv.$j.hairExt
              )
            ),
            e_.ZP.on(e_.Y7.debug.hairStyle.preAlphaContentSubType, l),
            a(eR.ZP.getParsedItem(eR.XC.debug.hairStyle.showFaceInfo, !1)),
            e_.ZP.on(e_.Y7.debug.hairStyle.showFaceInfo, l),
            s(eR.ZP.getParsedItem(eR.XC.debug.hairStyle.showFaceScore, !1)),
            e_.ZP.on(e_.Y7.debug.hairStyle.showFaceScore, l),
            function () {
              e_.ZP.off(e_.Y7.debug.hairStyle.preAlphaContentSubType, l),
                e_.ZP.off(e_.Y7.debug.hairStyle.showFaceInfo, l),
                e_.ZP.off(e_.Y7.debug.hairStyle.showFaceScore, l);
            }
          );
        }, []);
        var l = function (e) {
          var t = e.detail,
            r = t.key,
            o = t.newValue;
          r === eR.XC.debug.hairStyle.preAlphaContentSubType && n(o),
            r === eR.XC.debug.hairStyle.showFaceInfo && a(JSON.parse(o)),
            r === eR.XC.debug.hairStyle.showFaceScore && s(JSON.parse(o));
        };
        return {
          preAlphaContentSubType: t,
          setPreAlphaContentSubType: n,
          showFaceInfo: o,
          showFaceScore: i,
        };
      }
      var t_ = n(84806);
      function tw(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function tI(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? tw(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : tw(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function tS(e) {
        var t,
          n,
          r,
          o,
          a,
          c,
          i,
          s,
          f,
          p,
          h,
          m,
          g,
          b,
          v,
          x,
          y,
          _,
          w,
          I = e.settingsState,
          S = e.setSettingsState,
          j = e.paramsState,
          k = e.setParamsState,
          P = e.resultsState,
          R = e.handleUploadButtonClick,
          Z = e.handleGenerate,
          F = e.canGenerate,
          O = e.notEnough,
          T = e.actionCost,
          B = e.selectedStylesCount,
          N = e.taskRunning,
          E = e.canShowThumbnails,
          D = (0, u.useState)([]),
          A = D[0],
          U = D[1],
          W = (0, u.useRef)(null),
          G = (0, eh.Z)().isDesktop;
        (n = (t = {
          containerRef: W,
          tabChanged: I.activeTab,
          paramsState: j,
          paddingWithoutScrollBar: "0 20px 120px",
          paddingWithScrollBar: "0 10px 120px 20px",
        }).containerRef),
          (r = t.tabChanged),
          (o = t.paramsState),
          (a = t.paddingWithoutScrollBar),
          (c = t.paddingWithScrollBar),
          (i = (0, eU.Z)({ useHeight: !0 })),
          (f = (s = (0, d.Z)(i, 2))[0]),
          (p = s[1]),
          (h = (0, u.useMemo)(
            function () {
              return f > parseInt(eV()["width-lg"]);
            },
            [f]
          )),
          (0, u.useEffect)(
            function () {
              h || m(null);
            },
            [h]
          ),
          (0, u.useEffect)(
            function () {
              if (null != n && n.current && h) {
                var e = n.current;
                e.scrollHeight <= e.clientHeight ? m(a) : m(c);
              }
            },
            [h, p, r, o]
          ),
          (m = function (e) {
            n.current.style.padding = e;
          });
        var L = (0, eZ.PC)().t;
        (g = (0, t_.Z)().isDev),
          (b = (0, tx.Z)().isPreAlpha),
          (v = ty().preAlphaContentSubType),
          (x = (0, tg.Z)({
            categorytype: tv.UI[C.ft.hairStyle],
            contenttype: tv.IJ[C.ft.hairStyle],
            contentsubtypes:
              b && g
                ? v
                : [
                    tv.$j.hairstyle,
                    tv.$j.hairExt,
                    tv.$j.hairBang,
                    tv.$j.hairVol,
                  ],
          }).groups),
          (y = (0, tb.Z)({
            groups: x,
            querySubCategoryList: !0,
          }).subGroupStyles),
          (_ = (0, u.useMemo)(
            function () {
              return Q()(y)
                ? []
                : y
                    .filter(function (e) {
                      return "Color" !== e.internalName;
                    })
                    .map(function (e) {
                      var t = M()(e, "subCategoryList[0].items[0].subType");
                      if ("Style" === e.internalName) {
                        var n = y.find(function (e) {
                            return "Color" === e.internalName;
                          }),
                          r = e.subCategoryList.map(function (e) {
                            var t =
                              null == n
                                ? void 0
                                : n.subCategoryList.find(function (t) {
                                    return t.name === e.name;
                                  });
                            return t
                              ? tI(
                                  tI({}, e),
                                  {},
                                  {
                                    items: [].concat(
                                      (0, l.Z)(e.items),
                                      (0, l.Z)(t.items)
                                    ),
                                  }
                                )
                              : e;
                          });
                        return tI(
                          tI({}, e),
                          {},
                          { moduleType: C.ft.hairStyle, subCategoryList: r }
                        );
                      }
                      return tI(tI({}, e), {}, { moduleType: t });
                    });
            },
            [y]
          )),
          (0, u.useEffect)(
            function () {
              Q()(_) || w();
            },
            [_]
          ),
          (w = function () {
            var e = _.map(function (e) {
              return e.subCategoryList.map(function (e) {
                return e.items;
              });
            });
            k({
              groups: { paramGroups: (0, l.Z)(_) },
              groupStyles: (0, l.Z)(e),
            });
          });
        var H = (0, u.useMemo)(
            function () {
              return F || !N
                ? L("text.to.image.settings.button")
                : L("hair.style.settings.button.generating");
            },
            [F, N]
          ),
          z = (0, u.useMemo)(
            function () {
              return B <= 1
                ? L("hair.style.settings.button.credit", {
                    numOfStyles: B,
                    totalCredits: T,
                  })
                : L("hair.style.settings.button.credits", {
                    numOfStyles: B,
                    totalCredits: T,
                  });
            },
            [B, T]
          );
        return (0, eO.jsxs)(eO.Fragment, {
          children: [
            (0, eO.jsxs)("div", {
              ref: W,
              className: eX().settings,
              children: [
                (0, eO.jsx)(te, {
                  paramsState: j,
                  settingsState: I,
                  setSettingsState: S,
                  canShowThumbnails: E,
                  resultsState: P,
                  lastStyles: A,
                }),
                (0, eO.jsx)(tp, {
                  paramsState: j,
                  settingsState: I,
                  setSettingsState: S,
                  selectedStylesCount: B,
                  lastStyles: A,
                  setLastStyles: U,
                }),
              ],
            }),
            (0, eO.jsxs)("div", {
              className: eX().buttonWrapper,
              children: [
                G
                  ? (0, eO.jsxs)(eF.Z, {
                      className: ""
                        .concat(eX().button, " ")
                        .concat(F ? "" : eX().buttonDisabled),
                      hoverClass: "hover-46e4fa",
                      touchClass: "touch-46e4fa",
                      onClick: Z,
                      gaClass: ey.HS,
                      children: [
                        (0, eO.jsx)("div", {
                          className: eX().buttonDesc,
                          children: H,
                        }),
                        (F || !N) &&
                          (0, eO.jsx)("div", {
                            className: eX().costDesc,
                            children: z,
                          }),
                      ],
                    })
                  : (0, eO.jsx)(tm.N, {
                      custom: {
                        onUploadButtonClicked: function () {
                          return R();
                        },
                      },
                      children: (0, eO.jsxs)(eF.Z, {
                        className: ""
                          .concat(eX().button, " ")
                          .concat(F ? "" : eX().buttonDisabled),
                        hoverClass: "hover-46e4fa",
                        touchClass: "touch-46e4fa",
                        onClick: Z,
                        gaClass: ey.HS,
                        disabled: !F,
                        children: [
                          (0, eO.jsx)("div", {
                            className: eX().buttonDesc,
                            children: H,
                          }),
                          (F || !N) &&
                            (0, eO.jsx)("div", {
                              className: eX().costDesc,
                              children: z,
                            }),
                        ],
                      }),
                    }),
                (0, eO.jsx)(th.Z, { notEnough: O }),
              ],
            }),
          ],
        });
      }
      var tj = n(54591),
        tk = n.n(tj),
        tC = n(46066),
        tP = n(42235),
        tR = n.n(tP),
        tZ = n(72422),
        tF = n.n(tZ),
        tO = n(26126),
        tT = n(56716),
        tB = n(98246),
        tN = n.n(tB);
      function tM(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      var tE = ["topLeft", "topRight", "bottomLeft", "bottomRight"];
      function tD(e) {
        var t = e.faceRect,
          n = e.active,
          r = e.onClick,
          o = e.faceMaskAnimation,
          a = o.rectScale,
          c = o.showMask,
          i = o.hasShowed,
          s = (0, u.useState)(!1),
          l = s[0],
          d = s[1],
          f = (0, u.useMemo)(
            function () {
              var e = t.top,
                n = void 0 === e ? 0 : e,
                r = t.bottom,
                o = void 0 === r ? 0 : r,
                c = t.left,
                i = void 0 === c ? 0 : c,
                s = t.right,
                u = void 0 === s ? 0 : s;
              return {
                top: "".concat(n, "px"),
                bottom: "".concat(o, "px"),
                left: "".concat(i, "px"),
                right: "".concat(u, "px"),
                width: "".concat(u - i, "px"),
                height: "".concat(o - n, "px"),
                transform: "scale(".concat(a, ")"),
              };
            },
            [t, a]
          ),
          p = (0, u.useMemo)(
            function () {
              return i
                ? n
                  ? "#03ADE2"
                  : l
                  ? "#FFF"
                  : "rgba(0, 0, 0, 0)"
                : "#FFF";
            },
            [n, i, l]
          );
        return (0, eO.jsx)("div", {
          className: ""
            .concat(tN().container, " ")
            .concat(c ? tN().maskActive : ""),
          style: f,
          onClick: r,
          onPointerEnter: function () {
            return d(!0);
          },
          onPointerOut: function () {
            return d(!1);
          },
          onPointerUp: r,
          children: tE.map(function (e, n) {
            return (0, eO.jsx)(tA, { type: e, stroke: p, faceRect: t }, n);
          }),
        });
      }
      var tA = function (e) {
          var t = e.type,
            n = e.stroke,
            r = e.faceRect,
            o = (0, u.useMemo)(
              function () {
                var e = r.top,
                  t = r.bottom,
                  n = r.left,
                  o = r.right,
                  a = Math.min(
                    22,
                    ((void 0 === o ? 0 : o) - (void 0 === n ? 0 : n)) / 3,
                    ((void 0 === t ? 0 : t) - (void 0 === e ? 0 : e)) / 3
                  );
                return {
                  width: "".concat(a, "px"),
                  height: "".concat(a, "px"),
                };
              },
              [r]
            ),
            a = (0, u.useMemo)(
              function () {
                return "#FFF" === n;
              },
              [n]
            );
          return (0, eO.jsx)("svg", {
            className: ""
              .concat(tN().roundedCorner, " ")
              .concat(a ? tN().roundedCornerWithShadow : "", " ")
              .concat(tN()[t]),
            style: (function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2
                  ? tM(Object(n), !0).forEach(function (t) {
                      (0, f.Z)(e, t, n[t]);
                    })
                  : Object.getOwnPropertyDescriptors
                  ? Object.defineProperties(
                      e,
                      Object.getOwnPropertyDescriptors(n)
                    )
                  : tM(Object(n)).forEach(function (t) {
                      Object.defineProperty(
                        e,
                        t,
                        Object.getOwnPropertyDescriptor(n, t)
                      );
                    });
              }
              return e;
            })({ color: n }, o),
            width: "22",
            height: "22",
            viewBox: "0 0 22 22",
            fill: "none",
            children: (0, eO.jsx)("path", {
              d: "M3 18V5C3 3.89543 3.89543 3 5 3H18.6",
              stroke: "currentColor",
              strokeWidth: "6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
          });
        },
        tU = n(68387),
        tW = n.n(tU);
      function tG(e) {
        var t = e.faceMeshBlobUrl,
          n = e.showFaceInfo4Debug,
          r = e.containerSize,
          o = e.openFaceInfo,
          a = e.setOpenFaceInfo,
          c = (0, u.useRef)(null),
          i = (0, u.useMemo)(
            function () {
              var e = new Image();
              e.src = t;
              var n = e.width,
                o = e.height,
                a = r.width,
                c = r.height;
              return n / o > a / c
                ? { width: a, height: a * (o / n) }
                : { width: c * (n / o), height: c };
            },
            [t, r]
          );
        return (
          (0, u.useEffect)(
            function () {
              null != c &&
                c.current &&
                setTimeout(function () {
                  c.current.centerView(1);
                });
            },
            [r, i]
          ),
          (0, eO.jsx)(eO.Fragment, {
            children:
              n &&
              (0, eO.jsx)("div", {
                className: ""
                  .concat(tW().container, " ")
                  .concat(o ? tW().open : ""),
                children: (0, eO.jsx)("div", {
                  style: {
                    position: "relative",
                    maxWidth: "".concat(r.width, "px"),
                    maxHeight: "".concat(r.height, "px"),
                  },
                  children:
                    o &&
                    (0, eO.jsxs)(eO.Fragment, {
                      children: [
                        (0, eO.jsx)("div", {
                          className: tW().faceInfoContainer,
                          children: (0, eO.jsx)(tO.d$, {
                            ref: c,
                            disablePadding: !0,
                            centerOnInit: !0,
                            initialScale: 1,
                            velocityAnimation: {
                              equalToMove: !1,
                              sensitivity: 10,
                            },
                            onPanningStart: function (e, t) {},
                            onPanningStop: function (e, t) {},
                            onPinchingStart: function (e, t) {},
                            onPinchingStop: function (e, t) {},
                            onTransformed: function (e, t) {},
                            children: (0, eO.jsx)(tO.Uv, {
                              wrapperStyle: {
                                position: "relative",
                                overflow: "visible",
                                margin: "auto",
                                width: "".concat(r.width, "px"),
                                height: "".concat(r.height, "px"),
                              },
                              children: (0, eO.jsx)("img", {
                                src: t,
                                className: tW().image,
                                style: {
                                  width: "".concat(i.width, "px"),
                                  height: "".concat(i.height, "px"),
                                },
                              }),
                            }),
                          }),
                        }),
                        (0, eO.jsx)("div", {
                          className: tW().close,
                          onClick: function () {
                            return a(!1);
                          },
                          children: "X",
                        }),
                      ],
                    }),
                }),
              }),
          })
        );
      }
      var tL = n(38733),
        tH = n.n(tL);
      function tz(e) {
        var t = e.faceInfo,
          n = e.faceMaskAnimation,
          r = e.imageScale,
          o = n.rectScale,
          a = M()(t, "faceRect.top", 0),
          c = M()(t, "faceRect.left", 0),
          i = M()(t, "faceRect.bottom", 0),
          s = M()(t, "faceRect.right", 0),
          l = a * r,
          d = i * r,
          f = c * r,
          p = s * r,
          h = (0, u.useMemo)(
            function () {
              return {
                top: "".concat(l - 55, "px"),
                bottom: "".concat(d, "px"),
                left: "".concat(f, "px"),
                right: "".concat(p, "px"),
                transform: "scale(".concat(o, ")"),
              };
            },
            [o]
          ),
          m = M()(t, "boxScore", 0),
          g = M()(t, "faceScore", 0);
        return (0, eO.jsx)("div", {
          className: tH().container,
          style: h,
          children: (0, eO.jsxs)("div", {
            className: tH().faceInfo,
            children: [
              (0, eO.jsxs)("p", { children: ["Detection：", m] }),
              (0, eO.jsxs)("p", { children: ["Anylysis：", g] }),
            ],
          }),
        });
      }
      function tY(e) {
        var t = e.src,
          n = e.faceInfos,
          r = e.selectedFaceIndex,
          o = e.setSelectedFaceIndex,
          a = e.originalSrc,
          c = e.comparing,
          i = e.isActive,
          l = e.updateReduxWhenZoom,
          d = e.faceMaskAnimation,
          f = e.rejectedFaceInfos,
          p = e.faceMeshBlobUrl,
          m = d.showHint,
          g = (0, u.useState)(!1),
          b = g[0],
          v = g[1],
          x = (0, u.useState)(!1),
          y = x[0],
          _ = x[1],
          w = (0, u.useState)(1),
          I = w[0],
          S = w[1],
          j = (0, u.useState)(0),
          k = j[0],
          C = j[1],
          P = (0, u.useState)(!1),
          R = P[0],
          Z = P[1],
          F = (0, u.useState)(!1),
          O = F[0],
          T = F[1],
          B = (0, u.useState)({ width: 0, height: 0 }),
          N = B[0],
          E = B[1],
          A = (0, u.useState)(!1),
          U = A[0],
          W = A[1],
          L = (0, u.useRef)(null),
          H = (0, u.useRef)(null),
          z = (0, h.Z)().setProductConfig,
          Y = (0, eZ.PC)().t,
          X = (0, t_.Z)().isDev,
          K = ty(),
          V = K.showFaceInfo,
          Q = K.showFaceScore,
          q = (0, s.v9)(function (e) {
            return e.info;
          }),
          J = (0, s.v9)(function (e) {
            return e.result;
          }),
          $ = q.moduleType,
          ee = J.productConfig,
          et = (0, u.useRef)(null),
          en = (0, u.useRef)(null);
        (0, tT.Z)({
          targetRef: en,
          onResize: function () {
            return em();
          },
        });
        var er = (0, u.useMemo)(
            function () {
              return i && l
                ? M()(ee, "".concat($, ".resultImageZoomExtents"), {})
                : {};
            },
            [i, ee, l]
          ),
          eo = (0, u.useMemo)(
            function () {
              return M()(er, "now", 0);
            },
            [er]
          ),
          ea = (0, u.useMemo)(
            function () {
              return a && (c || !R)
                ? (setTimeout(function () {
                    return Z(!0);
                  }, 500),
                  a)
                : t || a;
            },
            [t, a, c, R]
          ),
          ec = (0, u.useMemo)(
            function () {
              return t && !a ? tF().image1 : [tF().image1, tF().image2];
            },
            [t, a]
          ),
          ei = (0, u.useMemo)(
            function () {
              return {
                width: M()(n, "0.originalImage.width", 0),
                height: M()(n, "0.originalImage.height", 0),
              };
            },
            [n]
          ),
          es = (0, u.useMemo)(
            function () {
              return k && (1 !== n.length || f.length)
                ? G()(n, function (e) {
                    var t = e.faceRect;
                    return {
                      top: Math.round(t.top * k),
                      bottom: Math.round(t.bottom * k),
                      left: Math.round(t.left * k),
                      right: Math.round(t.right * k),
                    };
                  })
                : [];
            },
            [n, k]
          ),
          eu = (0, u.useMemo)(
            function () {
              return 1 === n.length;
            },
            [n]
          ),
          el = (0, u.useMemo)(
            function () {
              return es.length > 0;
            },
            [es]
          );
        (0, u.useEffect)(function () {
          return function () {
            ep();
          };
        }, []),
          (0, u.useEffect)(
            function () {
              if (L.current && i && l) {
                var e = eo / 100;
                0 !== e && e !== I && (O || T(!0));
              }
            },
            [eo]
          ),
          (0, u.useEffect)(
            function () {
              i &&
                l &&
                O &&
                setTimeout(function () {
                  var e,
                    t,
                    n = eo / 100;
                  I < n
                    ? null === (e = L.current) ||
                      void 0 === e ||
                      e.zoomIn(n - I, 0)
                    : null === (t = L.current) ||
                      void 0 === t ||
                      t.zoomOut(I - n, 0),
                    T(!1);
                }, 8);
            },
            [O]
          ),
          (0, u.useEffect)(
            function () {
              if (i && l) {
                var e = 100 * I;
                eo !== e && z($, { resultImageZoomExtents: { now: e } });
              }
            },
            [I]
          ),
          (0, u.useEffect)(
            function () {
              var e, t;
              null === (e = L.current) || void 0 === e || e.resetTransform(0),
                null === (t = L.current) ||
                  void 0 === t ||
                  t.centerView(void 0, 0);
            },
            [t]
          ),
          (0, u.useEffect)(
            function () {
              ed(1);
            },
            [i]
          ),
          (0, u.useEffect)(
            function () {
              ed();
            },
            [t]
          );
        var ed = function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : 50;
            H.current = setTimeout(function () {
              return ef(e);
            }, 20);
          },
          ef = function e(t) {
            var n;
            !(t <= 0) &&
              H.current &&
              (null === (n = L.current) || void 0 === n || n.centerView(1, 0),
              (H.current = setTimeout(function () {
                return e(t - 1);
              }, 20)));
          },
          ep = function () {
            H.current && (clearTimeout(H.current), (H.current = null));
          },
          eh = function () {
            if (
              null != et &&
              et.current &&
              null != ei &&
              ei.width &&
              null != ei &&
              ei.height
            ) {
              var e = et.current.getBoundingClientRect(),
                t = e.width,
                n = e.height;
              C(Math.max(t / ei.width / I, n / ei.height / I));
            }
          },
          em = function () {
            if (null != en && en.current) {
              var e = en.current.getBoundingClientRect();
              E({ width: e.width, height: e.height });
            }
          };
        return (
          (0, u.useEffect)(
            function () {
              eh();
            },
            [ei, I, N]
          ),
          (0, eO.jsxs)(eO.Fragment, {
            children: [
              (0, eO.jsx)("div", {
                ref: en,
                id: "YCE-result-photo-text-to-image-result-image-preview-container",
                className: tF().container,
                onTouchStart: function (e) {
                  (y || b || 1 !== I) &&
                    (e.stopPropagation(), e.preventDefault());
                },
                onTouchMove: function (e) {
                  (y || b || 1 !== I) &&
                    (e.stopPropagation(), e.preventDefault());
                },
                onTouchEnd: function (e) {},
                children: (0, eO.jsx)(tO.d$, {
                  ref: L,
                  disablePadding: !0,
                  centerZoomedOut: !1,
                  smooth: !1,
                  onZoomStart: ep,
                  onWheelStart: ep,
                  onPinchingStart: function (e, t) {
                    _(!0), ep();
                  },
                  onPinching: function (e, t) {},
                  onPinchingStop: function (e, t) {
                    _(!1);
                  },
                  onPanningStart: function (e, t) {
                    1 !== I && v(!0), ep();
                  },
                  onPanning: function (e, t) {},
                  onPanningStop: function (e, t) {
                    v(!1);
                  },
                  onTransformed: function (e, t) {
                    S(t.scale);
                  },
                  panning: { disabled: I <= 1 },
                  doubleClick: { disabled: !0 },
                  children: (0, eO.jsx)(tO.Uv, {
                    wrapperClass: tF().transformWrapper,
                    contentClass: tF().transformComponent,
                    children:
                      ea &&
                      (0, eO.jsxs)("div", {
                        className: tF().imageContainer,
                        children: [
                          (0, eO.jsxs)("div", {
                            id: "YCE-result-photo-text-to-image-result-image-preview-image-wrapper",
                            ref: et,
                            className: tF().imageWrapper,
                            style: {
                              maxWidth: "".concat(N.width, "px"),
                              maxHeight: "".concat(N.height, "px"),
                            },
                            children: [
                              (0, eO.jsx)(ts.Z, {
                                src: ea,
                                alwaysShowLoading: !1,
                                imageClass: ec,
                                transitionDisabled: !!t && !!a,
                                onLoad: function () {
                                  eh();
                                },
                              }),
                              el &&
                                (0, eO.jsx)(eO.Fragment, {
                                  children: es.map(function (e, t) {
                                    return (0, eO.jsx)(
                                      tD,
                                      {
                                        faceRect: e,
                                        active: r === t,
                                        onClick: function () {
                                          t !== r && o(t);
                                        },
                                        faceMaskAnimation: d,
                                      },
                                      t
                                    );
                                  }),
                                }),
                              D()(n) &&
                                Q &&
                                (0, eO.jsx)(eO.Fragment, {
                                  children: n.map(function (e, t) {
                                    return (0,
                                    eO.jsx)(tz, { faceInfo: e, faceMaskAnimation: d, imageScale: k, scale: I }, t);
                                  }),
                                }),
                            ],
                          }),
                          el &&
                            !eu &&
                            (0, eO.jsx)("div", {
                              className: ""
                                .concat(tF().hintBlock, " ")
                                .concat(m ? tF().hintBlockActive : ""),
                              children: (0, eO.jsx)("div", {
                                className: tF().hint,
                                children: Y("hair.style.face.rect.hint"),
                              }),
                            }),
                          V &&
                            (0, eO.jsx)("button", {
                              className: tF().toggleFaceInfo,
                              onClick: function () {
                                return W(function (e) {
                                  return !e;
                                });
                              },
                              children: "Show Face Info",
                            }),
                        ],
                      }),
                  }),
                }),
              }),
              X &&
                p &&
                (0, eO.jsx)(tG, {
                  faceMeshBlobUrl: p,
                  showFaceInfo4Debug: V,
                  containerSize: N,
                  openFaceInfo: U,
                  setOpenFaceInfo: W,
                }),
            ],
          })
        );
      }
      var tX = n(70049),
        tK = n.n(tX),
        tV = n(98110),
        tQ = n(10752),
        tq = n.n(tQ),
        tJ = n(79833),
        t$ = n.n(tJ);
      function t0(e) {
        var t = e.show,
          n = e.generatedResults,
          r = e.imagePreviewIndex,
          o = e.paramsState,
          a = e.handleGoTo,
          c = e.diff,
          i = (0, u.useState)(0),
          s = i[0],
          l = i[1],
          d = (0, u.useRef)(null),
          f = (0, u.useRef)([]),
          p = (0, eh.Z)().isDesktop,
          h = (0, eS.useRouter)(),
          m = (0, eZ.PC)().t,
          g = h.query.locale,
          b = (0, u.useMemo)(
            function () {
              return e8.Z.convertACMSLanguageType(g);
            },
            [g]
          ),
          v = (0, u.useMemo)(
            function () {
              return G()(n, function (e) {
                return M()(e, "thumbUrl", "");
              });
            },
            [n]
          );
        (0, u.useEffect)(
          function () {
            _();
          },
          [c]
        ),
          (0, u.useEffect)(
            function () {
              var e;
              if (
                null !== r &&
                null != d &&
                null !== (e = d.current) &&
                void 0 !== e &&
                e.element &&
                f.current[r]
              ) {
                var t,
                  n,
                  o,
                  a,
                  c =
                    (null == f
                      ? void 0
                      : null === (t = f.current) || void 0 === t
                      ? void 0
                      : t[r]) || {},
                  i = c.offsetLeft,
                  s = c.offsetWidth,
                  u =
                    (null == d
                      ? void 0
                      : null === (n = d.current) || void 0 === n
                      ? void 0
                      : n.element) || {},
                  l = u.offsetLeft,
                  p = u.offsetWidth;
                null == d ||
                  null === (o = d.current) ||
                  void 0 === o ||
                  null === (a = o.element) ||
                  void 0 === a ||
                  a.scrollTo({ left: i - l + (s - p) / 2, behavior: "smooth" });
              }
            },
            [r]
          );
        var x = function (e) {
            var t = M()(n, e, {}),
              r = t.actId,
              a = t.clientCfg,
              c = t.style_id,
              i = M()(a, r, {}).paramGroupId,
              s = (o || {}).groupStyles;
            if (!a) return m("crop.options.original");
            var u = tq()(s),
              l = es()(u, function (e) {
                return e.pocGroupId === i && t$()(e.pocId) === t$()(c);
              }),
              d = M()(l, "i18n", []),
              f = es()(d, function (e) {
                return e.lang === b;
              });
            return M()(f, "name", "");
          },
          y = function (e) {
            if (
              (null === (t = d.current) || void 0 === t || !t.moved) &&
              (a(e), !p)
            ) {
              var t,
                n = document.getElementById("YCE-result-photo-container");
              n && n.scrollTo({ top: 0, left: 0, behavior: "smooth" });
            }
          },
          _ = function () {
            var e,
              t =
                null == d
                  ? void 0
                  : null === (e = d.current) || void 0 === e
                  ? void 0
                  : e.element;
            if (t) {
              if (c < 0 || !e2()(c)) {
                if (!t.style.maxHeight) return;
                (t.style.maxHeight = null),
                  setTimeout(function () {
                    l(t.clientHeight);
                  }, 50);
              } else t.style.maxHeight = "".concat(Math.max(100, s - c), "px");
            }
          };
        return void 0 === t || t
          ? (0, eO.jsx)(tV.Z, {
              ref: d,
              wrapperClass: tK().thumbBlock,
              enableDrag: { x: !0, y: !1 },
              children:
                !Q()(v) &&
                v.map(function (e, t) {
                  return (0, eO.jsxs)(
                    "div",
                    {
                      className: tK().thumbContainer,
                      onClick: function () {
                        return y(t);
                      },
                      children: [
                        (0, eO.jsx)("div", {
                          className: ""
                            .concat(tK().thumbOuterWrapper, " ")
                            .concat(
                              t === r ? tK().thumbOuterWrapperActive : ""
                            ),
                          ref: function (e) {
                            return (f.current[t] = e);
                          },
                          children: (0, eO.jsx)("div", {
                            className: tK().paddingTop,
                            children: (0, eO.jsx)("div", {
                              className: tK().thumbInnerWrapper,
                              children: e
                                ? (0, eO.jsx)(ts.Z, {
                                    src: e,
                                    imageClass: tK().thumbImage,
                                  })
                                : (0, eO.jsx)("div", {
                                    className: "".concat(
                                      tK().thumbImage,
                                      " shimmer-skeleton"
                                    ),
                                  }),
                            }),
                          }),
                        }),
                        e
                          ? (0, eO.jsx)("div", {
                              className: tK().thumbText,
                              children: x(t),
                            })
                          : (0, eO.jsx)("div", {
                              className: "".concat(
                                tK().thumbTextSkeleton,
                                " shimmer-skeleton"
                              ),
                            }),
                      ],
                    },
                    t
                  );
                }),
            })
          : null;
      }
      var t1 = n(45220),
        t2 = n.n(t1);
      function t4(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function t6(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? t4(Object(n), !0).forEach(function (t) {
                (0, f.Z)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : t4(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      function t3(e) {
        var t = e.sliderRef,
          n = e.images,
          r = e.canShowThumbnails,
          o = e.resultsState,
          a = e.setResultsState,
          c = e.paramsState,
          i = e.updateReduxWhenZoom,
          s = e.setSelectedFaceIndex,
          l = e.faceMaskAnimation,
          d = o.comparing,
          f = void 0 !== d && d,
          p = o.generatedResults,
          h = o.imagePreviewIndex,
          m = M()(p, "0.url", null),
          g = (0, u.useState)(0),
          b = g[0],
          v = g[1],
          x = (0, eh.Z)().isDesktop,
          y = (0, u.useMemo)(
            function () {
              return h > 0 && x;
            },
            [h, x]
          ),
          _ = (0, u.useMemo)(
            function () {
              return h < D()(n) - 1 && x;
            },
            [h, n, x]
          ),
          w = (0, u.useMemo)(
            function () {
              return x
                ? "/assets/images/txt2Img/ico_c_arraow.png"
                : "/assets/images/txt2Img/ico_c_arraow_mb.png";
            },
            [x]
          ),
          I = (0, u.useMemo)(
            function () {
              return f
                ? "/assets/images/hairStyle/btn_compare_lr_s.png"
                : "/assets/images/hairStyle/btn_compare_lr_n.png";
            },
            [f]
          ),
          S = (0, u.useMemo)(
            function () {
              return h > 0;
            },
            [h]
          );
        (0, u.useEffect)(
          function () {
            t2()(b) || b === h || k(b);
          },
          [b]
        ),
          (0, u.useEffect)(
            function () {
              t2()(h) || b === h || P(h);
            },
            [h]
          );
        var j = function (e) {
            a(function (t) {
              return t6(t6({}, t), {}, { comparing: e });
            });
          },
          k = function (e) {
            a(function (t) {
              return t6(t6({}, t), {}, { imagePreviewIndex: e });
            });
          },
          C = function (e) {
            null != t &&
              t.current &&
              (e ? t.current.slickPrev() : t.current.slickNext());
          },
          P = function (e) {
            null != t && t.current && t.current.slickGoTo(e);
          };
        return (0, eO.jsxs)("div", {
          className: tR().container,
          children: [
            (0, eO.jsxs)("div", {
              className: tR().previewBlock,
              children: [
                y &&
                  (0, eO.jsx)("div", {
                    className: tR().arrowButtonLeft,
                    onClick: function () {
                      return C(!0);
                    },
                    children: (0, eO.jsx)("img", {
                      className: tR().leftArrowIcon,
                      src: w,
                      alt: "",
                    }),
                  }),
                (0, eO.jsx)("div", {
                  className: tR().paddingTopForImagePreview,
                  children: (0, eO.jsx)("div", {
                    className: tR().absoluteBlock,
                    children: (0, eO.jsx)(tC.Z, {
                      ref: t,
                      arrows: !1,
                      dots: !1,
                      infinite: !1,
                      draggable: !1,
                      speed: 300,
                      easing: "ease-out",
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      touchThreshold: 12,
                      beforeChange: function (e, t) {
                        return v(t);
                      },
                      children:
                        !Q()(n) &&
                        n.map(function (e) {
                          var t = e.idx,
                            n = e.url,
                            r = e.faceInfos,
                            o = e.rejectedFaceInfos,
                            a = e.selectedFaceIndex,
                            c = e.backgroundUrl,
                            u = e.faceMeshBlobUrl;
                          return (0,
                          eO.jsx)(tY, { src: n, faceInfos: r, selectedFaceIndex: a, setSelectedFaceIndex: s, originalSrc: c || m, comparing: f, isActive: t === h, updateReduxWhenZoom: i, faceMaskAnimation: l, rejectedFaceInfos: o, faceMeshBlobUrl: u }, t);
                        }),
                    }),
                  }),
                }),
                _ &&
                  (0, eO.jsx)("div", {
                    className: tR().arrowButtonRight,
                    onClick: function () {
                      return C(!1);
                    },
                    children: (0, eO.jsx)("img", {
                      className: tR().rightArrowIcon,
                      src: w,
                      alt: "",
                    }),
                  }),
                S &&
                  (0, eO.jsx)("div", {
                    className: tR().compareBlock,
                    onPointerDown: function () {
                      return j(!0);
                    },
                    onPointerOut: function () {
                      return j(!1);
                    },
                    onPointerUp: function () {
                      return j(!1);
                    },
                    children: (0, eO.jsx)("img", {
                      src: I,
                      className: tR().compare,
                      draggable: !1,
                      alt: "",
                    }),
                  }),
              ],
            }),
            (0, eO.jsx)(t0, {
              show: r,
              generatedResults: p,
              imagePreviewIndex: h,
              paramsState: c,
              handleGoTo: P,
            }),
          ],
        });
      }
      function t5(e) {
        var t = e.sliderRef,
          n = e.resultsState,
          r = e.setResultsState,
          o = e.paramsState,
          a = e.updateReduxWhenZoom,
          c = e.setSelectedFaceIndex,
          i = e.faceMaskAnimation,
          s = e.hideThumbnailsIfEmpty,
          l = void 0 !== s && s,
          d = e.hideThumbnails,
          f = void 0 !== d && d,
          p = e.onlyShowThumbnails,
          h = e.diff,
          m = n.generatedResults,
          g = n.imagePreviewIndex,
          b = (0, u.useMemo)(
            function () {
              return G()(m, function (e, t) {
                return {
                  idx: t,
                  url: M()(e, "synthesizedUrl", M()(e, "url", "")),
                  backgroundUrl: M()(e, "backgroundUrl", ""),
                  faceInfos: M()(e, "faceInfos", []),
                  rejectedFaceInfos: M()(e, "rejectedFaceInfos", {}),
                  selectedFaceIndex: M()(e, "selectedFaceIndex", 0),
                  faceMeshBlobUrl: M()(e, "faceMeshBlobUrl", ""),
                };
              });
            },
            [m]
          ),
          v = (0, u.useMemo)(
            function () {
              return !f && !(l && 1 === D()(b));
            },
            [l, f, b]
          );
        return void 0 !== p && p
          ? !f &&
              (0, eO.jsx)(t0, {
                show: v,
                generatedResults: m,
                imagePreviewIndex: g,
                paramsState: o,
                handleGoTo: function (e) {
                  null != t && t.current && t.current.slickGoTo(e);
                },
                diff: h,
              })
          : (0, eO.jsx)("div", {
              className: tk().container,
              children: (0, eO.jsx)(t3, {
                sliderRef: t,
                images: b,
                canShowThumbnails: v,
                resultsState: n,
                setResultsState: r,
                paramsState: o,
                updateReduxWhenZoom: void 0 !== a && a,
                setSelectedFaceIndex: c,
                faceMaskAnimation: i,
              }),
            });
      }
      var t8 = n(1848),
        t9 = n(66683),
        t7 = { comparing: !1, generatedResults: [], imagePreviewIndex: -1 },
        ne = {
          comparing: !1,
          overlapping: !1,
          activeTab: 0,
          activeGender: 0,
          selectedStyles: [],
        },
        nt = { groups: {}, groupStyles: [] };
      function nn() {
        var e,
          t,
          n,
          o,
          c,
          N,
          E,
          A,
          W,
          L,
          z,
          X,
          V,
          q,
          $,
          et,
          er,
          ea,
          ei,
          eu,
          ed,
          eg,
          ew,
          eI,
          eS,
          ej,
          ek,
          eC,
          eP,
          eR,
          eZ,
          eF,
          eT,
          eB,
          eN,
          eM,
          eD,
          eA,
          eU,
          eG,
          eL,
          eH,
          eY,
          eX,
          eK,
          eV,
          eQ,
          eq,
          eJ,
          e$,
          e0,
          e1,
          e2,
          e4,
          e6,
          e3,
          e5,
          e8,
          e9,
          e7,
          te,
          tt,
          tn,
          tr,
          to,
          ta,
          tc,
          ti,
          ts,
          tu,
          tl,
          td,
          tf,
          tp,
          th,
          tm,
          tg,
          tb,
          tv,
          tx,
          ty,
          tw,
          tI,
          tj,
          tk,
          tC,
          tP,
          tR,
          tZ,
          tF,
          tO,
          tT,
          tB,
          tN,
          tM,
          tE,
          tD,
          tA,
          tU,
          tW,
          tG,
          tL,
          tH,
          tz,
          tY,
          tX,
          tK,
          tV,
          tQ,
          tq,
          tJ,
          t$,
          t0,
          t1,
          t4,
          t6,
          t3,
          nn,
          nr,
          no,
          na,
          nc = (0, u.useState)(ne),
          ni = nc[0],
          ns = nc[1],
          nu = (0, u.useState)(t7),
          nl = nu[0],
          nd = nu[1],
          nf = (0, u.useState)(nt),
          np = nf[0],
          nh = nf[1],
          nm = (0, u.useState)(!0),
          ng = nm[0],
          nb = nm[1],
          nv = (0, u.useState)([]),
          nx = nv[0],
          ny = nv[1],
          n_ = (0, u.useRef)(null),
          nw = (0, u.useRef)(null),
          nI = (0, u.useRef)(null),
          nS = (0, u.useRef)(null),
          nj = (0, m.Z)().onCanvasCompleted,
          nk =
            ((t = (e = {
              settingsState: ni,
              setSettingsState: ns,
              resultsState: nl,
              setResultsState: nd,
              historyDstKeys: nx,
              setHistoryDstKeys: ny,
              setIsEmptyResult: nb,
            }).settingsState),
            (n = e.setSettingsState),
            (o = e.resultsState),
            (c = e.setResultsState),
            (N = e.historyDstKeys),
            (E = e.setHistoryDstKeys),
            (A = e.setIsEmptyResult),
            (L = (W = (0, u.useState)(0))[0]),
            (z = W[1]),
            (V = (X = (0, u.useState)(ep))[0]),
            (q = X[1]),
            (et = ($ = (0, u.useState)(!1))[0]),
            (er = $[1]),
            (ei = (ea = (0, g.Z)()).modelsLoaded),
            (eu = ea.detectFace4HairStyleMultiple),
            (eg = (ed = (0, h.Z)()).setTaskFailed),
            (ew = ed.setTaskProcessType),
            (eI = ed.setBeforeImage),
            (eS = ed.cancelTaskProcessType),
            (ej = ed.setTaskComplete),
            (ek = ed.setProductConfig),
            (eC = ed.setNewTask),
            (eR = (eP = (0, m.Z)()).checkStatusBeforeProcess),
            (eZ = eP.runUpload),
            (eF = eP.runTask),
            (eT = eP.validateImageSize),
            (eB = eP.storeCompressedData),
            (eN = eP.validateGenerativeAITaskResult),
            (eM = (0, s.I0)()),
            (eD = (0, s.v9)(function (e) {
              return e.result;
            })),
            (eA = (0, s.v9)(function (e) {
              return e.info;
            })),
            (eU = (0, s.v9)(function (e) {
              return e.yceData;
            })),
            (eG = (0, s.v9)(function (e) {
              return e.task;
            })),
            (eL = (0, s.v9)(function (e) {
              return e.ui;
            })),
            (eH = (0, u.useMemo)(
              function () {
                return M()(eA, "moduleType", C.ft.hairStyle);
              },
              [eA]
            )),
            (eX = (eY = (0, v.Z)({ helperFunc: !0 })).leftCredits),
            (eK = eY.validateEnoughCredits),
            (eV = (0, x.Z)({ moduleType: eH }).tokenActionCost),
            (eQ = (0, w.Z)().sendGAProcessEvent),
            (eq = (0, y.Z)({ moduleType: eH }).needToShowGuideline),
            (eJ = (0, _.Z)({
              handleApply: (function (e) {
                function t() {
                  return e.apply(this, arguments);
                }
                return (
                  (t.toString = function () {
                    return e.toString();
                  }),
                  t
                );
              })(function () {
                return th();
              }),
            }).popupLoginModal),
            (e$ = (0, I.Z)().checkGeneratePopup),
            (e0 = (0, b.Z)().checkTriedStatus),
            (e1 = eD.general),
            (e2 = eD.productConfig),
            (e4 = e1.initialized),
            (e6 = eG.taskResult),
            (e3 = eG.finishResult),
            (e5 = (0, u.useMemo)(
              function () {
                return M()(e2, "".concat(eH, ".hairStyleStep"), "");
              },
              [e2, eH]
            )),
            (e8 = (0, u.useMemo)(
              function () {
                return M()(eL.crossPageState, "skipGuideline", !1);
              },
              [eL.crossPageState]
            )),
            (e9 = (0, u.useMemo)(
              function () {
                var e = eD.task,
                  t = e.type,
                  n = e.source,
                  r = j.Z.extractModelInfo(n).modelId;
                return t === R.$s.new && r;
              },
              [eD.task]
            )),
            (e7 = (0, u.useMemo)(
              function () {
                return !!M()(eD, "productConfig.".concat(eH, ".fromHistory"));
              },
              [eD, eH]
            )),
            (te = (0, u.useMemo)(
              function () {
                var e = M()(e2, eH);
                return !!M()(e, "oldVersion");
              },
              [e2, eH]
            )),
            (tt = (0, u.useMemo)(
              function () {
                return !!eU.base64;
              },
              [eU]
            )),
            (0, u.useEffect)(
              function () {
                e4 && tn();
              },
              [e4]
            ),
            (0, u.useEffect)(
              function () {
                e5 === P.Z.processImage &&
                  (ew(R.rh.processing),
                  ei && (to(), ek(eH, { hairStyleStep: null })));
              },
              [e5, ei, eH]
            ),
            (0, u.useEffect)(
              function () {
                V.taskRunning &&
                  D()(e6) &&
                  q(function (e) {
                    return ef(ef({}, e), {}, { taskResult: e6 });
                  });
              },
              [e6]
            ),
            (0, u.useEffect)(
              function () {
                V.taskRunning &&
                  D()(e3) &&
                  q(function (e) {
                    return ef(ef({}, e), {}, { taskResult: e3 });
                  });
              },
              [e3]
            ),
            (0, u.useEffect)(
              function () {
                V.updating || tP();
              },
              [V.taskResult, V.updating]
            ),
            (tn = function () {
              e9 || e7
                ? ek(eH, { hairStyleStep: P.Z.processImage })
                : e8 && tt
                ? (eM((0, T.Gh)(null)),
                  eC(R.$s.new, "yceData"),
                  ek(eH, { hairStyleStep: P.Z.processImage }))
                : eq()
                ? ek(eH, { hairStyleStep: P.Z.showGuideline })
                : tt &&
                  (eC(R.$s.new, "yceData"),
                  ek(eH, { hairStyleStep: P.Z.processImage }));
            }),
            (tr = function () {
              z(0), q(ep), er(!1);
            }),
            (to = function () {
              tr();
              var e = eD.task.type;
              e === R.$s.new ? tc() : e === R.$s.history && tE();
            }),
            (ta = (0, r.Z)(
              a().mark(function e() {
                var t, n, r, o, c, i, s, u, l, f, p, h;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (((t = eD.task.source), (n = en()(eU)), !e9)) {
                          e.next = 13;
                          break;
                        }
                        return (
                          (r = t.modelId),
                          (e.next = 6),
                          fetch(
                            "/assets/images/hairStyle/models/YCE_default_model_before-".concat(
                              r,
                              ".jpg"
                            )
                          ).then(function (e) {
                            return e.blob();
                          })
                        );
                      case 6:
                        return (
                          (o = e.sent),
                          (n.name = "YCE_default_model-".concat(r, ".jpg")),
                          (e.next = 10),
                          S.Z.blobToBase64(o)
                        );
                      case 10:
                        (n.base64 = e.sent),
                          (n.size = o.size),
                          (n.lastModified = o.lastModified);
                      case 13:
                        if (!(("yceData" === t || e9) && n.base64)) {
                          e.next = 49;
                          break;
                        }
                        return (
                          eM((0, R.bO)({ source: t })),
                          (c = n.base64),
                          (i = n.name),
                          (s = n.lastModified),
                          ((u = S.Z.base64ToBlob(c)).name = i),
                          (u.lastModified = s),
                          (e.next = 21),
                          eR(u)
                        );
                      case 21:
                        if (e.sent) {
                          e.next = 25;
                          break;
                        }
                        return eg(R.wt.imageProcessingFail), e.abrupt("return");
                      case 25:
                        return (e.next = 27), S.Z.downscaleForAvatar(u);
                      case 27:
                        return (
                          (l = e.sent),
                          (f = (0, d.Z)(l, 1)[0]),
                          (e.next = 32),
                          S.Z.generateThumbnail(f)
                        );
                      case 32:
                        if (((p = e.sent), eT(f))) {
                          e.next = 36;
                          break;
                        }
                        return eg(R.wt.imageProcessingFail), e.abrupt("return");
                      case 36:
                        return (e.next = 38), ts(f);
                      case 38:
                        if ((h = e.sent).goodFaceQuality) {
                          e.next = 43;
                          break;
                        }
                        return eS(), e.abrupt("return");
                      case 43:
                        return (
                          e7 && td(),
                          setTimeout(function () {
                            return tl(f, p, h);
                          }, 500),
                          (e.next = 47),
                          e0({})
                        );
                      case 47:
                        e.next = 50;
                        break;
                      case 49:
                        eg(R.wt.imageProcessingFail);
                      case 50:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tc = function () {
              return ta.apply(this, arguments);
            }),
            (ti = (0, r.Z)(
              a().mark(function e(t) {
                var n,
                  r,
                  o,
                  c,
                  i = arguments;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (n = !(i.length > 1) || void 0 === i[1] || i[1]),
                          (e.next = 3),
                          S.Z.newImage(t)
                        );
                      case 3:
                        return (
                          (r = e.sent), (e.next = 6), eu(r, { singleFace: !1 })
                        );
                      case 6:
                        return (
                          ((o = e.sent).rejectedFaceInfos = el()(
                            null == o ? void 0 : o.rejectedFaceInfos,
                            ["faceRect.left", "faceRect.top"]
                          )),
                          (c = M()(o, "forceEnter", !1)),
                          (null != o && o.goodFaceQuality) ||
                            !n ||
                            c ||
                            (ek(eH, { faceDetectError: o.message[0] }),
                            eM((0, Z.NU)()),
                            A(!0)),
                          e.abrupt(
                            "return",
                            ef(
                              ef({}, o),
                              {},
                              {
                                goodFaceQuality:
                                  c || !!(null != o && o.goodFaceQuality),
                              }
                            )
                          )
                        );
                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (ts = function (e) {
              return ti.apply(this, arguments);
            }),
            (tu = (0, r.Z)(
              a().mark(function e(t, n, r) {
                var o, i, s, u, l, f, p, h, m, g, b, v;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((o = r.faceInfos),
                          (i = r.rejectedFaceInfos),
                          (s = r.faceMeshBlob),
                          (u = r.faceMeshBlobUrl),
                          (l = M()(J()(o, "scale"), "scale", 1)),
                          (p = (f = M()(o, "0.originalImage", {})).width),
                          (h = f.height),
                          !(l < 1))
                        ) {
                          e.next = 11;
                          break;
                        }
                        return (
                          (m = Math.max(p, h) * l),
                          (e.next = 7),
                          S.Z.downscaleForAvatar(t, m, m)
                        );
                      case 7:
                        (g = e.sent),
                          (t = (0, d.Z)(g, 1)[0]),
                          eo()(o, function (e) {
                            var t = e.originalImage,
                              n = e.scale,
                              r = t.width,
                              o = t.height;
                            (t.width = r * n), (t.height = o * n);
                          });
                      case 11:
                        eB(t),
                          eM((0, Z.NU)()),
                          (b = window.URL.createObjectURL(t)),
                          (v = window.URL.createObjectURL(n)),
                          c(function (e) {
                            return ef(
                              ef({}, e),
                              {},
                              {
                                generatedResults: [
                                  {
                                    url: b,
                                    thumbUrl: v,
                                    faceInfos: o,
                                    rejectedFaceInfos: i,
                                    blob: t,
                                    selectedFaceIndex: 0,
                                    faceMeshBlob: s,
                                    faceMeshBlobUrl: u,
                                  },
                                ],
                                imagePreviewIndex: 0,
                              }
                            );
                          }),
                          eI(b);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tl = function (e, t, n) {
              return tu.apply(this, arguments);
            }),
            (td = function () {
              ek(eH, null);
            }),
            (tf = (0, r.Z)(
              a().mark(function e() {
                var n;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!et) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return", !1);
                      case 2:
                        if ("guest" !== eA.accType) {
                          e.next = 5;
                          break;
                        }
                        return eJ(), e.abrupt("return", !1);
                      case 5:
                        return (
                          er(!0),
                          (n = t.selectedStyles),
                          (e.next = 9),
                          eK(eV * D()(n))
                        );
                      case 9:
                        if (e.sent) {
                          e.next = 13;
                          break;
                        }
                        return er(!1), e.abrupt("return", !1);
                      case 13:
                        return e.abrupt("return", !0);
                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tp = (0, r.Z)(
              a().mark(function e() {
                var t, n, r, i, s, u, l, d, f, p, h, m, g;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.next = 2),
                          (function () {
                            return tf.apply(this, arguments);
                          })()
                        );
                      case 2:
                        if (e.sent) {
                          e.next = 5;
                          break;
                        }
                        return e.abrupt("return");
                      case 5:
                        if (
                          ((t = o.generatedResults),
                          (n = M()(t, "".concat(0, ".faceInfos"), [])),
                          (r = 1 >= D()(n)),
                          !e7)
                        ) {
                          e.next = 13;
                          break;
                        }
                        return (
                          c(function (e) {
                            return ef(ef({}, e), {}, { imagePreviewIndex: -1 });
                          }),
                          ek(eH, { fromHistory: !1 }),
                          (e.next = 13),
                          k.Z.sleep(100)
                        );
                      case 13:
                        return (
                          tx(e7, r),
                          q(function (e) {
                            return ef(ef({}, e), {}, { taskRunning: !0 });
                          }),
                          (e.next = 17),
                          k.Z.sleep(500)
                        );
                      case 17:
                        return (e.next = 19), tb(r);
                      case 19:
                        return (
                          (u =
                            void 0 === (s = (i = e.sent).originalFileId)
                              ? null
                              : s),
                          (d = void 0 === (l = i.cropFileId) ? null : l),
                          (p = void 0 === (f = i.originalFilePath) ? null : f),
                          (m = void 0 === (h = i.cropFilePath) ? null : h),
                          ew(R.rh.processing),
                          (g = ty({
                            originalFileId: u,
                            cropFileId: d,
                            originalFilePath: p,
                            cropFilePath: m,
                          })),
                          q(function (e) {
                            return ef(ef({}, e), {}, { params: g });
                          }),
                          (e.next = 33),
                          eF(g)
                        );
                      case 33:
                        return (
                          eN(e.sent)
                            ? (z(function (e) {
                                return e + 1;
                              }),
                              eM(
                                (0, F.QW)({
                                  retryCount: 0,
                                  reqId: eG.reqId + 1,
                                })
                              ),
                              tm())
                            : tF(),
                          er(!1),
                          (e.next = 39),
                          eM((0, O.LP)())
                        );
                      case 39:
                        e$(), e7 && td();
                      case 41:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (th = function () {
              return tp.apply(this, arguments);
            }),
            (tm = function () {
              var e = eD.imageSize.before;
              eQ({ before: e, after: e });
            }),
            (tg = (0, r.Z)(
              a().mark(function e(t) {
                var n, r, c, i, s, u, l, f, p, h, m, g, b, v, x, y, _;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((n = o.generatedResults),
                          (r = o.imagePreviewIndex),
                          (c = M()(n, r, {}).selectedFaceIndex),
                          (i = t
                            ? M()(n, "".concat(0, ".originalFilePath"), null)
                            : M()(n, "".concat(r, ".originalFilePath"), null)),
                          (s = t
                            ? M()(n, "".concat(0, ".cropFilePath.", c), null)
                            : M()(
                                n,
                                "".concat(r, ".cropFilePath.").concat(c),
                                null
                              )),
                          (u = t
                            ? M()(n, "".concat(0, ".originalFileId"), null)
                            : M()(n, "".concat(r, ".originalFileId"), null)),
                          (l = t
                            ? M()(n, "".concat(0, ".cropFileIds.", c), null)
                            : M()(
                                n,
                                "".concat(r, ".cropFileIds.").concat(c),
                                null
                              )),
                          !(u && l && i && s))
                        ) {
                          e.next = 10;
                          break;
                        }
                        return e.abrupt("return", {
                          originalFilePath: i,
                          cropFilePath: s,
                          originalFileId: u,
                          cropFileId: l,
                        });
                      case 10:
                        return ew(R.rh.uploading), (e.next = 13), tI(t);
                      case 13:
                        if (
                          ((f = e.sent),
                          (p = M()(f, "results", []).map(function (e) {
                            return { fileId: e.fileId, filePath: e.filePath };
                          })),
                          (m = (h = (0, d.Z)(p, 1)[0]).fileId),
                          (g = h.filePath),
                          f)
                        ) {
                          e.next = 18;
                          break;
                        }
                        return (
                          eg(R.wt.imageProcessingFail), e.abrupt("return", {})
                        );
                      case 18:
                        return (e.next = 20), tk(t);
                      case 20:
                        if (
                          ((b = e.sent),
                          (v = M()(b, "results", []).map(function (e) {
                            return { fileId: e.fileId, filePath: e.filePath };
                          })),
                          (y = (x = (0, d.Z)(v, 1)[0]).fileId),
                          (_ = x.filePath),
                          b)
                        ) {
                          e.next = 25;
                          break;
                        }
                        return (
                          eg(R.wt.imageProcessingFail), e.abrupt("return", {})
                        );
                      case 25:
                        return (
                          tv(m, y, r, c, g, _),
                          e.abrupt("return", {
                            originalFileId: m,
                            cropFileId: y,
                            originalFilePath: g,
                            cropFilePath: _,
                          })
                        );
                      case 27:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tb = function (e) {
              return tg.apply(this, arguments);
            }),
            (tv = function (e, t, n, r, o, a) {
              c(function (c) {
                var i = c.generatedResults;
                return e7
                  ? ef(
                      ef({}, c),
                      {},
                      {
                        generatedResults: [
                          ef(
                            ef({}, M()(i, 0, {})),
                            {},
                            {
                              originalFileId: e,
                              originalFilePath: o,
                              cropFileIds: ef(
                                ef({}, M()(i, "0.cropFileIds", {})),
                                {},
                                (0, f.Z)({}, r, t)
                              ),
                              cropFilePath: ef(
                                ef({}, M()(i, "0.cropFilePath", {})),
                                {},
                                (0, f.Z)({}, r, a)
                              ),
                            }
                          ),
                        ].concat((0, l.Z)(K()(i, 1))),
                      }
                    )
                  : ef(
                      ef({}, c),
                      {},
                      {
                        generatedResults: [].concat(
                          (0, l.Z)(K()(i, 0, n)),
                          [
                            ef(
                              ef({}, M()(i, n, {})),
                              {},
                              {
                                originalFileId: e,
                                originalFilePath: o,
                                cropFileIds: ef(
                                  ef(
                                    {},
                                    M()(i, "".concat(n, ".cropFileIds"), {})
                                  ),
                                  {},
                                  (0, f.Z)({}, r, t)
                                ),
                                cropFilePath: ef(
                                  ef(
                                    {},
                                    M()(i, "".concat(n, ".cropFilePath"), {})
                                  ),
                                  {},
                                  (0, f.Z)({}, r, a)
                                ),
                              }
                            ),
                          ],
                          (0, l.Z)(K()(i, n + 1))
                        ),
                      }
                    );
              });
            }),
            (tx = function (e, n) {
              var r = t.selectedStyles,
                a = o.generatedResults,
                i = o.imagePreviewIndex;
              if (e) {
                var s = Y()(D()(r) + 1).map(function (e, t) {
                  return 0 === t
                    ? {
                        backgroundBlob: n
                          ? M()(a, "".concat(0, ".backgroundBlob"))
                          : M()(a, "".concat(i, ".backgroundBlob")),
                        blob: n
                          ? M()(a, "".concat(0, ".blob"))
                          : M()(a, "".concat(i, ".blob")),
                        faceInfos: M()(a, "".concat(i, ".faceInfos")),
                        rejectedFaceInfos: M()(
                          a,
                          "".concat(i, ".rejectedFaceInfos"),
                          []
                        ),
                        selectedFaceIndex: M()(
                          a,
                          "".concat(i, ".selectedFaceIndex"),
                          0
                        ),
                        thumbUrl: n
                          ? M()(a, "".concat(0, ".url"))
                          : M()(a, "".concat(i, ".url")),
                        url:
                          n || 0 === i
                            ? M()(a, "".concat(0, ".url"))
                            : M()(a, "".concat(i, ".synthesizedUrl")),
                      }
                    : {};
                });
                return (
                  c(function (e) {
                    return ef(
                      ef({}, e),
                      {},
                      { generatedResults: s, imagePreviewIndex: 0 }
                    );
                  }),
                  s
                );
              }
              var u,
                d = Y()(D()(r)).map(function () {
                  return {
                    backgroundUrl: n
                      ? M()(a, "0.url")
                      : M()(
                          a,
                          "".concat(i, ".synthesizedUrl"),
                          M()(a, "".concat(i, ".url"))
                        ),
                  };
                });
              return (
                c(function (e) {
                  return (
                    (u = [].concat((0, l.Z)(e.generatedResults), (0, l.Z)(d))),
                    ef(
                      ef({}, e),
                      {},
                      {
                        generatedResults: u,
                        imagePreviewIndex: D()(e.generatedResults),
                      }
                    )
                  );
                }),
                u
              );
            }),
            (ty = function (e) {
              var n,
                r,
                a = e.originalFileId,
                c = e.cropFileId,
                i = e.originalFilePath,
                s = e.cropFilePath,
                u = o.generatedResults,
                l = o.imagePreviewIndex,
                d = M()(u, l, {}).selectedFaceIndex,
                p =
                  ((n = M()(u, "".concat(0, ".faceInfos"), [])),
                  G()(n, function (e) {
                    return H()(e, [
                      "cropRect",
                      "faceRect",
                      "originalImage",
                      "scale",
                      "relativeRect",
                      "faceScore",
                      "boxScore",
                      "gender",
                    ]);
                  })),
                h = M()(u, "".concat(0, ".rejectedFaceInfos"), []),
                m = t.selectedStyles,
                g = M()(m, "0.pocGroupId"),
                b = G()(m, function (e) {
                  return e.pocId;
                }),
                v = M()(m, "0.subType", "hairStyle"),
                x = 100 + L,
                y = {
                  paramGroupId: g,
                  paramIds: b,
                  originalFileId: a,
                  cropFileId: c,
                  faceInfos: p,
                  rejectedFaceInfos: h,
                  imagePreviewIndex: l,
                  selectedFaceIndex: void 0 === d ? 0 : d,
                  originalFilePath: i,
                  cropFilePath: s,
                },
                _ =
                  !N.some(function (e) {
                    return "srcIds" === e.name;
                  }) || 0 === N.length,
                w = tR(x, i, s, _),
                I = {
                  dstCount: D()(m),
                  baseActId: x,
                  paramGroupId: g,
                  paramIds: b.map(function (e) {
                    return window.BigInt(e);
                  }),
                  srcId: c,
                  effect: v,
                  clientCfg:
                    ((r = {}),
                    (0, f.Z)(r, x, y),
                    (0, f.Z)(r, "cusPaths", w),
                    r),
                };
              return (
                _ && (I.clientCfg.srcIds = y),
                e7 && (I.clientCfg.srcIds = { clientCfg: y }),
                I
              );
            }),
            (tw = (0, r.Z)(
              a().mark(function e(t) {
                var n, r, c, i;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (n = o.generatedResults),
                          (r = o.imagePreviewIndex),
                          (c = t
                            ? M()(n, "".concat(0, ".blob"))
                            : M()(n, "".concat(r, ".blob"))).name ||
                            (c.name = "".concat((0, p.Z)(), ".jpg")),
                          (e.next = 5),
                          eZ(c, {
                            ignore: { thumb: !0, downscale: !0, size: !0 },
                            return: { response: !0 },
                            updateFileId: !1,
                          })
                        );
                      case 5:
                        return (i = e.sent.response), e.abrupt("return", i);
                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tI = function (e) {
              return tw.apply(this, arguments);
            }),
            (tj = (0, r.Z)(
              a().mark(function e(t) {
                var n, r, c, i, s, u;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (n = o.generatedResults),
                          (r = o.imagePreviewIndex),
                          (i =
                            void 0 === (c = M()(n, r, {}).selectedFaceIndex)
                              ? 0
                              : c),
                          ((s = t
                            ? M()(
                                n,
                                "".concat(0, ".faceInfos.", i, ".cropBlob")
                              )
                            : M()(
                                n,
                                ""
                                  .concat(r, ".faceInfos.")
                                  .concat(i, ".cropBlob")
                              )).name = "crop.jpg"),
                          (e.next = 6),
                          eZ(s, {
                            ignore: { thumb: !0, downscale: !0, size: !0 },
                            return: { response: !0 },
                            updateFileId: !1,
                          })
                        );
                      case 6:
                        return (u = e.sent.response), e.abrupt("return", u);
                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tk = function (e) {
              return tj.apply(this, arguments);
            }),
            (tC = (0, r.Z)(
              a().mark(function e() {
                var t, c, i, s, u, l, d, f, h, m, g, b;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (D()(V.taskResult)) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        if (
                          (q(function (e) {
                            return ef(ef({}, e), {}, { updating: !0 });
                          }),
                          (t = V.taskResult),
                          (i = (c = V.params).dstCount),
                          (s = c.clientCfg),
                          (u = c.baseActId),
                          (l = M()(s, u, {})),
                          (d = o.generatedResults),
                          (f = M()(t, "results.0.data", [])),
                          0 ===
                            (h = D()(
                              U()(d, function (e) {
                                return !e.url;
                              })
                            )) && q(ep),
                          (m = i - h),
                          (g = K()(f, m)),
                          !Q()(g))
                        ) {
                          e.next = 15;
                          break;
                        }
                        return (
                          q(function (e) {
                            return ef(ef({}, e), {}, { updating: !1 });
                          }),
                          e.abrupt("return")
                        );
                      case 15:
                        return (
                          (b = G()(
                            g,
                            (function () {
                              var e = (0, r.Z)(
                                a().mark(function e(t, r) {
                                  var o,
                                    c,
                                    f,
                                    m,
                                    g,
                                    b,
                                    v,
                                    x,
                                    y,
                                    _,
                                    w,
                                    I,
                                    S,
                                    j,
                                    k,
                                    C,
                                    P,
                                    R;
                                  return a().wrap(function (e) {
                                    for (;;)
                                      switch ((e.prev = e.next)) {
                                        case 0:
                                          return (
                                            (o = H()(t, [
                                              "dstId",
                                              "url",
                                              "thumbUrl",
                                              "style_id",
                                            ])),
                                            (c = (0, p.Z)()),
                                            (f = l.imagePreviewIndex),
                                            (m = l.selectedFaceIndex),
                                            (g = l.faceInfos),
                                            (b = l.rejectedFaceInfos),
                                            (v = l.originalFileId),
                                            (x = l.originalFilePath),
                                            (y = M()(g, m, {})),
                                            (_ = M()(
                                              d,
                                              "".concat(0, ".faceInfos"),
                                              []
                                            )),
                                            (w = 1 >= D()(_)),
                                            (I = M()(
                                              d,
                                              w
                                                ? "0.blob"
                                                : "".concat(f, ".blob"),
                                              M()(d, "0.blob")
                                            )),
                                            (e.next = 9),
                                            fetch(o.url, {
                                              cache: "no-cache",
                                            }).then(function (e) {
                                              return e.blob();
                                            })
                                          );
                                        case 9:
                                          return (
                                            (S = e.sent),
                                            (j = M()(
                                              g,
                                              "".concat(m, ".cropRect")
                                            )),
                                            (e.next = 13),
                                            tA(I, S, j)
                                          );
                                        case 13:
                                          (k = e.sent),
                                            (C = G()(g, function (e) {
                                              return ef(
                                                ef({}, e),
                                                {},
                                                {
                                                  cropBlob: k,
                                                  cropBlobUrl:
                                                    window.URL.createObjectURL(
                                                      k
                                                    ),
                                                }
                                              );
                                            })),
                                            (P = M()(d, "0.faceMeshBlob")),
                                            (R = M()(d, "0.faceMeshBlobUrl")),
                                            ee()(o, {
                                              synthesizedUrl:
                                                window.URL.createObjectURL(k),
                                              blob: k,
                                              cropBlob: S,
                                              customDownloadFileName: c,
                                              clientCfg: s,
                                              actId: u,
                                              faceInfos: C,
                                              rejectedFaceInfos: b,
                                              selectedFaceIndex: m,
                                              backgroundFileId: v,
                                              backgroundFilePath: x,
                                              backgroundUrl: M()(
                                                d,
                                                w
                                                  ? "0.url"
                                                  : "".concat(
                                                      f,
                                                      ".synthesizedUrl"
                                                    ),
                                                M()(d, "0.url")
                                              ),
                                              backgroundCropInfo: ef(
                                                ef({}, y),
                                                {},
                                                {
                                                  originalFileId: v,
                                                  originalFilePath: x,
                                                }
                                              ),
                                              backgroundBlob: I,
                                              faceMeshBlob: P,
                                              faceMeshBlobUrl: R,
                                            }),
                                            tZ(o),
                                            h === i &&
                                              0 === r &&
                                              (ej(),
                                              n(function (e) {
                                                return ef(
                                                  ef({}, e),
                                                  {},
                                                  { selectedStyles: [] }
                                                );
                                              }));
                                        case 20:
                                        case "end":
                                          return e.stop();
                                      }
                                  }, e);
                                })
                              );
                              return function (t, n) {
                                return e.apply(this, arguments);
                              };
                            })()
                          )),
                          (e.next = 18),
                          Promise.all(b)
                        );
                      case 18:
                        "success" !== M()(t, "status")
                          ? q(function (e) {
                              return ef(ef({}, e), {}, { updating: !1 });
                            })
                          : q(ep);
                      case 20:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tP = function () {
              return tC.apply(this, arguments);
            }),
            (tR = function (e, t, n, r) {
              var o = { name: e, dstKeys: [t, n].filter(Boolean) },
                a = { name: "srcIds", dstKeys: [t, n].filter(Boolean) },
                c = {
                  name: "srcIds_".concat(e),
                  dstKeys: [t, n].filter(Boolean),
                };
              return (
                E(function (e) {
                  var t = [].concat((0, l.Z)(e), [o, c]);
                  return r ? [].concat((0, l.Z)(t), [a]) : t;
                }),
                r
                  ? [].concat((0, l.Z)(N), [o, a, c])
                  : [].concat((0, l.Z)(N), [o, c])
              );
            }),
            (tZ = function (e) {
              c(function (t) {
                return ef(
                  ef({}, t),
                  {},
                  {
                    generatedResults: [].concat(
                      (0, l.Z)(
                        U()(t.generatedResults, function (e) {
                          return !!e.url;
                        })
                      ),
                      [ef({}, e)],
                      (0, l.Z)(
                        K()(
                          U()(t.generatedResults, function (e) {
                            return !e.url;
                          }),
                          1
                        )
                      )
                    ),
                  }
                );
              });
            }),
            (tF = function () {
              c(function (e) {
                return ef(
                  ef({}, e),
                  {},
                  {
                    generatedResults: (0, l.Z)(
                      U()(e.generatedResults, function (e) {
                        return !!e.url;
                      })
                    ),
                  }
                );
              }),
                q(ep);
            }),
            (tO = (0, r.Z)(
              a().mark(function e(t) {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return e.abrupt(
                          "return",
                          fetch(t, { cache: "no-cache" }).then(function (e) {
                            return e.blob();
                          })
                        );
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tT = function (e) {
              return tO.apply(this, arguments);
            }),
            (tB = (0, r.Z)(
              a().mark(function e(t, n, r) {
                var o, c, i, s, u, l, d, f;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((o = []),
                          (c = []),
                          (i = null),
                          (s = null),
                          (u = null),
                          !t)
                        ) {
                          e.next = 18;
                          break;
                        }
                        return (
                          (u = M()(r, "0.file")),
                          (s = M()(u, "0.url")),
                          (e.next = 10),
                          tT(s)
                        );
                      case 10:
                        return (i = e.sent), (e.next = 13), ts(i, !1);
                      case 13:
                        (c = (l = e.sent).faceInfos),
                          (o = l.rejectedFaceInfos),
                          (e.next = 30);
                        break;
                      case 18:
                        return (
                          (o =
                            M()(n, "srcIds.rejectedFaceInfos") ||
                            M()(n, "100.rejectedFaceInfos") ||
                            []),
                          (u = M()(r, "dstUrls") || M()(r, "file")),
                          (s = M()(u, "0") || M()(u, "0.url")),
                          (e.next = 23),
                          tT(s)
                        );
                      case 23:
                        return (i = e.sent), (e.next = 26), S.Z.newImage(i);
                      case 26:
                        (d = e.sent),
                          (f = (c =
                            M()(n, "srcIds.faceInfos") ||
                            M()(n, "100.faceInfos") ||
                            []).map(function (e) {
                            return B.Z.drawScaleCropImage(d, {
                              cropLeft: e.cropRect.cropLeft,
                              cropRight: e.cropRect.cropRight,
                              cropTop: e.cropRect.cropTop,
                              cropBottom: e.cropRect.cropBottom,
                            });
                          })),
                          (c = c.map(function (e, t) {
                            return ef(
                              ef({}, e),
                              {},
                              {
                                cropBlob: f[t],
                                cropBlobUrl: window.URL.createObjectURL(f[t]),
                              }
                            );
                          }));
                      case 30:
                        return e.abrupt("return", {
                          rejectedFaceInfos: o,
                          faceInfos: c,
                          blob: i,
                          url: s,
                          originalFile: u,
                        });
                      case 31:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tN = function (e, t, n, r, o, a) {
              return e
                ? M()(t, "0")
                : 1 === D()(r) && 0 === D()(o)
                ? es()(n, function (e) {
                    return "srcIds" === e.name;
                  })
                : es()(n, function (e) {
                    return e.name === "srcIds_".concat(a);
                  });
            }),
            (tM = (0, r.Z)(
              a().mark(function e() {
                var t, n, o, i, s, u, f, h, m, g, b, v, x, y, _, w, I;
                return a().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.prev = 0),
                            (n = (t = M()(e2, eH)).clientCfg),
                            (o = t.historyImages),
                            (i = t.thumbUrl),
                            (s = t.originalImage),
                            (u = t.beforeImg),
                            (f = U()(o, function (e) {
                              return e.id < 1e6;
                            })),
                            (e.next = 6),
                            (function (e, t, n) {
                              return tB.apply(this, arguments);
                            })(te, n, s)
                          );
                        case 6:
                          return (
                            (m = (h = e.sent).rejectedFaceInfos),
                            (g = h.faceInfos),
                            (b = h.blob),
                            (v = h.url),
                            (x = h.originalFile),
                            (y = [
                              {
                                url: v,
                                thumbUrl: v,
                                faceInfos: g,
                                rejectedFaceInfos: m,
                                selectedFaceIndex: 0,
                                blob: b,
                                backgroundBlob: b,
                                originalFileId: M()(n, "srcIds.originalFileId"),
                                originalFilePath: M()(
                                  n,
                                  "srcIds.originalFilePath"
                                ),
                              },
                            ]),
                            eI(v),
                            (_ = ec()(
                              G()(f, function (e) {
                                return G()(e.files, function (t, n) {
                                  return ef(
                                    ef({}, t),
                                    {},
                                    { id: e.id, order: n }
                                  );
                                });
                              })
                            )),
                            (w = G()(
                              _,
                              (function () {
                                var e = (0, r.Z)(
                                  a().mark(function e(r, o) {
                                    var c,
                                      s,
                                      l,
                                      f,
                                      h,
                                      b,
                                      y,
                                      _,
                                      w,
                                      I,
                                      S,
                                      j,
                                      k,
                                      C,
                                      P,
                                      R,
                                      Z;
                                    return a().wrap(function (e) {
                                      for (;;)
                                        switch ((e.prev = e.next)) {
                                          case 0:
                                            return (
                                              (s = tN(
                                                te,
                                                x,
                                                u,
                                                g,
                                                m,
                                                (c = M()(r, "id"))
                                              )),
                                              (l = te
                                                ? M()(x, "0.id")
                                                : M()(
                                                    n,
                                                    "".concat(
                                                      c,
                                                      ".originalFileId"
                                                    )
                                                  ) || M()(s, "file.0.id")),
                                              (f = M()(s, "dstKeys.0")),
                                              (h = M()(
                                                n,
                                                "".concat(c),
                                                0
                                              ).selectedFaceIndex),
                                              (b = te
                                                ? M()(t, "cropInfo.cropRect")
                                                : M()(
                                                    n,
                                                    ""
                                                      .concat(c, ".faceInfos.")
                                                      .concat(h, ".cropRect")
                                                  )),
                                              (y = te
                                                ? v
                                                : M()(s, "dstUrls.0") ||
                                                  M()(s, "file.0.url") ||
                                                  v),
                                              (e.next = 9),
                                              Promise.all([
                                                tT(y),
                                                tT(M()(r, "url")),
                                              ])
                                            );
                                          case 9:
                                            return (
                                              (_ = e.sent),
                                              (I = (w = (0, d.Z)(_, 2))[0]),
                                              (S = w[1]),
                                              (j = M()(r, "dstId")),
                                              (k = M()(r, "url")),
                                              (e.next = 17),
                                              tA(I, S, b)
                                            );
                                          case 17:
                                            return (
                                              (C = e.sent),
                                              (P =
                                                window.URL.createObjectURL(C)),
                                              (R = G()(g, function (e) {
                                                return ef(
                                                  ef({}, e),
                                                  {},
                                                  {
                                                    cropBlob: C,
                                                    cropBlobUrl: P,
                                                  }
                                                );
                                              })),
                                              (Z = M()(r, "order", 0)),
                                              e.abrupt("return", {
                                                dstId: j,
                                                actId: c,
                                                url: k,
                                                thumbUrl: M()(i, o),
                                                style_id: M()(
                                                  n,
                                                  ""
                                                    .concat(c, ".paramIds.")
                                                    .concat(Z)
                                                ),
                                                paramGroupId: M()(
                                                  n,
                                                  "".concat(c, ".paramGroupId")
                                                ),
                                                synthesizedUrl: P,
                                                blob: C,
                                                cropBlob: S,
                                                customDownloadFileName: (0,
                                                p.Z)(),
                                                clientCfg: te ? M()(n, c) : n,
                                                faceInfos: R,
                                                rejectedFaceInfos: m,
                                                selectedFaceIndex: h,
                                                backgroundFileId: l,
                                                backgroundFilePath: f,
                                                backgroundUrl: y,
                                                backgroundBlob: I,
                                                backgroundCropInfo: ef(
                                                  ef({}, b),
                                                  {},
                                                  {
                                                    originalFileId: l,
                                                    originalFilePath: f,
                                                  }
                                                ),
                                                faceMeshBlob: null,
                                                faceMeshBlobUrl: null,
                                              })
                                            );
                                          case 24:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e);
                                  })
                                );
                                return function (t, n) {
                                  return e.apply(this, arguments);
                                };
                              })()
                            )),
                            (e.next = 20),
                            Promise.all(w)
                          );
                        case 20:
                          (I = e.sent),
                            c(function (e) {
                              return ef(
                                ef({}, e),
                                {},
                                {
                                  imagePreviewIndex: 0,
                                  generatedResults: [].concat(y, (0, l.Z)(I)),
                                }
                              );
                            }),
                            ej(),
                            (e.next = 28);
                          break;
                        case 25:
                          (e.prev = 25),
                            (e.t0 = e.catch(0)),
                            eg(R.wt.imageProcessingFail);
                        case 28:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[0, 25]]
                );
              })
            )),
            (tE = function () {
              return tM.apply(this, arguments);
            }),
            (tD = (0, r.Z)(
              a().mark(function e(t, n, r) {
                var o, c, i, s, u, l, d, f, p, h, m;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (o = r.cropLeft),
                          (c = r.cropRight),
                          (i = r.cropTop),
                          (s = r.cropBottom),
                          (e.next = 3),
                          S.Z.newImage(t)
                        );
                      case 3:
                        return (u = e.sent), (e.next = 6), S.Z.newImage(n);
                      case 6:
                        return (
                          (l = e.sent),
                          (d = document.createElement("canvas")),
                          (f = u.width),
                          (p = u.height),
                          (d.width = f),
                          (d.height = p),
                          (h = d.getContext("2d")).drawImage(u, 0, 0),
                          h.drawImage(
                            l,
                            0,
                            0,
                            l.width,
                            l.height,
                            o,
                            i,
                            c - o,
                            s - i
                          ),
                          (e.next = 16),
                          S.Z.canvasToBlob(d)
                        );
                      case 16:
                        return (m = e.sent), e.abrupt("return", m);
                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tA = function (e, t, n) {
              return tD.apply(this, arguments);
            }),
            {
              handleApply: th,
              isHistoryMode: e7,
              taskRunning: V.taskRunning,
              tokenActionCost: eV,
              leftCredits: eX,
            }),
          nC = nk.handleApply,
          nP = nk.taskRunning,
          nR = nk.tokenActionCost,
          nZ = nk.leftCredits,
          nF = nk.isHistoryMode,
          nO = (0, h.Z)(),
          nT = nO.setProductConfig,
          nB = nO.setBeforeImageSize,
          nN = nO.setBeforeImageLoaded,
          nM =
            ((tW = (tU = (0, u.useState)(ev))[0]),
            (tG = tU[1]),
            (tL = (0, s.v9)(function (e) {
              return e.result;
            }).images),
            (0, u.useEffect)(
              function () {
                tL.before ? tQ() : t$();
              },
              [tL.before]
            ),
            (tH = function (e) {
              tG(function (t) {
                return eb(eb({}, t), {}, { showMask: e });
              });
            }),
            (tz = function (e) {
              tG(function (t) {
                return eb(eb({}, t), {}, { rectScale: e });
              });
            }),
            (tY = function (e) {
              tG(function (t) {
                return eb(eb({}, t), {}, { showHint: e });
              });
            }),
            (tX = function (e) {
              tG(function (t) {
                return eb(eb({}, t), {}, { hasShowed: e });
              });
            }),
            (tK = function (e) {
              nd(function (t) {
                var n = t.imagePreviewIndex;
                return eb(
                  eb({}, t),
                  {},
                  {
                    generatedResults: [].concat(
                      (0, l.Z)(K()(t.generatedResults, 0, n)),
                      [
                        eb(
                          eb({}, t.generatedResults[n]),
                          {},
                          { selectedFaceIndex: e }
                        ),
                      ],
                      (0, l.Z)(K()(t.generatedResults, n + 1))
                    ),
                  }
                );
              });
            }),
            (tV = (0, r.Z)(
              a().mark(function e() {
                var t;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), k.Z.sleep(1500);
                      case 2:
                        tJ(), tz(1), (t = 1);
                      case 5:
                        if (!(t <= 4)) {
                          e.next = 13;
                          break;
                        }
                        return (e.next = 8), k.Z.sleep(800);
                      case 8:
                        tH(t % 2);
                      case 10:
                        (t += 1), (e.next = 5);
                        break;
                      case 13:
                        return (e.next = 15), k.Z.sleep(800);
                      case 15:
                        tX(!0), tK(0);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tQ = function () {
              return tV.apply(this, arguments);
            }),
            (tq = (0, r.Z)(
              a().mark(function e() {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), k.Z.sleep(800);
                      case 2:
                        return tY(!0), (e.next = 5), k.Z.sleep(3e3);
                      case 5:
                        tY(!1);
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            (tJ = function () {
              return tq.apply(this, arguments);
            }),
            (t$ = function () {
              tG(ev);
            }),
            { faceMaskAnimation: tW, setSelectedFaceIndex: tK }),
          nE = nM.faceMaskAnimation,
          nD = nM.setSelectedFaceIndex,
          nA = ((t1 = (t0 = (0, u.useState)(-1))[0]),
          (t4 = t0[1]),
          (t6 = (0, eh.Z)().isDesktop),
          (0, u.useEffect)(function () {
            var e = document.getElementById("YCE-result-photo-container");
            if (e)
              return (
                e.addEventListener("scroll", t3),
                function () {
                  e.removeEventListener("scroll", t3);
                }
              );
          }, []),
          (0, u.useEffect)(
            function () {
              t3();
            },
            [t6]
          ),
          (t3 = function () {
            if (t6) {
              t4(-1);
              return;
            }
            var e = document.getElementById("YCE-result-photo-container"),
              t = document.getElementById(
                "YCE-result-photo-hairstyle-settings-container"
              );
            t4((e.scrollTop || 0) - (t.offsetTop || 0) - 29);
          }),
          { diff: t1 }).diff,
          nU = (0, eh.Z)().isDesktop,
          nW = (0, em.Z)().isGuest,
          nG = ((nr =
            void 0 === (nn = {}.targetId) ? "YCE-result-photo-container" : nn),
          (no = (0, eh.Z)().isDesktop),
          {
            scrollToTop: function () {
              if (!no) {
                var e,
                  t =
                    null === (e = document) || void 0 === e
                      ? void 0
                      : e.getElementById(nr);
                t && t.scrollTo({ top: 0, left: 0, behavior: "smooth" });
              }
            },
          }).scrollToTop,
          nL = (0, s.I0)(),
          nH = (0, s.v9)(function (e) {
            return e.result;
          }),
          nz = (0, s.v9)(function (e) {
            return e.info;
          }),
          nY = nH.images,
          nX = (0, t_.Z)().isDev,
          nK = M()(nz, "moduleType", C.ft.hairStyle),
          nV = (0, u.useMemo)(
            function () {
              return D()(ni.selectedStyles);
            },
            [ni.selectedStyles]
          ),
          nQ = (0, u.useMemo)(
            function () {
              return nR * nV;
            },
            [nR, nV]
          ),
          nq = (0, u.useMemo)(
            function () {
              return nQ > nZ;
            },
            [nQ, nZ]
          ),
          nJ = (0, u.useMemo)(
            function () {
              var e = nl.generatedResults,
                t = nl.imagePreviewIndex;
              return M()(e, "".concat(t, ".faceInfos"), []);
            },
            [nl]
          ),
          n$ = (0, u.useMemo)(
            function () {
              return nW
                ? !!nY.before && !t2()(nR) && !!nV && !nP && !Q()(nJ)
                : !!nY.before && !t2()(nR) && !nq && !nP && !Q()(nJ) && !!nV;
            },
            [nY.before, nR, nV, nP, nq, nW, nJ]
          ),
          n0 = (0, u.useMemo)(
            function () {
              return D()(nl.generatedResults) > 1;
            },
            [nl.generatedResults]
          );
        (0, u.useEffect)(function () {
          var e = ey.ZP[nK];
          nL((0, t9.YS)(e)),
            (0, ex.z)("functionImpression", { functionType: e });
        }, []),
          (0, u.useEffect)(
            function () {
              nY.before ? n2() : n1();
            },
            [nY.before]
          ),
          (0, u.useEffect)(
            function () {
              ng && nY.before && nb(!1);
            },
            [nY.before]
          ),
          (0, u.useEffect)(
            function () {
              -1 !== nl.imagePreviewIndex && n3();
            },
            [nl.generatedResults, nl.imagePreviewIndex]
          ),
          (0, u.useEffect)(
            function () {
              -1 !== nl.imagePreviewIndex && n8();
            },
            [nl.generatedResults, nl.imagePreviewIndex, nY.beforeLoaded]
          );
        var n1 = function () {
            nd(t7),
              ny([]),
              nw.current.removeAttribute("src"),
              nI.current.removeAttribute("src");
          },
          n2 =
            ((na = (0, r.Z)(
              a().mark(function e() {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.next = 2), n4(nw, nY.before);
                      case 2:
                        nB(nw.current.width, nw.current.height),
                          nN(),
                          nF && e_.Kg.trigger(e_.Y7.result.beforeImageLoaded),
                          nF || (nj(!0), nG());
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return na.apply(this, arguments);
            }),
          n4 = function (e, t) {
            return new Promise(function (n, r) {
              var o = e.current;
              (o.crossOrigin = "anonymous"),
                (o.onload = function () {
                  return n();
                }),
                (o.onerror = function () {
                  return r();
                }),
                (o.src = t);
            });
          },
          n6 = function () {
            nT(nK, { hairStyleStep: P.Z.showGuideline });
          },
          n3 = function () {
            var e = nl.generatedResults,
              t = nl.imagePreviewIndex,
              n = M()(e, "".concat(t), {}),
              r = n.dstId,
              o = n.url,
              a = n.synthesizedUrl,
              c = n.customDownloadFileName,
              i = n.backgroundFileId,
              s = n.backgroundUrl;
            n5(
              void 0 === i ? null : i,
              void 0 === s ? null : s,
              void 0 === r ? null : r,
              void 0 === a ? null : a,
              void 0 === o ? null : o,
              void 0 === c ? null : c
            );
            var u = M()(e, "".concat(t), {}).backgroundCropInfo;
            nT(nK, { cropInfo: void 0 === u ? null : u });
          },
          n5 = function (e, t, n, r, o, a) {
            nL(
              (0, t8.u5)({
                srcFileId: e,
                srcUrl: t,
                downloadFileId: n,
                downloadUrl: r,
                previewFileId: n,
                previewUrl: r,
                shareFileId: n,
                shareUrl: o,
                customDownloadFileName: a,
                needRenewShareId: !0,
              })
            );
          },
          n8 = function () {
            var e = nl.imagePreviewIndex,
              t = nl.generatedResults;
            M()(t, "".concat(e, ".url"), null),
              nT(nK, {
                resultImageZoomExtents: {
                  show: !0,
                  width: nw.current.width,
                  height: nw.current.height,
                  fit: 100,
                  max: 800,
                  min: 100,
                  now: 100,
                },
              });
          };
        return (0, eO.jsxs)(eO.Fragment, {
          children: [
            (0, eO.jsxs)("div", {
              ref: n_,
              className: i().result,
              onContextMenu: function (e) {
                return e.preventDefault();
              },
              children: [
                (0, eO.jsx)("div", {
                  className: i().resultsBlock,
                  children: ng
                    ? (0, eO.jsx)(eW, { handleUploadButtonClick: n6 })
                    : (0, eO.jsx)(eO.Fragment, {
                        children: (0, eO.jsx)(t5, {
                          sliderRef: nS,
                          resultsState: nl,
                          setResultsState: nd,
                          paramsState: np,
                          updateReduxWhenZoom: !0,
                          faceMaskAnimation: nE,
                          setSelectedFaceIndex: nD,
                          hideThumbnailsIfEmpty: !nU,
                          hideThumbnails: !nU,
                        }),
                      }),
                }),
                (0, eO.jsxs)("div", {
                  id: "YCE-result-photo-hairstyle-settings-container",
                  className: i().settingsBlock,
                  children: [
                    !nU &&
                      (0, eO.jsx)(t5, {
                        sliderRef: nS,
                        resultsState: nl,
                        setResultsState: nd,
                        paramsState: np,
                        updateReduxWhenZoom: !0,
                        faceMaskAnimation: nE,
                        setSelectedFaceIndex: nD,
                        hideThumbnailsIfEmpty: !nU,
                        onlyShowThumbnails: !0,
                        diff: nA,
                      }),
                    (0, eO.jsx)(tS, {
                      sliderRef: nS,
                      settingsState: ni,
                      setSettingsState: ns,
                      paramsState: np,
                      setParamsState: nh,
                      resultsState: nl,
                      handleUploadButtonClick: n6,
                      handleGenerate: function () {
                        n$ && (nG(), nC());
                      },
                      canGenerate: n$,
                      notEnough: nq,
                      actionCost: nQ,
                      selectedStylesCount: nV,
                      taskRunning: nP,
                      canShowThumbnails: n0,
                    }),
                  ],
                }),
              ],
            }),
            (0, eO.jsx)("img", { ref: nw, style: { display: "none" } }),
            (0, eO.jsx)("img", { ref: nI, style: { display: "none" } }),
            (0, eO.jsx)(eE, {}),
            (0, eO.jsx)(ez, {}),
            nX &&
              (0, eO.jsx)("button", {
                id: "hair-style-download-crop-image-button",
                onClick: function () {
                  var e = nl.generatedResults,
                    t = nl.imagePreviewIndex;
                  if (!Q()(e)) {
                    var n = M()(e, t, {}).selectedFaceIndex,
                      r = M()(e, "".concat(t, ".faceInfos"), []),
                      o = M()(e, "".concat(t, ".rejectedFaceInfos"), []),
                      a = M()(r, n, []),
                      c = M()(a, "cropBlobUrl", null),
                      i = [];
                    r.map(function (e, t) {
                      t !== n &&
                        i.push([
                          e.faceRect.left - a.cropRect.cropLeft,
                          e.faceRect.top - a.cropRect.cropTop,
                          e.faceRect.right - a.cropRect.cropLeft,
                          e.faceRect.bottom - a.cropRect.cropTop,
                        ]);
                    }),
                      o.map(function (e) {
                        i.push([
                          e.faceRect.left - a.cropRect.cropLeft,
                          e.faceRect.top - a.cropRect.cropTop,
                          e.faceRect.right - a.cropRect.cropLeft,
                          e.faceRect.bottom - a.cropRect.cropTop,
                        ]);
                      });
                    var s = a.relativeRect,
                      u = [[[s.left, s.top, s.right, s.bottom]].concat(i)],
                      l = document.createElement("canvas"),
                      d = l.getContext("2d"),
                      f = new Image();
                    (f.crossOrigin = "anonymous"),
                      (f.onload = function () {
                        (l.width = f.width),
                          (l.height = f.height),
                          d.drawImage(f, 0, 0),
                          (d.strokeStyle = "red"),
                          (d.lineWidth = 2);
                        var e = u[0][0];
                        d.strokeRect(e[0], e[1], e[2] - e[0], e[3] - e[1]),
                          (d.strokeStyle = "blue"),
                          u[0].slice(1).forEach(function (e) {
                            d.strokeRect(e[0], e[1], e[2] - e[0], e[3] - e[1]);
                          }),
                          l.toBlob(function (e) {
                            var t = URL.createObjectURL(e),
                              n = document.createElement("a");
                            (n.href = t),
                              (n.download = "cropImage.png"),
                              n.click(),
                              URL.revokeObjectURL(t);
                          });
                      }),
                      (f.src = c);
                  }
                },
                className: i().devButton,
              }),
          ],
        });
      }
    },
    36722: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return f;
        },
      });
      var r = n(50029),
        o = n(87794),
        a = n.n(o),
        c = n(67294),
        i = n(9473),
        s = n(54473),
        u = n(43263),
        l = n(72880),
        d = n(89984);
      function f(e) {
        var t = e.handleApply,
          n = (0, c.useState)(!1),
          o = n[0],
          f = n[1],
          p = (0, c.useState)(null),
          h = p[0],
          m = p[1],
          g = (0, s.Z)().checkTriedStatus,
          b = (0, i.I0)(),
          v = (0, i.v9)(function (e) {
            return e.user;
          }),
          x = (0, i.v9)(function (e) {
            return e.result;
          }),
          y = (0, i.v9)(function (e) {
            return e.info;
          }),
          _ = (0, i.v9)(function (e) {
            return e.ui;
          });
        return (
          (0, c.useEffect)(
            function () {
              var e;
              ((e = (0, r.Z)(
                a().mark(function e() {
                  var t;
                  return a().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!(!v.showSignInSuccess || o)) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt("return");
                        case 2:
                          if (
                            ((t = x.task4AiHairStyle.source),
                            !(
                              v.showSignInSuccess &&
                              ("yceData" === t ||
                                y.moduleType === d.ft.txt2Img ||
                                y.moduleType === d.ft.muTransfer)
                            ))
                          ) {
                            e.next = 8;
                            break;
                          }
                          return (e.next = 6), g({});
                        case 6:
                          m(e.sent);
                        case 8:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )),
              function () {
                return e.apply(this, arguments);
              })();
            },
            [v.showSignInSuccess]
          ),
          (0, c.useEffect)(
            function () {
              var e;
              ((e = (0, r.Z)(
                a().mark(function e() {
                  var n;
                  return a().wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!(!v.showSignInSuccess || !o)) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt("return");
                        case 2:
                          if (
                            !(
                              "yceData" === x.task4AiHairStyle.source ||
                              y.moduleType === d.ft.txt2Img ||
                              y.moduleType === d.ft.muTransfer
                            )
                          ) {
                            e.next = 15;
                            break;
                          }
                          return (e.next = 6), g({});
                        case 6:
                          if (
                            ((n = e.sent),
                            b((0, l.bO)({ source: null })),
                            m(n),
                            n.showMessage)
                          ) {
                            e.next = 13;
                            break;
                          }
                          return t(), f(!1), e.abrupt("return");
                        case 13:
                          e.next = 17;
                          break;
                        case 15:
                          t(), f(!1);
                        case 17:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              )),
              function () {
                return e.apply(this, arguments);
              })();
            },
            [v.showSignInSuccess]
          ),
          (0, c.useEffect)(
            function () {
              !_.messageDialog.show &&
                ("free.ai.hairstyle.generator" === _.messageDialog.type ||
                  "free.ai.art.generator" === _.messageDialog.type ||
                  "free.mu.transfer" === _.messageDialog.type ||
                  "free.mu.transfer.a" === _.messageDialog.type) &&
                o &&
                (t(), f(!1));
            },
            [_.messageDialog.show]
          ),
          (0, c.useEffect)(
            function () {
              !_.loginModalOpened && "guest" === y.accType && o && f(!1);
            },
            [_.loginModalOpened]
          ),
          {
            popupLoginModal: function () {
              f(!0), b((0, u.eh)(!0));
            },
            trialStatus: h,
          }
        );
      }
    },
    88147: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return c;
        },
      });
      var r = n(67294),
        o = n(28953),
        a = n(32295);
      function c() {
        var e = (0, r.useState)(!1),
          t = e[0],
          n = e[1];
        (0, r.useEffect)(function () {
          return (
            n(o.ZP.getParsedItem(o.XC.debug.preAlpha, !1)),
            a.ZP.on(a.Y7.debug.preAlpha, c),
            function () {
              a.ZP.off(a.Y7.debug.preAlpha, c);
            }
          );
        }, []);
        var c = function (e) {
          var t = e.detail,
            r = t.key,
            a = t.newValue;
          r === o.XC.debug.preAlpha && n(JSON.parse(a));
        };
        return { isPreAlpha: t };
      }
    },
    56716: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return c;
        },
      });
      var r = n(67294),
        o = n(23560),
        a = n.n(o);
      function c(e) {
        var t = e.targetRef,
          n = e.onResize,
          o = void 0 === n ? function () {} : n,
          c = (0, r.useRef)(null);
        (0, r.useEffect)(
          function () {
            u(), i();
          },
          [null == t ? void 0 : t.current]
        );
        var i = function e() {
            var n =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : 10;
            n <= 0 ||
              (null != t && t.current
                ? s()
                : setTimeout(function () {
                    return e(n - 1);
                  }, 50));
          },
          s = function () {
            var e = new ResizeObserver(l);
            (c.current = e), c.current.observe(t.current);
          },
          u = function () {
            null != c &&
              c.current &&
              null != t &&
              t.current &&
              (c.current.unobserve(t.current), (c.current = null));
          },
          l = function (e, t) {
            a()(o) && o();
          };
      }
    },
    29010: function (e, t) {
      "use strict";
      var n = {
        default: "en",
        "en-us": "en",
        "zh-tw": "cht",
        ja: "ja",
        de: "de",
        fr: "fr",
        es: "es",
        pt: "pt",
        it: "it",
      };
      t.Z = {
        convertACMSLanguageType: function (e) {
          return n[e] || n.default;
        },
      };
    },
    22559: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "empty-result_container__iU_6x",
        innerContainer: "empty-result_innerContainer__OiZcP",
        image: "empty-result_image__kTMlu",
        desc: "empty-result_desc__axbTR",
        button: "empty-result_button__vHGNv",
      };
    },
    56568: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        title: "message-dialog_title__1stY0",
        desc: "message-dialog_desc__MkO1w",
        button: "message-dialog_button__Kg_8r",
      };
    },
    29065: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "photo-guideline_container__FC516",
        containerOpened: "photo-guideline_containerOpened__zxdsl",
        modal: "photo-guideline_modal__37p0k",
        title: "photo-guideline_title__V70no",
        exampleContainer: "photo-guideline_exampleContainer__yEXnw",
        allContainer: "photo-guideline_allContainer__EH5Xt",
        allBorder: "photo-guideline_allBorder__WeTGL",
        goodBorder: "photo-guideline_goodBorder__r9yYj",
        badBorder: "photo-guideline_badBorder___RPuH",
        exampleTitle: "photo-guideline_exampleTitle__mVGyD",
        exampleDesc: "photo-guideline_exampleDesc__Quy6H",
        exampleImageBlock: "photo-guideline_exampleImageBlock__7EaPE",
        exampleImageWrapper: "photo-guideline_exampleImageWrapper__iokBu",
        exampleImage: "photo-guideline_exampleImage__9Xexo",
        qualityIcon: "photo-guideline_qualityIcon__35CQC",
        doNotShowAgainWrapper: "photo-guideline_doNotShowAgainWrapper__KCpVQ",
        checkbox: "photo-guideline_checkbox__B_NBy",
        doNotShowAgain: "photo-guideline_doNotShowAgain__JHBBh",
        button: "photo-guideline_button__FUEKJ",
        tosContainer: "photo-guideline_tosContainer__kseoq",
        close: "photo-guideline_close__OEcIi",
      };
    },
    68387: function (e) {
      e.exports = {
        container: "face-info-image_container__Bvi5b",
        open: "face-info-image_open__trjZ4",
        faceInfoContainer: "face-info-image_faceInfoContainer__Q89Rn",
        close: "face-info-image_close__3VwId",
      };
    },
    38733: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "face-score_container__4byp_",
        faceInfo: "face-score_faceInfo__EFZPk",
      };
    },
    98246: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "face-rect_container__InVHh",
        maskActive: "face-rect_maskActive__28Wy3",
        roundedCorner: "face-rect_roundedCorner__enePX",
        roundedCornerWithShadow: "face-rect_roundedCornerWithShadow__vh2IX",
        topLeft: "face-rect_topLeft__wN4W_",
        topRight: "face-rect_topRight__tmRIH",
        bottomLeft: "face-rect_bottomLeft__BdLdb",
        bottomRight: "face-rect_bottomRight__LrY4n",
      };
    },
    42235: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "image-carousel_container__3F5cA",
        previewBlock: "image-carousel_previewBlock__zRD4r",
        paddingTopForImagePreview:
          "image-carousel_paddingTopForImagePreview__j8T6Q",
        absoluteBlock: "image-carousel_absoluteBlock__Z9vXg",
        arrowButtonRight: "image-carousel_arrowButtonRight__r3fdT",
        arrowButtonLeft: "image-carousel_arrowButtonLeft__2vIcK",
        leftArrowIcon: "image-carousel_leftArrowIcon__67GGY",
        rightArrowIcon: "image-carousel_rightArrowIcon__2BFSH",
        imgContainer: "image-carousel_imgContainer__HaiXD",
        image: "image-carousel_image__Eqjpb",
        inputArea: "image-carousel_inputArea__QtExE",
        inputAreaText: "image-carousel_inputAreaText__81D9y",
        inputAreaIcon: "image-carousel_inputAreaIcon__xQ_Xo",
        compareBlock: "image-carousel_compareBlock__B0IGb",
        compare: "image-carousel_compare__m8AM5",
      };
    },
    72422: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "image-preview_container__xuXGQ",
        transformWrapper: "image-preview_transformWrapper__bzu4I",
        transformComponent: "image-preview_transformComponent__fP9yK",
        imageContainer: "image-preview_imageContainer___QkkW",
        imageWrapper: "image-preview_imageWrapper__gWBQ8",
        image1: "image-preview_image1__LtHGO",
        image2: "image-preview_image2__Zi3Go",
        hintBlock: "image-preview_hintBlock__hYUbR",
        hintBlockActive: "image-preview_hintBlockActive__fbIoZ",
        hint: "image-preview_hint__ADnlk",
        toggleFaceInfo: "image-preview_toggleFaceInfo__JZUX5",
      };
    },
    54591: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "results_container__3Y0Z_",
        originalImageBlock: "results_originalImageBlock__AfdNf",
        hideOriginalImageBlock: "results_hideOriginalImageBlock__gSkIm",
      };
    },
    70049: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        thumbBlock: "thumbnails_thumbBlock__sY3u_",
        thumbContainer: "thumbnails_thumbContainer__hWtgV",
        thumbOuterWrapper: "thumbnails_thumbOuterWrapper__wEFlA",
        thumbOuterWrapperActive: "thumbnails_thumbOuterWrapperActive__x5Z_h",
        paddingTop: "thumbnails_paddingTop__MilO_",
        thumbInnerWrapper: "thumbnails_thumbInnerWrapper__wTURb",
        thumbImage: "thumbnails_thumbImage__dG3AP",
        thumbText: "thumbnails_thumbText__hmPV5",
        thumbTextSkeleton: "thumbnails_thumbTextSkeleton___zWGy",
      };
    },
    44324: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "settings_container__l1K3_",
        settings: "settings_settings__ImNLb",
        buttonWrapper: "settings_buttonWrapper__3ZgCq",
        button: "settings_button__KKkfg",
        buttonDisabled: "settings_buttonDisabled__krE_I",
        buttonDesc: "settings_buttonDesc__eC9AJ",
        costDesc: "settings_costDesc__AEOHY",
        uploadButton: "settings_uploadButton__2A4wM",
        uploadIcon: "settings_uploadIcon__GcjEc",
        loadingIcon: "settings_loadingIcon__D21Dg",
      };
    },
    21135: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "styles_container__w_Woy",
        stylesContainter: "styles_stylesContainter__da1Bb",
        stylesTitle: "styles_stylesTitle__d5dBG",
        stylesBlock: "styles_stylesBlock__dpJOg",
        marginTop20: "styles_marginTop20__NhPH7",
        doneWrapper: "styles_doneWrapper__EKWEJ",
        doneIcon: "styles_doneIcon__6lZW6",
        noStyleBlock: "styles_noStyleBlock__GQEfb",
        row: "styles_row__auT96",
      };
    },
    3625: function (e) {
      e.exports = {
        outerWrapper: "skeleton_outerWrapper__RhLrL",
        styleDescWrapper: "skeleton_styleDescWrapper__R7E76",
        styleDesc: "skeleton_styleDesc__qgUGx",
      };
    },
    4538: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        styleContainer: "style_styleContainer__J1NCV",
        outerWrapper: "style_outerWrapper__1KwuS",
        outerWrapperActive: "style_outerWrapperActive__x21lS",
        paddingTop: "style_paddingTop__GVNRR",
        innerWrapper: "style_innerWrapper__yHDZo",
        checkbox: "style_checkbox__Ib2Jk",
        image: "style_image__Usyjl",
        styleDesc: "style_styleDesc__FaWQW",
        bestMatchIcon: "style_bestMatchIcon__rmfvC",
      };
    },
    55926: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        tabsPadding: "tab-with-indicator_tabsPadding__1AO_X",
        tabsPaddingThumbnails:
          "tab-with-indicator_tabsPaddingThumbnails__71ZKB",
        tabs: "tab-with-indicator_tabs__W2gVP",
        tab: "tab-with-indicator_tab__8lvLr",
        activeTab: "tab-with-indicator_activeTab___STYb",
        genderTabs: "tab-with-indicator_genderTabs__JM2W4",
        genderTab: "tab-with-indicator_genderTab__e5qtW",
        activeGenderTab: "tab-with-indicator_activeGenderTab__Mqo9w",
        indicator: "tab-with-indicator_indicator__KSzjV",
        indicatorBottom: "tab-with-indicator_indicatorBottom__OWYkl",
      };
    },
    38883: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        tab: "skeleton_tab___gg9X",
        indicatorBottom: "skeleton_indicatorBottom__8QXmG",
      };
    },
    97098: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        result: "hair-style_result__lcYwO",
        resultsBlock: "hair-style_resultsBlock__yHN0v",
        resultsTitle: "hair-style_resultsTitle__jxGNH",
        settingsBlock: "hair-style_settingsBlock__77Zk4",
      };
    },
  },
]);
