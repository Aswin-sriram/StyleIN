(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6092],
  {
    61020: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return _;
        },
      });
      var r = n(27812),
        o = n(65433),
        i = n.n(o),
        a = n(84338),
        u = n(11163),
        c = n(49114),
        s = n(15613),
        f = n(23560),
        l = n.n(f),
        d = n(85893);
      function _(e) {
        var t = (0, a.PC)().t,
          n = (0, u.useRouter)(),
          o = e.icon,
          f = e.title,
          _ = e.desc,
          E = e.button,
          p = e.customButtonStyles,
          C = e.noticeRedirect,
          A = e.handleButtonClick,
          h = e.id;
        return (0, d.jsx)("div", {
          className: i().container,
          children: (0, d.jsxs)("div", {
            className: i().contents,
            id: void 0 === h ? null : h,
            children: [
              o && (0, d.jsx)("img", { className: i().icon, src: o }),
              f && (0, d.jsx)("div", { className: i().title, children: t(f) }),
              _ && (0, d.jsx)("div", { className: i().desc, children: t(_) }),
              E &&
                (0, d.jsx)("div", {
                  className: i().button,
                  onClick: function () {
                    l()(A) ? A() : s.Z.push(n, "/");
                  },
                  style: p,
                  children: t(E),
                }),
              C &&
                (0, d.jsx)("div", {
                  className: i().noticeRedirect,
                  dangerouslySetInnerHTML: {
                    __html: c.Z.sanitize(t.apply(void 0, (0, r.Z)(C)), "span"),
                  },
                }),
            ],
          }),
        });
      }
    },
    1955: function (e, t, n) {
      "use strict";
      n(67294);
      var r = n(68356),
        o = n.n(r),
        i = n(85893),
        a = function () {
          return (0, i.jsx)("div", {});
        };
      t.Z = function (e) {
        return o()({ loader: e, loading: a });
      };
    },
    41379: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return g;
        },
      });
      var r = n(27812),
        o = n(59499),
        i = n(50029),
        a = n(87794),
        u = n.n(a),
        c = n(1864),
        s = n.n(c),
        f = n(27957),
        l = n.n(f),
        d = n(67294),
        _ = n(11163),
        E = n(9473),
        p = n(30978),
        C = n(20327),
        A = n(81386),
        h = n(48956),
        v = n(22467),
        R = n(43263),
        Z = n(54555),
        O = n(15613),
        T = n(89984),
        I = n(19161),
        m = n(23560),
        P = n.n(m);
      function Y(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t &&
            (r = r.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function g() {
        var e,
          t,
          n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          a = n.containerRef,
          c = n.moduleType,
          f = n.sodType,
          m = n.canDrop,
          g = (0, d.useState)(!1),
          N = g[0],
          y = g[1],
          S = (0, d.useState)(!1),
          G = S[0],
          b = S[1],
          w = (0, d.useState)(!1),
          M = w[0],
          D = w[1],
          x = (0, d.useRef)(null),
          k = (0, d.useRef)(null),
          L = (0, p.Z)({ moduleType: c }).needToShowGuideline,
          j = (0, C.Z)().initNewUplaodTask,
          H = (0, A.Z)().showUserConsent,
          B = (0, _.useRouter)(),
          F = (0, E.I0)(),
          U = (0, E.v9)(function (e) {
            return e.info;
          }),
          V = (0, E.v9)(function (e) {
            return e.net;
          }),
          X = (0, E.v9)(function (e) {
            return e.ui;
          }),
          z = U.userConsentConfirmed,
          K = V.online,
          q = X.showUserConsentModal,
          W = (0, d.useMemo)(
            function () {
              return (
                null != B &&
                !!B.pathname &&
                (!!T.ZP.isVideoType(c) ||
                  B.pathname.match(/\/video-enhancer-ai/))
              );
            },
            [null == B ? void 0 : B.pathname, c]
          );
        (0, d.useEffect)(
          function () {
            !q && N && en(z);
          },
          [q]
        ),
          (0, d.useEffect)(
            function () {
              if (G) {
                var e, t, n, r;
                null == a ||
                  null === (e = a.current) ||
                  void 0 === e ||
                  null === (t = e.parentNode) ||
                  void 0 === t ||
                  null === (n = t.classList) ||
                  void 0 === n ||
                  null === (r = n.add) ||
                  void 0 === r ||
                  r.call(n, l().fadeoutActive);
              }
            },
            [G]
          );
        var Q =
            ((e = (0, i.Z)(
              u().mark(function e(t) {
                var n,
                  r,
                  i,
                  a,
                  s,
                  l,
                  d = arguments;
                return u().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((n = d.length > 1 && void 0 !== d[1] ? d[1] : {}), t)
                        ) {
                          e.next = 3;
                          break;
                        }
                        return e.abrupt("return");
                      case 3:
                        if (!W) {
                          e.next = 11;
                          break;
                        }
                        return (
                          F((0, h.Bs)({ moduleType: c, sodType: f })),
                          (e.next = 7),
                          j(t)
                        );
                      case 7:
                        if (!J) {
                          e.next = 9;
                          break;
                        }
                        return e.abrupt("return");
                      case 9:
                        e.next = 17;
                        break;
                      case 11:
                        return (
                          (r = t.name),
                          (i = t.lastModified),
                          (a = t.size),
                          (s = t.type),
                          (e.next = 14),
                          Z.Z.blobToBase64(t)
                        );
                      case 14:
                        (l = (function (e) {
                          for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2
                              ? Y(Object(n), !0).forEach(function (t) {
                                  (0, o.Z)(e, t, n[t]);
                                })
                              : Object.getOwnPropertyDescriptors
                              ? Object.defineProperties(
                                  e,
                                  Object.getOwnPropertyDescriptors(n)
                                )
                              : Y(Object(n)).forEach(function (t) {
                                  Object.defineProperty(
                                    e,
                                    t,
                                    Object.getOwnPropertyDescriptor(n, t)
                                  );
                                });
                          }
                          return e;
                        })(
                          {
                            base64: e.sent,
                            name: r,
                            lastModified: i,
                            size: a,
                            type: s,
                          },
                          n
                        )),
                          F((0, v.a_)(l));
                      case 17:
                        ee();
                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (t) {
              return e.apply(this, arguments);
            }),
          J = (0, d.useMemo)(
            function () {
              return !!B.isReady && RegExp(/\/result-photo$/).test(B.pathname);
            },
            [B.isReady, B.pathname]
          ),
          $ = function () {
            var e = s().join(T.ZP.moduleTypeToURL(c, f), "/result-photo");
            O.Z.push(B, e);
          },
          ee =
            ((t = (0, i.Z)(
              u().mark(function e() {
                return u().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          F((0, h.Bs)({ moduleType: c, sodType: f })),
                          b(!0),
                          (e.next = 4),
                          I.Z.sleep(500)
                        );
                      case 4:
                        $();
                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function () {
              return t.apply(this, arguments);
            }),
          et = (0, d.useCallback)(
            function () {
              var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : function () {};
              if (!H) {
                e();
                return;
              }
              y(!0), F((0, R._k)(!0)), (x.current = e);
            },
            [H]
          ),
          en = (0, d.useCallback)(function (e) {
            e && P()(x.current) && x.current(), y(!1), (x.current = null);
          }, []),
          er = function (e) {
            (null == e ? void 0 : e.target) === k.current &&
              ((k.current = null), D(!1));
          },
          eo = function (e) {
            return e.preventDefault(), e.stopPropagation(), !1;
          };
        return {
          fadeOut: G,
          handleInputClick: function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : null;
            [].concat((0, r.Z)(T.qu), [T.ft.muTransfer]).includes(c) && L()
              ? ee()
              : [T.ft.faceSwap, T.ft.faceSwapVid].includes(c)
              ? (ee(), F((0, R.Gh)({ fromProductPage: !0 })))
              : et(function () {
                  var t;
                  null == e ||
                    null === (t = e.current) ||
                    void 0 === t ||
                    t.click();
                });
          },
          handleInputFileChange: function (e) {
            var t = e.target.files[0];
            (e.target.value = ""), Q(t);
          },
          processImageData: Q,
          goToResultPage: $,
          showUserConsentIfNecessary: et,
          setModuleTypeAndGoToResultPage: ee,
          isVideoPage: W,
          dropMethods:
            void 0 === m || m
              ? {
                  handleDragEnter: function (e) {
                    K && ((k.current = e.target), D(!0));
                  },
                  handleDragLeave: er,
                  handleDrop: function (e) {
                    eo(e);
                    var t = e.dataTransfer.files[0];
                    er(e),
                      t &&
                        et(function () {
                          Q(t);
                        });
                  },
                  cancelDefault: eo,
                  dragging: M,
                }
              : {},
        };
      }
    },
    30978: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return s;
        },
      });
      var r = n(9473),
        o = n(67294),
        i = n(28953),
        a = n(89984),
        u = n(27361),
        c = n.n(u);
      function s(e) {
        var t = e.moduleType,
          n = (0, r.v9)(function (e) {
            return e.user;
          }),
          u = (0, o.useMemo)(
            function () {
              return a.qu.includes(t)
                ? i.XC.doNotShowHairStylePhotoGuideline
                : t === a.ft.muTransfer
                ? i.XC.doNotShowMakeupTransferPhotoGuideline
                : t === a.ft.faceSwap
                ? i.XC.doNotShowFaceSwapPhotoGuideline
                : t === a.ft.faceSwapVid
                ? i.XC.doNotShowFaceSwapVidPhotoGuideline
                : t === a.ft.faceShapeDetector
                ? i.XC.doNotShowFaceShapeDetectorPhotoGuideline
                : void 0;
            },
            [t]
          );
        return {
          needToShowGuideline: (0, o.useCallback)(
            function () {
              if (!n.checked) return !1;
              var e = c()(n, "userInfo.userId", -1),
                t = i.ZP.getParsedItem(u, {});
              return !c()(t, e, !1);
            },
            [n, u]
          ),
        };
      }
    },
    14448: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return l;
        },
      });
      var r = n(67294),
        o = n(11163),
        i = n(27361),
        a = n.n(i),
        u = n(9473),
        c = n(13311),
        s = n.n(c),
        f = n(45270);
      function l(e) {
        var t = e.content,
          n = e.moduleType,
          i = (0, r.useState)(!1),
          c = i[0],
          l = i[1],
          d = (0, o.useRouter)(),
          _ = (0, u.I0)(),
          E = (0, u.v9)(function (e) {
            return e.cms;
          }).appButtons;
        (0, r.useEffect)(
          function () {
            d.isReady && d.query && t && p();
          },
          [d.isReady, d.query, t]
        );
        var p = function () {
          if (
            (l(!1),
            s()(E, function (e) {
              return e.moduleType === n;
            }))
          )
            return l(!0), null;
          if (!t) return l(!0), _((0, f.e3)(n, null)), null;
          var e = s()(a()(t, "attributes.sections"), function (e) {
            return "apps-page.section-bottom" === e.__component;
          });
          if (e) {
            var r = a()(e, "imageCTA");
            _(
              (0, f.e3)(n, {
                iosButton: a()(r, "[0]", null),
                androidButton: a()(r, "[1]", null),
              })
            );
          } else _((0, f.e3)(n, null));
          l(!0);
        };
        return { isLoaded: c };
      }
    },
    81386: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return u;
        },
      });
      var r = n(67294),
        o = n(9473),
        i = n(27361),
        a = n.n(i);
      function u() {
        var e = (0, o.v9)(function (e) {
            return e.info;
          }),
          t = (0, o.v9)(function (e) {
            return e.user;
          }),
          n = e.userConsentConfirmed,
          i = t.userInfo;
        return {
          showUserConsent: (0, r.useMemo)(
            function () {
              return !(n || a()(i, "info.consent.confirmed", !1));
            },
            [n, i]
          ),
        };
      }
    },
    45270: function (e, t, n) {
      "use strict";
      n.d(t, {
        Bm: function () {
          return o;
        },
        e3: function () {
          return a;
        },
        hE: function () {
          return i;
        },
      });
      var r = n(98679),
        o = function () {
          return { type: r.a.CMS.INIT };
        },
        i = function (e) {
          return { type: r.a.CMS.UPDATE_ITEMS, payload: e };
        },
        a = function (e, t) {
          return {
            type: r.a.CMS.UPDATE_APP_BUTTONS_BY_MODULE_TYPE,
            payload: { moduleType: e, appButtons: t },
          };
        };
    },
    78569: function (e, t, n) {
      "use strict";
      n.d(t, {
        I: function () {
          return a;
        },
      });
      var r,
        o = n(59499),
        i = n(89984),
        a =
          ((r = {}),
          (0, o.Z)(r, i.ft.enhance, "YCE_ENHANCER"),
          (0, o.Z)(r, i.ft.objRemoval, "YCE_REMOVAL"),
          (0, o.Z)(r, i.ft.removeBackground, "YCE_REMOVE_BACKGROUND"),
          (0, o.Z)(r, i.ft.changeBackground, "YCE_CHANGE_BACKGROUND"),
          (0, o.Z)(r, i.ft.blurBackground, "YCE_BLUR_BACKGROUND"),
          (0, o.Z)(r, i.ft.colorize, "YCE_COLORIZE"),
          (0, o.Z)(r, i.ft.lighting, "YCE_LIGHTING"),
          (0, o.Z)(r, i.ft.avatar, "YCE_AVATAR"),
          (0, o.Z)(r, i.ft.txt2Img, "YCE_AI_IMAGE_GENERATOR"),
          (0, o.Z)(r, i.ft.hairStyle, "YCE_HAIR_STYLE"),
          (0, o.Z)(r, i.ft.hairBang, "YCE_AI_HAIR_BANG"),
          (0, o.Z)(r, i.ft.hairExt, "YCE_AI_HAIR_EXTENSION"),
          (0, o.Z)(r, i.ft.hairVol, "YCE_AI_HAIR_VOLUME"),
          (0, o.Z)(r, i.ft.aiApi, "YCE_API_PROFILE"),
          (0, o.Z)(r, i.ft.profilePictureMaker, "YCE_PROFILE_PIC_MAKER"),
          (0, o.Z)(r, i.ft.aiFaceGenerator, "YCE_FACE_GENERATOR"),
          (0, o.Z)(
            r,
            i.ft.animeAiArtGenerator,
            "YCE_FREE_AI_HEADSHOT_GENERATOR"
          ),
          (0, o.Z)(r, i.ft.aiCharacterGenerator, "YCE_AI_CHARACTER_GENERATOR"),
          (0, o.Z)(r, i.ft.oldPhotoRestoration, "YCE_OLD_PHOTO_RESTORATION"),
          (0, o.Z)(r, i.ft.flipAndRotateImage, "YCE_FLIPPER"),
          (0, o.Z)(r, i.ft.resizeImage, "YCE_RESIZE"),
          (0, o.Z)(r, i.ft.cropPhoto, "YCE_CROP"),
          (0, o.Z)(r, i.ft.outPaint, "YCE_OUTPAINTING"),
          (0, o.Z)(r, i.ft.banner, "YCE_PROMO_BANNER"),
          (0, o.Z)(r, i.ft.home, "YCE_HOME"),
          (0, o.Z)(r, i.ft.aiGirlGenerator, "YCE_AI_GIRL_GENERATOR"),
          (0, o.Z)(r, i.ft.passportPhotoMaker, "YCE_PASSPORT_PHOTO_MAKER"),
          (0, o.Z)(r, i.ft.aiArtWorkGenerator, "YCE_AI_ART_GENERATOR"),
          (0, o.Z)(r, i.ft.photoToCartoon, "YCE_CARTOONIZE_PHOTO"),
          (0, o.Z)(r, i.ft.gridModule, "YCE_GRID_MODULE"),
          (0, o.Z)(r, i.ft.objReplace, "YCE_AI_REPLACE"),
          (0, o.Z)(r, i.ft.avtV3Img, "YCE_AI_STUDIO"),
          (0, o.Z)(r, i.ft.headshot, "YCE_AI_HEADSHOT"),
          (0, o.Z)(r, i.ft.muTransfer, "YCE_MAKEUP_TRANSFER"),
          (0, o.Z)(r, i.ft.useCaseMenu, "YCE_MENU"),
          (0, o.Z)(r, i.ft.colorCorrection, "YCE_AI_COLOR_CORRECTION"),
          (0, o.Z)(r, i.ft.videoSr, "YCE_VIDEO_ENHANCER"),
          (0, o.Z)(r, i.ft.aiVideoFilters, "YCE_AI_VIDEO_STYLE_TRANSFORM"),
          (0, o.Z)(r, i.ft.faceShapeDetector, "YCE_FACE_ANALYZER"),
          (0, o.Z)(r, i.ft.faceSwap, "YCE_FACE_SWAP"),
          (0, o.Z)(r, i.ft.faceSwapVid, "YCE_AI_VIDEO_FACE_SWAP"),
          (0, o.Z)(r, i.ft.faceAnalyzerPreview, "YCE_FACE_ANALYZER_TOOL"),
          (0, o.Z)(r, i.ft.categoryEditing, "YCE_CATEGORY_EDITING"),
          (0, o.Z)(r, i.ft.categoryGenAi, "YCE_CATEGORY_GEN_AI"),
          (0, o.Z)(r, i.ft.categoryFaceAi, "YCE_CATEGORY_FACE_AI"),
          (0, o.Z)(r, i.ft.dehazePhoto, "YCE_DEHAZE_PHOTO"),
          (0, o.Z)(r, i.ft.shaprenImage, "YCE_SHARPEN_IMAGE"),
          r);
    },
    65433: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "invalid_container__XvDpQ",
        contents: "invalid_contents__FTMqJ",
        icon: "invalid_icon__sTgQ5",
        title: "invalid_title__xlGTE",
        desc: "invalid_desc__gCHZa",
        button: "invalid_button__XO9hR",
        noticeRedirect: "invalid_noticeRedirect__5lSGj",
      };
    },
    27957: function (e) {
      e.exports = { fadeoutActive: "use-handle-file_fadeoutActive__bC4YP" };
    },
  },
]);
