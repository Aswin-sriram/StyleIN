(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7966],
  {
    69818: function (n, e, t) {
      "use strict";
      t.r(e),
        t.d(e, {
          __N_SSG: function () {
            return o;
          },
          default: function () {
            return s;
          },
        });
      var u = t(68524),
        a = t(21319),
        c = t(85893),
        o = !0;
      function s(n) {
        var e = n.publicDomain,
          t = n.cmsUseCaseMenu,
          o = n.isReady,
          s = {
            title:
              "YouCam Enhance | Best AI Photo Enhancer to Upgrade Any Photo",
            description:
              "Best online AI photo enhancer to sharpen, unblur, and upscale images instantly in 2023.",
            url: "".concat(e),
            path: "account",
            locale: (null == n ? void 0 : n.locale) || "en-us",
          };
        return (0, c.jsx)(c.Fragment, {
          children: (0, c.jsx)(a.Z, {
            pageMeta: s,
            isReady: o,
            children: (0, c.jsx)(u.Z, { cmsUseCaseMenu: t }),
          }),
        });
      }
    },
    84865: function (n, e, t) {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/account",
        function () {
          return t(69818);
        },
      ]);
    },
  },
  function (n) {
    n.O(
      0,
      [3089, 640, 1785, 6816, 1319, 7221, 7042, 6331, 9774, 2888, 179],
      function () {
        return n((n.s = 84865));
      }
    ),
      (_N_E = n.O());
  },
]);
