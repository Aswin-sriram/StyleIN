(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9191],
  {
    86187: function (n, _, u) {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/ai-api",
        function () {
          return u(69039);
        },
      ]);
    },
  },
  function (n) {
    n.O(
      0,
      [3089, 640, 1785, 1319, 7221, 6092, 6257, 6511, 9774, 2888, 179],
      function () {
        return n((n.s = 86187));
      }
    ),
      (_N_E = n.O());
  },
]);
