(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6795],
  {
    86480: function (e, n, t) {
      "use strict";
      t.r(n),
        t.d(n, {
          __N_SSG: function () {
            return i;
          },
          default: function () {
            return s;
          },
        });
      var o = t(6899),
        a = t(21319),
        r = t(85893),
        i = !0;
      function s(e) {
        var n = e.publicDomain,
          t = e.isReady,
          i = e.cmsUseCaseMenu,
          s = {
            title:
              "Save the Photo | YouCam Online Editor: Best AI Photo Enhancer",
            description:
              "Save the  AI-enhanced photo and share on any social platform you like.",
            url: "".concat(n),
            path: "ai-hairstyle-generator/result-photo",
            locale: (null == e ? void 0 : e.locale) || "en-us",
          };
        return (0, r.jsx)(r.Fragment, {
          children: (0, r.jsx)(a.Z, {
            pageMeta: s,
            isReady: t,
            children: (0, r.jsx)(o.Z, {
              cmsContent: e.cmsContent,
              cmsUseCaseMenu: i,
            }),
          }),
        });
      }
    },
    49101: function (e, n, t) {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/ai-hairstyle-generator/result-photo",
        function () {
          return t(86480);
        },
      ]);
    },
  },
  function (e) {
    e.O(
      0,
      [3089, 640, 1785, 1319, 7221, 6092, 2547, 7005, 9774, 2888, 179],
      function () {
        return e((e.s = 49101));
      }
    ),
      (_N_E = e.O());
  },
]);
