(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6257],
  {
    81763: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return u;
        },
      });
      var r = n(55305),
        i = n.n(r),
        o = n(70310),
        a = n(85893);
      function c() {
        return (0, a.jsx)("div", {
          className: i().container,
          children: (0, a.jsx)(o.Z, {}),
        });
      }
      var s = n(61020);
      function u(t) {
        var e = t.opened;
        return (0, a.jsxs)("div", {
          style: {
            width: "100%",
            height: "calc(100% - 64px)",
            display: void 0 !== e && e ? "block" : "none",
          },
          children: [
            (0, a.jsx)(c, {}),
            (0, a.jsx)(s.Z, {
              icon: "/assets/images/icon_no_internet.svg",
              title: "invalid.no.internet.title",
              desc: "invalid.no.internet.desc",
            }),
          ],
        });
      }
    },
    23354: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return d;
        },
      });
      var r = n(20233),
        i = n.n(r),
        o = n(81763),
        a = n(16835),
        c = n(67294),
        s = n(85893);
      function u(t) {
        var e,
          n,
          r,
          i,
          o = t.children,
          u = t.rootMargin,
          l = t.thresholdValue,
          d = t.classes,
          p = t.topIn,
          f = t.topOut,
          g = t.bottomIn,
          b = t.bottomOut,
          m =
            ((e = (0, c.useRef)(null)),
            (r = (n = (0, c.useState)(""))[0]),
            (i = n[1]),
            (0, c.useEffect)(
              function () {
                var t = e.current,
                  n = new IntersectionObserver(
                    function (t) {
                      t.forEach(function (t) {
                        var e = t.boundingClientRect;
                        e.y <= 0
                          ? t.isIntersecting
                            ? i("topIn")
                            : i("topOut")
                          : e.y <=
                            (window.innerHeight ||
                              document.documentElement.clientHeight)
                          ? i("bottomIn")
                          : e.y >=
                              (window.innerHeight ||
                                document.documentElement.clientHeight) &&
                            i("bottomOut");
                      });
                    },
                    { root: null, rootMargin: u, threshold: l }
                  );
                return (
                  t && n.observe(t),
                  function () {
                    t && n.unobserve(t);
                  }
                );
              },
              [u, l]
            ),
            [e, r]),
          h = (0, a.Z)(m, 2),
          x = h[0],
          v = h[1],
          k = (0, c.useState)(d),
          y = k[0],
          w = k[1];
        return (
          (0, c.useEffect)(
            function () {
              switch (v) {
                case "topIn":
                  w("".concat(d, " ").concat(p));
                  break;
                case "topOut":
                  w("".concat(d, " ").concat(f));
                  break;
                case "bottomIn":
                  w("".concat(d, " ").concat(g));
                  break;
                default:
                  w("".concat(d, " ").concat(b));
              }
            },
            [v, d, p, f, g, b]
          ),
          (0, s.jsx)("div", { ref: x, className: y, children: o })
        );
      }
      var l = n(9473);
      function d(t) {
        var e = t.children,
          n = (0, l.v9)(function (t) {
            return t.net;
          });
        return (0, s.jsxs)("div", {
          className: i().container,
          children: [
            (0, s.jsx)("div", {
              className: i().noInternetContainer,
              style: { display: n.online ? "none" : "block" },
              children: (0, s.jsx)(o.Z, { opened: !n.online }),
            }),
            (0, s.jsx)(u, {
              rootMargin: "0px",
              thresholdValue: 1,
              topIn: "top-in",
              topOut: "top-out",
              bottomIn: "bottom-in",
              bottomOut: "bottom-out",
              children: n.online && e,
            }),
          ],
        });
      }
    },
    26927: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return b;
        },
      });
      var r = n(79884),
        i = n.n(r),
        o = n(35045),
        a = n.n(o),
        c = n(92792),
        s = n(77456),
        u = n.n(s),
        l = n(85893);
      function d() {
        return (0, l.jsxs)("div", {
          className: u().bannerContent,
          children: [
            (0, l.jsx)("div", {
              className: u().loadingContent,
              style: { width: "80%", height: "42px", marginBottom: "19px" },
            }),
            (0, l.jsx)("div", {
              className: u().loadingContent,
              style: { height: "19px", marginBottom: "13px" },
            }),
            (0, l.jsx)("div", {
              className: u().loadingContent,
              style: { width: "60%", height: "19px", marginBottom: "13px" },
            }),
            (0, l.jsxs)("div", {
              className: u().bannerBtnContainer,
              children: [
                (0, l.jsx)("div", {
                  className: ""
                    .concat(u().loadingContent, " ")
                    .concat(u().bannerBtn),
                }),
                (0, l.jsx)("div", { style: { width: "12px", height: "18px" } }),
                (0, l.jsx)("div", {
                  className: ""
                    .concat(u().loadingContent, " ")
                    .concat(u().bannerBtn),
                }),
              ],
            }),
          ],
        });
      }
      var p = n(80268),
        f = n.n(p);
      function g(t) {
        var e = t.theme,
          n = t.width,
          r = t.reverse,
          i = n <= parseInt(a()["width-sm"]);
        return (0, l.jsx)("div", {
          style: { backgroundColor: "dark" === e ? "#f2f2f2" : "#fff" },
          children: (0, l.jsxs)("div", {
            style: { flexDirection: r ? "row-reverse" : "initial" },
            className: ""
              .concat(f().container, " ")
              .concat(f().containerMobile, " ")
              .concat(f().imageTextContainer),
            children: [
              (0, l.jsx)("div", {
                className: f().loadingContent,
                style: {
                  height: i ? "219px" : "320px",
                  marginBottom: i ? "25px" : 0,
                },
              }),
              (0, l.jsxs)("div", {
                children: [
                  (0, l.jsx)("div", {
                    className: f().loadingContent,
                    style: {
                      height: "42px",
                      marginBottom: "29px",
                      width: "90%",
                    },
                  }),
                  (0, l.jsx)("div", {
                    className: f().loadingContent,
                    style: { height: "19px", marginBottom: "13px" },
                  }),
                  (0, l.jsx)("div", {
                    className: f().loadingContent,
                    style: {
                      height: "19px",
                      marginBottom: "29px",
                      width: "60%",
                    },
                  }),
                  (0, l.jsx)("div", {
                    style: { textAlign: n > 600 ? "left" : "right" },
                    children: (0, l.jsx)("div", {
                      className: ""
                        .concat(f().loadingContent, " ")
                        .concat(f().bannerBtn),
                    }),
                  }),
                ],
              }),
            ],
          }),
        });
      }
      function b() {
        var t = (0, c.Z)(),
          e = t <= parseInt(a()["width-sm"]);
        return (0, l.jsxs)("div", {
          children: [
            e
              ? (0, l.jsxs)("div", {
                  className: i().borderBottom,
                  children: [
                    (0, l.jsx)("div", { className: i().loadingContainer }),
                    (0, l.jsx)(d, {}),
                  ],
                })
              : (0, l.jsx)("div", {
                  className: i().loadingContainer,
                  children: (0, l.jsx)(d, {}),
                }),
            (0, l.jsx)(g, { theme: "white", reverse: !1, width: t }),
            (0, l.jsx)(g, { theme: "dark", reverse: !0, width: t }),
            (0, l.jsx)(g, { theme: "white", reverse: !1, width: t }),
          ],
        });
      }
    },
    35218: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return R;
        },
      });
      var r = n(9473),
        i = n(18224),
        o = n(43263),
        a = n(1955),
        c = (0, a.Z)(function () {
          return n.e(1131).then(n.bind(n, 1131));
        }),
        s = (0, a.Z)(function () {
          return n.e(7695).then(n.bind(n, 37695));
        }),
        u = (0, a.Z)(function () {
          return Promise.all([n.e(9675), n.e(3646)]).then(n.bind(n, 77872));
        }),
        l = (0, a.Z)(function () {
          return Promise.all([n.e(9675), n.e(5430)]).then(n.bind(n, 18641));
        }),
        d = (0, a.Z)(function () {
          return n.e(3509).then(n.bind(n, 73509));
        }),
        p = (0, a.Z)(function () {
          return n.e(5630).then(n.bind(n, 95630));
        }),
        f = (0, a.Z)(function () {
          return n.e(3330).then(n.bind(n, 3330));
        }),
        g = (0, a.Z)(function () {
          return n.e(1019).then(n.bind(n, 1019));
        }),
        b = (0, a.Z)(function () {
          return n.e(9224).then(n.bind(n, 79224));
        }),
        m = (0, a.Z)(function () {
          return Promise.all([n.e(336), n.e(6524)]).then(n.bind(n, 66524));
        }),
        h = (0, a.Z)(function () {
          return n.e(9155).then(n.bind(n, 39155));
        }),
        x = (0, a.Z)(function () {
          return n.e(3126).then(n.bind(n, 93126));
        }),
        v = (0, a.Z)(function () {
          return n.e(3313).then(n.bind(n, 3313));
        }),
        k = (0, a.Z)(function () {
          return n.e(2950).then(n.bind(n, 42950));
        }),
        y = (0, a.Z)(function () {
          return n.e(7768).then(n.bind(n, 27768));
        }),
        w = (0, a.Z)(function () {
          return n.e(9464).then(n.bind(n, 19464));
        }),
        j = (0, a.Z)(function () {
          return n.e(9107).then(n.bind(n, 89107));
        }),
        C = (0, a.Z)(function () {
          return Promise.all([n.e(187), n.e(3276)]).then(n.bind(n, 59526));
        }),
        _ = (0, a.Z)(function () {
          return n.e(3611).then(n.bind(n, 33611));
        }),
        I = (0, a.Z)(function () {
          return Promise.all([n.e(9675), n.e(6026)]).then(n.bind(n, 73986));
        }),
        P = (0, a.Z)(function () {
          return Promise.all([n.e(336), n.e(5999)]).then(n.bind(n, 55999));
        }),
        Z = n(27361),
        T = n.n(Z),
        B = n(18446),
        O = n.n(B),
        M = n(41609),
        N = n.n(M),
        A = n(89984),
        L = n(84338),
        D = n(67294),
        q = (0, a.Z)(function () {
          return n.e(8196).then(n.bind(n, 28196));
        }),
        E = n(85893);
      function R(t) {
        var e,
          n,
          a,
          Z = t.content,
          B = t.width,
          M = t.productPage,
          R = t.getFilePickerComponent,
          S = t.isAvatarOrderInProcess,
          F = void 0 !== S && S,
          U = t.isAvatarOrderChecking,
          H = void 0 !== U && U,
          V = t.functionUrl,
          K = void 0 === V ? null : V,
          Q = t.moduleType,
          z = void 0 === Q ? null : Q,
          G = t.forceShowBanner,
          W = (0, r.I0)(),
          X = (0, i.Z)().isMobile,
          Y = X ? "Mobile" : "Desktop",
          $ = (0, L.PC)(),
          J = $.t,
          tt = $.locale,
          te = (0, r.v9)(function (t) {
            return t.info;
          }),
          tn = function (t) {
            return T()(Z, t + ".width", 0) / T()(Z, t + ".height", 1);
          },
          tr = function (t) {
            if (t) return "grey" === t ? "#f2f2f2" : t;
          },
          ti = function () {
            var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "";
            return null == t ? void 0 : t.match(/\/avatar\/create$/);
          },
          to = {
            isAvatarCreateLink: ti,
            isAvatarCreateLinkAndIsChecking: function (t) {
              return ti(t) && H;
            },
            onAvatarCreateLinkClick: function (t) {
              if (F) {
                t.preventDefault(), W((0, o.Rm)(!0));
                return;
              }
            },
          },
          ta = (0, D.useMemo)(
            function () {
              return T()(Z, "__component");
            },
            [Z]
          );
        if ("topBanner" === ta)
          return (0, E.jsx)(c, {
            title: Z.title,
            desc: Z.description,
            video: T()(Z, "banner".concat(Y, ".data.attributes.url")),
            posterImage: T()(Z, "background".concat(Y, ".data.attributes.url")),
            backgroundImage: T()(
              Z,
              "background.backgroundImage".concat(Y, ".data.attributes.url")
            ),
            superscriptIcon: T()(Z, "superscriptIcon.data.attributes.url"),
            productPage: M,
            getFilePickerComponent: R,
          });
        if ("product-page.rich-editor" === ta)
          return O()(M, A.ft.aiApi)
            ? (0, E.jsx)(w, {
                title: T()(Z, "sectionText.title"),
                desc: T()(Z, "sectionText.description"),
              })
            : (0, E.jsx)(s, {
                backgroundColor: T()(
                  Z,
                  "sectionBackground.backgroundColor",
                  "#FFF"
                ),
                title: T()(Z, "sectionText.title"),
                desc: T()(Z, "sectionText.description"),
              });
        if ("apps-page.section-be-af-image" === ta)
          return (0, E.jsx)(u, {
            backgroundColor: T()(Z, "sectionBackground.backgroundColor"),
            reverse: "left" !== T()(Z, "textPosition"),
            title: T()(Z, "sectionText.title"),
            desc: T()(Z, "sectionText.description"),
            sectionOrderLeft: T()(Z, "sectionOrderLeft"),
            sectionOrderRight: T()(Z, "sectionOrderRight"),
            beforeImage: T()(
              Z,
              "sectionBeAfMedia.imageBefore".concat(Y, ".data.attributes.url")
            ),
            afterImage: T()(
              Z,
              "sectionBeAfMedia.imageAfter".concat(Y, ".data.attributes.url")
            ),
            aspectRatio: tn(
              "sectionBeAfMedia.imageAfter".concat(
                Y,
                ".data.attributes.formats.medium"
              )
            ),
            video: T()(Z, "sectionBeAfMedia.video.data.attributes.url"),
            cta: T()(Z, "cta"),
            avatarProps: to,
            productPage: M,
          });
        if ("apps-page.section-multi-be-af" === ta)
          return (0, E.jsx)(I, {
            backgroundColor: T()(Z, "sectionBackground.backgroundColor"),
            reverse: "left" !== T()(Z, "textPosition"),
            title: T()(Z, "sectionText.title"),
            desc: T()(Z, "sectionText.description"),
            sectionOrderLeft: T()(Z, "sectionOrderLeft"),
            sectionOrderRight: T()(Z, "sectionOrderRight"),
            sectionBeAfMedia: T()(Z, "sectionBeAfMedia"),
            cta: T()(Z, "cta"),
            avatarProps: to,
            productPage: M,
          });
        if ("product-page.basic-section" === ta)
          return (0, E.jsx)(l, {
            backgroundColor: T()(Z, "sectionBackground.backgroundColor"),
            reverse: "right" === T()(Z, "textPosition"),
            title: T()(Z, "sectionText.title"),
            desc: T()(Z, "sectionText.description"),
            video: T()(
              Z,
              "sectionMedia.video".concat(Y, ".data.attributes.url")
            ),
            image: T()(
              Z,
              "sectionMedia.image".concat(Y, ".data.attributes.url")
            ),
            alt: T()(Z, "sectionMedia.alt"),
            cta: T()(Z, "cta"),
            avatarProps: to,
            productPage: M,
          });
        if ("product-page.mid-banner" === ta)
          return (0, E.jsx)(d, {
            enhancedTitle: T()(Z, "enhancedTitle"),
            title: T()(Z, "title"),
            desc: T()(Z, "description"),
            banner: T()(Z, "banner".concat(Y, ".data.attributes.url")),
            aspectRatio: tn(
              "banner".concat(Y, ".data.attributes.formats.medium")
            ),
            backgroundImage: T()(
              Z,
              "background".concat(Y, ".data.attributes.url")
            ),
            button: T()(Z, "button"),
            isMobile: X,
          });
        if ("product-page.section-multi-cards" === ta)
          return (0, E.jsx)(p, {
            title: T()(Z, "title"),
            backgroundColor: T()(Z, "backgroundColorType"),
            backgroundImage: T()(
              Z,
              "background".concat(Y, "1.data.attributes.url")
            ),
            sections: T()(Z, "sections"),
            devicePrefix: Y,
          });
        if ("product-page.section-steps" === ta)
          return (0, E.jsx)(f, {
            title: Z.title,
            description: Z.description,
            blocks: T()(Z, "blocks", []),
            cta: Z.cta,
            orientationOnMobile: T()(Z, "orientationOnMobile", "vertical"),
            width: B,
            isSteps: Z.isSteps,
            stepText: T()(Z, "stepText") || "STEP",
            stepNumPosition: T()(Z, "stepNumPosition", "right"),
            isMobile: X,
            productPage: M,
          });
        if ("apps-page.section-icon-text" === ta)
          return (0, E.jsx)(g, {
            backgroundColor: tr(T()(Z, "background.backgroundColor")),
            backgroundImage:
              ((e = T()(Z, "backgroundColor")),
              X
                ? T()(e, "backgroundImageMobile.data.attributes.url")
                : T()(e, "backgroundImageDesktop.data.attributes.url")),
            features: T()(Z, "features", []),
            isMobile: X,
          });
        if ("apps-page.section-bottom" === ta) {
          var tc = {
            1: T()(Z, "imgTopLeft.data.attributes.url"),
            2: T()(Z, "imgTopRight.data.attributes.url"),
            3: T()(Z, "imgBottomLeft.data.attributes.url"),
            4: T()(Z, "imgBottomRight.data.attributes.url"),
          };
          return (0, E.jsx)(b, {
            title: T()(Z, "title"),
            desc: T()(Z, "description"),
            imageCTA: T()(Z, "imageCTA"),
            logo: T()(Z, "logo.data.attributes.url"),
            productPage: M,
            images: tc,
          });
        }
        if ("product-page.blog-carousel" === ta)
          return (0, E.jsx)(m, {
            title: Z.title,
            itemId: Z.itemId,
            itemLink: Z.itemLink,
            width: B,
            isMobile: X,
            locale: tt,
          });
        if ("product-page.latest-posts" === ta)
          return (0, E.jsx)(P, {
            title: J("strapi.section.latest.posts"),
            postsData: Z.postsData,
            width: B,
            isMobile: X,
            locale: tt,
            moduleType: z,
          });
        if ("yce.section-yce-grids" === ta)
          return null !== Z.defaultType &&
            null != Z &&
            null !== (n = Z.grid) &&
            void 0 !== n &&
            n.length
            ? (0, E.jsx)(v, {
                title: Z.title,
                grids: T()(Z, "grid", []),
                description: Z.description,
                backgroundColor: tr(T()(Z, "background.backgroundColor")),
                functionUrl: K,
                moduleType: z,
              })
            : (0, E.jsx)(v, {
                title: Z.title,
                description: Z.description,
                backgroundColor: tr(T()(Z, "background.backgroundColor")),
                functionUrl: K,
                moduleType: z,
              });
        if ("apps-page.section-multi-grids" === ta)
          return O()(M, A.ft.txt2Img)
            ? null === Z.defaultType ||
              (null != Z && null !== (a = Z.grids) && void 0 !== a && a.length)
              ? (0, E.jsx)(v, {
                  title: Z.title,
                  description: Z.description,
                  backgroundColor: tr(T()(Z, "background.backgroundColor")),
                  functionUrl: K,
                  moduleType: z,
                })
              : null
            : (0, E.jsx)(h, {
                title: Z.title,
                description: Z.description,
                grids: T()(Z, "grids", []),
                background: T()(Z, "background"),
                getBackgroundColor: tr,
                productPage: M,
              });
        if ("yce.section-style" === ta) {
          var ts = T()(Z, "styleItems", []);
          return N()(ts)
            ? null
            : (0, E.jsx)(k, {
                title: Z.title,
                desc: Z.description,
                subTitle1: Z.subTitle1,
                subTitle2: Z.subTitle2,
                cta: Z.cta,
                styleItems: ts,
                productPage: M,
              });
        }
        return "apps-page.section-faq" === ta
          ? (0, E.jsx)(x, { title: Z.title, faqList: Z.faqList })
          : "featureBanner" === ta
          ? (0, E.jsx)(j, {
              content: Z,
              forceShowBanner: void 0 !== G && G,
              productPage: M,
            })
          : "yce.section-yce-cards" === ta
          ? (0, E.jsx)(y, {
              backgroundColor: tr(T()(Z, "background.backgroundColor")),
              title: T()(Z, "title"),
              description: T()(Z, "description"),
              sections: T()(Z, "sections"),
              devicePrefix: Y,
              documentCta: T()(Z, "cta"),
            })
          : "gridModule" === ta
          ? "guest" === te.accType
            ? (0, E.jsx)(C, { content: Z.attributes })
            : (0, E.jsx)(q, { content: Z.attributes })
          : "shared.borderline" === ta
          ? (0, E.jsx)(_, { lineColor: Z.lineColor })
          : null;
      }
    },
    31127: function (t, e, n) {
      "use strict";
      n.d(e, {
        Z: function () {
          return I;
        },
      });
      var r = n(59499),
        i = n(36864),
        o = n(50029),
        a = n(87794),
        c = n.n(a),
        s = n(11163),
        u = n(67294),
        l = n(9473),
        d = n(45270),
        p = n(13311),
        f = n.n(p),
        g = n(27361),
        b = n.n(g),
        m = n(35161),
        h = n.n(m),
        x = n(49162),
        v = n(94552),
        k = n(78569),
        y = n(89984),
        w = n(78718),
        j = n.n(w);
      function C(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(t);
          e &&
            (r = r.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
        }
        return n;
      }
      function _(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? C(Object(n), !0).forEach(function (e) {
                (0, r.Z)(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : C(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function I(t) {
        var e,
          n,
          r,
          a = t.content,
          p = t.type,
          g = void 0 === p ? null : p,
          m = t.isBlogUseCase,
          w = void 0 !== m && m,
          C = (0, u.useState)(null),
          I = C[0],
          P = C[1],
          Z = (0, u.useState)(!1),
          T = Z[0],
          B = Z[1],
          O = (0, s.useRouter)(),
          M = (0, l.I0)(),
          N = (0, l.v9)(function (t) {
            return t.cms;
          }),
          A = function () {
            return (
              "localhost" === location.hostname ||
              "127.0.0.1" === location.hostname ||
              "yce-test.perfectcorp.com" === location.hostname ||
              location.hostname.match(/^192.168.29/) ||
              location.hostname.match(/^192.168.19/)
            );
          };
        (0, u.useEffect)(
          function () {
            O.isReady && O.query && (w ? F() : S());
          },
          [O.isReady, O.query]
        );
        var L =
            ((e = (0, o.Z)(
              c().mark(function t() {
                var e, n, r, i, o;
                return c().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        if ((e = O.query.pfFormId)) {
                          t.next = 3;
                          break;
                        }
                        return t.abrupt("return");
                      case 3:
                        return (
                          M((0, d.Bm)()),
                          (n = ""
                            .concat(
                              "/smb-frontend/yce/strapi/query-project.action",
                              "?formId="
                            )
                            .concat(e)),
                          (r = A() ? "" : "https://www.perfectcorp.com"),
                          (t.next = 9),
                          fetch(r + n).then(function (t) {
                            return 200 === t.status && t.json();
                          })
                        );
                      case 9:
                        if (null != (i = t.sent) && i.projectItems) {
                          t.next = 12;
                          break;
                        }
                        return t.abrupt("return");
                      case 12:
                        if (
                          !(
                            (o = h()(i.projectItems, function (t) {
                              return { type: b()(t, "type"), id: b()(t, "id") };
                            })).length > 0
                          )
                        ) {
                          t.next = 15;
                          break;
                        }
                        return t.abrupt("return", M((0, d.hE)(o)));
                      case 15:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
          D = function (t) {
            var e = b()(t, "payload", b()(N, "cmsItems"));
            return b()(
              f()(e, function (t) {
                return t.type === g;
              }),
              "id",
              b()(O.query, "cmsId")
            );
          },
          q = function (t) {
            var e = A() ? "" : "https://www.perfectcorp.com";
            return fetch(
              e +
                "/smb-frontend/yce/blog/post/query-post.action?postId=".concat(
                  t
                )
            ).then(function (t) {
              return 200 === t.status && t.json();
            });
          },
          E = function (t) {
            var e = x.Z.splitPostItemLink(t),
              n = e.postHandle,
              r = e.languageType;
            return e.isYCEUseCase, R(n, r);
          },
          R = function (t, e) {
            var n =
                "/smb-frontend/yce/blog/post/query-post-by-key.action?postHandle="
                  .concat(t, "&languageType=")
                  .concat(e),
              r = A() ? "" : "https://www.perfectcorp.com";
            return fetch(r + n).then(function (t) {
              return 200 === t.status && t.json();
            });
          },
          S =
            ((n = (0, o.Z)(
              c().mark(function t() {
                var e, n, r, s, u, l, d;
                return c().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (t.next = 2), L();
                        case 2:
                          if ((e = D(t.sent))) {
                            t.next = 8;
                            break;
                          }
                          return P(a), B(!0), t.abrupt("return");
                        case 8:
                          return (
                            (n = ""
                              .concat(
                                "/smb-frontend/yce/strapi/query-content-by-id.action",
                                "?id="
                              )
                              .concat(e, "&type=")
                              .concat(g)),
                            (r = A() ? "" : "https://www.perfectcorp.com"),
                            (t.prev = 11),
                            (t.next = 14),
                            fetch(r + n).then(function (t) {
                              return 200 === t.status && t.json();
                            })
                          );
                        case 14:
                          if (!(s = t.sent)) {
                            t.next = 45;
                            break;
                          }
                          if (
                            !(u = f()(b()(s, "attributes.sections", []), {
                              __component: "product-page.blog-carousel",
                            }))
                          ) {
                            t.next = 32;
                            break;
                          }
                          if (!u.itemLink) {
                            t.next = 25;
                            break;
                          }
                          return (
                            (t.t0 = Promise),
                            (t.next = 22),
                            u.itemLink.map(
                              (function () {
                                var t = (0, o.Z)(
                                  c().mark(function t(e) {
                                    var n;
                                    return c().wrap(function (t) {
                                      for (;;)
                                        switch ((t.prev = t.next)) {
                                          case 0:
                                            return (t.next = 2), E(e.link);
                                          case 2:
                                            (n = t.sent) &&
                                              (e.rContent = j()(n, [
                                                "title",
                                                "postAuthors",
                                                "postDate",
                                                "imageUrl",
                                                "languageType",
                                                "postKey",
                                                "id",
                                                "metaDesc",
                                                "featuredTopic",
                                                "subTitle",
                                              ]));
                                          case 4:
                                          case "end":
                                            return t.stop();
                                        }
                                    }, t);
                                  })
                                );
                                return function (e) {
                                  return t.apply(this, arguments);
                                };
                              })()
                            )
                          );
                        case 22:
                          return (
                            (t.t1 = t.sent),
                            (t.next = 25),
                            t.t0.all.call(t.t0, t.t1)
                          );
                        case 25:
                          if (!u.itemId) {
                            t.next = 32;
                            break;
                          }
                          return (
                            (t.t2 = Promise),
                            (t.next = 29),
                            u.itemId.map(
                              (function () {
                                var t = (0, o.Z)(
                                  c().mark(function t(e) {
                                    var n;
                                    return c().wrap(function (t) {
                                      for (;;)
                                        switch ((t.prev = t.next)) {
                                          case 0:
                                            return (t.next = 2), q(e.itemId);
                                          case 2:
                                            (n = t.sent) &&
                                              (e.rContent = j()(n, [
                                                "title",
                                                "postAuthors",
                                                "postDate",
                                                "imageUrl",
                                                "languageType",
                                                "postKey",
                                                "id",
                                                "metaDesc",
                                                "featuredTopic",
                                                "subTitle",
                                              ]));
                                          case 4:
                                          case "end":
                                            return t.stop();
                                        }
                                    }, t);
                                  })
                                );
                                return function (e) {
                                  return t.apply(this, arguments);
                                };
                              })()
                            )
                          );
                        case 29:
                          return (
                            (t.t3 = t.sent),
                            (t.next = 32),
                            t.t2.all.call(t.t2, t.t3)
                          );
                        case 32:
                          if (
                            ![
                              k.I[y.ft.categoryEditing],
                              k.I[y.ft.categoryGenAi],
                              k.I[y.ft.categoryFaceAi],
                            ].includes(g) ||
                            !s
                          ) {
                            t.next = 41;
                            break;
                          }
                          return (
                            (l = (0, i.Z)({}, O.query).locale),
                            (t.next = 38),
                            v.ZP._listBlogPostDetail({ locale: l })
                          );
                        case 38:
                          (d = t.sent),
                            (s.postsData = d),
                            s.attributes.sections.push({
                              __component: "product-page.latest-posts",
                              postsData: d,
                            });
                        case 41:
                          P(s), B(!0), (t.next = 46);
                          break;
                        case 45:
                          P(null);
                        case 46:
                          t.next = 51;
                          break;
                        case 48:
                          (t.prev = 48), (t.t4 = t.catch(11)), P(null);
                        case 51:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  null,
                  [[11, 48]]
                );
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
          F =
            ((r = (0, o.Z)(
              c().mark(function t() {
                var e, n, r, o;
                return c().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((n = (e = (0, i.Z)({}, O.query)).locale),
                            (r = e.postId),
                            x.Z.convertFAQLanguageType(n),
                            r)
                          ) {
                            t.next = 7;
                            break;
                          }
                          return P(a), B(!0), t.abrupt("return");
                        case 7:
                          return (t.prev = 7), (t.next = 10), q(r);
                        case 10:
                          (o = t.sent) ? (P(_(_({}, a), o)), B(!0)) : P(null),
                            (t.next = 17);
                          break;
                        case 14:
                          (t.prev = 14), (t.t0 = t.catch(7)), P(null);
                        case 17:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  null,
                  [[7, 14]]
                );
              })
            )),
            function () {
              return r.apply(this, arguments);
            });
        return { cmsContent: I, isLoaded: T };
      }
    },
    55305: function (t) {
      t.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "offline_container__Uf0Z1",
      };
    },
    20233: function (t) {
      t.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "layout_container___h7ao",
        noInternetContainer: "layout_noInternetContainer__hSelD",
      };
    },
    77456: function (t) {
      t.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        bannerContent: "banner_bannerContent__lSLQ5",
        loadingContent: "banner_loadingContent__s0qzj",
        shimmer: "banner_shimmer__l1Wf5",
        bannerBtnContainer: "banner_bannerBtnContainer__2Faco",
        bannerBtn: "banner_bannerBtn__NM25v",
      };
    },
    80268: function (t) {
      t.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container: "image-text_container__AZ7qo",
        containerMobile: "image-text_containerMobile___jVE_",
        imageTextContainer: "image-text_imageTextContainer__ORI2P",
        loadingContent: "image-text_loadingContent__I3PxM",
        shimmer: "image-text_shimmer__r_mmi",
        bannerBtn: "image-text_bannerBtn__jby2H",
      };
    },
    79884: function (t) {
      t.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        loadingContainer: "loading-skeleton_loadingContainer__tPXvg",
        borderBottom: "loading-skeleton_borderBottom__12kt1",
      };
    },
  },
]);
