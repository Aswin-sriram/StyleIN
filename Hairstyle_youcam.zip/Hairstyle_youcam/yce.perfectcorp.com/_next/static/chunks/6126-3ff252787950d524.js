"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6126],
  {
    26126: function (n, t, e) {
      e.d(t, {
        Uv: function () {
          return nv;
        },
        d$: function () {
          return nd;
        },
      });
      var i = e(67294),
        o = function (n, t) {
          return Number(n.toFixed(t));
        },
        a = function (n, t, e) {
          e && "function" == typeof e && e(n, t);
        },
        r = {
          easeOut: function (n) {
            return -Math.cos(n * Math.PI) / 2 + 0.5;
          },
          linear: function (n) {
            return n;
          },
          easeInQuad: function (n) {
            return n * n;
          },
          easeOutQuad: function (n) {
            return n * (2 - n);
          },
          easeInOutQuad: function (n) {
            return n < 0.5 ? 2 * n * n : -1 + (4 - 2 * n) * n;
          },
          easeInCubic: function (n) {
            return n * n * n;
          },
          easeOutCubic: function (n) {
            return --n * n * n + 1;
          },
          easeInOutCubic: function (n) {
            return n < 0.5
              ? 4 * n * n * n
              : (n - 1) * (2 * n - 2) * (2 * n - 2) + 1;
          },
          easeInQuart: function (n) {
            return n * n * n * n;
          },
          easeOutQuart: function (n) {
            return 1 - --n * n * n * n;
          },
          easeInOutQuart: function (n) {
            return n < 0.5 ? 8 * n * n * n * n : 1 - 8 * --n * n * n * n;
          },
          easeInQuint: function (n) {
            return n * n * n * n * n;
          },
          easeOutQuint: function (n) {
            return 1 + --n * n * n * n * n;
          },
          easeInOutQuint: function (n) {
            return n < 0.5
              ? 16 * n * n * n * n * n
              : 1 + 16 * --n * n * n * n * n;
          },
        },
        s = function (n) {
          "number" == typeof n && cancelAnimationFrame(n);
        },
        l = function (n) {
          n.mounted &&
            (s(n.animation),
            (n.animate = !1),
            (n.animation = null),
            (n.velocity = null));
        };
      function u(n, t, e, i) {
        if (n.mounted) {
          var o = new Date().getTime();
          l(n),
            (n.animation = function () {
              if (!n.mounted) return s(n.animation);
              var a = new Date().getTime() - o,
                l = (0, r[t])(a / e);
              a >= e
                ? (i(1), (n.animation = null))
                : n.animation && (i(l), requestAnimationFrame(n.animation));
            }),
            requestAnimationFrame(n.animation);
        }
      }
      function c(n, t, e, i) {
        var o,
          a,
          r,
          s =
            ((o = t.scale),
            (a = t.positionX),
            (r = t.positionY),
            !(Number.isNaN(o) || Number.isNaN(a) || Number.isNaN(r)));
        if (n.mounted && s) {
          var l = n.setTransformState,
            c = n.transformState,
            p = c.scale,
            m = c.positionX,
            d = c.positionY,
            f = t.scale - p,
            v = t.positionX - m,
            h = t.positionY - d;
          0 === e
            ? l(t.scale, t.positionX, t.positionY)
            : u(n, i, e, function (n) {
                l(p + f * n, m + v * n, d + h * n);
              });
        }
      }
      var p = function (n, t, e, i, o, a, r) {
          var s = n > t ? e * (r ? 1 : 0.5) : 0,
            l = i > o ? a * (r ? 1 : 0.5) : 0;
          return {
            minPositionX: n - t - s,
            maxPositionX: s,
            minPositionY: i - o - l,
            maxPositionY: l,
          };
        },
        m = function (n, t) {
          var e,
            i,
            o,
            a,
            r,
            s,
            l = n.wrapperComponent,
            u = n.contentComponent,
            c = n.setup.centerZoomedOut;
          if (!l || !u) throw Error("Components are not mounted");
          var m =
              ((e = l.offsetWidth),
              (i = l.offsetHeight),
              (o = u.offsetWidth),
              (a = u.offsetHeight),
              {
                wrapperWidth: e,
                wrapperHeight: i,
                newContentWidth: (r = o * t),
                newDiffWidth: e - r,
                newContentHeight: (s = a * t),
                newDiffHeight: i - s,
              }),
            d = m.wrapperWidth,
            f = m.wrapperHeight;
          return p(
            d,
            m.newContentWidth,
            m.newDiffWidth,
            f,
            m.newContentHeight,
            m.newDiffHeight,
            Boolean(c)
          );
        },
        d = function (n, t, e, i) {
          return i ? (n < t ? o(t, 2) : n > e ? o(e, 2) : o(n, 2)) : o(n, 2);
        },
        f = function (n, t) {
          var e = m(n, t);
          return (n.bounds = e), e;
        };
      function v(n, t, e, i, o, a, r) {
        var s = e.minPositionX,
          l = e.minPositionY,
          u = e.maxPositionX,
          c = e.maxPositionY,
          p = 0,
          m = 0;
        return (
          r && ((p = o), (m = a)),
          { x: d(n, s - p, u + p, i), y: d(t, l - m, c + m, i) }
        );
      }
      function h(n, t, e, i, o, a) {
        var r = n.transformState,
          s = r.scale,
          l = r.positionX,
          u = r.positionY,
          c = i - s;
        return "number" != typeof t || "number" != typeof e
          ? (console.error("Mouse X and Y position were not provided!"),
            { x: l, y: u })
          : v(l - t * c, u - e * c, o, a, 0, 0, null);
      }
      function g(n, t, e, i, o) {
        var a = t - (o ? i : 0);
        return !Number.isNaN(e) && n >= e
          ? e
          : !Number.isNaN(t) && n <= a
          ? a
          : n;
      }
      var S = function (n, t) {
          var e = n.setup.panning.excluded,
            i = n.isInitialized,
            o = n.wrapperComponent,
            a = t.target,
            r = null == o ? void 0 : o.contains(a);
          return !(!(i && a && r) || H(a, e));
        },
        y = function (n) {
          var t = n.isInitialized,
            e = n.isPanning,
            i = n.setup.panning.disabled;
          return !!t && !!e && !i;
        },
        w = function (n, t) {
          var e = n.transformState,
            i = e.positionX,
            o = e.positionY;
          n.isPanning = !0;
          var a = t.clientX,
            r = t.clientY;
          n.startCoords = { x: a - i, y: r - o };
        },
        b = function (n, t) {
          var e = t.touches,
            i = n.transformState,
            o = i.positionX,
            a = i.positionY;
          if (((n.isPanning = !0), 1 === e.length)) {
            var r = e[0].clientX,
              s = e[0].clientY;
            n.startCoords = { x: r - o, y: s - a };
          }
        },
        C = function (n, t, e) {
          var i = n.startCoords,
            o = n.transformState,
            a = n.setup.panning,
            r = a.lockAxisX,
            s = a.lockAxisY,
            l = o.positionX,
            u = o.positionY;
          if (!i) return { x: l, y: u };
          var c = t - i.x,
            p = e - i.y;
          return { x: r ? l : c, y: s ? u : p };
        },
        P = function (n, t) {
          var e = n.setup,
            i = n.transformState.scale,
            o = e.minScale,
            a = e.disablePadding;
          return t > 0 && i >= o && !a ? t : 0;
        },
        T = function (n) {
          var t = n.mounted,
            e = n.setup,
            i = e.disabled,
            o = e.velocityAnimation,
            a = n.transformState.scale;
          return !o.disabled || a > 1 || !i || !!t;
        },
        x = function (n) {
          var t = n.mounted,
            e = n.velocity,
            i = n.bounds,
            o = n.setup,
            a = o.disabled,
            r = o.velocityAnimation,
            s = n.transformState.scale;
          return (!r.disabled || s > 1 || !a || !!t) && !!e && !!i;
        };
      function Y(n, t, e, i, o, a, r, s, l, u) {
        if (o) {
          if (t > r && e > r) {
            var c = r + (n - r) * u;
            return c > l ? l : c < r ? r : c;
          }
          if (t < a && e < a) {
            var c = a + (n - a) * u;
            return c < s ? s : c > a ? a : c;
          }
        }
        return i ? t : d(n, a, r, o);
      }
      function E(n, t) {
        var e = n.transformState.scale;
        l(n),
          f(n, e),
          void 0 !== window.TouchEvent && t instanceof TouchEvent
            ? b(n, t)
            : w(n, t);
      }
      function X(n) {
        var t = n.transformState.scale,
          e = n.setup,
          i = e.minScale,
          o = e.alignmentAnimation,
          a = o.disabled,
          r = o.sizeX,
          s = o.sizeY,
          l = o.animationTime,
          u = o.animationType;
        if (!(a || t < i || (!r && !s))) {
          var p = (function (n) {
            var t = n.transformState,
              e = t.positionX,
              i = t.positionY,
              o = t.scale,
              a = n.setup,
              r = a.disabled,
              s = a.limitToBounds,
              l = a.centerZoomedOut,
              u = n.wrapperComponent;
            if (!r && u && n.bounds) {
              var c = n.bounds,
                p = c.maxPositionX,
                m = c.minPositionX,
                d = c.maxPositionY,
                f = c.minPositionY,
                v = e > p ? u.offsetWidth : n.setup.minPositionX || 0,
                g = i > d ? u.offsetHeight : n.setup.minPositionY || 0,
                S = h(n, v, g, o, n.bounds, s || l),
                y = S.x,
                w = S.y;
              return {
                scale: o,
                positionX: e > p || e < m ? y : e,
                positionY: i > d || i < f ? w : i,
              };
            }
          })(n);
          p && c(n, p, l, u);
        }
      }
      function N(n, t, e) {
        var i = n.startCoords,
          o = n.setup.alignmentAnimation,
          a = o.sizeX,
          r = o.sizeY;
        if (i) {
          var s = C(n, t, e),
            l = s.x,
            u = s.y,
            c = P(n, a),
            p = P(n, r);
          !(function (n, t) {
            if (T(n)) {
              var e = n.lastMousePosition,
                i = n.velocityTime,
                o = n.setup,
                a = n.wrapperComponent,
                r = o.velocityAnimation.equalToMove,
                s = Date.now();
              if (e && i && a) {
                var l = r ? Math.min(1, a.offsetWidth / window.innerWidth) : 1,
                  u = t.x - e.x,
                  c = t.y - e.y;
                n.velocity = {
                  velocityX: u / l,
                  velocityY: c / l,
                  total: Math.sqrt(u * u + c * c) / (s - i),
                };
              }
              (n.lastMousePosition = t), (n.velocityTime = s);
            }
          })(n, { x: l, y: u }),
            (function (n, t, e, i, o) {
              var a = n.setup.limitToBounds,
                r = n.wrapperComponent,
                s = n.bounds,
                l = n.transformState,
                u = l.scale,
                c = l.positionX,
                p = l.positionY;
              if (null !== r && null !== s && (t !== c || e !== p)) {
                var m = v(t, e, s, a, i, o, r),
                  d = m.x,
                  f = m.y;
                n.setTransformState(u, d, f);
              }
            })(n, l, u, c, p);
        }
      }
      function k(n, t, e, i) {
        var a = n.setup,
          r = a.minScale,
          s = a.maxScale,
          l = a.limitToBounds,
          u = g(o(t, 2), r, s, 0, !1),
          c = f(n, u),
          p = h(n, e, i, u, c, l),
          m = p.x,
          d = p.y;
        return { scale: u, positionX: m, positionY: d };
      }
      function z(n, t, e) {
        var i = n.transformState.scale,
          o = n.wrapperComponent,
          a = n.setup,
          r = a.minScale,
          s = a.limitToBounds,
          l = a.zoomAnimation,
          u = l.disabled,
          p = l.animationTime,
          m = l.animationType;
        if (((i >= 1 || s) && X(n), !(u || i >= r) && o && n.mounted)) {
          var d = k(n, r, t || o.offsetWidth / 2, e || o.offsetHeight / 2);
          d && c(n, d, p, m);
        }
      }
      var W = function () {
        return (W =
          Object.assign ||
          function (n) {
            for (var t, e = 1, i = arguments.length; e < i; e++)
              for (var o in (t = arguments[e]))
                Object.prototype.hasOwnProperty.call(t, o) && (n[o] = t[o]);
            return n;
          }).apply(this, arguments);
      };
      function D(n, t, e) {
        if (e || 2 == arguments.length)
          for (var i, o = 0, a = t.length; o < a; o++)
            (!i && o in t) ||
              (i || (i = Array.prototype.slice.call(t, 0, o)), (i[o] = t[o]));
        return n.concat(i || Array.prototype.slice.call(t));
      }
      var O = { previousScale: 1, scale: 1, positionX: 0, positionY: 0 },
        A = {
          disabled: !1,
          minPositionX: null,
          maxPositionX: null,
          minPositionY: null,
          maxPositionY: null,
          minScale: 1,
          maxScale: 8,
          limitToBounds: !0,
          centerZoomedOut: !1,
          centerOnInit: !1,
          disablePadding: !1,
          smooth: !0,
          wheel: {
            step: 0.2,
            disabled: !1,
            smoothStep: 0.001,
            wheelDisabled: !1,
            touchPadDisabled: !1,
            activationKeys: [],
            excluded: [],
          },
          panning: {
            disabled: !1,
            velocityDisabled: !1,
            lockAxisX: !1,
            lockAxisY: !1,
            allowLeftClickPan: !0,
            allowMiddleClickPan: !0,
            allowRightClickPan: !0,
            activationKeys: [],
            excluded: [],
          },
          pinch: { step: 5, disabled: !1, excluded: [] },
          doubleClick: {
            disabled: !1,
            step: 0.7,
            mode: "zoomIn",
            animationType: "easeOut",
            animationTime: 200,
            excluded: [],
          },
          zoomAnimation: {
            disabled: !1,
            size: 0.4,
            animationTime: 200,
            animationType: "easeOut",
          },
          alignmentAnimation: {
            disabled: !1,
            sizeX: 100,
            sizeY: 100,
            animationTime: 200,
            velocityAlignmentTime: 400,
            animationType: "easeOut",
          },
          velocityAnimation: {
            disabled: !1,
            sensitivity: 1,
            animationTime: 400,
            animationType: "easeOut",
            equalToMove: !0,
          },
        },
        I = function (n) {
          var t, e, i, o;
          return {
            previousScale:
              null !== (t = n.initialScale) && void 0 !== t ? t : O.scale,
            scale: null !== (e = n.initialScale) && void 0 !== e ? e : O.scale,
            positionX:
              null !== (i = n.initialPositionX) && void 0 !== i
                ? i
                : O.positionX,
            positionY:
              null !== (o = n.initialPositionY) && void 0 !== o
                ? o
                : O.positionY,
          };
        },
        B = function (n) {
          var t = W({}, A);
          return (
            Object.keys(n).forEach(function (e) {
              var i = void 0 !== n[e];
              if (void 0 !== A[e] && i) {
                var o = Object.prototype.toString.call(A[e]);
                "[object Object]" === o
                  ? (t[e] = W(W({}, A[e]), n[e]))
                  : "[object Array]" === o
                  ? (t[e] = D(D([], A[e], !0), n[e], !0))
                  : (t[e] = n[e]);
              }
            }),
            t
          );
        },
        M = function (n, t, e) {
          var i = n.transformState.scale,
            a = n.wrapperComponent,
            r = n.setup,
            s = r.maxScale,
            l = r.minScale,
            u = r.zoomAnimation,
            c = r.smooth,
            p = u.size;
          if (!a) throw Error("Wrapper is not mounted");
          return g(o(c ? i * Math.exp(t * e) : i + t * e, 3), l, s, p, !1);
        };
      function K(n, t, e, i, o) {
        var a = n.wrapperComponent,
          r = n.transformState,
          s = r.scale,
          l = r.positionX,
          u = r.positionY;
        if (!a) return console.error("No WrapperComponent found");
        var p = a.offsetWidth,
          m = a.offsetHeight,
          d = M(n, t, e),
          f = k(n, d, (p / 2 - l) / s, (m / 2 - u) / s);
        if (!f)
          return console.error(
            "Error during zoom event. New transformation state was not calculated."
          );
        c(n, f, i, o);
      }
      function L(n, t, e, i) {
        var o = n.setup,
          a = n.wrapperComponent,
          r = o.limitToBounds,
          s = I(n.props),
          l = n.transformState,
          u = l.scale,
          p = l.positionX,
          d = l.positionY;
        if (a) {
          var f = m(n, s.scale),
            h = v(s.positionX, s.positionY, f, r, 0, 0, a),
            g = { scale: s.scale, positionX: h.x, positionY: h.y };
          if (u === s.scale && p === s.positionX && d === s.positionY) return;
          null == i || i(), c(n, g, t, e);
        }
      }
      var _ = function (n) {
          return {
            instance: n,
            zoomIn: function (t, e, i) {
              void 0 === t && (t = 0.5),
                void 0 === e && (e = 300),
                void 0 === i && (i = "easeOut"),
                K(n, 1, t, e, i);
            },
            zoomOut: function (t, e, i) {
              void 0 === t && (t = 0.5),
                void 0 === e && (e = 300),
                void 0 === i && (i = "easeOut"),
                K(n, -1, t, e, i);
            },
            setTransform: function (t, e, i, o, a) {
              void 0 === o && (o = 300), void 0 === a && (a = "easeOut");
              var r = n.transformState,
                s = r.positionX,
                l = r.positionY,
                u = r.scale,
                p = n.wrapperComponent,
                m = n.contentComponent;
              !n.setup.disabled &&
                p &&
                m &&
                c(
                  n,
                  {
                    positionX: Number.isNaN(t) ? s : t,
                    positionY: Number.isNaN(e) ? l : e,
                    scale: Number.isNaN(i) ? u : i,
                  },
                  o,
                  a
                );
            },
            resetTransform: function (t, e) {
              void 0 === t && (t = 200),
                void 0 === e && (e = "easeOut"),
                L(n, t, e);
            },
            centerView: function (t, e, i) {
              void 0 === e && (e = 200), void 0 === i && (i = "easeOut");
              var o = n.transformState,
                a = n.wrapperComponent,
                r = n.contentComponent;
              a && r && c(n, j(t || o.scale, a, r), e, i);
            },
            zoomToElement: function (t, e, i, o) {
              void 0 === i && (i = 600), void 0 === o && (o = "easeOut"), l(n);
              var a = n.wrapperComponent,
                r = "string" == typeof t ? document.getElementById(t) : t;
              if (a && r && a.contains(r)) {
                var s = (function (n, t, e) {
                  var i,
                    o,
                    a,
                    r,
                    s,
                    l = n.wrapperComponent,
                    u = n.contentComponent,
                    c = n.transformState,
                    p = n.setup,
                    d = p.limitToBounds,
                    f = p.minScale,
                    h = p.maxScale;
                  if (!l || !u) return c;
                  var S = l.getBoundingClientRect(),
                    y = t.getBoundingClientRect(),
                    w =
                      ((i = t.getBoundingClientRect()),
                      (o = l.getBoundingClientRect()),
                      (a = u.getBoundingClientRect()),
                      (r = o.x * c.scale),
                      (s = o.y * c.scale),
                      {
                        x: (i.x - a.x + r) / c.scale,
                        y: (i.y - a.y + s) / c.scale,
                      }),
                    b = w.x,
                    C = w.y,
                    P = y.width / c.scale,
                    T = y.height / c.scale,
                    x = l.offsetWidth / P,
                    Y = l.offsetHeight / T,
                    E = g(e || Math.min(x, Y), f, h, 0, !1),
                    X = (S.width - P * E) / 2,
                    N = (S.height - T * E) / 2,
                    k = v(
                      (S.left - b) * E + X,
                      (S.top - C) * E + N,
                      m(n, E),
                      d,
                      0,
                      0,
                      l
                    );
                  return { positionX: k.x, positionY: k.y, scale: E };
                })(n, r, e);
                c(n, s, i, o);
              }
            },
          };
        },
        R = function (n) {
          var t = {};
          return (
            Object.assign(t, { instance: n, state: n.transformState }),
            Object.assign(t, _(n)),
            t
          );
        };
      function Z() {
        try {
          return {
            get passive() {
              return !1;
            },
          };
        } catch (n) {
          return !1;
        }
      }
      var H = function (n, t) {
          var e = n.tagName.toUpperCase();
          return !!(
            t.find(function (n) {
              return n.toUpperCase() === e;
            }) ||
            t.find(function (t) {
              return n.classList.contains(t);
            })
          );
        },
        F = function (n) {
          n && clearTimeout(n);
        },
        j = function (n, t, e) {
          var i = e.offsetWidth * n,
            o = e.offsetHeight * n;
          return {
            scale: n,
            positionX: (t.offsetWidth - i) / 2,
            positionY: (t.offsetHeight - o) / 2,
          };
        },
        Q = function (n, t) {
          var e = n.setup.wheel,
            i = e.disabled,
            o = e.wheelDisabled,
            a = e.touchPadDisabled,
            r = e.excluded,
            s = n.isInitialized,
            l = n.isPanning,
            u = t.target;
          return !(
            !(s && !l && !i && u) ||
            (o && !t.ctrlKey) ||
            (a && t.ctrlKey) ||
            H(u, r)
          );
        };
      function q(n, t, e) {
        var i = t.getBoundingClientRect(),
          o = 0,
          a = 0;
        if ("clientX" in n)
          (o = (n.clientX - i.left) / e), (a = (n.clientY - i.top) / e);
        else {
          var r = n.touches[0];
          (o = (r.clientX - i.left) / e), (a = (r.clientY - i.top) / e);
        }
        return (
          (Number.isNaN(o) || Number.isNaN(a)) &&
            console.error("No mouse or touch offset found"),
          { x: o, y: a }
        );
      }
      var U = function (n, t, e, i, a) {
          var r = n.transformState.scale,
            s = n.wrapperComponent,
            l = n.setup,
            u = l.maxScale,
            c = l.minScale,
            p = l.zoomAnimation,
            m = l.disablePadding,
            d = p.size,
            f = p.disabled;
          if (!s) throw Error("Wrapper is not mounted");
          var v = r + t * e;
          return a ? v : g(o(v, 3), c, u, d, !i && !f && !m);
        },
        V = function (n, t) {
          var e = n.previousWheelEvent,
            i = n.transformState.scale,
            o = n.setup,
            a = o.maxScale,
            r = o.minScale;
          return (
            !!e &&
            (i < a ||
              i > r ||
              Math.sign(e.deltaY) !== Math.sign(t.deltaY) ||
              (e.deltaY > 0 && e.deltaY < t.deltaY) ||
              (e.deltaY < 0 && e.deltaY > t.deltaY) ||
              Math.sign(e.deltaY) !== Math.sign(t.deltaY))
          );
        },
        $ = function (n, t) {
          var e = n.setup.pinch,
            i = e.disabled,
            o = e.excluded,
            a = n.isInitialized,
            r = t.target;
          return !(!(a && !i && r) || H(r, o));
        },
        G = function (n) {
          var t = n.setup.pinch.disabled,
            e = n.isInitialized,
            i = n.pinchStartDistance;
          return !!e && !t && !!i;
        },
        J = function (n, t, e) {
          var i = e.getBoundingClientRect(),
            a = n.touches,
            r = o(a[0].clientX - i.left, 5),
            s = o(a[0].clientY - i.top, 5);
          return {
            x: (r + o(a[1].clientX - i.left, 5)) / 2 / t,
            y: (s + o(a[1].clientY - i.top, 5)) / 2 / t,
          };
        },
        nn = function (n) {
          return Math.sqrt(
            Math.pow(n.touches[0].pageX - n.touches[1].pageX, 2) +
              Math.pow(n.touches[0].pageY - n.touches[1].pageY, 2)
          );
        },
        nt = function (n, t) {
          var e = n.pinchStartScale,
            i = n.pinchStartDistance,
            a = n.setup,
            r = a.maxScale,
            s = a.minScale,
            l = a.zoomAnimation,
            u = a.disablePadding,
            c = l.size,
            p = l.disabled;
          if (!e || null === i || !t)
            throw Error("Pinch touches distance was not provided");
          return t < 0
            ? n.transformState.scale
            : g(o((t / i) * e, 2), s, r, c, !p && !u);
        },
        ne = function (n, t) {
          var e = n.props,
            i = e.onWheelStart,
            o = e.onZoomStart;
          n.wheelStopEventTimer || (l(n), a(R(n), t, i), a(R(n), t, o));
        },
        ni = function (n, t) {
          var e,
            i = n.props,
            o = i.onWheel,
            r = i.onZoom,
            s = n.contentComponent,
            l = n.setup,
            u = n.transformState.scale,
            c = l.limitToBounds,
            p = l.centerZoomedOut,
            m = l.zoomAnimation,
            d = l.wheel,
            v = l.disablePadding,
            g = l.smooth,
            S = m.size,
            y = m.disabled,
            w = d.step,
            b = d.smoothStep;
          if (!s) throw Error("Component not mounted");
          t.preventDefault(), t.stopPropagation();
          var C = U(
            n,
            (e = t ? (t.deltaY < 0 ? 1 : -1) : 0),
            g ? b * Math.abs(t.deltaY) : w,
            !t.ctrlKey
          );
          if (u !== C) {
            var P = f(n, C),
              T = q(t, s, u),
              x = h(n, T.x, T.y, C, P, c && (y || 0 === S || p || v)),
              Y = x.x,
              E = x.y;
            (n.previousWheelEvent = t),
              n.setTransformState(C, Y, E),
              a(R(n), t, o),
              a(R(n), t, r);
          }
        },
        no = function (n, t) {
          var e = n.props,
            i = e.onWheelStop,
            o = e.onZoomStop;
          F(n.wheelAnimationTimer),
            (n.wheelAnimationTimer = setTimeout(function () {
              n.mounted && (z(n, t.x, t.y), (n.wheelAnimationTimer = null));
            }, 100)),
            V(n, t) &&
              (F(n.wheelStopEventTimer),
              (n.wheelStopEventTimer = setTimeout(function () {
                n.mounted &&
                  ((n.wheelStopEventTimer = null),
                  a(R(n), t, i),
                  a(R(n), t, o));
              }, 160)));
        },
        na = function (n, t) {
          var e = nn(t);
          (n.pinchStartDistance = e),
            (n.lastDistance = e),
            (n.pinchStartScale = n.transformState.scale),
            (n.isPanning = !1),
            l(n);
        },
        nr = function (n, t) {
          var e = n.contentComponent,
            i = n.pinchStartDistance,
            o = n.transformState.scale,
            a = n.setup,
            r = a.limitToBounds,
            s = a.centerZoomedOut,
            l = a.zoomAnimation,
            u = l.disabled,
            c = l.size;
          if (null !== i && e) {
            var p = J(t, o, e);
            if (Number.isFinite(p.x) && Number.isFinite(p.y)) {
              var m = nn(t),
                d = nt(n, m);
              if (d !== o) {
                var v = f(n, d),
                  g = h(n, p.x, p.y, d, v, r && (u || 0 === c || s)),
                  S = g.x,
                  y = g.y;
                (n.pinchMidpoint = p),
                  (n.lastDistance = m),
                  n.setTransformState(d, S, y);
              }
            }
          }
        },
        ns = function (n) {
          var t = n.pinchMidpoint;
          (n.velocity = null),
            (n.lastDistance = null),
            (n.pinchMidpoint = null),
            (n.pinchStartScale = null),
            (n.pinchStartDistance = null),
            z(n, null == t ? void 0 : t.x, null == t ? void 0 : t.y);
        },
        nl = function (n, t) {
          var e = n.props.onZoomStop,
            i = n.setup.doubleClick.animationTime;
          F(n.doubleClickStopEventTimer),
            (n.doubleClickStopEventTimer = setTimeout(function () {
              (n.doubleClickStopEventTimer = null), a(R(n), t, e);
            }, i));
        },
        nu = function (n, t) {
          var e = n.props,
            i = e.onZoomStart,
            o = e.onZoom,
            r = n.setup.doubleClick,
            s = r.animationTime,
            l = r.animationType;
          a(R(n), t, i),
            L(n, s, l, function () {
              return a(R(n), t, o);
            }),
            nl(n, t);
        },
        nc = function (n, t) {
          var e = n.isInitialized,
            i = n.setup,
            o = n.wrapperComponent,
            a = i.doubleClick,
            r = a.disabled,
            s = a.excluded,
            l = t.target,
            u = null == o ? void 0 : o.contains(l);
          return !(!(e && l && u && !r) || H(l, s));
        },
        np = function (n) {
          var t = this;
          (this.mounted = !0),
            (this.onChangeCallbacks = new Set()),
            (this.onInitCallbacks = new Set()),
            (this.wrapperComponent = null),
            (this.contentComponent = null),
            (this.isInitialized = !1),
            (this.bounds = null),
            (this.previousWheelEvent = null),
            (this.wheelStopEventTimer = null),
            (this.wheelAnimationTimer = null),
            (this.isPanning = !1),
            (this.startCoords = null),
            (this.lastTouch = null),
            (this.distance = null),
            (this.lastDistance = null),
            (this.pinchStartDistance = null),
            (this.pinchStartScale = null),
            (this.pinchMidpoint = null),
            (this.doubleClickStopEventTimer = null),
            (this.velocity = null),
            (this.velocityTime = null),
            (this.lastMousePosition = null),
            (this.animate = !1),
            (this.animation = null),
            (this.maxBounds = null),
            (this.pressedKeys = {}),
            (this.mount = function () {
              t.initializeWindowEvents();
            }),
            (this.unmount = function () {
              t.cleanupWindowEvents();
            }),
            (this.update = function (n) {
              f(t, t.transformState.scale), (t.setup = B(n));
            }),
            (this.initializeWindowEvents = function () {
              var n,
                e = Z(),
                i =
                  null === (n = t.wrapperComponent) || void 0 === n
                    ? void 0
                    : n.ownerDocument,
                o = null == i ? void 0 : i.defaultView;
              null == o || o.addEventListener("mousedown", t.onPanningStart, e),
                null == o || o.addEventListener("mousemove", t.onPanning, e),
                null == o || o.addEventListener("mouseup", t.onPanningStop, e),
                null == i ||
                  i.addEventListener("mouseleave", t.clearPanning, e),
                null == o || o.addEventListener("keyup", t.setKeyUnPressed, e),
                null == o || o.addEventListener("keydown", t.setKeyPressed, e);
            }),
            (this.cleanupWindowEvents = function () {
              var n,
                e,
                i = Z(),
                o =
                  null === (n = t.wrapperComponent) || void 0 === n
                    ? void 0
                    : n.ownerDocument,
                a = null == o ? void 0 : o.defaultView;
              null == a ||
                a.removeEventListener("mousedown", t.onPanningStart, i),
                null == a || a.removeEventListener("mousemove", t.onPanning, i),
                null == a ||
                  a.removeEventListener("mouseup", t.onPanningStop, i),
                null == o ||
                  o.removeEventListener("mouseleave", t.clearPanning, i),
                null == a ||
                  a.removeEventListener("keyup", t.setKeyUnPressed, i),
                null == a ||
                  a.removeEventListener("keydown", t.setKeyPressed, i),
                document.removeEventListener("mouseleave", t.clearPanning, i),
                l(t),
                null === (e = t.observer) || void 0 === e || e.disconnect();
            }),
            (this.handleInitializeWrapperEvents = function (n) {
              var e = Z();
              n.addEventListener("wheel", t.onWheelZoom, e),
                n.addEventListener("dblclick", t.onDoubleClick, e),
                n.addEventListener("touchstart", t.onTouchPanningStart, e),
                n.addEventListener("touchmove", t.onTouchPanning, e),
                n.addEventListener("touchend", t.onTouchPanningStop, e);
            }),
            (this.handleInitialize = function (n) {
              var e = t.setup.centerOnInit;
              t.applyTransformation(),
                t.onInitCallbacks.forEach(function (n) {
                  return n(R(t));
                }),
                e &&
                  (t.setCenter(),
                  (t.observer = new ResizeObserver(function () {
                    var n;
                    t.onInitCallbacks.forEach(function (n) {
                      return n(R(t));
                    }),
                      t.setCenter(),
                      null === (n = t.observer) ||
                        void 0 === n ||
                        n.disconnect();
                  })),
                  t.observer.observe(n));
            }),
            (this.onWheelZoom = function (n) {
              !t.setup.disabled &&
                Q(t, n) &&
                t.isPressingKeys(t.setup.wheel.activationKeys) &&
                (ne(t, n), ni(t, n), no(t, n));
            }),
            (this.onPanningStart = function (n) {
              var e = t.setup.disabled,
                i = t.props.onPanningStart;
              !e &&
                S(t, n) &&
                t.isPressingKeys(t.setup.panning.activationKeys) &&
                (0 !== n.button || t.setup.panning.allowLeftClickPan) &&
                (1 !== n.button || t.setup.panning.allowMiddleClickPan) &&
                (2 !== n.button || t.setup.panning.allowRightClickPan) &&
                (n.preventDefault(),
                n.stopPropagation(),
                l(t),
                E(t, n),
                a(R(t), n, i));
            }),
            (this.onPanning = function (n) {
              var e = t.setup.disabled,
                i = t.props.onPanning;
              !e &&
                y(t) &&
                t.isPressingKeys(t.setup.panning.activationKeys) &&
                (n.preventDefault(),
                n.stopPropagation(),
                N(t, n.clientX, n.clientY),
                a(R(t), n, i));
            }),
            (this.onPanningStop = function (n) {
              var e = t.props.onPanningStop;
              t.isPanning &&
                ((function (n) {
                  if (n.isPanning) {
                    var t = n.setup.panning.velocityDisabled,
                      e = n.velocity,
                      i = n.wrapperComponent,
                      o = n.contentComponent;
                    (n.isPanning = !1), (n.animate = !1), (n.animation = null);
                    var a = null == i ? void 0 : i.getBoundingClientRect(),
                      s = null == o ? void 0 : o.getBoundingClientRect(),
                      l = (null == a ? void 0 : a.width) || 0,
                      c = (null == a ? void 0 : a.height) || 0,
                      p = (null == s ? void 0 : s.width) || 0,
                      m = (null == s ? void 0 : s.height) || 0;
                    !t &&
                    e &&
                    (null == e ? void 0 : e.total) > 0.1 &&
                    (l < p || c < m)
                      ? (function (n) {
                          var t,
                            e,
                            i,
                            o,
                            a = n.velocity,
                            s = n.bounds,
                            l = n.setup,
                            c = n.wrapperComponent;
                          if (x(n) && a && s && c) {
                            var p = a.velocityX,
                              m = a.velocityY,
                              d = a.total,
                              f = s.maxPositionX,
                              v = s.minPositionX,
                              h = s.maxPositionY,
                              g = s.minPositionY,
                              S = l.limitToBounds,
                              y = l.alignmentAnimation,
                              w = l.zoomAnimation,
                              b = l.panning,
                              C = b.lockAxisY,
                              T = b.lockAxisX,
                              E = w.animationType,
                              X = y.sizeX,
                              N = y.sizeY,
                              k = y.velocityAlignmentTime,
                              z =
                                ((e = (t = n.setup.velocityAnimation)
                                  .equalToMove),
                                (i = t.animationTime),
                                (o = t.sensitivity),
                                e ? i * d * o : i),
                              W = P(n, X),
                              D = P(n, N),
                              O = (W * c.offsetWidth) / 100,
                              A = (D * c.offsetHeight) / 100,
                              I = f + O,
                              B = v - O,
                              M = h + A,
                              K = g - A,
                              L = n.transformState,
                              _ = new Date().getTime();
                            u(n, E, Math.max(z, k), function (t) {
                              var e = n.transformState,
                                i = e.scale,
                                o = e.positionX,
                                a = e.positionY,
                                s = new Date().getTime() - _,
                                l =
                                  1 -
                                  (0, r[y.animationType])(Math.min(1, s / k)),
                                u = 1 - t,
                                c = o + p * u,
                                d = a + m * u,
                                w = Y(c, L.positionX, o, T, S, v, f, B, I, l),
                                b = Y(d, L.positionY, a, C, S, g, h, K, M, l);
                              (o !== c || a !== d) &&
                                n.setTransformState(i, w, b);
                            });
                          }
                        })(n)
                      : X(n);
                  }
                })(t),
                a(R(t), n, e));
            }),
            (this.onPinchStart = function (n) {
              var e = t.setup.disabled,
                i = t.props,
                o = i.onPinchingStart,
                r = i.onZoomStart;
              !e && $(t, n) && (na(t, n), l(t), a(R(t), n, o), a(R(t), n, r));
            }),
            (this.onPinch = function (n) {
              var e = t.setup.disabled,
                i = t.props,
                o = i.onPinching,
                r = i.onZoom;
              !e &&
                G(t) &&
                (n.preventDefault(),
                n.stopPropagation(),
                nr(t, n),
                a(R(t), n, o),
                a(R(t), n, r));
            }),
            (this.onPinchStop = function (n) {
              var e = t.props,
                i = e.onPinchingStop,
                o = e.onZoomStop;
              t.pinchStartScale && (ns(t), a(R(t), n, i), a(R(t), n, o));
            }),
            (this.onTouchPanningStart = function (n) {
              var e = t.setup.disabled,
                i = t.props.onPanningStart;
              if (!e && S(t, n)) {
                if (
                  t.lastTouch &&
                  +new Date() - t.lastTouch < 200 &&
                  1 === n.touches.length
                )
                  t.onDoubleClick(n);
                else {
                  (t.lastTouch = +new Date()), l(t);
                  var o = n.touches,
                    r = 1 === o.length,
                    s = 2 === o.length;
                  r && (l(t), E(t, n), a(R(t), n, i)), s && t.onPinchStart(n);
                }
              }
            }),
            (this.onTouchPanning = function (n) {
              var e = t.setup.disabled,
                i = t.props.onPanning;
              if (t.isPanning && 1 === n.touches.length) {
                if (e || !y(t)) return;
                n.preventDefault(), n.stopPropagation();
                var o = n.touches[0];
                N(t, o.clientX, o.clientY), a(R(t), n, i);
              } else n.touches.length > 1 && t.onPinch(n);
            }),
            (this.onTouchPanningStop = function (n) {
              t.onPanningStop(n), t.onPinchStop(n);
            }),
            (this.onDoubleClick = function (n) {
              !t.setup.disabled &&
                nc(t, n) &&
                (function (n, t) {
                  var e = n.setup,
                    i = n.doubleClickStopEventTimer,
                    o = n.transformState,
                    r = n.contentComponent,
                    s = o.scale,
                    l = n.props,
                    u = l.onZoomStart,
                    p = l.onZoom,
                    m = e.doubleClick,
                    d = m.disabled,
                    f = m.mode,
                    v = m.step,
                    h = m.animationTime,
                    g = m.animationType;
                  if (!d && !i) {
                    if ("reset" === f) return nu(n, t);
                    if (!r) return console.error("No ContentComponent found");
                    var S = M(n, "zoomOut" === f ? -1 : 1, v);
                    if (s !== S) {
                      a(R(n), t, u);
                      var y = q(t, r, s),
                        w = k(n, S, y.x, y.y);
                      if (!w)
                        return console.error(
                          "Error during zoom event. New transformation state was not calculated."
                        );
                      a(R(n), t, p), c(n, w, h, g), nl(n, t);
                    }
                  }
                })(t, n);
            }),
            (this.clearPanning = function (n) {
              t.isPanning && t.onPanningStop(n);
            }),
            (this.setKeyPressed = function (n) {
              t.pressedKeys[n.key] = !0;
            }),
            (this.setKeyUnPressed = function (n) {
              t.pressedKeys[n.key] = !1;
            }),
            (this.isPressingKeys = function (n) {
              return (
                !n.length ||
                Boolean(
                  n.find(function (n) {
                    return t.pressedKeys[n];
                  })
                )
              );
            }),
            (this.setTransformState = function (n, e, i) {
              var o = t.props.onTransformed;
              if (Number.isNaN(n) || Number.isNaN(e) || Number.isNaN(i))
                console.error("Detected NaN set state values");
              else {
                n !== t.transformState.scale &&
                  ((t.transformState.previousScale = t.transformState.scale),
                  (t.transformState.scale = n)),
                  (t.transformState.positionX = e),
                  (t.transformState.positionY = i),
                  t.applyTransformation();
                var r = R(t);
                t.onChangeCallbacks.forEach(function (n) {
                  return n(r);
                }),
                  a(r, { scale: n, positionX: e, positionY: i }, o);
              }
            }),
            (this.setCenter = function () {
              if (t.wrapperComponent && t.contentComponent) {
                var n = j(
                  t.transformState.scale,
                  t.wrapperComponent,
                  t.contentComponent
                );
                t.setTransformState(n.scale, n.positionX, n.positionY);
              }
            }),
            (this.handleTransformStyles = function (n, e, i) {
              return t.props.customTransform
                ? t.props.customTransform(n, e, i)
                : "translate("
                    .concat(n, "px, ")
                    .concat(e, "px) scale(")
                    .concat(i, ")");
            }),
            (this.applyTransformation = function () {
              if (t.mounted && t.contentComponent) {
                var n = t.transformState,
                  e = n.scale,
                  i = n.positionX,
                  o = n.positionY,
                  a = t.handleTransformStyles(i, o, e);
                t.contentComponent.style.transform = a;
              }
            }),
            (this.getContext = function () {
              return R(t);
            }),
            (this.onChange = function (n) {
              return (
                t.onChangeCallbacks.has(n) || t.onChangeCallbacks.add(n),
                function () {
                  t.onChangeCallbacks.delete(n);
                }
              );
            }),
            (this.onInit = function (n) {
              return (
                t.onInitCallbacks.has(n) || t.onInitCallbacks.add(n),
                function () {
                  t.onInitCallbacks.delete(n);
                }
              );
            }),
            (this.init = function (n, e) {
              t.cleanupWindowEvents(),
                (t.wrapperComponent = n),
                (t.contentComponent = e),
                f(t, t.transformState.scale),
                t.handleInitializeWrapperEvents(n),
                t.handleInitialize(e),
                t.initializeWindowEvents(),
                (t.isInitialized = !0),
                a(R(t), void 0, t.props.onInit);
            }),
            (this.props = n),
            (this.setup = B(this.props)),
            (this.transformState = I(this.props));
        },
        nm = i.createContext(null),
        nd = i.forwardRef(function (n, t) {
          var e,
            o,
            a = (0, i.useRef)(new np(n)).current,
            r =
              ((e = n.children), (o = _(a)), "function" == typeof e ? e(o) : e);
          return (
            (0, i.useImperativeHandle)(
              t,
              function () {
                return _(a);
              },
              [a]
            ),
            (0, i.useEffect)(
              function () {
                a.update(n);
              },
              [a, n]
            ),
            i.createElement(nm.Provider, { value: a }, r)
          );
        });
      i.forwardRef(function (n, t) {
        var e,
          o = (0, i.useRef)(null),
          a = (0, i.useContext)(nm);
        return (
          (0, i.useEffect)(
            function () {
              return a.onChange(function (n) {
                o.current &&
                  (o.current.style.transform = a.handleTransformStyles(
                    0,
                    0,
                    1 / n.instance.transformState.scale
                  ));
              });
            },
            [a]
          ),
          i.createElement(
            "div",
            W({}, n, {
              ref:
                ((e = [o, t]),
                function (n) {
                  e.forEach(function (t) {
                    "function" == typeof t
                      ? t(n)
                      : null != t && (t.current = n);
                  });
                }),
            })
          )
        );
      });
      var nf = {
        wrapper: "transform-component-module_wrapper__SPB86",
        content: "transform-component-module_content__FBWxo",
      };
      !(function (n, t) {
        void 0 === t && (t = {});
        var e = t.insertAt;
        if (n && "undefined" != typeof document) {
          var i = document.head || document.getElementsByTagName("head")[0],
            o = document.createElement("style");
          (o.type = "text/css"),
            "top" === e && i.firstChild
              ? i.insertBefore(o, i.firstChild)
              : i.appendChild(o),
            o.styleSheet
              ? (o.styleSheet.cssText = n)
              : o.appendChild(document.createTextNode(n));
        }
      })(
        ".transform-component-module_wrapper__SPB86 {\n  position: relative;\n  width: -moz-fit-content;\n  width: fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  overflow: hidden;\n  -webkit-touch-callout: none; /* iOS Safari */\n  -webkit-user-select: none; /* Safari */\n  -khtml-user-select: none; /* Konqueror HTML */\n  -moz-user-select: none; /* Firefox */\n  -ms-user-select: none; /* Internet Explorer/Edge */\n  user-select: none;\n  margin: 0;\n  padding: 0;\n}\n.transform-component-module_content__FBWxo {\n  display: flex;\n  flex-wrap: wrap;\n  width: -moz-fit-content;\n  width: fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  margin: 0;\n  padding: 0;\n  transform-origin: 0% 0%;\n}\n.transform-component-module_content__FBWxo img {\n  pointer-events: none;\n}\n"
      );
      var nv = function (n) {
        var t = n.children,
          e = n.wrapperClass,
          o = n.contentClass,
          a = n.wrapperStyle,
          r = n.contentStyle,
          s = n.wrapperProps,
          l = n.contentProps,
          u = (0, i.useContext)(nm),
          c = u.init,
          p = u.cleanupWindowEvents,
          m = (0, i.useRef)(null),
          d = (0, i.useRef)(null);
        return (
          (0, i.useEffect)(function () {
            var n = m.current,
              t = d.current;
            return (
              null !== n && null !== t && c && (null == c || c(n, t)),
              function () {
                null == p || p();
              }
            );
          }, []),
          i.createElement(
            "div",
            W({}, void 0 === s ? {} : s, {
              ref: m,
              className: "react-transform-wrapper "
                .concat(nf.wrapper, " ")
                .concat(void 0 === e ? "" : e),
              style: a,
            }),
            i.createElement(
              "div",
              W({}, void 0 === l ? {} : l, {
                ref: d,
                className: "react-transform-component "
                  .concat(nf.content, " ")
                  .concat(void 0 === o ? "" : o),
                style: r,
              }),
              t
            )
          )
        );
      };
    },
  },
]);
