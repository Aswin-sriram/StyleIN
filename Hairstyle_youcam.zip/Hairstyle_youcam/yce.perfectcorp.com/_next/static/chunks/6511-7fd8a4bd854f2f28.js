(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6511],
  {
    79325: function (e, t, n) {
      "use strict";
      var r = n(1955);
      t.Z = (0, r.Z)(function () {
        return Promise.all([n.e(3213), n.e(7374)]).then(n.bind(n, 33213));
      });
    },
    48682: function (e, t, n) {
      "use strict";
      var r = n(27812),
        o = n(50029),
        i = n(87794),
        a = n.n(i),
        u = n(67294),
        s = n(9473),
        c = n(11163),
        l = n(41379),
        p = n(89984),
        d = n(75818),
        f = n(43570),
        m = n(84338),
        h = n(48956),
        y = n(43263);
      t.Z = function (e) {
        var t,
          n,
          i = e.moduleType,
          b = e.sodType,
          _ = void 0 === b ? null : b,
          g = e.cmsFeatureBanner,
          v = (0, s.I0)(),
          x = (0, c.useRouter)(),
          A = (0, m.PC)().locale,
          C = void 0 === A ? "" : A,
          T = p.ZP.getAdjustedModuleType(i),
          j = (0, l.Z)({ moduleType: i, sodType: _ }),
          Z = j.processImageData,
          M = j.goToResultPage,
          k = (0, u.useMemo)(
            function () {
              return x.isReady ? f.Z.transformFeatureBanner(x, g) : null;
            },
            [x.isReady, g]
          );
        return {
          handleModelClick:
            ((t = (0, o.Z)(
              a().mark(function e(t) {
                var n, r;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!d.Z.useDefaultModel(i)) {
                          e.next = 8;
                          break;
                        }
                        return (
                          (n = d.Z.getModelLocale(C, i)),
                          (e.next = 4),
                          v(
                            (0, y.Gh)({
                              type: "model",
                              modelId: t,
                              modelLocale: n,
                              modelUseCase: p.ZP.getUseCaseModel(i),
                            })
                          )
                        );
                      case 4:
                        v((0, h.Bs)({ adujstedModuleType: T, sodType: _ })),
                          M(),
                          (e.next = 13);
                        break;
                      case 8:
                        return (
                          (e.next = 10),
                          fetch(
                            "/assets/images/"
                              .concat(i, "/models/YCE_default_model-")
                              .concat(t, ".jpg")
                          ).then(function (e) {
                            return e.blob();
                          })
                        );
                      case 10:
                        ((r = e.sent).name = "YCE_default_model-".concat(
                          t,
                          ".jpg"
                        )),
                          Z(r, { isModelMode: !0 });
                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
          handleCmsModelClick:
            ((n = (0, o.Z)(
              a().mark(function e(t) {
                var n,
                  o,
                  u,
                  s,
                  c = arguments;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (n = c.length > 1 && void 0 !== c[1] ? c[1] : ""),
                          (e.next = 3),
                          fetch(t, { cache: "no-cache" })
                        );
                      case 3:
                        if (!(o = e.sent).ok) {
                          e.next = 13;
                          break;
                        }
                        return (e.next = 7), o.blob();
                      case 7:
                        if (
                          ((u = e.sent),
                          (s = new File([u], n, { type: u.type })),
                          ![]
                            .concat((0, r.Z)(p.qu), [p.ft.muTransfer])
                            .includes(i))
                        ) {
                          e.next = 12;
                          break;
                        }
                        return (
                          (e.next = 12), v((0, y.Gh)({ skipGuideline: !0 }))
                        );
                      case 12:
                        Z(s, { isModelMode: !0 });
                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return n.apply(this, arguments);
            }),
          featureBannerContent: k,
        };
      };
    },
    43570: function (e, t, n) {
      "use strict";
      var r = n(27812),
        o = n(27361),
        i = n.n(o),
        a = n(18721),
        u = n.n(a),
        s = n(84238),
        c = n.n(s);
      t.Z = {
        sectionCombine: function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = e.cmsFeatureBanner,
            n = e.cmsContent,
            o = e.combineTopBanner,
            a = e.cmsGridModule,
            s = void 0 === a ? null : a,
            l = i()(n, "attributes"),
            p = [];
          c()(t) && ((t.__component = "featureBanner"), p.push(t)),
            void 0 !== o &&
              o &&
              u()(l, "topBanner") &&
              ((l.topBanner.__component = "topBanner"), p.push(l.topBanner)),
            s && ((s.__component = "gridModule"), p.push(s));
          var d = i()(l, "sections", []);
          return p.push.apply(p, (0, r.Z)(d)), p;
        },
        transformFeatureBanner: function (e, t) {
          var n,
            r =
              null == e
                ? void 0
                : null === (n = e.pathname) || void 0 === n
                ? void 0
                : n.replace("/[locale]", ""),
            o = RegExp(/https?:\/\/[^/]+(\/[^?#]*)/),
            a = i()(t, "attributes.cta.link", "").match(o);
          return r === (a ? a[1] : i()(t, "attributes.cta.link"))
            ? null
            : (c()(t) && (t.__component = "featureBanner"), t);
        },
      };
    },
    69039: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          __N_SSG: function () {
            return E;
          },
          default: function () {
            return R;
          },
        });
      var r = n(78614),
        o = n(21319),
        i = n(67294),
        a = n(9473),
        u = n(92792),
        s = n(31127),
        c = n(17268),
        l = n(23354),
        p = n(35218),
        d = n(88139),
        f = n.n(d),
        m = n(11163),
        h = n(97221),
        y = n(45395),
        b = n(49114),
        _ = n(15613),
        g = n(43263),
        v = n(48682),
        x = n(85893);
      function A(e) {
        var t = e.title,
          n = e.desc,
          r = e.buttonText,
          o = e.moduleType,
          u = e.cmsFeatureBanner,
          s = e.cmsUseCaseMenu,
          c = e.productPage,
          l = (0, i.useRef)(null),
          d = (0, m.useRouter)(),
          A = (0, a.I0)(),
          C = (0, a.v9)(function (e) {
            return e.user;
          }),
          T = (0, v.Z)({
            moduleType: o,
            cmsFeatureBanner: u,
          }).featureBannerContent,
          j = (0, i.useCallback)(
            function () {
              return C.checked && !C.userInfo.userId;
            },
            [C]
          ),
          Z = t && n;
        return (0, x.jsxs)(x.Fragment, {
          children: [
            !!T &&
              (0, x.jsx)("div", {
                className: f().featureBannerContainer,
                children: (0, x.jsx)(p.Z, { content: T, productPage: c }),
              }),
            (0, x.jsxs)("div", {
              ref: l,
              className: "".concat(Z ? f().container4AiApi : ""),
              children: [
                (0, x.jsx)("div", {
                  onDragEnter: function (e) {
                    return e.stopPropagation();
                  },
                  children: (0, x.jsx)(h.Z, { cmsUseCaseMenu: s }),
                }),
                Z &&
                  (0, x.jsxs)(x.Fragment, {
                    children: [
                      (0, x.jsx)("div", {
                        className: f().functionContainer4AiApi,
                        children: (0, x.jsxs)("div", {
                          className: f().function,
                          "data-nodes": "function-box",
                          children: [
                            (0, x.jsx)("h1", {
                              className: f().firstTitle,
                              dangerouslySetInnerHTML: {
                                __html: b.Z.sanitize(t, "title"),
                              },
                            }),
                            (0, x.jsx)("h2", {
                              className: f().subtitle,
                              dangerouslySetInnerHTML: {
                                __html: b.Z.sanitize(n, "desc"),
                              },
                            }),
                            (0, x.jsx)(y.Z, {
                              className: "".concat(f().apiButton),
                              hoverClass: "hover-with-border-46e4fa",
                              touchClass: "touch-with-border-46e4fa",
                              onClick: function () {
                                j()
                                  ? A((0, g.eh)(!0))
                                  : _.Z.push(d, "/account/apikey");
                              },
                              children: r,
                            }),
                          ],
                        }),
                      }),
                      (0, x.jsx)("div", {
                        className: f().pictureContainer4AiApi,
                        children: (0, x.jsx)("img", {
                          className: "".concat(f().image4AiApi),
                          src: "/assets/images/aiApi/banner/yce-topbanner-dt.png",
                          loading: "lazy",
                        }),
                      }),
                    ],
                  }),
              ],
            }),
          ],
        });
      }
      var C = n(79325),
        T = n(26927),
        j = n(89984),
        Z = n(57203),
        M = n(66683),
        k = n(27361),
        w = n.n(k),
        B = n(78569),
        O = n(14448);
      function P(e) {
        var t = e.cmsFeatureBanner,
          n = e.cmsUseCaseMenu,
          r = (0, s.Z)({ content: e.cmsContent, type: B.I[j.ft.aiApi] }),
          o = r.cmsContent,
          d = r.isLoaded;
        (0, O.Z)({ content: o, moduleType: B.I[j.ft.aiApi] }).isLoaded;
        var f = (0, u.Z)(),
          m = (0, a.I0)();
        (0, i.useEffect)(function () {
          var e = Z.ZP[j.ft.aiApi];
          m((0, M.YS)(e)), (0, c.z)("functionImpression", { functionType: e });
        }, []);
        var h = (0, i.useCallback)(
            function () {
              return d && o ? w()(o, "attributes.sections") : [];
            },
            [o, d]
          ),
          y = w()(o, "attributes.topBanner", null),
          b = !d || !o;
        return (0, x.jsxs)(l.Z, {
          children: [
            (0, x.jsx)(A, {
              title: w()(y, "title"),
              desc: w()(y, "description"),
              buttonText: w()(y, "buttonText.0.text"),
              moduleType: j.ft.aiApi,
              cmsFeatureBanner: t,
              cmsUseCaseMenu: n,
              productPage: j.ft.aiApi,
            }),
            b
              ? (0, x.jsx)(T.Z, {})
              : h().map(function (e, t) {
                  return (0,
                  x.jsx)("div", { className: "strapiContainer", children: (0, x.jsx)(p.Z, { content: e, width: f, productPage: j.ft.aiApi }) }, "ai-api-strapi-sec".concat(t));
                }),
            !b && (0, x.jsx)(C.Z, {}),
          ],
        });
      }
      var E = !0;
      function R(e) {
        var t = e.publicDomain,
          n = e.cmsContent,
          i = e.cmsFeatureBanner,
          a = e.cmsUseCaseMenu,
          u = e.isReady,
          s = w()(e, "locale", "en-us"),
          c = r.Z.getPageMeta({
            locale: s,
            url: t,
            pathname: "ai-api",
            cmsContent: n,
          });
        return (0, x.jsx)(x.Fragment, {
          children: (0, x.jsx)(o.Z, {
            pageMeta: c,
            isReady: u,
            cmsContent: n,
            children: (0, x.jsx)(P, {
              cmsContent: n,
              cmsFeatureBanner: i,
              cmsUseCaseMenu: a,
            }),
          }),
        });
      }
    },
    88139: function (e) {
      e.exports = {
        "width-sm": "640px",
        "width-md": "768px",
        "width-lg": "1024px",
        "width-xl": "1280px",
        "width-2xl": "1536px",
        container4AiApi: "module-banner-4AiApi_container4AiApi__jnyOM",
        featureBannerContainer:
          "module-banner-4AiApi_featureBannerContainer__nEEvR",
        firstTitle: "module-banner-4AiApi_firstTitle__tkh_g",
        subtitle: "module-banner-4AiApi_subtitle__CV5Ql",
        pictureContainer4AiApi:
          "module-banner-4AiApi_pictureContainer4AiApi__ccHaZ",
        image4AiApi: "module-banner-4AiApi_image4AiApi__aO0vY",
        functionContainer4AiApi:
          "module-banner-4AiApi_functionContainer4AiApi__4X_jF",
        function: "module-banner-4AiApi_function__pRgcz",
        apiButton: "module-banner-4AiApi_apiButton__2TSOv",
      };
    },
    92703: function (e, t, n) {
      "use strict";
      var r = n(50414);
      function o() {}
      function i() {}
      (i.resetWarningCache = o),
        (e.exports = function () {
          function e(e, t, n, o, i, a) {
            if (a !== r) {
              var u = Error(
                "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
              );
              throw ((u.name = "Invariant Violation"), u);
            }
          }
          function t() {
            return e;
          }
          e.isRequired = e;
          var n = {
            array: e,
            bigint: e,
            bool: e,
            func: e,
            number: e,
            object: e,
            string: e,
            symbol: e,
            any: e,
            arrayOf: t,
            element: e,
            elementType: e,
            instanceOf: t,
            node: e,
            objectOf: t,
            oneOf: t,
            oneOfType: t,
            shape: t,
            exact: t,
            checkPropTypes: i,
            resetWarningCache: o,
          };
          return (n.PropTypes = n), n;
        });
    },
    45697: function (e, t, n) {
      e.exports = n(92703)();
    },
    50414: function (e) {
      "use strict";
      e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    },
    68356: function (e, t, n) {
      "use strict";
      var r =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            };
      function o(e, t) {
        if (!(e instanceof t))
          throw TypeError("Cannot call a class as a function");
      }
      function i(e, t) {
        if (!e)
          throw ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t && ("object" == typeof t || "function" == typeof t) ? t : e;
      }
      function a(e, t) {
        if ("function" != typeof t && null !== t)
          throw TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
      var u = n(67294),
        s = n(45697),
        c = [],
        l = [];
      function p(e) {
        var t = e(),
          n = { loading: !0, loaded: null, error: null };
        return (
          (n.promise = t
            .then(function (e) {
              return (n.loading = !1), (n.loaded = e), e;
            })
            .catch(function (e) {
              throw ((n.loading = !1), (n.error = e), e);
            })),
          n
        );
      }
      function d(e) {
        var t = { loading: !1, loaded: {}, error: null },
          n = [];
        try {
          Object.keys(e).forEach(function (r) {
            var o = p(e[r]);
            o.loading
              ? (t.loading = !0)
              : ((t.loaded[r] = o.loaded), (t.error = o.error)),
              n.push(o.promise),
              o.promise
                .then(function (e) {
                  t.loaded[r] = e;
                })
                .catch(function (e) {
                  t.error = e;
                });
          });
        } catch (r) {
          t.error = r;
        }
        return (
          (t.promise = Promise.all(n)
            .then(function (e) {
              return (t.loading = !1), e;
            })
            .catch(function (e) {
              throw ((t.loading = !1), e);
            })),
          t
        );
      }
      function f(e, t) {
        return u.createElement(e && e.__esModule ? e.default : e, t);
      }
      function m(e, t) {
        if (!t.loading)
          throw Error("react-loadable requires a `loading` component");
        var p,
          d,
          m = Object.assign(
            {
              loader: null,
              loading: null,
              delay: 200,
              timeout: null,
              render: f,
              webpack: null,
              modules: null,
            },
            t
          ),
          h = null;
        function y() {
          return h || (h = e(m.loader)), h.promise;
        }
        return (
          c.push(y),
          "function" == typeof m.webpack &&
            l.push(function () {
              var e;
              if (
                ((e = m.webpack),
                "object" === r(n.m) &&
                  e().every(function (e) {
                    return void 0 !== e && void 0 !== n.m[e];
                  }))
              )
                return y();
            }),
          (d = p =
            (function (t) {
              function n(r) {
                o(this, n);
                var a = i(this, t.call(this, r));
                return (
                  (a.retry = function () {
                    a.setState({ error: null, loading: !0, timedOut: !1 }),
                      (h = e(m.loader)),
                      a._loadModule();
                  }),
                  y(),
                  (a.state = {
                    error: h.error,
                    pastDelay: !1,
                    timedOut: !1,
                    loading: h.loading,
                    loaded: h.loaded,
                  }),
                  a
                );
              }
              return (
                a(n, t),
                (n.preload = function () {
                  return y();
                }),
                (n.prototype.componentWillMount = function () {
                  (this._mounted = !0), this._loadModule();
                }),
                (n.prototype._loadModule = function () {
                  var e = this;
                  if (
                    (this.context.loadable &&
                      Array.isArray(m.modules) &&
                      m.modules.forEach(function (t) {
                        e.context.loadable.report(t);
                      }),
                    h.loading)
                  ) {
                    "number" == typeof m.delay &&
                      (0 === m.delay
                        ? this.setState({ pastDelay: !0 })
                        : (this._delay = setTimeout(function () {
                            e.setState({ pastDelay: !0 });
                          }, m.delay))),
                      "number" == typeof m.timeout &&
                        (this._timeout = setTimeout(function () {
                          e.setState({ timedOut: !0 });
                        }, m.timeout));
                    var t = function () {
                      e._mounted &&
                        (e.setState({
                          error: h.error,
                          loaded: h.loaded,
                          loading: h.loading,
                        }),
                        e._clearTimeouts());
                    };
                    h.promise
                      .then(function () {
                        t();
                      })
                      .catch(function (e) {
                        t();
                      });
                  }
                }),
                (n.prototype.componentWillUnmount = function () {
                  (this._mounted = !1), this._clearTimeouts();
                }),
                (n.prototype._clearTimeouts = function () {
                  clearTimeout(this._delay), clearTimeout(this._timeout);
                }),
                (n.prototype.render = function () {
                  return this.state.loading || this.state.error
                    ? u.createElement(m.loading, {
                        isLoading: this.state.loading,
                        pastDelay: this.state.pastDelay,
                        timedOut: this.state.timedOut,
                        error: this.state.error,
                        retry: this.retry,
                      })
                    : this.state.loaded
                    ? m.render(this.state.loaded, this.props)
                    : null;
                }),
                n
              );
            })(u.Component)),
          (p.contextTypes = {
            loadable: s.shape({ report: s.func.isRequired }),
          }),
          d
        );
      }
      function h(e) {
        return m(p, e);
      }
      h.Map = function (e) {
        if ("function" != typeof e.render)
          throw Error(
            "LoadableMap requires a `render(loaded, props)` function"
          );
        return m(d, e);
      };
      var y = (function (e) {
        function t() {
          return o(this, t), i(this, e.apply(this, arguments));
        }
        return (
          a(t, e),
          (t.prototype.getChildContext = function () {
            return { loadable: { report: this.props.report } };
          }),
          (t.prototype.render = function () {
            return u.Children.only(this.props.children);
          }),
          t
        );
      })(u.Component);
      function b(e) {
        for (var t = []; e.length; ) {
          var n = e.pop();
          t.push(n());
        }
        return Promise.all(t).then(function () {
          if (e.length) return b(e);
        });
      }
      (y.propTypes = { report: s.func.isRequired }),
        (y.childContextTypes = {
          loadable: s.shape({ report: s.func.isRequired }).isRequired,
        }),
        (h.Capture = y),
        (h.preloadAll = function () {
          return new Promise(function (e, t) {
            b(c).then(e, t);
          });
        }),
        (h.preloadReady = function () {
          return new Promise(function (e, t) {
            b(l).then(e, e);
          });
        }),
        (e.exports = h);
    },
    36864: function (e, t, n) {
      "use strict";
      function r() {
        return (r =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }).apply(this, arguments);
      }
      n.d(t, {
        Z: function () {
          return r;
        },
      });
    },
  },
]);
